"""Source-only plan, bounded binary parser, and exact comparison. No Torch/CUDA."""
import hashlib
import json
import math
import struct
from pathlib import Path

SDK_SHA = 'b66d70b61b39e1bf0d565aca33bac7c5e21849677396ce5216f5baf73027d37e'
SYMBOL = 'infinity_gte_layer_norm_1024_candle'
SCHEMA = 'gte1024-actual-candle-gold/v1'
PREFIX = 8
GUARD = 0x4F20
ARG_SIZES = [8, 8, 8, 8, 8, 8, 4, 4, 4]
ARG_OFFSETS = [0, 8, 16, 24, 32, 40, 48, 52, 56]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while b := f.read(4 * 1024 * 1024):
            h.update(b)
    return h.hexdigest()


def case_plan():
    result = []
    for rows in [1, 7, 33, 129, 4097]:
        for epsilon in ([1e-12] if rows == 4097 else [1e-12, 1e-5]):
            for pattern in ([2] if rows == 4097 else [0, 1, 2]):
                for residual in ([True] if rows == 4097 else [False, True]):
                    result.append(dict(id=f'c{len(result):03}', rows=rows, width=1024,
                                       epsilon_f32_bits=struct.unpack('<I', struct.pack('<f', epsilon))[0],
                                       pattern=pattern, residual=residual))
    return result


def guarded_words(case, role):
    length = 1024 if role in ['gamma', 'beta'] else case['rows'] * 1024
    values = []
    for i in range(length):
        sign = 0x8000 if (i * 7 + i // 1024) % 3 == 0 else 0
        if role == 'gamma':
            value = sign | (0x3F00 + (i * 19) % 111)
        elif role == 'beta':
            value = sign | (0x3B00 + (i * 13) % 193)
        elif case['pattern'] == 0:
            value = sign | (0x3F00 + (i * 37 + i // 1024 * 13) % 191)
        elif case['pattern'] == 1:
            value = sign | [0x0000, 0x0001, 0x007F, 0x0080, 0x2000, 0x3F80][i % 6]
        else:
            value = sign | (0x3F80 + (i * 31) % 17)
        if role == 'residual':
            if case['pattern'] == 0:
                value = (sign ^ 0x8000) | (0x3B00 + (i * 17) % 127)
            elif case['pattern'] == 1:
                value = (sign ^ 0x8000) | (0x3880 + (i * 23) % 113)
            else:
                value = (value ^ 0x8000) + 1
        values.append(value)
    return [GUARD] * PREFIX + values + [GUARD] * PREFIX


def u16_bytes(words):
    return struct.pack('<%dH' % len(words), *words)


def logical(raw, offset_words, count):
    if not isinstance(offset_words, int) or isinstance(offset_words, bool) or offset_words < 0:
        raise ValueError('Invalid logical offset')
    if not isinstance(count, int) or isinstance(count, bool) or count < 1 or count > 16 * 1024 * 1024:
        raise ValueError('Invalid logical extent')
    end = (offset_words + count) * 2
    if end > len(raw):
        raise ValueError('Logical extent exceeds physical storage')
    return raw[offset_words * 2:end]


def compare(actual, expected):
    if len(actual) != len(expected) or len(actual) % 2:
        raise ValueError('BF16 comparison extent differs')
    mismatch = []
    count = 0
    for i, (a, e) in enumerate(zip(struct.iter_unpack('<H', actual), struct.iter_unpack('<H', expected))):
        if a != e:
            count += 1
            if len(mismatch) < 8:
                mismatch.append(dict(index=i, actual_hex=f'{a[0]:04x}', expected_hex=f'{e[0]:04x}'))
    return dict(words=len(actual) // 2, mismatches=count, first_mismatches=mismatch, exact=count == 0)


def load_gold(root):
    root = Path(root).resolve()
    data = json.loads((root / 'manifest.json').read_text())
    if data.get('schema') != SCHEMA or data.get('synthetic') is not False:
        raise ValueError('Actual Native gold required')
    if data.get('sdk_sha256') != SDK_SHA or data.get('reference') != 'actual_exported_b66_encoder_layer_norm_only_round_false':
        raise ValueError('Native SDK/reference differs')
    proof = data.get('cpu_proof', {})
    here = Path(__file__).resolve().parent
    if (proof.get('status') != 'cpu-linked-loaded' or proof.get('GPU') is not False
        or proof.get('cuda_initialized') is not False or proof.get('sdk_sha256') != SDK_SHA
        or proof.get('torch_version') != '2.14.1+cu130'
        or proof.get('torch_git') != '5c4886908584029761b579af026dcfb627c84070'
        or proof.get('function_owner') != data.get('function_owner')
        or proof.get('bridge_source_sha256') != sha(here / 'native/norm_bridge.cpp')
        or proof.get('contract_sha256') != sha(Path(__file__))
        or proof.get('producer_source_sha256') != sha(here / 'root_native.py')):
        raise ValueError('Actual Native CPU link/source proof differs')
    if data.get('plan') != case_plan() or len(data.get('cases', [])) != len(case_plan()):
        raise ValueError('Exact case plan differs')
    seen = set()
    for case, plan in zip(data['cases'], data['plan']):
        if case['id'] != plan['id'] or case.get('input_immutability') is not True or case.get('three_repeat_exact') is not True:
            raise ValueError('Native case proof differs')
        blobs = case['blobs']
        required = {'input', 'gamma', 'beta', 'expected'} | ({'residual'} if plan['residual'] else set())
        if set(blobs) != required:
            raise ValueError('Native role set differs')
        for role, blob in blobs.items():
            validate_blob(root, role, blob, plan, seen)
    return data


def validate_blob(root, role, blob, plan, seen):
    root = Path(root).resolve()
    relative = Path(blob['file'])
    path = (root / relative).resolve()
    if relative.is_absolute() or '..' in relative.parts or not path.is_relative_to(root) or path in seen:
        raise ValueError('Aliased or escaping payload path')
    seen.add(path)
    if blob['dtype'] != 'bfloat16' or not path.is_file() or path.stat().st_size > 40 * 1024 * 1024 or sha(path) != blob['sha256']:
        raise ValueError('Payload dtype/file/hash differs')
    count = 1024 if role in ['gamma', 'beta'] else plan['rows'] * 1024
    if blob['logical_words'] != count or blob['logical_offset_words'] != (0 if role == 'expected' else PREFIX):
        raise ValueError('Payload logical shape differs')
    raw = path.read_bytes()
    logical(raw, blob['logical_offset_words'], count)
    expected_words = count if role == 'expected' else count + 2 * PREFIX
    if len(raw) != 2 * expected_words:
        raise ValueError('Payload physical extent differs')
    if role != 'expected' and raw != u16_bytes(guarded_words(plan, role)):
        raise ValueError('Native input bytes differ from deterministic source plan')
    if role == 'expected' and any(word[0] & 0x7F80 == 0x7F80 for word in struct.iter_unpack('<H', raw)):
        raise ValueError('Nonfinite actual Native output')
