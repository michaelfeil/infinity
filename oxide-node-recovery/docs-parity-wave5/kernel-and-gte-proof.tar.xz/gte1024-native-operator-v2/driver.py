# Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
# Derived from Root-qualified encoder primitive control; see DRIVER-ORIGIN.json.
import ctypes, json, math
from pathlib import Path
from contract import sha as sha256_file
CUDA_DRIVER = 'libcuda.so.1'
ABI_WITNESS = None
class PacketError(Exception): pass
def _require(value, message):
    if not value: raise PacketError(message)
def cuda_error_name(code): return 'CUDA_ERROR_' + str(code)

def build_kernel_args(kernel: dict, values: dict) -> tuple[object, list, list]:
    ctypes_module = ctypes
    objects = []
    descriptors = []
    for index, arg in enumerate(kernel["args"]):
        name = arg["name"]
        _require(name in values, f"{kernel['symbol']}: missing arg value {name}")
        value = values[name]
        if arg["c_type"] == "ptr":
            if value is None:
                _require(arg.get("nullable") is True,
                         f"{kernel['symbol']}: {name} is not nullable")
                value = 0
            _require(isinstance(value, int) and value >= 0,
                     f"{kernel['symbol']}: bad pointer for {name}")
            obj = ctypes_module.c_uint64(value)
        elif arg["c_type"] == "u32":
            _require(isinstance(value, int) and 0 <= value <= 0xFFFFFFFF,
                     f"{kernel['symbol']}: bad u32 for {name}")
            obj = ctypes_module.c_uint32(value)
        elif arg["c_type"] == "f32":
            _require(isinstance(value, (int, float)) and math.isfinite(float(value)),
                     f"{kernel['symbol']}: bad f32 for {name}")
            obj = ctypes_module.c_float(float(value))
        else:
            raise PacketError(f"{kernel['symbol']}: unsupported c_type {arg['c_type']!r}")
        objects.append(obj)
        descriptors.append({"index": index, "name": name, "param_size": arg["param_size"]})
    array = (ctypes_module.c_void_p * len(objects))(
        *[ctypes_module.cast(ctypes_module.byref(obj), ctypes_module.c_void_p) for obj in objects]
    )
    return array, objects, descriptors


class CudaDriver:
    def __init__(self):
        self.lib = ctypes.CDLL(CUDA_DRIVER)
        self._bind()

    def _bind(self):
        lib = self.lib
        lib.cuInit.argtypes = [ctypes.c_uint]
        lib.cuInit.restype = ctypes.c_int
        lib.cuDeviceGet.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int]
        lib.cuDeviceGet.restype = ctypes.c_int
        lib.cuDevicePrimaryCtxRetain.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_int]
        lib.cuDevicePrimaryCtxRetain.restype = ctypes.c_int
        lib.cuDevicePrimaryCtxRelease.argtypes = [ctypes.c_int]
        lib.cuDevicePrimaryCtxRelease.restype = ctypes.c_int
        lib.cuCtxSetCurrent.argtypes = [ctypes.c_void_p]
        lib.cuCtxSetCurrent.restype = ctypes.c_int
        lib.cuModuleLoadData.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p]
        lib.cuModuleLoadData.restype = ctypes.c_int
        lib.cuModuleGetFunction.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p,
                                            ctypes.c_char_p]
        lib.cuModuleGetFunction.restype = ctypes.c_int
        lib.cuModuleUnload.argtypes = [ctypes.c_void_p]
        lib.cuModuleUnload.restype = ctypes.c_int
        self.param_info = getattr(lib, "cuFuncGetParamInfo", None)
        if self.param_info is not None:
            self.param_info.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
                                        ctypes.POINTER(ctypes.c_size_t),
                                        ctypes.POINTER(ctypes.c_size_t)]
            self.param_info.restype = ctypes.c_int
        lib.cuMemAlloc_v2.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.c_size_t]
        lib.cuMemAlloc_v2.restype = ctypes.c_int
        lib.cuMemFree_v2.argtypes = [ctypes.c_uint64]
        lib.cuMemFree_v2.restype = ctypes.c_int
        lib.cuMemcpyHtoD_v2.argtypes = [ctypes.c_uint64, ctypes.c_void_p, ctypes.c_size_t]
        lib.cuMemcpyHtoD_v2.restype = ctypes.c_int
        lib.cuMemcpyDtoH_v2.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_size_t]
        lib.cuMemcpyDtoH_v2.restype = ctypes.c_int
        lib.cuLaunchKernel.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint,
                                       ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
                                       ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p,
                                       ctypes.c_void_p, ctypes.c_void_p]
        lib.cuLaunchKernel.restype = ctypes.c_int
        lib.cuCtxSynchronize.argtypes = []
        lib.cuCtxSynchronize.restype = ctypes.c_int
        lib.cuGetErrorName.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char_p)]
        lib.cuGetErrorName.restype = ctypes.c_int
        self.context = ctypes.c_void_p()
        self.device = ctypes.c_int()
        self.module = ctypes.c_void_p()

    def check(self, result: int, where: str) -> None:
        if result == 0:
            return
        name = cuda_error_name(result)
        error_name = ctypes.c_char_p()
        if self.lib.cuGetErrorName(result, ctypes.byref(error_name)) == 0 and error_name.value:
            name = error_name.value.decode()
        raise PacketError(f"{where}: {name} ({result})")

    def init(self) -> None:
        self.check(self.lib.cuInit(0), "cuInit")
        self.check(self.lib.cuDeviceGet(ctypes.byref(self.device), 0), "cuDeviceGet")
        self.check(self.lib.cuDevicePrimaryCtxRetain(ctypes.byref(self.context), self.device),
                   "cuDevicePrimaryCtxRetain")
        self.check(self.lib.cuCtxSetCurrent(self.context), "cuCtxSetCurrent")

    def load_module(self, artifact: Path) -> None:
        self.artifact_sha256 = sha256_file(artifact)
        data = artifact.read_bytes()
        if artifact.suffix.lower() in (".ptx", ".ptx.txt"):
            data += b"\x00"
        image = ctypes.create_string_buffer(data, len(data))
        self.check(self.lib.cuModuleLoadData(ctypes.byref(self.module),
                                             ctypes.cast(image, ctypes.c_void_p)),
                   "cuModuleLoadData")

    def function(self, symbol: str):
        func = ctypes.c_void_p()
        self.check(self.lib.cuModuleGetFunction(ctypes.byref(func), self.module,
                                                symbol.encode()),
                   f"cuModuleGetFunction({symbol})")
        return func

    def verify_abi(self, kernel: dict, func) -> dict:
        if self.param_info is None:
            raise PacketError("cuFuncGetParamInfo unavailable; cannot reject ABI mismatch")
        checked = []
        for index, arg in enumerate(kernel["args"]):
            offset = ctypes.c_size_t()
            size = ctypes.c_size_t()
            result = self.param_info(func, index, ctypes.byref(offset), ctypes.byref(size))
            self.check(result, f"{kernel['symbol']} param {index} info")
            if size.value != arg["param_size"]:
                raise PacketError(
                    f"{kernel['symbol']} ABI mismatch at param {index} ({arg['name']}): "
                    f"artifact size {size.value} != manifest {arg['param_size']}")
            checked.append({"index": index, "name": arg["name"], "param_size": size.value,
                            "offset": offset.value})
        witness_path = ABI_WITNESS
        witness = json.loads(witness_path.read_text())
        _require(witness["artifact_sha256"] == self.artifact_sha256,
                 "ABI count witness is for another artifact")
        entries = witness["kernels"][kernel["symbol"]]
        _require(len(entries) == len(kernel["args"]),
                 f"{kernel['symbol']}: artifact has extra or missing kernel parameters")
        for actual, expected in zip(checked, entries):
            _require(actual["index"] == expected["ordinal"]
                     and actual["offset"] == expected["offset"]
                     and actual["param_size"] == expected["size"],
                     "driver ABI differs from frozen ELF metadata")
        return {"symbol": kernel["symbol"], "args": checked, "param_info": True}

    def alloc(self, size: int) -> int:
        pointer = ctypes.c_uint64()
        self.check(self.lib.cuMemAlloc_v2(ctypes.byref(pointer), size), "cuMemAlloc_v2")
        return pointer.value

    def free(self, pointer: int) -> None:
        self.check(self.lib.cuMemFree_v2(ctypes.c_uint64(pointer)), "cuMemFree_v2")

    def hto_d(self, pointer: int, data: bytes) -> None:
        buffer = ctypes.create_string_buffer(data, len(data))
        self.check(self.lib.cuMemcpyHtoD_v2(ctypes.c_uint64(pointer),
                                            ctypes.cast(buffer, ctypes.c_void_p),
                                            len(data)), "cuMemcpyHtoD_v2")

    def dto_h(self, pointer: int, size: int) -> bytes:
        buffer = ctypes.create_string_buffer(size)
        self.check(self.lib.cuMemcpyDtoH_v2(ctypes.cast(buffer, ctypes.c_void_p),
                                            ctypes.c_uint64(pointer), size),
                   "cuMemcpyDtoH_v2")
        return bytes(buffer.raw)

    def launch(self, kernel: dict, func, values: dict) -> None:
        array, keepalive, _ = build_kernel_args(kernel, values)
        grid_x = (int(values["rows"]) + 3) // 4
        block = kernel["block"]
        self.check(self.lib.cuLaunchKernel(
            func, grid_x, 1, 1, block[0], block[1], block[2],
            kernel["dynamic_shared_bytes"], None, ctypes.cast(array, ctypes.c_void_p), None),
            f"cuLaunchKernel({kernel['symbol']})")
        _ = keepalive  # keep ctypes argument storage alive through the launch
        self.check(self.lib.cuCtxSynchronize(), "cuCtxSynchronize")

    def close(self) -> None:
        if self.module:
            self.lib.cuModuleUnload(self.module)
            self.module = ctypes.c_void_p()
        if self.context:
            self.lib.cuDevicePrimaryCtxRelease(self.device.value)
            self.context = ctypes.c_void_p()

