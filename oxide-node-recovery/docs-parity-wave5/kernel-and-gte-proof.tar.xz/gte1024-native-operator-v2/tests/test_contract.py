import copy
import ctypes
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import contract
import consume
import freeze_artifact
import driver


class ContractTests(unittest.TestCase):
    def test_actual_plan_entry_runs_without_torch_or_cuda(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory) / 'plan'
            result = subprocess.run([sys.executable, str(ROOT / 'root_native.py'), '--phase', 'plan', '--output', str(out)], env=dict(os.environ, CUDA_VISIBLE_DEVICES=''), capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads((out / 'plan.json').read_text()), contract.case_plan())
            self.assertEqual(len(contract.case_plan()), 49)
            self.assertNotIn('torch', sys.modules)

    def test_logical_slice_has_actual_nonzero_aligned_prefix_and_rejects_ranges(self):
        plan = contract.case_plan()[0]
        raw = contract.u16_bytes(contract.guarded_words(plan, 'input'))
        self.assertEqual(len(contract.logical(raw, 8, 1024)), 2048)
        self.assertEqual(raw[:16], contract.u16_bytes([contract.GUARD] * 8))
        for offset, count in [(-1, 1024), (8, 0), (8, 2 ** 64), (2 ** 64, 1), (8, 1050)]:
            with self.assertRaises(ValueError):
                contract.logical(raw, offset, count)

    def test_payload_validation_used_path_rejects_alias_dtype_hash_and_shape(self):
        plan = contract.case_plan()[0]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'input.bf16'
            path.write_bytes(contract.u16_bytes(contract.guarded_words(plan, 'input')))
            blob = dict(file='input.bf16', dtype='bfloat16', sha256=contract.sha(path), logical_offset_words=8, logical_words=1024)
            contract.validate_blob(root, 'input', blob, plan, set())
            for key, value in [('dtype', 'float32'), ('sha256', '0' * 64), ('logical_offset_words', 0), ('logical_words', 1023), ('file', '../escape.bf16'), ('file', str(path))]:
                bad = dict(blob, **{key: value})
                with self.assertRaises(ValueError):
                    contract.validate_blob(root, 'input', bad, plan, set())
            seen = set()
            contract.validate_blob(root, 'input', blob, plan, seen)
            with self.assertRaisesRegex(ValueError, 'Aliased'):
                contract.validate_blob(root, 'input', blob, plan, seen)

    def test_exact_word_comparison_rejects_one_ulp_and_signed_zero(self):
        expected = contract.u16_bytes([0x3F80, 0x8000])
        same = contract.compare(expected, expected)
        self.assertTrue(same['exact'])
        changed = contract.compare(contract.u16_bytes([0x3F81, 0]), expected)
        self.assertEqual(changed['mismatches'], 2)
        self.assertEqual(changed['first_mismatches'][0]['actual_hex'], '3f81')

    def test_nullable_pointer_packing_is_the_actual_nine_arg_abi(self):
        values = dict(input=0x100010, residual=None, bias=None, gamma=0x200010, beta=0x300010, out=0x400010, rows=7, width=1024, eps=1e-12)
        array, objects, descriptors = driver.build_kernel_args(consume.KERNEL, values)
        self.assertEqual(len(objects), 9)
        self.assertEqual([d['param_size'] for d in descriptors], contract.ARG_SIZES)
        self.assertEqual([x.value for x in objects[:6]], [0x100010, 0, 0, 0x200010, 0x300010, 0x400010])
        self.assertEqual(objects[6].value, 7)
        self.assertEqual(len(array), 9)

    def test_elf_parser_uses_actual_previously_qualified_nine_arg_section(self):
        source = Path('/tmp/oxide-docs-parity-20261102/encoder-primitives-root-gate-v4-root/reports/root-cubin-elf.txt')
        entries = freeze_artifact.parameters(source.read_text(), 'infinity_deberta_plain_norm_bf16_aten')
        self.assertEqual([(e['ordinal'], e['offset'], e['size']) for e in entries], list(zip(range(9), contract.ARG_OFFSETS, contract.ARG_SIZES)))
        with self.assertRaises(ValueError):
            freeze_artifact.parameters(source.read_text(), 'not_an_actual_export')

    def test_cpu_fixture_cannot_masquerade_as_actual_native_gold(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'manifest.json').write_text(json.dumps(dict(schema=contract.SCHEMA, synthetic=True)))
            with self.assertRaisesRegex(ValueError, 'Actual Native gold required'):
                contract.load_gold(root)
            report = root / 'not-a-qualified-report.json'
            result = subprocess.run([sys.executable, str(ROOT / 'consume.py'), '--gold', str(root), '--check-only', '--output', str(report)],
                                    env=dict(os.environ, CUDA_VISIBLE_DEVICES=''), capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('Actual Native gold required', result.stderr)
            self.assertFalse(report.exists())


if __name__ == '__main__':
    unittest.main()
