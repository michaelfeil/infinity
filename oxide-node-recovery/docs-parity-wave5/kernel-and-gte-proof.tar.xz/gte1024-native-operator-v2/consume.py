#!/usr/bin/env python3
"""Torch-free exact Root GPU consumer; --check-only never loads libcuda."""
import argparse
import ctypes
import json
import os
import struct
from pathlib import Path
import contract
import driver

KERNEL = dict(symbol=contract.SYMBOL, arg_count=9, block=[128, 1, 1], dynamic_shared_bytes=0,
              args=[dict(name=name, c_type=kind, param_size=size, nullable=name in ['residual', 'bias'])
                    for name, kind, size in zip(['input', 'residual', 'bias', 'gamma', 'beta', 'out', 'rows', 'width', 'eps'],
                    ['ptr'] * 6 + ['u32', 'u32', 'f32'], contract.ARG_SIZES)])


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--gold', type=Path, required=True)
    p.add_argument('--artifact', type=Path)
    p.add_argument('--abi-witness', type=Path)
    p.add_argument('--check-only', action='store_true')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists():
        raise ValueError('Fresh report output required')
    gold = contract.load_gold(a.gold)
    if a.check_only:
        a.output.write_text(json.dumps(dict(status='CPU-gold-validated', cases=len(gold['cases']), libcuda_loaded=False), indent=2) + '\n')
        return
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or os.environ.get('INFINITY_GTE1024_ROOT_GPU') != '1':
        raise ValueError('Root exclusive GPU0 lease flag required')
    if not a.artifact or not a.abi_witness:
        raise ValueError('Actual compiled cubin and ELF ABI witness required')
    witness = json.loads(a.abi_witness.read_text())
    if witness['artifact_sha256'] != contract.sha(a.artifact):
        raise ValueError('Actual artifact SHA differs from ABI witness')
    entries = witness['kernels'][contract.SYMBOL]
    if [(e['ordinal'], e['offset'], e['size']) for e in entries] != list(zip(range(9), contract.ARG_OFFSETS, contract.ARG_SIZES)):
        raise ValueError('Exact nine-parameter ELF ABI witness required')
    driver.ABI_WITNESS = a.abi_witness
    cuda = driver.CudaDriver()
    report = dict(status='running', cases=[], reference='actual_b66_Candle_not_ATen', artifact_sha256=contract.sha(a.artifact))
    try:
        cuda.init()
        cuda.load_module(a.artifact)
        fn = cuda.function(contract.SYMBOL)
        report['valid_driver_parameter_queries'] = cuda.verify_abi(KERNEL, fn)
        for plan, case in zip(gold['plan'], gold['cases']):
            allocations = {}
            originals = {}
            primary_error = None
            try:
                pointers = {}
                for role, blob in case['blobs'].items():
                    raw = (a.gold / blob['file']).read_bytes()
                    originals[role] = raw
                    if role == 'expected':
                        continue
                    pointer = cuda.alloc(len(raw))
                    allocations[role] = pointer
                    cuda.hto_d(pointer, raw)
                    pointers[role] = pointer + 2 * blob['logical_offset_words']
                count = plan['rows'] * 1024
                guards = contract.u16_bytes([contract.GUARD] * contract.PREFIX)
                initial = guards + contract.u16_bytes([0x7FC1] * count) + guards
                output = cuda.alloc(len(initial))
                allocations['output'] = output
                epsilon = struct.unpack('<f', struct.pack('<I', plan['epsilon_f32_bits']))[0]
                values = dict(input=pointers['input'], residual=pointers.get('residual'), bias=None,
                              gamma=pointers['gamma'], beta=pointers['beta'], out=output + len(guards),
                              rows=plan['rows'], width=1024, eps=epsilon)
                for repeat in range(3):
                    cuda.hto_d(output, initial)
                    cuda.launch(KERNEL, fn, values)
                    raw = cuda.dto_h(output, len(initial))
                    if raw[:len(guards)] != guards or raw[-len(guards):] != guards:
                        raise ValueError('Actual output canary changed')
                    comparison = contract.compare(raw[len(guards):-len(guards)], originals['expected'])
                    if not comparison['exact']:
                        raise ValueError(json.dumps(dict(case=plan['id'], repeat=repeat, comparison=comparison)))
                    for role, pointer in allocations.items():
                        if role != 'output' and cuda.dto_h(pointer, len(originals[role])) != originals[role]:
                            raise ValueError('Actual input/guard immutability failed: ' + role)
                report['cases'].append(dict(id=plan['id'], words=count, exact=True, repeats=3,
                                           actual_input_and_output_guards=True, input_immutability=True))
            except BaseException as error:
                primary_error = error
                raise
            finally:
                cleanup_errors = []
                for pointer in allocations.values():
                    try:
                        cuda.free(pointer)
                    except BaseException as error:
                        cleanup_errors.append(str(error))
                if cleanup_errors:
                    report.setdefault('cleanup_errors', []).extend(cleanup_errors)
                    if primary_error is None:
                        raise RuntimeError('CUDA allocation cleanup failed: ' + '; '.join(cleanup_errors))
        report['status'] = 'passed'
    except BaseException as error:
        report.update(status='failed', error=str(error))
        raise
    finally:
        cuda.close()
        a.output.write_text(json.dumps(report, indent=2) + '\n')
    print(a.output)


if __name__ == '__main__':
    main()
