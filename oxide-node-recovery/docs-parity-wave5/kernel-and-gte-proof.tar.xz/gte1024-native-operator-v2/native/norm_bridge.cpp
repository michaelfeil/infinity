// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
// Test-only adapter to the existing exported b66 Candle normalization.
#include <ATen/ATen.h>
#include <torch/library.h>
#include <dlfcn.h>
#include <cstdint>
#include <optional>
#include <sstream>

namespace infinity {
at::Tensor encoder_layer_norm_only(const at::Tensor&, const at::Tensor&, double,
                                  const at::Tensor&, const at::Tensor&, bool);
}
namespace {
using Method = at::Tensor (*)(const at::Tensor&, const at::Tensor&, double,
                              const at::Tensor&, const at::Tensor&, bool);
Method method() { return &infinity::encoder_layer_norm_only; }
std::string owner() {
  Dl_info info{};
  TORCH_CHECK(dladdr(reinterpret_cast<void*>(method()), &info) && info.dli_fname,
              "Cannot identify actual Native norm owner");
  return std::string(info.dli_fname);
}
at::Tensor norm(const at::Tensor& x, const at::Tensor& gamma, const at::Tensor& beta,
                const std::optional<at::Tensor>& residual, double epsilon) {
  TORCH_CHECK(x.is_cuda() && x.scalar_type() == at::kBFloat16 && x.is_contiguous() &&
              x.dim() == 2 && x.size(0) > 0 && x.size(1) == 1024,
              "Actual Native reference requires contiguous CUDA BF16 [rows,1024]");
  for (const auto* affine : {&gamma, &beta}) {
    TORCH_CHECK(affine->device() == x.device() && affine->scalar_type() == at::kBFloat16 &&
                affine->is_contiguous() && affine->dim() == 1 && affine->numel() == 1024,
                "Actual Native affine must be same-device contiguous BF16 [1024]");
  }
  if (residual) {
    TORCH_CHECK(residual->device() == x.device() && residual->scalar_type() == at::kBFloat16 &&
                residual->is_contiguous() && residual->sizes() == x.sizes(),
                "Actual Native residual geometry differs");
  }
  // No ATen substitute, no copied CUDA implementation, no rounded residual.
  return method()(x, gamma, epsilon, residual ? *residual : at::Tensor(), beta, false);
}
}
TORCH_LIBRARY(oxide_gte1024_native_control, m) {
  m.def("owner() -> str", &owner);
  m.def("norm(Tensor input, Tensor gamma, Tensor beta, Tensor? residual, float epsilon) -> Tensor", &norm);
}
