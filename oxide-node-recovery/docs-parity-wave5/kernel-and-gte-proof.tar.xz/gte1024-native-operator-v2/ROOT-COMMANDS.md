Root-only sequence is in ROOT-COMMANDS.json as exact argument arrays. No author Torch, Docker, compiler, CUDA context or GPU execution occurred.

1. Stage this source-only packet to the owned SDK container directory; preserve inherited Docker credential/proxy/CA selectors.
2. Run cpu_link_load with CUDA hidden. Require actual Torch2.14.1/5c488 and b66 function dladdr ownership, extension/source hashes, and no Torch CUDA initialization. This CPU native link/load is pending.
3. Under the exclusive GPU0 lease run native_gpu_gold, then copy_gold. This invokes the actual exported encoder_layer_norm_only with round_residual=false; it never substitutes ATen LayerNorm or recompiles Candle.
4. Run consumer_cpu against actual collected49-case gold before any candidate GPU launch. This actual-gold parse is pending.
5. Run candidate_plain with the candidate_environment, then the same49 cases under memcheck and initcheck with fresh output paths; all BF16 words must match, three repeats, real input/output canaries and immutability. Both sanitizer summaries must be zero.

ABI-WITNESS-ROOT160.json was produced on CPU from the actual new Root H100160-export cubin and source-pinned build manifest. It uses ELF KPARAM_INFO plus only valid driver parameter queries; no one-past probe.

The case plan has49 cases /6,284,288 output BF16 words including rows4097, which exercises the Native8-warp launch while the owned kernel retains four independent row warps. There is no trained-model, FP16, other-GPU-runtime or performance qualification claim.
