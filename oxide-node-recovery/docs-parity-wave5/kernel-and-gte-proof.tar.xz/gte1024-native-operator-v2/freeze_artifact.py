#!/usr/bin/env python3
"""CPU-only ELF KPARAM witness. Never calls a CUDA API or probes one-past args."""
import argparse
import json
import re
import subprocess
from pathlib import Path
import contract


def parameters(text, symbol):
    match = re.search(r'^\.nv\.info\.' + re.escape(symbol) + r'\n(.*?)(?=^\S|\Z)', text, re.M | re.S)
    if not match:
        raise ValueError('Actual kernel ELF metadata section absent')
    entries = [dict(ordinal=int(a, 16), offset=int(b, 16), size=int(c, 16))
               for a, b, c in re.findall(r'Ordinal\s*:\s*(0x[0-9a-fA-F]+)\s+Offset\s*:\s*(0x[0-9a-fA-F]+)\s+Size\s*:\s*(0x[0-9a-fA-F]+)', match[1])]
    entries.sort(key=lambda e: e['ordinal'])
    if len({e['ordinal'] for e in entries}) != len(entries):
        raise ValueError('Duplicate parameter ordinal')
    return entries


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--cubin', type=Path, required=True)
    p.add_argument('--bundle-manifest', type=Path, required=True)
    p.add_argument('--cuobjdump', default='/usr/local/cuda-13.1/bin/cuobjdump')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists():
        raise ValueError('Fresh ABI witness path required')
    manifest = json.loads(a.bundle_manifest.read_text())
    leaf = Path(__file__).resolve().parent / 'frozen/gte_norm1024.rs'
    if manifest['sources']['src/gte_norm1024.rs'] != contract.sha(leaf):
        raise ValueError('Device source pin differs from reviewed leaf')
    selected = [x for x in manifest['architectures'] if x['cubin_sha256'] == contract.sha(a.cubin)]
    if len(selected) != 1 or selected[0]['architecture'] != 'sm_90' or contract.SYMBOL not in selected[0]['symbols_verified']:
        raise ValueError('Exact H100 compiled module/source match required')
    text = subprocess.check_output([a.cuobjdump, '--dump-elf', str(a.cubin)], text=True)
    entries = parameters(text, contract.SYMBOL)
    if [(e['ordinal'], e['offset'], e['size']) for e in entries] != list(zip(range(9), contract.ARG_OFFSETS, contract.ARG_SIZES)):
        raise ValueError('Actual ELF kernel ABI differs')
    a.output.write_text(json.dumps(dict(artifact_sha256=contract.sha(a.cubin), bundle_manifest_sha256=contract.sha(a.bundle_manifest),
        kernels={contract.SYMBOL: entries}, source_sha256=contract.sha(leaf), no_onepast_driver_query=True), indent=2) + '\n')


if __name__ == '__main__':
    main()
