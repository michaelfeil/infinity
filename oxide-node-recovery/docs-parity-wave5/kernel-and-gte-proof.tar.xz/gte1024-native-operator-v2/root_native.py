#!/usr/bin/env python3
"""Root SDK entry: CPU C++ adapter link/load, then actual exported CUDA gold.

Only --phase plan is runnable by the author. Torch import and all SDK/device
actions occur inside the two explicitly Root-owned execution phases.
"""
import argparse
import json
import os
import struct
import subprocess
import sys
import sysconfig
from pathlib import Path
from contract import SDK_SHA, SCHEMA, PREFIX, case_plan, guarded_words, u16_bytes, sha

ROOT = Path(__file__).resolve().parent
SDK = Path('/tmp/native214-fa4-mode20/install/lib/libtei_torch.so')
TORCH_GIT = '5c4886908584029761b579af026dcfb627c84070'


def sdk_torch(sdk):
    if sha(sdk) != SDK_SHA:
        raise ValueError('Actual b66 SDK hash required')
    import torch
    if torch.__version__ != '2.14.1+cu130' or torch.version.git_version != TORCH_GIT:
        raise ValueError('Actual SDK Torch identity differs')
    return torch


def owner(torch, sdk):
    path = Path(torch.ops.oxide_gte1024_native_control.owner()).resolve()
    if path != sdk.resolve() or sha(path) != SDK_SHA:
        raise ValueError('Actual Native function dladdr owner differs')
    return str(path)


def cpu(a):
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '':
        raise ValueError('Root CPU compile/load requires CUDA hidden')
    torch = sdk_torch(a.sdk)
    if torch.cuda.is_initialized():
        raise ValueError('CPU adapter phase already initialized CUDA')
    import ctypes
    ctypes.CDLL(str(a.sdk), mode=ctypes.RTLD_GLOBAL)
    from torch.utils.cpp_extension import include_paths, library_paths
    build = a.output / 'build'
    build.mkdir()
    extension = build / 'oxide_gte1024_native_control.so'
    includes = list(include_paths()) + [sysconfig.get_paths()['include']]
    libraries = list(library_paths())
    compiler = os.environ.get('CXX', 'c++')
    command = [compiler, '-std=c++20', '-O2', '-fPIC', '-shared',
               '-D_GLIBCXX_USE_CXX11_ABI=' + str(int(torch._C._GLIBCXX_USE_CXX11_ABI))]
    command += ['-I' + path for path in includes]
    command += [str(ROOT / 'native/norm_bridge.cpp'), '-o', str(extension)]
    command += ['-L' + path for path in libraries]
    command += ['-Wl,-rpath,' + path for path in libraries]
    command += [str(a.sdk), '-ltorch', '-ltorch_cpu', '-ltorch_cuda', '-ltorch_python',
                '-lc10', '-lc10_cuda', '-ldl', '-Wl,-z,now', '-Wl,-rpath,' + str(a.sdk.parent)]
    (a.output / 'compiler-argv.json').write_text(json.dumps(command, indent=2) + '\n')
    compiled = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (a.output / 'compiler-stdout.log').write_text(compiled.stdout)
    (a.output / 'compiler-stderr.log').write_text(compiled.stderr)
    if compiled.returncode:
        print(compiled.stdout, end='')
        print(compiled.stderr, file=sys.stderr, end='')
        raise RuntimeError('Direct C++20 adapter compile/link failed; compiler logs preserved')
    torch.ops.load_library(str(extension))
    if torch.cuda.is_initialized():
        raise ValueError('CPU adapter link/load initialized CUDA')
    proof = dict(status='cpu-linked-loaded', GPU=False, cuda_initialized=False,
                 torch_version=torch.__version__, torch_git=torch.version.git_version,
                 cxx11_abi=bool(torch._C._GLIBCXX_USE_CXX11_ABI), sdk_sha256=SDK_SHA,
                 compiler_argv=command, include_paths=includes, library_paths=libraries,
                 dependency_policy='Direct host C++20 compile/link; no Ninja or NumPy required',
                 function_owner=owner(torch, a.sdk), extension=str(extension), extension_sha256=sha(extension),
                 bridge_source_sha256=sha(ROOT / 'native/norm_bridge.cpp'), contract_sha256=sha(ROOT / 'contract.py'),
                 producer_source_sha256=sha(Path(__file__)))
    (a.output / 'cpu-proof.json').write_text(json.dumps(proof, indent=2) + '\n')


def gpu(a):
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or not a.cpu_proof:
        raise ValueError('Root exclusive GPU0 and actual CPU link proof required')
    proof = json.loads(a.cpu_proof.read_text())
    if (proof.get('status') != 'cpu-linked-loaded' or proof.get('GPU') is not False
        or proof['sdk_sha256'] != SDK_SHA or proof['extension_sha256'] != sha(proof['extension'])
        or proof['bridge_source_sha256'] != sha(ROOT / 'native/norm_bridge.cpp')
        or proof['contract_sha256'] != sha(ROOT / 'contract.py')
        or proof['producer_source_sha256'] != sha(Path(__file__))):
        raise ValueError('Root CPU link proof/source identity changed')
    torch = sdk_torch(a.sdk)
    torch.ops.load_library(proof['extension'])
    function_owner = owner(torch, a.sdk)
    manifest = dict(schema=SCHEMA, synthetic=False, sdk_sha256=SDK_SHA,
                    reference='actual_exported_b66_encoder_layer_norm_only_round_false',
                    function_owner=function_owner, cpu_proof=proof, plan=case_plan(), cases=[])
    for plan in manifest['plan']:
        folder = a.output / plan['id']
        folder.mkdir()
        full, logical, blobs, originals = {}, {}, {}, {}
        roles = ['input', 'gamma', 'beta'] + (['residual'] if plan['residual'] else [])
        for role in roles:
            words = guarded_words(plan, role)
            raw = u16_bytes(words)
            originals[role] = raw
            count = 1024 if role in ['gamma', 'beta'] else plan['rows'] * 1024
            full[role] = torch.tensor(words, dtype=torch.uint16).view(torch.bfloat16).to('cuda:0')
            logical[role] = full[role].narrow(0, PREFIX, count)
            if role not in ['gamma', 'beta']:
                logical[role] = logical[role].reshape(plan['rows'], 1024)
            path = folder / (role + '.bf16')
            path.write_bytes(raw)
            blobs[role] = dict(file=str(path.relative_to(a.output)), dtype='bfloat16', sha256=sha(path),
                               logical_offset_words=PREFIX, logical_words=count)
        epsilon = struct.unpack('<f', struct.pack('<I', plan['epsilon_f32_bits']))[0]
        expected = None
        for repeat in range(3):
            result = torch.ops.oxide_gte1024_native_control.norm(logical['input'], logical['gamma'],
                       logical['beta'], logical.get('residual'), epsilon)
            if result.dtype != torch.bfloat16 or list(result.shape) != [plan['rows'], 1024]:
                raise ValueError('Actual Native output shape/dtype differs')
            raw = u16_bytes(result.contiguous().view(torch.uint16).cpu().reshape(-1).tolist())
            if expected is not None and raw != expected:
                raise ValueError('Actual Native repeats differ')
            expected = raw
        for role in roles:
            raw = u16_bytes(full[role].view(torch.uint16).cpu().reshape(-1).tolist())
            if raw != originals[role]:
                raise ValueError('Actual Native input/guards mutated')
        path = folder / 'expected.bf16'
        path.write_bytes(expected)
        blobs['expected'] = dict(file=str(path.relative_to(a.output)), dtype='bfloat16', sha256=sha(path),
                                 logical_offset_words=0, logical_words=plan['rows'] * 1024)
        manifest['cases'].append(dict(id=plan['id'], blobs=blobs, input_immutability=True, three_repeat_exact=True))
        (a.output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(a.output / 'manifest.json')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--phase', choices=['plan', 'cpu', 'gpu'], required=True)
    p.add_argument('--sdk', type=Path, default=SDK)
    p.add_argument('--cpu-proof', type=Path)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    if a.phase == 'plan':
        (a.output / 'plan.json').write_text(json.dumps(case_plan(), indent=2) + '\n')
    elif a.phase == 'cpu':
        cpu(a)
    else:
        gpu(a)


if __name__ == '__main__':
    main()
