# Gemma3 bench v1

Small Root-only balanced Gemma3 latency packet. Source-only here; no weights,
GPU, Torch, Docker, or release build was executed by the author.

## Default target

Balanced 270m benchmark for B1 T=128, pools `cls` and `mean`:

- 20 warmup + 100 measured submit+complete operations per process.
- One backend per process, ABBA order `oxide, native, native, oxide` per task.
- Oxide host process uses the real `Backend::new_selected(... DType::Bfloat16,
  ModelType::Embedding(pool), BackendKind::Oxide, TorchDevice::Cuda)` factory.
- Native container process uses the verified 19-argument `tei_forward` bridge
  and the pinned b66 SDK.
- Exact zero-tolerance check against `gemma3-runtime-v4/root-native-gold-270m`
  for every warmup and measured output. Outputs are finite and unhidden.
- All 100 measured samples are retained; no fast-sample filtering.
- Native graph flags/budgets are inherited, not forced; the actual environment,
  options, counters, replay/capture observations, and cuBLAS identity are
  recorded.
- GPU0 is protected by `/tmp/oxide-gemma3-bench-gpu0.lock`.
- Container code/fixtures/gold are staged with `docker cp` only. No weights are
  copied and no host bind mount is assumed.
- Inherited host/container runtime/auth/guard environments are preserved; only
  the explicit selectors documented by the controller are overridden. No
  environment dump is written.

## 12B diagnostic

`--model 12b --mode diag` is bounded to the three known first failures:
`b1_t128_last/cls`, `b1_t7_last/mean`, and `b1_t7_last/last-token`. It records
all output vectors plus max/relative error, L2, cosine, and the first failing
stage. It still performs and fails the formal strict zero-tolerance check.
Full 12B performance is unqualified.

## Files

- `bench/`: opt3/noLTO/CGU16 Rust consumer with a light CPU-testable library.
- `native/native_bench_b66.py`: stdlib-only Native b66 benchmark/diagnostic.
- `native/attention_profile_probe.py`: CPU-only profile source audit.
- `native/verified/`, `native/native_gold_b66.py`: byte copies of the frozen V4
  wrappers.
- `fixtures/`: byte copies of the frozen 25 V4 fixtures.
- `control/bench_controller.py`: CPU dry-run, Root staging, ABBA execution,
  validation, and aggregation.
- `control/root_bench.sh`: the single Root entry point.
- `SOURCE-HASHES.json`: packet freeze and V4 provenance.
- `reports/DRYRUN.json`: CPU dry-run evidence.
- `HANDOFF.md`: compact Root handoff.

## Commands

CPU dry-run:

```sh
python3 /tmp/oxide-docs-parity-20261102/gemma3-bench-v1/control/bench_controller.py
```

One exact Root command (one release build + balanced 270m run):

```sh
sudo env BENCH_ROOT_APPROVED=1 bash /tmp/oxide-docs-parity-20261102/gemma3-bench-v1/control/root_bench.sh
```

Optional bounded 12B diagnostic, reusing the same built binary:

```sh
sudo env BENCH_ROOT_APPROVED=1 BENCH_MODEL=12b BENCH_MODE=diag BENCH_SKIP_BUILD=1 \
  bash /tmp/oxide-docs-parity-20261102/gemma3-bench-v1/control/root_bench.sh
```

The 12B diagnostic is expected to exit `2` because the formal strict check
fails; the report contains the full metrics.
