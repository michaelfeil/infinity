#!/usr/bin/env python3
"""Actual b66 Native Gemma3 gold producer (Root-only execution).

Uses the previously verified local Native wrapper modules copied under
``native/verified``: the staged ``tei_create/tei_option/tei_weight/tei_ready/
tei_forward/tei_destroy`` C ABI and its 19-argument ``tei_forward`` layout.
Graph options are never set here: ``native_base.build_options`` reads the
existing production environment and the actual flags/statistics are recorded.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import pathlib
import struct
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
VERIFIED = pathlib.Path(__file__).resolve().parent / "verified"
sys.path.insert(0, str(VERIFIED))
import native_batch as nb  # noqa: E402
import model_checkpoint as mc  # noqa: E402

EXPECTED_SDK_SHA256 = "b66d70b61b39e1bf0d565aca33bac7c5e21849677396ce5216f5baf73027d37e"
POOLS = ("cls", "mean", "last-token")
POOL_CODE = {"cls": 0, "mean": 1, "last-token": 2}
GRAPH_KEYS = ("hits", "misses", "captures", "attempts", "evictions",
              "live_bytes", "admitted_bytes")

def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_json(path: pathlib.Path):
    return json.loads(path.read_text())

def write_json(path: pathlib.Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temp.replace(path)

def fixture_manifest(path: pathlib.Path):
    doc = read_json(path)
    if doc.get("schema") != "oxide-gemma3-unified-fixtures/v1":
        raise RuntimeError("fixture schema differs")
    cases = doc.get("cases")
    if not isinstance(cases, list) or len(cases) != 25:
        raise RuntimeError("fixture manifest must have exactly 25 cases")
    return doc

def load_batch(case, root):
    path = root / case["file"]
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != case["sha256"]:
        raise RuntimeError(f"{case['name']}: fixture sha256 differs")
    batch = json.loads(data)
    ids_sha = hashlib.sha256(json.dumps(batch["input_ids"], separators=(",", ":")).encode()).hexdigest()
    if ids_sha != case["input_ids_sha256"]:
        raise RuntimeError(f"{case['name']}: input_ids sha256 differs")
    return path, batch

def native_config(raw, activation="gelu_pytorch_tanh"):
    cfg = dict(raw)
    cfg["hidden_act"] = raw.get("hidden_activation", activation)
    cfg["layer_norm_eps"] = raw.get("rms_norm_eps", 1e-6)
    cfg["type_vocab_size"] = int(raw.get("type_vocab_size", 1))
    return cfg

def config_preflight(model: pathlib.Path, expected_config_sha: str | None):
    config_path = model / "config.json"
    raw = read_json(config_path)
    config_sha = sha(config_path)
    if expected_config_sha and config_sha != expected_config_sha:
        raise RuntimeError("checkpoint config_sha256 differs from expected")
    if raw.get("model_type") not in ("gemma3_text", "gemma3"):
        raise RuntimeError("not a Gemma3 text config")
    if raw.get("architectures") not in (None, ["Gemma3TextModel"], ["Gemma3ForCausalLM"], ["Gemma3Model"]):
        raise RuntimeError("unexpected Gemma3 architectures")
    hidden = int(raw["hidden_size"])
    if hidden not in (640, 3840, 5376):
        raise RuntimeError(f"unexpected Gemma3 hidden width {hidden}")
    checkpoint = mc.Checkpoint(model)
    counts = {}
    for name, info in checkpoint.tensors.items():
        if info.dtype != "BF16":
            raise RuntimeError(f"{name}: non-BF16 tensor")
        root = "model." if name.startswith("model.") else ""
        if name == root + "embed_tokens.weight":
            counts["embed"] = counts.get("embed", 0) + 1
        elif name == root + "norm.weight":
            counts["norm"] = counts.get("norm", 0) + 1
    if counts.get("embed") != 1 or counts.get("norm") != 1:
        raise RuntimeError(f"ambiguous or missing Gemma3 root: {counts}")
    expected_count = int(raw["num_hidden_layers"]) * 13 + 2
    if len(checkpoint.tensors) != expected_count:
        raise RuntimeError(f"tensor count {len(checkpoint.tensors)} != expected {expected_count}")
    return raw, config_sha, hidden, checkpoint, len(checkpoint.tensors)

def run(args):
    out = pathlib.Path(args.out)
    manifest_path = pathlib.Path(args.cases).resolve()
    manifest = fixture_manifest(manifest_path)
    fixture_root = manifest_path.parent
    model = pathlib.Path(args.model).resolve()
    raw, config_sha, hidden, checkpoint, tensor_count = config_preflight(model, args.expected_config_sha256)
    import native_base
    import native_raw_probe as raw_probe
    library_path = pathlib.Path(args.library).resolve()
    if not library_path.is_file():
        raise RuntimeError(f"missing b66 SDK: {library_path}")
    if sha(library_path) != EXPECTED_SDK_SHA256:
        raise RuntimeError("Native SDK is not the pinned b66 build")
    if os.environ.get("CUDA_VISIBLE_DEVICES") in (None, "", "-1"):
        raise RuntimeError("Root must explicitly select CUDA_VISIBLE_DEVICES")
    capi = pathlib.Path(args.capi_cpp).resolve()
    abi = nb.check_forward_abi((capi / "bridge.h").read_text())
    library = native_base.bind_library(library_path)
    if len(library.tei_forward.argtypes) != 19:
        raise RuntimeError("verified Native wrapper is not the 19-argument tei_forward ABI")
    options = native_base.build_options(raw, "last-token")
    if args.max_isolation_threads == 0:
        raise ValueError("--max-isolation-threads must be positive")
    import torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(args.max_isolation_threads)
    native_config_values = native_config(raw)
    handle = None
    status = {
        "schema": "oxide-gemma3-native-gold/v1",
        "status": "running",
        "model": str(model),
        "config_sha256": config_sha,
        "hidden_size": hidden,
        "tensor_count": tensor_count,
        "fixture_manifest": str(manifest_path),
        "fixture_manifest_sha256": sha(manifest_path),
        "library": {"path": str(library_path), "sha256": sha(library_path), "pinned": EXPECTED_SDK_SHA256},
        "capi_bridge": {"path": str(capi / "bridge.h"), "sha256": sha(capi / "bridge.h"), "abi": abi},
        "graph_environment": {k: os.environ.get(k) for k in (
            "INFINITY_TORCH_CUDA_GRAPHS", "INFINITY_TORCH_CUDA_GRAPH_MAX_TOKENS",
            "INFINITY_TORCH_CUDA_GRAPH_ENTRIES", "INFINITY_TORCH_CUDA_GRAPH_REUSE",
            "INFINITY_TORCH_CUDA_GRAPH_MAX_BYTES", "INFINITY_TORCH_CUDA_GRAPH_MAX_CAPTURES")},
        "graph_options": {k: v for k, v in options.items() if k.startswith("_cuda_graph")},
        "acceptance": {"atol": args.atol, "rtol": args.rtol},
        "pools": list(args.pools),
        "repeat": args.repeat,
        "cases": [],
        "failures": [],
        "cuda_initialized": False,
        "engine_created": False,
    }
    write_json(out / "native-gold.json", status)
    try:
        handle = native_base.create_engine(library, native_config_values, options, f"cuda:{args.device}", 2, True)
        status["engine_created"] = True
        native_base.upload_weights(library, handle, checkpoint)
        native_base.check_status(library, library.tei_ready(handle), "tei_ready")
        out_width = int(library.tei_output_width(handle))
        pooled_width = int(library.tei_pooled_width(handle))
        if out_width != hidden or pooled_width != hidden:
            raise RuntimeError(f"native widths {out_width}/{pooled_width} != {hidden}")
        status["runtime_widths"] = {"output": out_width, "pooled": pooled_width}
        status["cuda_initialized"] = True
        # Preserve actual graph counters for the whole run and per case.
        for case in manifest["cases"]:
            if not case["valid"]:
                status["cases"].append({
                    "name": case["name"], "valid": False,
                    "expected_error_variant": case.get("expected_error_variant"),
                    "fixture_sha256": case["sha256"],
                    "input_ids_sha256": case["input_ids_sha256"],
                    "pools": {},
                })
                write_json(out / "native-gold.json", status)
                continue
            case_path, batch = load_batch(case, fixture_root)
            verified = nb.validate_batch(batch)
            layout = nb.physical_layout(verified, hidden)
            record = {
                "name": case["name"], "valid": True,
                "fixture_file": case["file"],
                "fixture_path": str(case_path),
                "fixture_sha256": case["sha256"],
                "input_ids_sha256": case["input_ids_sha256"],
                "token_count": len(batch["input_ids"]),
                "sequence_count": len(batch["cumulative_seq_lengths"]) - 1,
                "pools": {},
            }
            for pool in args.pools:
                records, outputs, facts, flat, result_index = raw_probe.run_physical_calls(
                    library, handle, verified, layout, POOL_CODE[pool], args.repeat)
                if not all(item["bit_identical_to_first"] for item in records):
                    raise RuntimeError(f"{case['name']}/{pool}: repeated Native output bits differ")
                if any(not math.isfinite(value) for item in outputs for value in item["values"]):
                    raise RuntimeError(f"{case['name']}/{pool}: nonfinite Native output")
                values = []
                entries = []
                offset = 0
                for item in outputs:
                    count = 1
                    for dim in item["shape"]:
                        count *= dim
                    values.extend(item["values"])
                    bin_name = f"{case['name']}.{pool}.{item['index']}.{item['kind']}.f32"
                    payload = struct.pack("<%df" % len(item["values"]), *item["values"])
                    (out / bin_name).write_bytes(payload)
                    entries.append({
                        "index": item["index"],
                        "kind": item["kind"],
                        "shape": item["shape"],
                        "values_file": bin_name,
                        "sha256": hashlib.sha256(payload).hexdigest(),
                        "elements": len(item["values"]),
                    })
                    offset += len(item["values"])
                if offset != len(values):
                    raise RuntimeError("native output flattening differs")
                last = records[-1]
                record["pools"][pool] = {
                    "entries": entries,
                    "physical_float_count": layout["physical_float_count"],
                    "canonical_float_count": len(values),
                    "flat_sha256": hashlib.sha256(flat).hexdigest(),
                    "repeat": args.repeat,
                    "repeat_bit_identity": True,
                    "graph_stats_after": last["graph_stats_after"],
                    "graph_count_after": last["graph_count_after"],
                    "observed_replay": any(item["observed_replay"] for item in records),
                    "observed_capture": any(item["observed_capture"] for item in records),
                    "result_call_index": result_index,
                }
            status["cases"].append(record)
            write_json(out / "native-gold.json", status)
        status["status"] = "ok"
        write_json(out / "native-gold.json", status)
        print(json.dumps({"status": "ok", "model": str(model), "cases": len(status["cases"]),
                          "pools": list(args.pools), "out": str(out)}))
    except BaseException as error:
        status["status"] = "partial-failure"
        status["failures"].append(type(error).__name__ + ": " + str(error))
        write_json(out / "native-gold.json", status)
        raise
    finally:
        if handle is not None:
            library.tei_destroy(handle)
    return 0

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True)
    parser.add_argument("--cases", default=str(ROOT / "fixtures/manifest.json"))
    parser.add_argument("--out", required=True)
    parser.add_argument("--library", default="/tmp/native214-fa4-mode20/install/lib/libtei_torch.so")
    parser.add_argument("--capi-cpp", default="/tmp/infinity-plain-cuda/libs/infinity-v3/backends/libtorch/cpp")
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--pools", default=",".join(POOLS))
    parser.add_argument("--repeat", type=int, default=2)
    parser.add_argument("--atol", type=float, default=0.0)
    parser.add_argument("--rtol", type=float, default=0.0)
    parser.add_argument("--max-isolation-threads", type=int, default=1)
    parser.add_argument("--expected-config-sha256")
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    args.pools = [pool.strip() for pool in args.pools.split(",") if pool.strip()]
    if not args.pools or any(pool not in POOL_CODE for pool in args.pools):
        raise SystemExit("invalid --pools")
    if args.repeat < 1 or args.atol < 0 or args.rtol < 0:
        raise SystemExit("invalid repeat/tolerance")
    if args.preflight_only:
        model = pathlib.Path(args.model).resolve()
        raw, config_sha, hidden, checkpoint, tensor_count = config_preflight(model, args.expected_config_sha256)
        manifest_path = pathlib.Path(args.cases).resolve()
        manifest = fixture_manifest(manifest_path)
        out = pathlib.Path(args.out); out.mkdir(parents=True, exist_ok=True)
        plan = {"schema": "oxide-gemma3-native-gold-preflight/v1", "status": "preflight-ok",
                "model": str(model), "config_sha256": config_sha, "hidden_size": hidden,
                "tensor_count": tensor_count, "fixture_manifest": str(manifest_path),
                "fixture_manifest_sha256": sha(manifest_path), "cases": len(manifest["cases"]),
                "pools": args.pools, "requires_torch_cuda": True,
                "graph_environment": {k: os.environ.get(k) for k in (
                    "INFINITY_TORCH_CUDA_GRAPHS", "INFINITY_TORCH_CUDA_GRAPH_MAX_TOKENS",
                    "INFINITY_TORCH_CUDA_GRAPH_ENTRIES", "INFINITY_TORCH_CUDA_GRAPH_REUSE",
                    "INFINITY_TORCH_CUDA_GRAPH_MAX_BYTES", "INFINITY_TORCH_CUDA_GRAPH_MAX_CAPTURES")},
                "library_container_path": args.library}
        write_json(out / "native-gold-preflight.json", plan)
        print(json.dumps(plan))
        return 0
    try:
        return run(args)
    except Exception as error:
        out = pathlib.Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        target = out / "native-gold.json"
        if not target.is_file():
            write_json(target, {
                "schema": "oxide-gemma3-native-gold/v1",
                "status": "failed-before-engine",
                "model": str(pathlib.Path(args.model).resolve()),
                "failures": [type(error).__name__ + ": " + str(error)],
                "cases": [],
                "pools": args.pools,
                "numeric_claim": False,
            })
        raise

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"native gold producer failed: {error}", file=sys.stderr)
        raise SystemExit(1)
