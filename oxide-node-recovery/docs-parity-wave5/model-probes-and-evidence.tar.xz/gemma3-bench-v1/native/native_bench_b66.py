#!/usr/bin/env python3
"""Bounded Native b66 latency benchmark/diagnostic.

Uses the copied verified 19-argument ``tei_forward`` wrapper and the original
b66 SDK.  Graph options are never set here: ``native_base.build_options``
reads the inherited production environment, and the actual flags/statistics
are recorded.  The script uses only the Python standard library plus the
already-qualified Torch SDK wrappers; it does not import NumPy.

The formal exact check is never relaxed.  ``--mode diag`` records all output
vectors plus max/rel/L2/cosine and the first failing stage, then still exits
non-zero when the strict reference differs.
"""
from __future__ import annotations

import argparse
import ctypes as C
import hashlib
import json
import math
import os
import pathlib
import struct
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
NATIVE = pathlib.Path(__file__).resolve().parent
VERIFIED = NATIVE / "verified"
sys.path.insert(0, str(NATIVE))
sys.path.insert(0, str(VERIFIED))
import native_gold_b66 as goldmod  # noqa: E402
import native_batch as nb  # noqa: E402

EXPECTED_SDK_SHA256 = "b66d70b61b39e1bf0d565aca33bac7c5e21849677396ce5216f5baf73027d37e"
POOL_CODES = {"cls": 0, "mean": 1, "last-token": 2}
GRAPH_KEYS = ("hits", "misses", "captures", "attempts", "evictions",
              "live_bytes", "admitted_bytes")
SCHEMA = "oxide-gemma3-latency-bench/v1"
QUIET_NAN = struct.pack("<I", 0x7FC00000)


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with pathlib.Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: pathlib.Path):
    return json.loads(pathlib.Path(path).read_text())


def write_json_atomic(path: pathlib.Path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temp.replace(path)


def file_identity(path: pathlib.Path):
    path = pathlib.Path(path)
    if not path.is_file():
        return {"path": str(path), "exists": False}
    resolved = path.resolve()
    return {
        "path": str(path),
        "resolved": str(resolved),
        "exists": True,
        "size": resolved.stat().st_size,
        "sha256": sha(resolved),
    }


def nearest_rank(sorted_values, fraction):
    rank = int(math.ceil(fraction * len(sorted_values)))
    rank = min(max(rank, 1), len(sorted_values))
    return sorted_values[rank - 1]


def stats(samples_ns):
    if not samples_ns:
        raise RuntimeError("cannot aggregate zero samples")
    ordered = sorted(samples_ns)
    count = len(ordered)
    total = sum(ordered)
    mean = total / count
    variance = sum((value - mean) ** 2 for value in ordered) / count
    return {
        "count": count,
        "min_ns": ordered[0],
        "max_ns": ordered[-1],
        "mean_ns": mean,
        "stdev_ns": math.sqrt(variance),
        "p50_ns": nearest_rank(ordered, 0.50),
        "p90_ns": nearest_rank(ordered, 0.90),
        "p99_ns": nearest_rank(ordered, 0.99),
        "sum_ns": total,
    }


def env_names_digest():
    names = sorted(os.environ)
    return len(names), hashlib.sha256("\n".join(names).encode()).hexdigest()


def graph_environment():
    return {key: os.environ.get(key) for key in (
        "INFINITY_TORCH_CUDA_GRAPHS",
        "INFINITY_TORCH_CUDA_GRAPH_MAX_TOKENS",
        "INFINITY_TORCH_CUDA_GRAPH_ENTRIES",
        "INFINITY_TORCH_CUDA_GRAPH_REUSE",
        "INFINITY_TORCH_CUDA_GRAPH_MAX_BYTES",
        "INFINITY_TORCH_CUDA_GRAPH_MAX_CAPTURES",
    )}


def graph_options(options):
    return {key: value for key, value in options.items()
            if key.startswith("_cuda_graph") or key == "_media_cuda_graphs"}


def inherited_env():
    count, digest = env_names_digest()
    return {
        "key_count": count,
        "keys_sha256": digest,
        "selectors": {
            "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "INFINITY_BENCH_REQUIRE_HOST_VENDOR": os.environ.get("INFINITY_BENCH_REQUIRE_HOST_VENDOR"),
            "INFINITY_TORCH_CUDA_GRAPHS": os.environ.get("INFINITY_TORCH_CUDA_GRAPHS"),
        },
        "note": "Only names are digested; values are limited to explicit selectors and vendor identity.",
    }


def cublas_preload_identity():
    preload = os.environ.get("LD_PRELOAD") or ""
    entries = []
    for entry in preload.split(":"):
        if entry:
            entries.append(file_identity(pathlib.Path(entry)))
    return {
        "ld_preload": os.environ.get("LD_PRELOAD"),
        "ld_library_path": os.environ.get("LD_LIBRARY_PATH"),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "entries": entries,
        "cublas_130200_preload": any(
            "/tmp/oxide-host-cublas-130200/" in entry for entry in preload.split(":") if entry),
    }


def source_record(model, config_sha, manifest_path, case, hidden, library):
    bridge = pathlib.Path("/tmp/gemma3-native-stage-v4/cpp/bridge.h")
    staged_bridge = NATIVE / "verified/bridge.h"
    return {
        "script": file_identity(pathlib.Path(__file__)),
        "native_gold_b66": file_identity(NATIVE / "native_gold_b66.py"),
        "native_batch": file_identity(VERIFIED / "native_batch.py"),
        "native_base": file_identity(VERIFIED / "native_base.py"),
        "native_raw_probe": file_identity(VERIFIED / "native_raw_probe.py"),
        "model_checkpoint": file_identity(VERIFIED / "model_checkpoint.py"),
        "bridge_header": file_identity(staged_bridge),
        "container_bridge_path": str(bridge),
        "model": str(model),
        "config_sha256": config_sha,
        "hidden_size": hidden,
        "fixture_manifest": str(manifest_path),
        "fixture_manifest_sha256": sha(manifest_path),
        "case": case["name"],
        "fixture_sha256": case["sha256"],
        "input_ids_sha256": case["input_ids_sha256"],
        "token_count": case["token_count"],
        "sequence_count": case["sequence_count"],
        "library": file_identity(library),
        "expected_library_sha256": EXPECTED_SDK_SHA256,
        "library_is_pinned_b66": pathlib.Path(library).is_file() and sha(pathlib.Path(library)) == EXPECTED_SDK_SHA256,
        "script_imports_numpy": False,
    }


def load_gold(path, config_sha, hidden, case_name, pool):
    if not path:
        return None
    document = read_json(path)
    if document.get("schema") != "oxide-gemma3-native-gold/v1":
        raise RuntimeError("gold schema differs")
    if document.get("config_sha256") != config_sha:
        raise RuntimeError("gold config_sha256 differs from checkpoint")
    if int(document.get("hidden_size")) != hidden:
        raise RuntimeError("gold hidden width differs")
    case = None
    for candidate in document.get("cases", []):
        if candidate.get("name") == case_name:
            case = candidate
            break
    if case is None:
        raise RuntimeError(f"{case_name}: absent from gold")
    if pool not in case.get("pools", {}):
        raise RuntimeError(f"{case_name}: gold lacks pool {pool}")
    entries = []
    for entry in case["pools"][pool]["entries"]:
        value_path = pathlib.Path(path).parent / entry["values_file"]
        raw = value_path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            raise RuntimeError(f"{value_path}: gold sha256 differs")
        count = 1
        for dim in entry["shape"]:
            count *= int(dim)
        if len(raw) != count * 4:
            raise RuntimeError(f"{value_path}: gold length differs")
        values = list(struct.unpack("<%df" % count, raw))
        if any(not math.isfinite(value) for value in values):
            raise RuntimeError(f"{value_path}: nonfinite gold")
        entries.append({
            "index": int(entry["index"]),
            "kind": entry["kind"],
            "shape": list(entry["shape"]),
            "values": values,
            "raw": raw,
        })
    return entries


def f32_bytes(value):
    return struct.pack("<f", float(value))


def output_sha256(outputs):
    digest = hashlib.sha256()
    for output in outputs:
        digest.update(int(output["index"]).to_bytes(8, "little"))
        kind = output["kind"].encode()
        digest.update(len(kind).to_bytes(8, "little"))
        digest.update(kind)
        digest.update(len(output["shape"]).to_bytes(8, "little"))
        for dim in output["shape"]:
            digest.update(int(dim).to_bytes(8, "little"))
        digest.update(len(output["values"]).to_bytes(8, "little"))
        for value in output["values"]:
            digest.update(f32_bytes(value))
    return digest.hexdigest()


def compare_entry(index, actual, expected):
    actual = actual or {}
    expected = expected or {}
    actual_values = actual.get("values", [])
    expected_values = expected.get("values", [])
    actual_kind = actual.get("kind", "")
    expected_kind = expected.get("kind", "")
    actual_shape = list(actual.get("shape", []))
    expected_shape = list(expected.get("shape", []))
    shape_match = (bool(actual) and actual_kind == expected_kind
                   and actual_shape == expected_shape
                   and len(actual_values) == len(expected_values))
    finite = (bool(actual) and all(math.isfinite(value) for value in actual_values)
              and all(math.isfinite(value) for value in expected_values))
    exact = shape_match and all(
        f32_bytes(a) == f32_bytes(b) for a, b in zip(actual_values, expected_values))
    first_offset = None
    first_actual = None
    first_expected = None
    for offset in range(max(len(actual_values), len(expected_values))):
        same = (offset < len(actual_values) and offset < len(expected_values)
                and f32_bytes(actual_values[offset]) == f32_bytes(expected_values[offset]))
        if not same:
            first_offset = offset
            if offset < len(actual_values) and math.isfinite(actual_values[offset]):
                first_actual = actual_values[offset]
            if offset < len(expected_values) and math.isfinite(expected_values[offset]):
                first_expected = expected_values[offset]
            break
    if not shape_match and first_offset is None:
        first_offset = 0
        if actual_values and math.isfinite(actual_values[0]):
            first_actual = actual_values[0]
        if expected_values and math.isfinite(expected_values[0]):
            first_expected = expected_values[0]
    metrics = {
        "index": index,
        "kind": actual_kind,
        "shape": actual_shape,
        "expected_kind": expected_kind,
        "expected_shape": expected_shape,
        "expected_elements": len(expected_values),
        "finite": finite,
        "shape_match": shape_match,
        "exact": exact,
        "max_abs": None,
        "max_rel": None,
        "l2": None,
        "ref_l2": None,
        "cosine": None,
        "mean_abs": None,
        "rms": None,
        "first_diff_offset": first_offset,
        "first_diff_actual": first_actual,
        "first_diff_expected": first_expected,
    }
    if shape_match and finite and actual_values:
        sq_diff = 0.0
        sq_ref = 0.0
        sq_actual = 0.0
        dot = 0.0
        abs_sum = 0.0
        max_abs = 0.0
        max_rel = 0.0
        for a, b in zip(actual_values, expected_values):
            diff = abs(a - b)
            max_abs = max(max_abs, diff)
            max_rel = max(max_rel, diff if b == 0.0 else diff / abs(b))
            sq_diff += diff * diff
            sq_ref += b * b
            sq_actual += a * a
            dot += a * b
            abs_sum += diff
        count = len(actual_values)
        metrics["max_abs"] = max_abs
        metrics["max_rel"] = max_rel
        metrics["l2"] = math.sqrt(sq_diff)
        metrics["ref_l2"] = math.sqrt(sq_ref)
        denominator = max(math.sqrt(sq_actual) * math.sqrt(sq_ref), sys.float_info.min)
        metrics["cosine"] = max(-1.0, min(1.0, dot / denominator))
        metrics["mean_abs"] = abs_sum / count
        metrics["rms"] = math.sqrt(sq_diff / count)
    return metrics


def compare_outputs(case_name, pool, outputs, expected):
    actual_map = {int(item["index"]): item for item in outputs}
    expected_map = {int(item["index"]): item for item in expected}
    indices = sorted(set(actual_map) | set(expected_map))
    entries = [compare_entry(index, actual_map.get(index), expected_map.get(index))
               for index in indices]
    exact = all(item["exact"] for item in entries)
    finite = all(item["finite"] for item in entries)
    first_stage = None
    for item in entries:
        if not item["exact"]:
            first_stage = (f"case={case_name}/pool={pool}/entry={item['index']}/"
                           f"kind={item['kind']}/offset={item['first_diff_offset']}")
            break
    max_abs = max((item["max_abs"] for item in entries if item["max_abs"] is not None), default=None)
    max_rel = max((item["max_rel"] for item in entries if item["max_rel"] is not None), default=None)
    max_l2 = max((item["l2"] for item in entries if item["l2"] is not None), default=None)
    min_cosine = min((item["cosine"] for item in entries if item["cosine"] is not None), default=None)
    return {
        "case": case_name,
        "pool": pool,
        "entries": entries,
        "exact": exact,
        "finite": finite,
        "compared_values": sum(item["expected_elements"] for item in entries),
        "max_abs": max_abs,
        "max_rel": max_rel,
        "max_l2": max_l2,
        "min_cosine": min_cosine,
        "first_failing_stage": first_stage,
    }


def safe_graph_counts(library, handle):
    try:
        counters = (C.c_uint64 * len(GRAPH_KEYS))()
        status = library.tei_graph_stats(handle, counters, len(GRAPH_KEYS))
        if status != 0:
            detail = library.tei_error()
            text = detail.decode() if detail else ""
            return None, None, f"tei_graph_stats status {status}: {text}"
        values = dict(zip(GRAPH_KEYS, (int(value) for value in counters)))
        return values, int(library.tei_graph_count(handle)), None
    except Exception as error:
        return None, None, f"{type(error).__name__}: {error}"


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["bench", "diag"])
    parser.add_argument("--model", required=True)
    parser.add_argument("--cases", default=str(ROOT / "fixtures/manifest.json"))
    parser.add_argument("--case", default="b1_t128_last")
    parser.add_argument("--pool", required=True, choices=sorted(POOL_CODES))
    parser.add_argument("--gold")
    parser.add_argument("--out", required=True)
    parser.add_argument("--library", default="/tmp/native214-fa4-mode20/install/lib/libtei_torch.so")
    parser.add_argument("--capi-cpp", default=str(NATIVE / "verified"))
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument("--measured", type=int, default=100)
    parser.add_argument("--label", default="270m")
    parser.add_argument("--expected-config-sha256")
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    if args.device != 0:
        parser.error("this bounded packet is GPU0-only")
    if args.warmup <= 0 or args.measured <= 0:
        parser.error("--warmup and --measured must be positive")
    return args


def preflight(args):
    model = pathlib.Path(args.model).resolve()
    manifest_path = pathlib.Path(args.cases).resolve()
    manifest = goldmod.fixture_manifest(manifest_path)
    raw, config_sha, hidden, checkpoint, tensor_count = goldmod.config_preflight(
        model, args.expected_config_sha256)
    case = None
    for candidate in manifest["cases"]:
        if candidate["name"] == args.case:
            case = candidate
            break
    if case is None:
        raise RuntimeError(f"{args.case}: absent from fixtures")
    if not case["valid"]:
        raise RuntimeError(f"{args.case}: fixture is invalid")
    _, batch = goldmod.load_batch(case, manifest_path.parent)
    verified = nb.validate_batch(batch)
    gold = load_gold(pathlib.Path(args.gold) if args.gold else None,
                     config_sha, hidden, args.case, args.pool)
    library = pathlib.Path(args.library).resolve()
    bridge = pathlib.Path(args.capi_cpp) / "bridge.h"
    abi = nb.check_forward_abi(bridge.read_text()) if bridge.is_file() else None
    source = source_record(model, config_sha, manifest_path, case, hidden, library)
    report = {
        "schema": SCHEMA,
        "mode": args.mode,
        "status": "preflight-ok",
        "backend": "native-b66",
        "model": str(model),
        "model_label": args.label,
        "pool": args.pool,
        "case": args.case,
        "config_sha256": config_sha,
        "hidden_size": hidden,
        "tensor_count": tensor_count,
        "fixture_manifest": str(manifest_path),
        "fixture_manifest_sha256": sha(manifest_path),
        "fixture_sha256": case["sha256"],
        "input_ids_sha256": case["input_ids_sha256"],
        "token_count": len(verified["input_ids"]),
        "sequence_count": len(verified["cumulative_seq_lengths"]) - 1,
        "gold": None if gold is None else {
            "path": str(pathlib.Path(args.gold).resolve()),
            "entries": len(gold),
            "compared_values": sum(len(item["values"]) for item in gold),
        },
        "library": file_identity(library),
        "capi_bridge": {"path": str(bridge), "sha256": sha(bridge) if bridge.is_file() else None, "abi": abi},
        "graph": {"environment": graph_environment(), "options": None, "support": None},
        "vendor": cublas_preload_identity(),
        "source": source,
        "inherited_env": inherited_env(),
        "requires_torch_cuda": True,
        "script_imports_numpy": False,
    }
    write_json_atomic(pathlib.Path(args.out), report)
    print(json.dumps({"status": "preflight-ok", "out": args.out}))
    return 0


def run(args):
    model = pathlib.Path(args.model).resolve()
    manifest_path = pathlib.Path(args.cases).resolve()
    manifest = goldmod.fixture_manifest(manifest_path)
    raw, config_sha, hidden, checkpoint, tensor_count = goldmod.config_preflight(
        model, args.expected_config_sha256)
    case = next((candidate for candidate in manifest["cases"]
                 if candidate["name"] == args.case), None)
    if case is None or not case["valid"]:
        raise RuntimeError(f"{args.case}: missing or invalid fixture")
    _, batch = goldmod.load_batch(case, manifest_path.parent)
    verified = nb.validate_batch(batch)
    layout = nb.physical_layout(verified, hidden)
    expected = load_gold(pathlib.Path(args.gold) if args.gold else None,
                         config_sha, hidden, args.case, args.pool)
    library_path = pathlib.Path(args.library).resolve()
    if not library_path.is_file():
        raise RuntimeError(f"missing b66 SDK: {library_path}")
    if sha(library_path) != EXPECTED_SDK_SHA256:
        raise RuntimeError("Native SDK is not the pinned b66 build")
    if os.environ.get("INFINITY_BENCH_REQUIRE_HOST_VENDOR") != "1":
        raise RuntimeError("native controls require INFINITY_BENCH_REQUIRE_HOST_VENDOR=1")
    if os.environ.get("CUDA_VISIBLE_DEVICES") in (None, "", "-1"):
        raise RuntimeError("Root must explicitly select CUDA_VISIBLE_DEVICES")

    import torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    import native_base
    import native_raw_probe as raw_probe

    library = native_base.bind_library(library_path)
    if len(library.tei_forward.argtypes) != 19:
        raise RuntimeError("verified Native wrapper is not the 19-argument tei_forward ABI")
    bridge = pathlib.Path(args.capi_cpp) / "bridge.h"
    abi = nb.check_forward_abi(bridge.read_text())
    options = native_base.build_options(raw, "last-token")
    native_config_values = goldmod.native_config(raw)
    source = source_record(model, config_sha, manifest_path, case, hidden, library_path)
    vendor = native_base.vendor_metadata()
    vendor["cublas_preload"] = cublas_preload_identity()
    handle = None
    status = {
        "schema": SCHEMA,
        "mode": args.mode,
        "status": "running",
        "backend": "native-b66",
        "model": str(model),
        "model_label": args.label,
        "pool": args.pool,
        "case": args.case,
        "dtype": "bfloat16",
        "factory": {
            "route": "native_base.create_engine + tei_forward(19 args)",
            "kind": "native-b66",
            "dtype": "bfloat16",
            "gpu": f"cuda:{args.device}",
        },
        "config_sha256": config_sha,
        "hidden_size": hidden,
        "tensor_count": tensor_count,
        "warmup": args.warmup,
        "measured": args.measured,
        "warmup_ns": [],
        "samples_ns": [],
        "samples": [],
        "reference": {
            "source": "native-gold" if expected is not None else "warm-baseline",
            "path": str(pathlib.Path(args.gold).resolve()) if args.gold else None,
            "acceptance": {"atol": 0.0, "rtol": 0.0},
        },
        "comparison": None,
        "first_failing_stage": None,
        "first_failing_comparison": None,
        "outputs": [],
        "first_outputs": [],
        "finite": False,
        "exact": False,
        "failures": [],
        "library": file_identity(library_path),
        "capi_bridge": {"path": str(bridge), "sha256": sha(bridge), "abi": abi},
        "graph": {
            "environment": graph_environment(),
            "options": graph_options(options),
            "support": None,
            "statistics_after": None,
        },
        "vendor": vendor,
        "source": source,
        "inherited_env": inherited_env(),
        "qualification": {
            "perf_claim": False,
            "strict": True,
            "model_label": args.label,
            "note": "Benchmark samples are reported only after the exact reference check.",
        },
    }
    write_json_atomic(pathlib.Path(args.out), status)
    arrays = raw_probe.build_call_arrays(verified)
    capacity = int(layout["physical_float_count"])
    storage = nb.make_guarded_buffer(capacity)
    backing = (C.c_char * len(storage)).from_buffer(storage)
    output = C.cast(backing, C.POINTER(C.c_float))
    batch_count = len(verified["cumulative_seq_lengths"]) - 1
    pool_code = POOL_CODES[args.pool]
    graph_error = None
    graph_support = True
    warm_baseline = None
    first_outputs = None
    last_outputs = []
    first_failing_comparison = None
    first_failing_stage = None
    strict_ok = True

    def call_once():
        nonlocal graph_error, graph_support
        if capacity:
            storage[:capacity * 4] = QUIET_NAN * capacity
        storage[capacity * 4:] = nb.guard_bytes()
        stats_before, graph_before, error = safe_graph_counts(library, handle)
        if error is not None:
            graph_support = False
            graph_error = graph_error or error
        started = time.perf_counter()
        code = library.tei_forward(
            handle, arrays["ids"], arrays["types"], arrays["positions"],
            arrays["cumulative"], batch_count, verified["max_length"], pool_code,
            arrays["pooled"], len(verified["pooled_indices"]),
            arrays["raw"], len(verified["raw_indices"]),
            output, capacity, None, None, 0, None, 0)
        wall_ns = int((time.perf_counter() - started) * 1_000_000_000)
        if code != 0:
            detail = library.tei_error()
            kind = library.tei_last_error_kind()
            text = detail.decode() if detail else ""
            raise RuntimeError(f"tei_forward failed (status {code}, kind {kind}: {text})")
        stats_after, graph_after, error = safe_graph_counts(library, handle)
        if error is not None:
            graph_support = False
            graph_error = graph_error or error
        nb.check_guards(storage, capacity)
        flat = bytes(storage[:capacity * 4])
        outputs, facts = nb.canonical_outputs(verified, layout, flat)
        return wall_ns, outputs, facts, stats_before, graph_before, stats_after, graph_after

    try:
        handle = native_base.create_engine(
            library, native_config_values, options, f"cuda:{args.device}", 2, True)
        native_base.upload_weights(library, handle, checkpoint)
        native_base.check_status(library, library.tei_ready(handle), "tei_ready")
        out_width = int(library.tei_output_width(handle))
        pooled_width = int(library.tei_pooled_width(handle))
        if out_width != hidden or pooled_width != hidden:
            raise RuntimeError(f"native widths {out_width}/{pooled_width} != {hidden}")
        status["runtime_widths"] = {"output": out_width, "pooled": pooled_width}
        status["cuda_initialized"] = True
        status["engine_created"] = True

        for index in range(args.warmup):
            wall_ns, outputs, facts, stats_before, graph_before, stats_after, graph_after = call_once()
            if expected is None and warm_baseline is None:
                warm_baseline = outputs
            reference = expected if expected is not None else warm_baseline
            comparison = compare_outputs(args.case, args.pool, outputs, reference)
            if not comparison["exact"] or not comparison["finite"]:
                strict_ok = False
                stage = comparison["first_failing_stage"] or "nonfinite output"
                status["failures"].append(f"warmup {index}: {stage}")
                if first_failing_comparison is None:
                    first_failing_stage = comparison["first_failing_stage"]
                    first_failing_comparison = comparison
                if args.mode == "bench":
                    status["status"] = "strict-fail"
                    status["warmup_ns"] = status["warmup_ns"]
                    status["samples_ns"] = status["samples_ns"]
                    status["comparison"] = comparison
                    status["first_failing_stage"] = first_failing_stage
                    status["first_failing_comparison"] = first_failing_comparison
                    status["outputs"] = outputs
                    status["finite"] = comparison["finite"]
                    status["exact"] = comparison["exact"]
                    write_json_atomic(pathlib.Path(args.out), status)
                    raise RuntimeError(stage)
            status["warmup_ns"].append(wall_ns)
            if first_outputs is None:
                first_outputs = outputs
            last_outputs = outputs
            status["comparison"] = comparison
            status["first_failing_stage"] = first_failing_stage
            status["first_failing_comparison"] = first_failing_comparison
            status["outputs"] = last_outputs

        for index in range(args.measured):
            wall_ns, outputs, facts, stats_before, graph_before, stats_after, graph_after = call_once()
            reference = expected if expected is not None else warm_baseline
            comparison = compare_outputs(args.case, args.pool, outputs, reference)
            if not comparison["exact"] or not comparison["finite"]:
                strict_ok = False
                stage = comparison["first_failing_stage"] or "nonfinite output"
                status["failures"].append(f"measured {index}: {stage}")
                if first_failing_comparison is None:
                    first_failing_stage = comparison["first_failing_stage"]
                    first_failing_comparison = comparison
            sample = {
                "index": index,
                "wall_ns": wall_ns,
                "exact": comparison["exact"],
                "finite": comparison["finite"],
                "output_sha256": output_sha256(outputs),
                "max_abs": comparison["max_abs"],
                "max_rel": comparison["max_rel"],
                "l2": comparison["max_l2"],
                "cosine": comparison["min_cosine"],
                "first_failing_stage": comparison["first_failing_stage"],
                "graph_count_before": graph_before,
                "graph_count_after": graph_after,
                "graph_stats_before": stats_before,
                "graph_stats_after": stats_after,
                "observed_replay": bool(
                    stats_before and stats_after and stats_after["hits"] > stats_before["hits"]),
                "observed_capture": bool(
                    (stats_before and stats_after and stats_after["captures"] > stats_before["captures"])
                    or (graph_before is not None and graph_after is not None and graph_after > graph_before)),
            }
            if args.mode == "diag":
                sample["comparison"] = comparison
            status["samples_ns"].append(wall_ns)
            status["samples"].append(sample)
            if first_outputs is None:
                first_outputs = outputs
            last_outputs = outputs
            status["comparison"] = comparison
            status["first_failing_stage"] = first_failing_stage
            status["first_failing_comparison"] = first_failing_comparison
            status["outputs"] = last_outputs
            status["first_outputs"] = first_outputs
            if args.mode == "bench" and not strict_ok:
                status["status"] = "strict-fail"
                status["finite"] = comparison["finite"]
                status["exact"] = comparison["exact"]
                write_json_atomic(pathlib.Path(args.out), status)
                raise RuntimeError(stage)
            if (index + 1) % 10 == 0 or index + 1 == args.measured:
                status["status"] = "running" if strict_ok else "running-strict-fail"
                write_json_atomic(pathlib.Path(args.out), status)

        status["stats_ns"] = stats(status["samples_ns"])
        status["first_outputs"] = first_outputs
        status["outputs"] = last_outputs
        status["finite"] = all(sample["finite"] for sample in status["samples"])
        status["exact"] = all(sample["exact"] for sample in status["samples"]) and strict_ok
        status["graph"] = {
            "environment": graph_environment(),
            "options": graph_options(options),
            "support": graph_support and graph_error is None,
            "error": graph_error,
            "statistics_after": safe_graph_counts(library, handle)[0],
            "graph_count_after": safe_graph_counts(library, handle)[1],
            "observed_replay": any(sample.get("observed_replay") for sample in status["samples"]),
            "observed_capture": any(sample.get("observed_capture") for sample in status["samples"]),
        }
        status["inherited_env"] = inherited_env()
        status["status"] = "ok" if strict_ok else "strict-fail"
        status["qualification"] = {
            "perf_claim": strict_ok and not args.label.startswith("12b"),
            "strict": True,
            "model_label": args.label,
            "note": ("12B performance remains unqualified until strict quality passes."
                     if args.label.startswith("12b")
                     else "Balanced 270m benchmark; exact reference check required."),
        }
        write_json_atomic(pathlib.Path(args.out), status)
        print(json.dumps({
            "status": status["status"],
            "backend": "native-b66",
            "pool": args.pool,
            "case": args.case,
            "p50_ns": status["stats_ns"]["p50_ns"],
            "p90_ns": status["stats_ns"]["p90_ns"],
            "p99_ns": status["stats_ns"]["p99_ns"],
            "out": args.out,
        }))
        return 0 if strict_ok else 2
    except BaseException as error:
        status["status"] = "strict-fail" if strict_ok is False else "error"
        status["failures"].append(f"{type(error).__name__}: {error}")
        try:
            status["vendor"] = native_base.vendor_metadata() if "native_base" in globals() else None
        except Exception:
            pass
        write_json_atomic(pathlib.Path(args.out), status)
        raise
    finally:
        if handle is not None:
            library.tei_destroy(handle)


def main():
    args = parse_args()
    if args.preflight_only:
        return preflight(args)
    return run(args)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"native benchmark failed: {error}", file=sys.stderr)
        raise SystemExit(1)
