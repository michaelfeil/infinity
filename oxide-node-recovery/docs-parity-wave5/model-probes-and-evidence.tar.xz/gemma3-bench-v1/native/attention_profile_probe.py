#!/usr/bin/env python3
"""Bounded CPU-only Native-vs-Oxide attention profile source audit.

This does not load Torch, the CUDA runtime, or a model.  It reads the model
config, the canonical FA4 profile source, the staged FA4 manifest, and the
Native b66 SDK bytes.  Its output is a source hypothesis, not numeric proof.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import re

SCHEMA = "oxide-gemma3-attention-profile-audit/v1"
DEFAULT_PROFILES = pathlib.Path(
    "/tmp/oxide-docs-parity-20261102/gemma3-runtime-v4/repo/libs/infinity-v3/"
    "backends/libtorch/cpp/vendor/infinity_fa4/profiles.inc"
)
DEFAULT_FA4 = pathlib.Path("/tmp/oxide-fa4-canonical38-all3-v2")
DEFAULT_SDK = pathlib.Path("/tmp/h5120-root-recovered-v5/sdk/libtei_torch.so")
FIRST_NATIVE_PROFILES = 20
PROFILE_RE = re.compile(
    r"FA4_PROFILE\(([^,]+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)\)")


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with pathlib.Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: pathlib.Path):
    return json.loads(pathlib.Path(path).read_text())


def write_json(path: pathlib.Path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temp.replace(path)


def parse_profiles(path: pathlib.Path):
    profiles = []
    for line in pathlib.Path(path).read_text().splitlines():
        match = PROFILE_RE.search(line.strip())
        if not match:
            continue
        name, heads, kv_heads, width, causal, local = match.groups()
        profiles.append({
            "mode": len(profiles),
            "name": name.strip(),
            "heads": int(heads),
            "kv_heads": int(kv_heads),
            "ratio": int(heads) // int(kv_heads) if int(kv_heads) else None,
            "head_dim": int(width),
            "causal": bool(int(causal)),
            "local": bool(int(local)),
        })
    return profiles


def model_masks(config):
    layer_types = config.get("layer_types") or []
    counts = {}
    for item in layer_types:
        counts[item] = counts.get(item, 0) + 1
    masks = []
    if counts.get("full_attention") or not counts:
        masks.append({"mask": "global", "local": False,
                      "layers": counts.get("full_attention", len(layer_types) or None)})
    if counts.get("sliding_attention"):
        masks.append({"mask": "local", "local": True,
                      "window": config.get("sliding_window"),
                      "layers": counts["sliding_attention"]})
    return counts, masks


def match_profile(profiles, config, local):
    heads = int(config["num_attention_heads"])
    kv_heads = int(config["num_key_value_heads"])
    width = int(config["head_dim"])
    ratio = heads // kv_heads if kv_heads else None
    causal = not bool(config.get("use_bidirectional_attention", False))
    matches = [profile for profile in profiles
               if profile["ratio"] == ratio and profile["head_dim"] == width
               and profile["causal"] == causal and profile["local"] == local]
    return matches


def fa4_kernels(bundle: pathlib.Path):
    manifest = bundle / "sm_90/manifest.json"
    if not manifest.is_file():
        return {"path": str(manifest), "exists": False, "kernels": []}
    document = read_json(manifest)
    kernels = []
    for kernel in document.get("kernels", []):
        symbol = kernel.get("symbol", "")
        if "gemma3" in symbol:
            kernels.append(kernel)
    return {
        "path": str(manifest),
        "exists": True,
        "manifest_sha256": sha(manifest),
        "registry": document.get("registry"),
        "kernels": kernels,
    }


def scan_sdk(path: pathlib.Path):
    if not path.is_file():
        return {"path": str(path), "exists": False}
    data = path.read_bytes()
    markers = {
        "infinity_fa4_modes": data.count(b"infinity_fa4_modes"),
        "infinity_fa4": data.count(b"infinity_fa4"),
        "tei_torch_flash": data.count(b"tei_torch_flash"),
        "flash_fwd_kernel": data.count(b"flash_fwd_kernel"),
        "gemma3_global_d256_gqa2": data.count(b"gemma3_global_d256_gqa2"),
        "gemma3_local1024_d256_gqa2": data.count(b"gemma3_local1024_d256_gqa2"),
        "causal_wide4": data.count(b"causal_wide4"),
        "gemma3_local512": data.count(b"gemma3_local512"),
    }
    return {
        "path": str(path),
        "exists": True,
        "size": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "markers": markers,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True)
    parser.add_argument("--label", default="")
    parser.add_argument("--profiles-inc", default=str(DEFAULT_PROFILES))
    parser.add_argument("--fa4-bundle", default=str(DEFAULT_FA4))
    parser.add_argument("--sdk", default=str(DEFAULT_SDK))
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    model = pathlib.Path(args.model).resolve()
    config_path = model / "config.json"
    config = read_json(config_path)
    profiles_path = pathlib.Path(args.profiles_inc)
    profiles = parse_profiles(profiles_path)
    counts, masks = model_masks(config)
    required = []
    for mask in masks:
        matches = match_profile(profiles, config, mask["local"])
        required.append({
            **mask,
            "matches": matches,
            "matched_modes": [item["mode"] for item in matches],
            "within_first_20": any(item["mode"] < FIRST_NATIVE_PROFILES for item in matches),
            "outside_first_20": any(item["mode"] >= FIRST_NATIVE_PROFILES for item in matches),
        })
    fallback_possible = any(item["outside_first_20"] for item in required)
    labels = {
        "270m": {
            "expected_source": "Q4/KV1 d256 causal; global config matches mode 18 causal_wide4 through reduced ratio",
            "steering": "270m Q4 KV1 d256 local512 uses an existing mode",
        },
        "12b": {
            "expected_source": "Q16/KV8 d256 causal; global -> mode 34, local1024 -> mode 35",
            "steering": "12B q16 kv8 d256 local1024 global causal uses new FA4 modes 34/35",
        },
    }
    report = {
        "schema": SCHEMA,
        "status": "source-audit-ok",
        "claim": "source-only hypothesis; no numeric qualification and no full 48-layer trace",
        "model": str(model),
        "label": args.label,
        "config_sha256": sha(config_path),
        "hidden_size": config.get("hidden_size"),
        "num_attention_heads": config.get("num_attention_heads"),
        "num_key_value_heads": config.get("num_key_value_heads"),
        "head_dim": config.get("head_dim"),
        "sliding_window": config.get("sliding_window"),
        "use_bidirectional_attention": config.get("use_bidirectional_attention"),
        "layer_type_counts": counts,
        "model_masks": masks,
        "profiles_source": {
            "path": str(profiles_path),
            "sha256": sha(profiles_path),
            "profile_count": len(profiles),
            "first_20": profiles[:FIRST_NATIVE_PROFILES],
            "all_profiles": profiles,
        },
        "required_profiles": required,
        "native_auto_accept_first_20": True,
        "torch_flash_fallback_possible": fallback_possible,
        "native_source_hypothesis": labels.get(args.label, {}),
        "native_sdk": scan_sdk(pathlib.Path(args.sdk)),
        "oxide_fa4": fa4_kernels(pathlib.Path(args.fa4_bundle)),
        "conclusion": {
            "native_12b_profiles_outside_first_20": bool(
                args.label == "12b" and fallback_possible),
            "oxide_12b_modes": [34, 35] if args.label == "12b" else [],
            "likely_divergence": (
                "Native b66 auto-accepts the first 20 FA4 profiles; 12B global/local1024 "
                "modes 34/35 are appended beyond that, so a Torch Flash fallback is possible. "
                "Oxide explicitly uses FA4 modes 34/35. Treat this as a source hypothesis "
                "until the Native provider recipe is proved; do not loosen the formal check."
            ) if args.label == "12b" and fallback_possible else (
                "All source-matched Native profiles are inside the first 20; no fallback "
                "is implied by the profile table for this label."
            ),
        },
    }
    write_json(pathlib.Path(args.out), report)
    print(json.dumps({
        "status": report["status"],
        "label": args.label,
        "required_modes": [item["matched_modes"] for item in required],
        "torch_flash_fallback_possible": fallback_possible,
        "out": args.out,
    }))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
