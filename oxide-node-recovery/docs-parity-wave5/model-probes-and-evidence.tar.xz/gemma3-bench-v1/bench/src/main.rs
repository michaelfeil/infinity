// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Bounded Gemma3 Oxide latency benchmark and strict numeric diagnostic.

use gemma3_latency_bench::*;
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};
use std::time::Instant;

#[cfg(feature = "oxide")]
use infinity_v3_backend::{
    Backend, BackendKind, DType, Embedding, Embeddings, ModelType, Pool, TorchDevice,
};
#[cfg(feature = "oxide")]
use infinity_v3_backend_core::Batch;

const HOST_VENDOR: &str = "/usr/local/cuda-13.1/lib64";
const GRAPH_FREE_EXECUTOR: &str = "oxide graph-free BF16 Gemma3 text executor";

struct Args {
    mode: String,
    model: PathBuf,
    cases: PathBuf,
    case: String,
    pool: String,
    gold: Option<PathBuf>,
    expected_config_sha256: Option<String>,
    warmup: usize,
    measured: usize,
    out: PathBuf,
    preflight_only: bool,
    label: String,
    device: usize,
}

fn usage() -> &'static str {
    "usage: gemma3-latency-bench <bench|diag> --model DIR --pool cls|mean|last-token --out FILE [--cases MANIFEST] [--case NAME] [--gold NATIVE-GOLD.json] [--expected-config-sha256 HEX] [--warmup 20] [--measured 100] [--label 270m] [--device 0] [--preflight-only]"
}

fn parse_args() -> Result<Args, String> {
    let values = std::env::args().collect::<Vec<_>>();
    if values.len() < 2 || values[1].starts_with('-') {
        return Err(usage().into());
    }
    let mode = values[1].clone();
    if !matches!(mode.as_str(), "bench" | "diag") {
        return Err(format!("unknown mode {mode:?}\n{}", usage()));
    }
    let mut seen = BTreeSet::new();
    let mut model = None;
    let mut cases = default_manifest_path();
    let mut case = "b1_t128_last".to_string();
    let mut pool = None;
    let mut gold = None;
    let mut expected = None;
    let mut warmup = DEFAULT_WARMUP;
    let mut measured = DEFAULT_MEASURED;
    let mut out = None;
    let mut preflight_only = false;
    let mut label = "270m".to_string();
    let mut device = 0usize;
    let mut i = 2;
    while i < values.len() {
        let flag = &values[i];
        if !flag.starts_with("--") {
            return Err(format!("unexpected positional {flag:?}"));
        }
        if flag == "--preflight-only" {
            if !seen.insert(flag.clone()) {
                return Err(format!("duplicate argument {flag}"));
            }
            preflight_only = true;
            i += 1;
            continue;
        }
        if !seen.insert(flag.clone()) {
            return Err(format!("duplicate argument {flag}"));
        }
        let value = values.get(i + 1).ok_or_else(|| format!("{flag} requires a value"))?;
        if value.starts_with("--") {
            return Err(format!("{flag} requires a value"));
        }
        match flag.as_str() {
            "--model" => model = Some(PathBuf::from(value)),
            "--cases" => cases = PathBuf::from(value),
            "--case" => case = value.clone(),
            "--pool" => pool = Some(parse_pool(value)?),
            "--gold" => gold = Some(PathBuf::from(value)),
            "--expected-config-sha256" => expected = Some(value.clone()),
            "--warmup" => {
                warmup = value.parse().map_err(|_| format!("invalid --warmup {value:?}"))?;
                if warmup == 0 {
                    return Err("--warmup must be positive".into());
                }
            }
            "--measured" => {
                measured = value.parse().map_err(|_| format!("invalid --measured {value:?}"))?;
                if measured == 0 {
                    return Err("--measured must be positive".into());
                }
            }
            "--out" => out = Some(PathBuf::from(value)),
            "--label" => label = value.clone(),
            "--device" => {
                device = value.parse().map_err(|_| format!("invalid --device {value:?}"))?;
                if device != 0 {
                    return Err("this bounded packet is GPU0-only".into());
                }
            }
            _ => return Err(format!("unknown argument {flag}")),
        }
        i += 2;
    }
    Ok(Args {
        mode,
        model: model.ok_or_else(|| "--model is required".to_string())?,
        cases,
        case,
        pool: pool.ok_or_else(|| "--pool is required".to_string())?,
        gold,
        expected_config_sha256: expected,
        warmup,
        measured,
        out: out.ok_or_else(|| "--out is required".to_string())?,
        preflight_only,
        label,
        device,
    })
}

fn read_config(model: &Path, expected_sha: Option<&str>) -> Result<(Value, String, usize), String> {
    let path = model.join("config.json");
    let bytes = std::fs::read(&path).map_err(|e| format!("read {}: {e}", path.display()))?;
    let config_sha = sha_bytes(&bytes);
    if let Some(expected) = expected_sha {
        if expected != config_sha {
            return Err("checkpoint config_sha256 differs from pinned expected".into());
        }
    }
    let config: Value = serde_json::from_slice(&bytes).map_err(|e| format!("parse config: {e}"))?;
    if config["model_type"] != "gemma3_text" {
        return Err("benchmark requires gemma3_text".into());
    }
    let hidden = config["hidden_size"]
        .as_u64()
        .ok_or_else(|| "missing hidden_size".to_string())? as usize;
    Ok((config, config_sha, hidden))
}

fn bundle_record(path: Option<&Path>, manifest_rel: &str) -> Value {
    let Some(path) = path else {
        return json!({"path": null, "exists": false});
    };
    let manifest_path = path.join(manifest_rel);
    let exists = manifest_path.is_file();
    if !exists {
        return json!({"path": path.display().to_string(), "exists": false, "manifest": manifest_path.display().to_string()});
    }
    let bytes = match std::fs::read(&manifest_path) {
        Ok(bytes) => bytes,
        Err(error) => return json!({"path": path.display().to_string(), "exists": true, "read_error": error.to_string()}),
    };
    let manifest: Value = match serde_json::from_slice(&bytes) {
        Ok(value) => value,
        Err(error) => return json!({"path": path.display().to_string(), "exists": true, "parse_error": error.to_string()}),
    };
    let kernel_count = manifest["kernels"]
        .as_array()
        .map(|items| items.len())
        .or_else(|| manifest["architectures"].as_array().map(|items| items.len()))
        .unwrap_or(0);
    json!({
        "path": path.display().to_string(),
        "exists": true,
        "manifest": manifest_path.display().to_string(),
        "manifest_sha256": sha_bytes(&bytes),
        "kernel_count": kernel_count,
    })
}

fn host_vendor_record() -> Value {
    let mut files = Vec::new();
    for name in ["libcublas.so.13", "libcublasLt.so.13", "libcudart.so.13"] {
        let path = Path::new(HOST_VENDOR).join(name);
        if let Ok(resolved) = std::fs::canonicalize(&path) {
            let sha = file_sha256(&resolved).unwrap_or_else(|error| format!("unavailable: {error}"));
            let size = std::fs::metadata(&resolved).map(|meta| meta.len()).unwrap_or(0);
            files.push(json!({"name": name, "path": resolved.display().to_string(), "size": size, "sha256": sha}));
        }
    }
    json!({"path": HOST_VENDOR, "exists": Path::new(HOST_VENDOR).is_dir(), "files": files})
}

fn vendor_record() -> Value {
    let ld_preload = std::env::var("LD_PRELOAD").ok();
    let ld_library_path = std::env::var("LD_LIBRARY_PATH").ok();
    let mut resolved = BTreeMap::new();
    if let Some(value) = &ld_preload {
        for entry in value.split(':').filter(|entry| !entry.is_empty()) {
            let path = Path::new(entry);
            if let Ok(canonical) = std::fs::canonicalize(path) {
                let sha = file_sha256(&canonical).unwrap_or_else(|error| format!("unavailable: {error}"));
                let size = std::fs::metadata(&canonical).map(|meta| meta.len()).unwrap_or(0);
                resolved.insert(canonical.display().to_string(), json!({"path": canonical.display().to_string(), "size": size, "sha256": sha}));
            }
        }
    }
    if let Some(value) = &ld_library_path {
        for entry in value.split(':').filter(|entry| !entry.is_empty()) {
            for name in ["libcublas.so.13", "libcublasLt.so.13"] {
                let path = Path::new(entry).join(name);
                if let Ok(canonical) = std::fs::canonicalize(&path) {
                    let sha = file_sha256(&canonical).unwrap_or_else(|error| format!("unavailable: {error}"));
                    let size = std::fs::metadata(&canonical).map(|meta| meta.len()).unwrap_or(0);
                    resolved.insert(canonical.display().to_string(), json!({"path": canonical.display().to_string(), "size": size, "sha256": sha}));
                }
            }
        }
    }
    let mut mapped = BTreeSet::new();
    if let Ok(maps) = std::fs::read_to_string("/proc/self/maps") {
        for line in maps.lines() {
            if let Some(path) = line.split_whitespace().last() {
                let name = Path::new(path).file_name().and_then(|value| value.to_str()).unwrap_or("");
                if name.starts_with("libcublas") || name.starts_with("libcudart") || name.starts_with("libcudnn") {
                    mapped.insert(path.to_string());
                }
            }
        }
    }
    let cublas_130200_preload = ld_preload
        .as_deref()
        .map(|value| value.contains("/tmp/oxide-host-cublas-130200/"))
        .unwrap_or(false);
    json!({
        "ld_preload": ld_preload,
        "ld_library_path": ld_library_path,
        "cuda_visible_devices": std::env::var("CUDA_VISIBLE_DEVICES").ok(),
        "mapped_libraries": mapped.into_iter().collect::<Vec<_>>(),
        "resolved_files": resolved.into_values().collect::<Vec<_>>(),
        "host_vendor": host_vendor_record(),
        "cublas_130200_preload": cublas_130200_preload,
    })
}

fn inherited_env_record() -> Value {
    let (count, digest) = env_names_digest();
    json!({
        "key_count": count,
        "keys_sha256": digest,
        "selectors": {
            "CUDA_VISIBLE_DEVICES": std::env::var("CUDA_VISIBLE_DEVICES").ok(),
            "INFINITY_OXIDE_KERNEL_MODULE": std::env::var("INFINITY_OXIDE_KERNEL_MODULE").ok(),
            "INFINITY_FA4_ROOT": std::env::var("INFINITY_FA4_ROOT").ok(),
            "INFINITY_TORCH_CUDA_GRAPHS": std::env::var("INFINITY_TORCH_CUDA_GRAPHS").ok(),
        },
        "note": "Only names are digested; values are limited to explicit selectors and vendor identity.",
    })
}

fn source_record(args: &Args, config_sha: &str, manifest_sha: &str, case: &LoadedCase) -> Value {
    let exe = std::env::current_exe().ok();
    let binary_sha = exe.as_deref().and_then(|path| file_sha256(path).ok());
    let device = std::env::var_os("INFINITY_OXIDE_KERNEL_MODULE").map(PathBuf::from);
    let fa4 = std::env::var_os("INFINITY_FA4_ROOT").map(PathBuf::from);
    json!({
        "binary_path": exe.as_deref().map(|path| path.display().to_string()),
        "binary_sha256": binary_sha,
        "crate_version": env!("CARGO_PKG_VERSION"),
        "model": args.model.display().to_string(),
        "model_label": args.label,
        "config_sha256": config_sha,
        "fixture_manifest": args.cases.display().to_string(),
        "fixture_manifest_sha256": manifest_sha,
        "fixture_sha256": case.meta.sha256,
        "input_ids_sha256": case.meta.input_ids_sha256,
        "case": case.meta.name,
        "token_count": case.meta.token_count,
        "sequence_count": case.meta.sequence_count,
        "pooled_count": case.meta.pooled_count,
        "raw_count": case.meta.raw_count,
        "device_bundle": bundle_record(device.as_deref(), "manifest.json"),
        "fa4_bundle": bundle_record(fa4.as_deref(), "sm_90/manifest.json"),
    })
}

#[cfg(feature = "oxide")]
fn to_backend_batch(batch: &BatchJson) -> Batch {
    Batch {
        multimodal: Vec::new(),
        input_ids: batch.input_ids.clone(),
        token_type_ids: batch.token_type_ids.clone(),
        position_ids: batch.position_ids.clone(),
        cumulative_seq_lengths: batch.cumulative_seq_lengths.clone(),
        max_length: batch.max_length,
        pooled_indices: batch.pooled_indices.clone(),
        raw_indices: batch.raw_indices.clone(),
        compact_input_ids: None,
        compact_position_ids: None,
        fold_gather: None,
        scatter_unfold: None,
        tokens: Vec::new(),
        offsets: Vec::new(),
    }
}

#[cfg(feature = "oxide")]
fn output_entries(embeddings: &Embeddings, hidden: usize) -> Result<Vec<OutputEntry>, String> {
    let mut out = Vec::new();
    for (&index, value) in embeddings.iter() {
        let (kind, shape, values) = match value {
            Embedding::Pooled(row) => {
                if row.len() != hidden {
                    return Err(format!("index {index} width {} != {hidden}", row.len()));
                }
                ("pooled".to_string(), vec![row.len()], row.clone())
            }
            Embedding::All(rows) => {
                let width = rows.first().map_or(hidden, Vec::len);
                if width != hidden {
                    return Err(format!("index {index} width {width} != {hidden}"));
                }
                if rows.iter().any(|row| row.len() != hidden) {
                    return Err(format!("index {index} ragged raw rows"));
                }
                (
                    "raw".to_string(),
                    vec![rows.len(), width],
                    rows.iter().flat_map(|row| row.iter().copied()).collect(),
                )
            }
        };
        out.push(OutputEntry { index, kind, shape, values });
    }
    out.sort_by_key(|entry| entry.index);
    Ok(out)
}

#[cfg(feature = "oxide")]
fn compare_against(
    expected: &Option<Vec<(GoldEntry, Vec<f32>)>>,
    baseline: &Option<Vec<OutputEntry>>,
    outputs: &[OutputEntry],
    case: &str,
    pool: &str,
) -> Comparison {
    if let Some(expected) = expected {
        return compare_outputs(case, pool, outputs, expected);
    }
    let fallback;
    let reference: &Vec<OutputEntry> = match baseline {
        Some(value) => value,
        None => {
            fallback = outputs.to_vec();
            &fallback
        }
    };
    let expected_entries = reference
        .iter()
        .map(|entry| {
            (
                GoldEntry {
                    index: entry.index,
                    kind: entry.kind.clone(),
                    shape: entry.shape.clone(),
                    values_file: String::new(),
                    sha256: String::new(),
                },
                entry.values.clone(),
            )
        })
        .collect::<Vec<_>>();
    compare_outputs(case, pool, outputs, &expected_entries)
}

#[cfg(feature = "oxide")]
async fn run_one(
    backend: &Backend,
    batch: &Batch,
) -> Result<(Embeddings, std::time::Duration, u64), String> {
    let started = Instant::now();
    let submission = backend
        .submit_embed(batch.clone())
        .await
        .map_err(|error| format!("submit: {error}"))?;
    let (embeddings, backend_duration) = submission
        .complete()
        .await
        .map_err(|error| format!("complete: {error}"))?;
    Ok((embeddings, backend_duration, started.elapsed().as_nanos() as u64))
}

fn preflight(args: &Args) -> Result<(), String> {
    let (config, config_sha, hidden) = read_config(&args.model, args.expected_config_sha256.as_deref())?;
    let manifest = load_manifest(&args.cases)?;
    let manifest_sha = file_sha256(&args.cases)?;
    let root = args.cases.parent().ok_or_else(|| "fixture manifest has no parent".to_string())?;
    let case = load_case(&manifest, root, &args.case)?;
    let gold_info = if let Some(path) = &args.gold {
        let gold = load_gold(path, &config_sha, hidden)?;
        let gold_root = path.parent().ok_or_else(|| "gold has no parent".to_string())?;
        let entries = gold_pool_entries(&gold, gold_root, &args.case, &args.pool)?;
        json!({
            "path": path.display().to_string(),
            "sha256": file_sha256(path)?,
            "schema": gold.schema,
            "config_sha256": gold.config_sha256,
            "hidden_size": gold.hidden_size,
            "pool": args.pool,
            "entries": entries.len(),
            "compared_values": entries.iter().map(|(_, values)| values.len()).sum::<usize>(),
            "acceptance": gold.acceptance,
        })
    } else {
        Value::Null
    };
    let report = json!({
        "schema": SCHEMA_BENCH,
        "mode": args.mode,
        "status": "preflight-ok",
        "backend": "oxide-host",
        "model": args.model.display().to_string(),
        "model_label": args.label,
        "pool": args.pool,
        "case": args.case,
        "config_sha256": config_sha,
        "hidden_size": hidden,
        "attention_heads": config["num_attention_heads"],
        "num_key_value_heads": config["num_key_value_heads"],
        "head_dim": config["head_dim"],
        "sliding_window": config["sliding_window"],
        "fixture_manifest": args.cases.display().to_string(),
        "fixture_manifest_sha256": manifest_sha,
        "fixture_sha256": case.meta.sha256,
        "input_ids_sha256": case.meta.input_ids_sha256,
        "token_count": case.meta.token_count,
        "sequence_count": case.meta.sequence_count,
        "gold": gold_info,
        "graph": {
            "environment": graph_environment(),
            "support": GRAPH_FREE_EXECUTOR,
            "device_bundle": bundle_record(std::env::var_os("INFINITY_OXIDE_KERNEL_MODULE").map(PathBuf::from).as_deref(), "manifest.json"),
            "fa4_bundle": bundle_record(std::env::var_os("INFINITY_FA4_ROOT").map(PathBuf::from).as_deref(), "sm_90/manifest.json"),
        },
        "vendor": vendor_record(),
        "source": source_record(args, &config_sha, &manifest_sha, &case),
        "inherited_env": inherited_env_record(),
        "requires_cuda": true,
        "numpy": false,
    });
    write_json_atomic(&args.out, &report)?;
    println!("{}", serde_json::to_string(&json!({"status":"preflight-ok","out":args.out.display().to_string()})).unwrap());
    Ok(())
}

#[cfg(feature = "oxide")]
async fn run_oxide(args: Args) -> Result<(), String> {
    let (_config, config_sha, hidden) = read_config(&args.model, args.expected_config_sha256.as_deref())?;
    let manifest = load_manifest(&args.cases)?;
    let manifest_sha = file_sha256(&args.cases)?;
    let root = args.cases.parent().ok_or_else(|| "fixture manifest has no parent".to_string())?;
    let case = load_case(&manifest, root, &args.case)?;
    let expected = if let Some(path) = &args.gold {
        let gold = load_gold(path, &config_sha, hidden)?;
        let gold_root = path.parent().ok_or_else(|| "gold has no parent".to_string())?;
        Some(gold_pool_entries(&gold, gold_root, &args.case, &args.pool)?)
    } else {
        None
    };
    let reference = if let Some(path) = &args.gold {
        json!({
            "source": "native-gold",
            "path": path.display().to_string(),
            "sha256": file_sha256(path)?,
            "config_sha256": config_sha,
            "hidden_size": hidden,
            "pool": args.pool,
            "acceptance": {"atol": 0.0, "rtol": 0.0},
        })
    } else {
        json!({"source": "warm-baseline", "pool": args.pool, "acceptance": {"atol": 0.0, "rtol": 0.0}})
    };
    let pool = match args.pool.as_str() {
        "cls" => Pool::Cls,
        "mean" => Pool::Mean,
        "last-token" => Pool::LastToken,
        other => return Err(format!("unsupported pool {other}")),
    };
    let batch = to_backend_batch(&case.batch);
    let backend = Backend::new_selected(
        args.model.clone(),
        None,
        DType::Bfloat16,
        ModelType::Embedding(pool.clone()),
        None,
        args.device,
        false,
        BackendKind::Oxide,
        TorchDevice::Cuda,
    )
    .await
    .map_err(|error| format!("constructor: {error}"))?;

    let mut warmup_ns = Vec::new();
    let mut samples_ns = Vec::new();
    let mut samples = Vec::new();
    let mut failures = Vec::new();
    let mut strict_ok = true;
    let mut warm_baseline: Option<Vec<OutputEntry>> = None;
    let mut first_outputs: Option<Vec<OutputEntry>> = None;
    let mut last_outputs: Vec<OutputEntry> = Vec::new();
    let mut first_failing_comparison: Option<Comparison> = None;
    let mut last_comparison: Option<Comparison> = None;
    let mut first_failing_stage: Option<String> = None;

    for index in 0..args.warmup {
        let (embeddings, _backend_duration, wall_ns) = run_one(&backend, &batch).await?;
        let outputs = output_entries(&embeddings, hidden)?;
        let comparison = compare_against(&expected, &warm_baseline, &outputs, &args.case, &args.pool);
        if warm_baseline.is_none() && expected.is_none() {
            warm_baseline = Some(outputs.clone());
        }
        if !comparison.exact || !comparison.finite {
            strict_ok = false;
            failures.push(format!("warmup {index}: {}", comparison.first_failing_stage.clone().unwrap_or_else(|| "nonfinite output".into())));
            if first_failing_comparison.is_none() {
                first_failing_stage = comparison.first_failing_stage.clone();
                first_failing_comparison = Some(comparison.clone());
            }
            if args.mode == "bench" {
                let report = json!({
                    "schema": SCHEMA_BENCH,
                    "mode": args.mode,
                    "status": "strict-fail",
                    "backend": "oxide-host",
                    "model": args.model.display().to_string(),
                    "model_label": args.label,
                    "pool": args.pool,
                    "case": args.case,
                    "warmup": args.warmup,
                    "measured": args.measured,
                    "warmup_ns": warmup_ns.clone(),
                    "samples_ns": samples_ns.clone(),
                    "samples": samples.clone(),
                    "reference": reference.clone(),
                    "comparison": comparison.clone(),
                    "first_failing_stage": first_failing_stage.clone(),
                    "outputs": outputs.clone(),
                    "failures": failures.clone(),
                    "source": source_record(&args, &config_sha, &manifest_sha, &case),
                    "vendor": vendor_record(),
                    "inherited_env": inherited_env_record(),
                    "graph": {"environment": graph_environment(), "support": GRAPH_FREE_EXECUTOR},
                });
                write_json_atomic(&args.out, &report)?;
                return Err(failures.last().cloned().unwrap_or_else(|| "warmup strict failure".into()));
            }
        }
        first_outputs.get_or_insert(outputs.clone());
        last_outputs = outputs;
        last_comparison = Some(comparison);
        warmup_ns.push(wall_ns);
    }

    for index in 0..args.measured {
        let (embeddings, backend_duration, wall_ns) = run_one(&backend, &batch).await?;
        let outputs = output_entries(&embeddings, hidden)?;
        let comparison = compare_against(&expected, &warm_baseline, &outputs, &args.case, &args.pool);
        if !comparison.exact || !comparison.finite {
            strict_ok = false;
            let stage = comparison.first_failing_stage.clone().unwrap_or_else(|| "nonfinite output".into());
            failures.push(format!("measured {index}: {stage}"));
            if first_failing_comparison.is_none() {
                first_failing_stage = comparison.first_failing_stage.clone();
                first_failing_comparison = Some(comparison.clone());
            }
        }
        let mut sample = json!({
            "index": index,
            "wall_ns": wall_ns,
            "backend_ns": backend_duration.as_nanos() as u64,
            "exact": comparison.exact,
            "finite": comparison.finite,
            "output_sha256": output_sha256(&outputs),
            "max_abs": comparison.max_abs,
            "max_rel": comparison.max_rel,
            "l2": comparison.max_l2,
            "cosine": comparison.min_cosine,
            "first_failing_stage": comparison.first_failing_stage,
        });
        if args.mode == "diag" {
            sample["comparison"] = serde_json::to_value(&comparison).map_err(|e| e.to_string())?;
        }
        samples_ns.push(wall_ns);
        samples.push(sample);
        first_outputs.get_or_insert(outputs.clone());
        last_outputs = outputs;
        last_comparison = Some(comparison);
        if args.mode == "bench" && !strict_ok {
            let report = json!({
                "schema": SCHEMA_BENCH,
                "mode": args.mode,
                "status": "strict-fail",
                "backend": "oxide-host",
                "model": args.model.display().to_string(),
                "model_label": args.label,
                "pool": args.pool,
                "case": args.case,
                "warmup": args.warmup,
                "measured": args.measured,
                "warmup_ns": warmup_ns.clone(),
                "samples_ns": samples_ns.clone(),
                "samples": samples.clone(),
                "reference": reference.clone(),
                "comparison": first_failing_comparison.clone(),
                "first_failing_stage": first_failing_stage.clone(),
                "outputs": last_outputs.clone(),
                "failures": failures.clone(),
                "source": source_record(&args, &config_sha, &manifest_sha, &case),
                "vendor": vendor_record(),
                "inherited_env": inherited_env_record(),
                "graph": {"environment": graph_environment(), "support": GRAPH_FREE_EXECUTOR},
            });
            write_json_atomic(&args.out, &report)?;
            return Err(failures.last().cloned().unwrap_or_else(|| "strict failure".into()));
        }
        if (index + 1) % 10 == 0 || index + 1 == args.measured {
            let report = json!({
                "schema": SCHEMA_BENCH,
                "mode": args.mode,
                "status": if strict_ok { "running" } else { "running-strict-fail" },
                "backend": "oxide-host",
                "model": args.model.display().to_string(),
                "model_label": args.label,
                "pool": args.pool,
                "case": args.case,
                "warmup": args.warmup,
                "measured": args.measured,
                "warmup_ns": warmup_ns.clone(),
                "samples_ns": samples_ns.clone(),
                "samples": samples.clone(),
                "reference": reference.clone(),
                "comparison": last_comparison.clone(),
                "first_failing_stage": first_failing_stage.clone(),
                "outputs": last_outputs.clone(),
                "failures": failures.clone(),
                "source": source_record(&args, &config_sha, &manifest_sha, &case),
                "vendor": vendor_record(),
                "inherited_env": inherited_env_record(),
                "graph": {"environment": graph_environment(), "support": GRAPH_FREE_EXECUTOR},
            });
            write_json_atomic(&args.out, &report)?;
        }
    }

    let stats = stats(&samples_ns)?;
    let health = backend.health().await.map(|_| "ok".to_string()).unwrap_or_else(|error| format!("error: {error}"));
    let status = if strict_ok { "ok" } else { "strict-fail" };
    let report = json!({
        "schema": SCHEMA_BENCH,
        "mode": args.mode,
        "status": status,
        "backend": "oxide-host",
        "model": args.model.display().to_string(),
        "model_label": args.label,
        "pool": args.pool,
        "case": args.case,
        "dtype": "bfloat16",
        "factory": {
            "route": "infinity_v3_backend::Backend::new_selected",
            "kind": "oxide",
            "dtype": "bfloat16",
            "gpu": "cuda:0",
            "pool": args.pool,
            "normal_factory_route": true,
            "engine_count": 1,
        },
        "warmup": args.warmup,
        "measured": args.measured,
        "warmup_ns": warmup_ns.clone(),
        "samples_ns": samples_ns.clone(),
        "samples": samples.clone(),
        "stats_ns": stats.clone(),
        "reference": reference.clone(),
        "comparison": last_comparison.clone(),
        "first_failing_stage": first_failing_stage.clone(),
        "first_failing_comparison": first_failing_comparison.clone(),
        "outputs": last_outputs.clone(),
        "first_outputs": first_outputs.clone(),
        "finite": samples.iter().all(|sample| sample["finite"].as_bool() == Some(true)),
        "exact": samples.iter().all(|sample| sample["exact"].as_bool() == Some(true)) && strict_ok,
        "failures": failures.clone(),
        "health": health,
        "source": source_record(&args, &config_sha, &manifest_sha, &case),
        "vendor": vendor_record(),
        "inherited_env": inherited_env_record(),
        "graph": {
            "environment": graph_environment(),
            "support": GRAPH_FREE_EXECUTOR,
            "statistics": null,
            "note": "Oxide Gemma3 executor is graph-free; Native graph counters are recorded by the separate b66 producer.",
        },
        "qualification": {
            "perf_claim": status == "ok" && !args.label.starts_with("12b"),
            "strict": true,
            "model_label": args.label,
            "note": if args.label.starts_with("12b") { "12B performance remains unqualified until strict quality passes." } else { "Balanced 270m benchmark; exact reference check required." },
        },
    });
    write_json_atomic(&args.out, &report)?;
    println!("{}", serde_json::to_string(&json!({
        "status": status,
        "backend": "oxide-host",
        "pool": args.pool,
        "case": args.case,
        "p50_ns": stats.p50_ns,
        "p90_ns": stats.p90_ns,
        "p99_ns": stats.p99_ns,
        "out": args.out.display().to_string(),
    })).unwrap());
    if status == "ok" {
        Ok(())
    } else {
        Err(format!("strict failure: {}", first_failing_stage.unwrap_or_else(|| "unknown".into())))
    }
}

async fn run_inner() -> Result<(), String> {
    let args = parse_args()?;
    if args.preflight_only {
        return preflight(&args);
    }
    #[cfg(feature = "oxide")]
    {
        return run_oxide(args).await;
    }
    #[cfg(not(feature = "oxide"))]
    {
        let _ = args;
        return Err("run mode requires building with --features oxide".into());
    }
}

#[tokio::main]
async fn main() {
    if let Err(error) = run_inner().await {
        eprintln!("{error}");
        std::process::exit(2);
    }
}
