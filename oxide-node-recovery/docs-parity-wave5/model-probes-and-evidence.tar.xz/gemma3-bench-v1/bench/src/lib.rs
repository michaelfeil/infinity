// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Pure CPU helpers for the bounded Gemma3 latency benchmark/diagnostic.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};

pub const SCHEMA_FIXTURES: &str = "oxide-gemma3-unified-fixtures/v1";
pub const SCHEMA_GOLD: &str = "oxide-gemma3-native-gold/v1";
pub const SCHEMA_BENCH: &str = "oxide-gemma3-latency-bench/v1";
pub const DEFAULT_WARMUP: usize = 20;
pub const DEFAULT_MEASURED: usize = 100;
pub const ABBA: [&str; 4] = ["oxide", "native", "native", "oxide"];
pub const GRAPH_ENV_KEYS: [&str; 6] = [
    "INFINITY_TORCH_CUDA_GRAPHS",
    "INFINITY_TORCH_CUDA_GRAPH_MAX_TOKENS",
    "INFINITY_TORCH_CUDA_GRAPH_ENTRIES",
    "INFINITY_TORCH_CUDA_GRAPH_REUSE",
    "INFINITY_TORCH_CUDA_GRAPH_MAX_BYTES",
    "INFINITY_TORCH_CUDA_GRAPH_MAX_CAPTURES",
];

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct CaseMeta {
    pub name: String,
    pub file: String,
    pub sha256: String,
    pub input_ids_sha256: String,
    pub valid: bool,
    #[serde(default)]
    pub expected_error_variant: Option<String>,
    pub token_count: usize,
    pub sequence_count: usize,
    pub pooled_count: usize,
    pub raw_count: usize,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct Manifest {
    pub schema: String,
    pub cases: Vec<CaseMeta>,
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct BatchJson {
    pub input_ids: Vec<u32>,
    pub position_ids: Vec<u32>,
    pub token_type_ids: Vec<u32>,
    pub cumulative_seq_lengths: Vec<u32>,
    pub pooled_indices: Vec<u32>,
    pub raw_indices: Vec<u32>,
    pub max_length: u32,
}

#[derive(Clone, Debug)]
pub struct LoadedCase {
    pub meta: CaseMeta,
    pub batch: BatchJson,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct GoldEntry {
    pub index: usize,
    pub kind: String,
    pub shape: Vec<usize>,
    pub values_file: String,
    pub sha256: String,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct GoldPool {
    pub entries: Vec<GoldEntry>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct GoldCase {
    pub name: String,
    pub fixture_sha256: String,
    pub input_ids_sha256: String,
    pub pools: BTreeMap<String, GoldPool>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct Acceptance {
    pub atol: f64,
    pub rtol: f64,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct Gold {
    pub schema: String,
    pub model: String,
    pub config_sha256: String,
    pub hidden_size: usize,
    pub cases: Vec<GoldCase>,
    pub acceptance: Acceptance,
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct OutputEntry {
    pub index: usize,
    pub kind: String,
    pub shape: Vec<usize>,
    pub values: Vec<f32>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct EntryMetrics {
    pub index: usize,
    pub kind: String,
    pub shape: Vec<usize>,
    pub expected_kind: String,
    pub expected_shape: Vec<usize>,
    pub expected_elements: usize,
    pub finite: bool,
    pub shape_match: bool,
    pub exact: bool,
    pub max_abs: Option<f64>,
    pub max_rel: Option<f64>,
    pub l2: Option<f64>,
    pub ref_l2: Option<f64>,
    pub cosine: Option<f64>,
    pub mean_abs: Option<f64>,
    pub rms: Option<f64>,
    pub first_diff_offset: Option<usize>,
    pub first_diff_actual: Option<f32>,
    pub first_diff_expected: Option<f32>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct Comparison {
    pub case: String,
    pub pool: String,
    pub entries: Vec<EntryMetrics>,
    pub exact: bool,
    pub finite: bool,
    pub compared_values: usize,
    pub max_abs: Option<f64>,
    pub max_rel: Option<f64>,
    pub max_l2: Option<f64>,
    pub min_cosine: Option<f64>,
    pub first_failing_stage: Option<String>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct Stats {
    pub count: usize,
    pub min_ns: u64,
    pub max_ns: u64,
    pub mean_ns: f64,
    pub stdev_ns: f64,
    pub p50_ns: u64,
    pub p90_ns: u64,
    pub p99_ns: u64,
    pub sum_ns: u64,
}

pub fn sha_bytes(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

pub fn file_sha256(path: &Path) -> Result<String, String> {
    let mut digest = Sha256::new();
    let mut file = std::fs::File::open(path)
        .map_err(|e| format!("open {}: {e}", path.display()))?;
    use std::io::Read;
    let mut buffer = [0u8; 1 << 20];
    loop {
        let read = file.read(&mut buffer).map_err(|e| format!("read {}: {e}", path.display()))?;
        if read == 0 {
            break;
        }
        digest.update(&buffer[..read]);
    }
    Ok(format!("{:x}", digest.finalize()))
}

pub fn parse_pool(value: &str) -> Result<String, String> {
    match value {
        "cls" => Ok("cls".into()),
        "mean" => Ok("mean".into()),
        "last-token" => Ok("last-token".into()),
        _ => Err(format!("invalid pool {value:?}")),
    }
}

pub fn parse_backend(value: &str) -> Result<String, String> {
    match value {
        "oxide" => Ok("oxide".into()),
        "native" => Ok("native".into()),
        _ => Err(format!("invalid backend {value:?}")),
    }
}

pub fn abba_order() -> [&'static str; 4] {
    ABBA
}

pub fn balanced_counts(sequence: &[&str]) -> BTreeMap<String, usize> {
    let mut counts = BTreeMap::new();
    for item in sequence {
        *counts.entry((*item).to_string()).or_insert(0) += 1;
    }
    counts
}

pub fn load_manifest(path: &Path) -> Result<Manifest, String> {
    let data = std::fs::read(path).map_err(|e| format!("read {}: {e}", path.display()))?;
    let manifest: Manifest = serde_json::from_slice(&data)
        .map_err(|e| format!("parse {}: {e}", path.display()))?;
    if manifest.schema != SCHEMA_FIXTURES {
        return Err(format!("unsupported fixture schema {}", manifest.schema));
    }
    if manifest.cases.len() != 25 {
        return Err(format!("expected 25 fixtures, found {}", manifest.cases.len()));
    }
    let valid = manifest.cases.iter().filter(|case| case.valid).count();
    if valid != 20 || manifest.cases.len() - valid != 5 {
        return Err(format!("expected 20 valid / 5 invalid fixtures, found {valid}/{}", manifest.cases.len() - valid));
    }
    Ok(manifest)
}

pub fn load_case(manifest: &Manifest, root: &Path, name: &str) -> Result<LoadedCase, String> {
    let meta = manifest.cases.iter().find(|case| case.name == name)
        .ok_or_else(|| format!("fixture {name} is absent"))?;
    if !meta.valid {
        return Err(format!("fixture {name} is marked invalid"));
    }
    let path = root.join(&meta.file);
    let bytes = std::fs::read(&path).map_err(|e| format!("read {}: {e}", path.display()))?;
    if sha_bytes(&bytes) != meta.sha256 {
        return Err(format!("{} fixture sha256 mismatch", path.display()));
    }
    let batch: BatchJson = serde_json::from_slice(&bytes)
        .map_err(|e| format!("parse {}: {e}", path.display()))?;
    let ids = serde_json::to_vec(&batch.input_ids).map_err(|e| e.to_string())?;
    if sha_bytes(&ids) != meta.input_ids_sha256 {
        return Err(format!("{} input_ids_sha256 mismatch", path.display()));
    }
    if batch.input_ids.len() != meta.token_count
        || batch.cumulative_seq_lengths.len() != meta.sequence_count + 1
        || batch.pooled_indices.len() != meta.pooled_count
        || batch.raw_indices.len() != meta.raw_count
    {
        return Err(format!("{} counts disagree with manifest", path.display()));
    }
    Ok(LoadedCase { meta: meta.clone(), batch })
}

pub fn load_gold(path: &Path, config_sha256: &str, hidden: usize) -> Result<Gold, String> {
    let gold: Gold = serde_json::from_slice(
        &std::fs::read(path).map_err(|e| format!("read gold {}: {e}", path.display()))?,
    )
    .map_err(|e| format!("parse gold: {e}"))?;
    if gold.schema != SCHEMA_GOLD {
        return Err(format!("unsupported gold schema {}", gold.schema));
    }
    if gold.config_sha256 != config_sha256 {
        return Err("gold config_sha256 differs from checkpoint config".into());
    }
    if gold.hidden_size != hidden {
        return Err("gold hidden width differs".into());
    }
    Ok(gold)
}

pub fn read_gold_values(root: &Path, entry: &GoldEntry) -> Result<Vec<f32>, String> {
    let path = root.join(&entry.values_file);
    let bytes = std::fs::read(&path).map_err(|e| format!("read {}: {e}", path.display()))?;
    if sha_bytes(&bytes) != entry.sha256 {
        return Err(format!("{} gold sha256 mismatch", path.display()));
    }
    let elements = entry.shape.iter().product::<usize>();
    if bytes.len() != elements * 4 {
        return Err(format!("{} gold length mismatch", path.display()));
    }
    let mut out = Vec::with_capacity(elements);
    for chunk in bytes.chunks_exact(4) {
        out.push(f32::from_le_bytes(chunk.try_into().unwrap()));
    }
    if out.iter().any(|value| !value.is_finite()) {
        return Err(format!("{} nonfinite gold", path.display()));
    }
    Ok(out)
}

pub fn gold_pool_entries(
    gold: &Gold,
    gold_root: &Path,
    case_name: &str,
    pool: &str,
) -> Result<Vec<(GoldEntry, Vec<f32>)>, String> {
    let case = gold.cases.iter().find(|case| case.name == case_name)
        .ok_or_else(|| format!("{case_name}: absent from gold"))?;
    let gold_pool = case.pools.get(pool)
        .ok_or_else(|| format!("{case_name}: gold lacks pool {pool}"))?;
    gold_pool
        .entries
        .iter()
        .map(|entry| Ok((entry.clone(), read_gold_values(gold_root, entry)?)))
        .collect()
}

pub fn output_sha256(outputs: &[OutputEntry]) -> String {
    let mut digest = Sha256::new();
    for output in outputs {
        digest.update((output.index as u64).to_le_bytes());
        digest.update((output.kind.len() as u64).to_le_bytes());
        digest.update(output.kind.as_bytes());
        digest.update((output.shape.len() as u64).to_le_bytes());
        for dim in &output.shape {
            digest.update((*dim as u64).to_le_bytes());
        }
        digest.update((output.values.len() as u64).to_le_bytes());
        for value in &output.values {
            digest.update(value.to_bits().to_le_bytes());
        }
    }
    format!("{:x}", digest.finalize())
}

fn compare_entry(
    index: usize,
    actual: Option<&OutputEntry>,
    expected_kind: &str,
    expected_shape: &[usize],
    expected_values: &[f32],
) -> EntryMetrics {
    let actual_kind = actual.map(|entry| entry.kind.clone()).unwrap_or_default();
    let actual_shape = actual.map(|entry| entry.shape.clone()).unwrap_or_default();
    let actual_values = actual.map(|entry| entry.values.as_slice()).unwrap_or(&[]);
    let shape_match = actual.is_some()
        && actual_kind == expected_kind
        && actual_shape == expected_shape
        && actual_values.len() == expected_values.len();
    let finite = actual.is_some()
        && actual_values.iter().all(|value| value.is_finite())
        && expected_values.iter().all(|value| value.is_finite());
    let exact = shape_match
        && expected_values.len() == actual_values.len()
        && actual_values
            .iter()
            .zip(expected_values)
            .all(|(a, b)| a.to_bits() == b.to_bits());
    let mut first_diff_offset = None;
    let mut first_diff_actual = None;
    let mut first_diff_expected = None;
    for offset in 0..actual_values.len().max(expected_values.len()) {
        let same = match (actual_values.get(offset), expected_values.get(offset)) {
            (Some(a), Some(b)) => a.to_bits() == b.to_bits(),
            _ => false,
        };
        if !same {
            first_diff_offset = Some(offset);
            first_diff_actual = actual_values.get(offset).copied().filter(|value| value.is_finite());
            first_diff_expected = expected_values.get(offset).copied().filter(|value| value.is_finite());
            break;
        }
    }
    if !shape_match && first_diff_offset.is_none() {
        first_diff_offset = Some(0);
        first_diff_actual = actual_values.first().copied().filter(|value| value.is_finite());
        first_diff_expected = expected_values.first().copied().filter(|value| value.is_finite());
    }
    let mut max_abs = None;
    let mut max_rel = None;
    let mut l2 = None;
    let mut ref_l2 = None;
    let mut cosine = None;
    let mut mean_abs = None;
    let mut rms = None;
    if shape_match && finite && !actual_values.is_empty() {
        let mut max_abs_value = 0.0f64;
        let mut max_rel_value = 0.0f64;
        let mut sq_diff = 0.0f64;
        let mut sq_ref = 0.0f64;
        let mut sq_actual = 0.0f64;
        let mut dot = 0.0f64;
        let mut abs_sum = 0.0f64;
        for (a, b) in actual_values.iter().zip(expected_values) {
            let a = *a as f64;
            let b = *b as f64;
            let diff = (a - b).abs();
            max_abs_value = max_abs_value.max(diff);
            let rel = if b == 0.0 { diff } else { diff / b.abs() };
            max_rel_value = max_rel_value.max(rel);
            sq_diff += diff * diff;
            sq_ref += b * b;
            sq_actual += a * a;
            dot += a * b;
            abs_sum += diff;
        }
        let count = actual_values.len() as f64;
        max_abs = Some(max_abs_value);
        max_rel = Some(max_rel_value);
        l2 = Some(sq_diff.sqrt());
        ref_l2 = Some(sq_ref.sqrt());
        let denominator = (sq_actual.sqrt() * sq_ref.sqrt()).max(f64::MIN_POSITIVE);
        cosine = Some((dot / denominator).clamp(-1.0, 1.0));
        mean_abs = Some(abs_sum / count);
        rms = Some((sq_diff / count).sqrt());
    }
    EntryMetrics {
        index,
        kind: actual_kind,
        shape: actual_shape,
        expected_kind: expected_kind.to_string(),
        expected_shape: expected_shape.to_vec(),
        expected_elements: expected_values.len(),
        finite,
        shape_match,
        exact,
        max_abs,
        max_rel,
        l2,
        ref_l2,
        cosine,
        mean_abs,
        rms,
        first_diff_offset,
        first_diff_actual,
        first_diff_expected,
    }
}

pub fn compare_outputs(
    case: &str,
    pool: &str,
    actual: &[OutputEntry],
    expected: &[(GoldEntry, Vec<f32>)],
) -> Comparison {
    let actual_map: BTreeMap<usize, &OutputEntry> =
        actual.iter().map(|entry| (entry.index, entry)).collect();
    let expected_map: BTreeMap<usize, (&GoldEntry, &Vec<f32>)> =
        expected.iter().map(|(entry, values)| (entry.index, (entry, values))).collect();
    let indices: BTreeSet<usize> = actual_map
        .keys()
        .chain(expected_map.keys())
        .copied()
        .collect();
    let mut entries = Vec::with_capacity(indices.len());
    for index in indices {
        let metrics = match expected_map.get(&index) {
            Some((entry, values)) => compare_entry(
                index,
                actual_map.get(&index).copied(),
                &entry.kind,
                &entry.shape,
                values,
            ),
            None => compare_entry(index, actual_map.get(&index).copied(), "", &[], &[]),
        };
        entries.push(metrics);
    }
    let exact = entries.iter().all(|entry| entry.exact);
    let finite = entries.iter().all(|entry| entry.finite);
    let compared_values = entries.iter().map(|entry| entry.expected_elements).sum();
    let max_abs = entries.iter().filter_map(|entry| entry.max_abs).reduce(f64::max);
    let max_rel = entries.iter().filter_map(|entry| entry.max_rel).reduce(f64::max);
    let max_l2 = entries.iter().filter_map(|entry| entry.l2).reduce(f64::max);
    let min_cosine = entries.iter().filter_map(|entry| entry.cosine).reduce(f64::min);
    let first_failing_stage = entries.iter().find(|entry| !entry.exact).map(|entry| {
        let offset = entry.first_diff_offset.unwrap_or(0);
        format!(
            "case={case}/pool={pool}/entry={}/kind={}/offset={offset}",
            entry.index, entry.kind
        )
    });
    Comparison {
        case: case.to_string(),
        pool: pool.to_string(),
        entries,
        exact,
        finite,
        compared_values,
        max_abs,
        max_rel,
        max_l2,
        min_cosine,
        first_failing_stage,
    }
}

fn nearest_rank(sorted: &[u64], fraction: f64) -> u64 {
    let rank = ((fraction * sorted.len() as f64).ceil() as usize).clamp(1, sorted.len());
    sorted[rank - 1]
}

pub fn stats(samples_ns: &[u64]) -> Result<Stats, String> {
    if samples_ns.is_empty() {
        return Err("cannot aggregate zero samples".into());
    }
    let mut sorted = samples_ns.to_vec();
    sorted.sort_unstable();
    let count = sorted.len();
    let sum: u64 = sorted.iter().sum();
    let mean = sum as f64 / count as f64;
    let variance = sorted
        .iter()
        .map(|value| {
            let delta = *value as f64 - mean;
            delta * delta
        })
        .sum::<f64>()
        / count as f64;
    Ok(Stats {
        count,
        min_ns: sorted[0],
        max_ns: sorted[count - 1],
        mean_ns: mean,
        stdev_ns: variance.sqrt(),
        p50_ns: nearest_rank(&sorted, 0.50),
        p90_ns: nearest_rank(&sorted, 0.90),
        p99_ns: nearest_rank(&sorted, 0.99),
        sum_ns: sum,
    })
}

pub fn graph_environment() -> BTreeMap<String, Option<String>> {
    GRAPH_ENV_KEYS
        .iter()
        .map(|key| ((*key).to_string(), std::env::var(key).ok()))
        .collect()
}

pub fn env_names_digest() -> (usize, String) {
    let mut names: Vec<String> = std::env::vars_os()
        .map(|(key, _)| key.to_string_lossy().into_owned())
        .collect();
    names.sort();
    names.dedup();
    let digest = sha_bytes(names.join("\n").as_bytes());
    (names.len(), digest)
}

pub fn write_json_atomic<T: Serialize>(path: &Path, value: &T) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let data = serde_json::to_vec_pretty(value).map_err(|e| e.to_string())?;
    let temp = path.with_extension("json.tmp");
    std::fs::write(&temp, data).map_err(|e| e.to_string())?;
    std::fs::rename(&temp, path).map_err(|e| e.to_string())
}

pub fn default_manifest_path() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("../fixtures/manifest.json")
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture_root() -> PathBuf {
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../fixtures")
    }

    #[test]
    fn manifest_has_expected_counts_and_exact_hashes() {
        let manifest = load_manifest(&fixture_root().join("manifest.json")).unwrap();
        assert_eq!(manifest.cases.len(), 25);
        assert_eq!(manifest.cases.iter().filter(|case| case.valid).count(), 20);
        for meta in &manifest.cases {
            let bytes = std::fs::read(fixture_root().join(&meta.file)).unwrap();
            assert_eq!(sha_bytes(&bytes), meta.sha256, "{}", meta.name);
            let batch: BatchJson = serde_json::from_slice(&bytes).unwrap();
            let ids = serde_json::to_vec(&batch.input_ids).unwrap();
            assert_eq!(sha_bytes(&ids), meta.input_ids_sha256, "{}", meta.name);
        }
    }

    #[test]
    fn load_case_accepts_b1_t128_and_ragged_fixtures() {
        let manifest = load_manifest(&fixture_root().join("manifest.json")).unwrap();
        let root = fixture_root();
        let b1 = load_case(&manifest, &root, "b1_t128_last").unwrap();
        assert_eq!(b1.meta.token_count, 128);
        assert_eq!(b1.meta.sequence_count, 1);
        assert_eq!(b1.batch.cumulative_seq_lengths, vec![0, 128]);
        assert_eq!(b1.batch.max_length, 128);
        for name in [
            "ragged_growing_1_4_9_17_last",
            "ragged_shrinking_17_9_4_1_last",
            "ragged_mixed",
        ] {
            let case = load_case(&manifest, &root, name).unwrap();
            assert!(case.meta.valid, "{name}");
            assert!(case.meta.sequence_count > 1, "{name}");
        }
    }

    #[test]
    fn abba_is_balanced_and_one_backend_per_position() {
        let order = abba_order();
        assert_eq!(order, ["oxide", "native", "native", "oxide"]);
        let counts = balanced_counts(&order);
        assert_eq!(counts.get("oxide"), Some(&2));
        assert_eq!(counts.get("native"), Some(&2));
        assert_eq!(order[0], order[3]);
        assert_eq!(order[1], order[2]);
        assert_ne!(order[0], order[1]);
    }

    #[test]
    fn stats_keep_every_sample_without_filtering() {
        let samples: Vec<u64> = (1..=100).collect();
        let result = stats(&samples).unwrap();
        assert_eq!(result.count, 100);
        assert_eq!(result.min_ns, 1);
        assert_eq!(result.max_ns, 100);
        assert_eq!(result.sum_ns, 5050);
        assert_eq!(result.p50_ns, 50);
        assert_eq!(result.p90_ns, 90);
        assert_eq!(result.p99_ns, 99);
        assert!((result.mean_ns - 50.5).abs() < 1e-9);
        assert!(result.stdev_ns > 28.0 && result.stdev_ns < 29.0);
    }

    #[test]
    fn percentile_edges_are_nearest_rank() {
        assert_eq!(nearest_rank(&[7], 0.99), 7);
        assert_eq!(nearest_rank(&[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.50), 5);
        assert_eq!(nearest_rank(&[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.90), 9);
        assert_eq!(nearest_rank(&[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.99), 10);
    }

    #[test]
    fn pool_parser_rejects_unknown_values() {
        assert_eq!(parse_pool("cls").unwrap(), "cls");
        assert_eq!(parse_pool("mean").unwrap(), "mean");
        assert_eq!(parse_pool("last-token").unwrap(), "last-token");
        assert!(parse_pool("splade").is_err());
        assert_eq!(parse_backend("oxide").unwrap(), "oxide");
        assert_eq!(parse_backend("native").unwrap(), "native");
        assert!(parse_backend("torch").is_err());
    }

    fn expected_entry(values: Vec<f32>) -> Vec<(GoldEntry, Vec<f32>)> {
        vec![(
            GoldEntry {
                index: 0,
                kind: "pooled".into(),
                shape: vec![values.len()],
                values_file: "unused.f32".into(),
                sha256: String::new(),
            },
            values,
        )]
    }

    #[test]
    fn exact_compare_reports_zero_metrics_for_identical_bits() {
        let values = vec![0.0, -0.0, 1.5, -2.25];
        let actual = vec![OutputEntry {
            index: 0,
            kind: "pooled".into(),
            shape: vec![values.len()],
            values: values.clone(),
        }];
        let comparison = compare_outputs("case", "cls", &actual, &expected_entry(values));
        assert!(comparison.exact);
        assert!(comparison.finite);
        assert_eq!(comparison.first_failing_stage, None);
        assert_eq!(comparison.compared_values, 4);
        assert_eq!(comparison.entries[0].max_abs, Some(0.0));
        assert_eq!(comparison.entries[0].max_rel, Some(0.0));
        assert_eq!(comparison.entries[0].l2, Some(0.0));
        assert!(comparison.entries[0].cosine.unwrap().is_finite());
    }

    #[test]
    fn exact_compare_reports_first_diff_and_full_metrics() {
        let expected = vec![0.0, 1.0, 2.0, 3.0];
        let actual = vec![OutputEntry {
            index: 0,
            kind: "pooled".into(),
            shape: vec![4],
            values: vec![0.0, 1.0, 2.25, 3.0],
        }];
        let comparison = compare_outputs("b1_t128_last", "mean", &actual, &expected_entry(expected));
        assert!(!comparison.exact);
        assert!(comparison.finite);
        assert_eq!(
            comparison.first_failing_stage.as_deref(),
            Some("case=b1_t128_last/pool=mean/entry=0/kind=pooled/offset=2")
        );
        let entry = &comparison.entries[0];
        assert_eq!(entry.first_diff_offset, Some(2));
        assert_eq!(entry.first_diff_actual, Some(2.25));
        assert_eq!(entry.first_diff_expected, Some(2.0));
        assert!((entry.max_abs.unwrap() - 0.25).abs() < 1e-6);
        assert!((entry.l2.unwrap() - 0.25).abs() < 1e-6);
    }

    #[test]
    fn shape_mismatch_is_never_exact() {
        let actual = vec![OutputEntry {
            index: 0,
            kind: "raw".into(),
            shape: vec![2, 2],
            values: vec![1.0, 2.0, 3.0, 4.0],
        }];
        let comparison = compare_outputs("case", "cls", &actual, &expected_entry(vec![1.0, 2.0, 3.0, 4.0]));
        assert!(!comparison.exact);
        assert!(!comparison.entries[0].shape_match);
        assert_eq!(comparison.entries[0].first_diff_offset, Some(0));
    }

    #[test]
    fn output_hash_changes_when_values_change() {
        let a = vec![OutputEntry {
            index: 0,
            kind: "pooled".into(),
            shape: vec![2],
            values: vec![1.0, 2.0],
        }];
        let b = vec![OutputEntry {
            index: 0,
            kind: "pooled".into(),
            shape: vec![2],
            values: vec![1.0, 2.5],
        }];
        assert_eq!(output_sha256(&a), output_sha256(&a));
        assert_ne!(output_sha256(&a), output_sha256(&b));
    }

    #[test]
    fn env_digest_records_no_values() {
        let (count, digest) = env_names_digest();
        assert!(count > 0);
        assert_eq!(digest.len(), 64);
        assert!(!digest.contains('/'));
    }
}
