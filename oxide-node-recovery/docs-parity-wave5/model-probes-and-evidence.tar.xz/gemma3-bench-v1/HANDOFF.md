# Gemma3 bench v1 handoff

Status: `SOURCE_READY_ROOT_GPU_PENDING`.

## Inherited evidence (do not overclaim)

- Root 270m: opt3 binary `125e5eb70aba994fee80e115941bd15dcfa503bc35e16a8372ee12d55ec9d27d`
  passed strict zero-tolerance Native 270m quality on all three pools:
  49,280 values/pool, 147,840 total, plus owning-life schedule.
- Root 12B: normal factory life passed, but strict quality **FAILED**:
  CLS `b1_t128_last` first diff `0.015625`; mean `b1_t7_last` first diff
  `0.0625`; last-token `b1_t7_last` first diff `1.25`.
- 12B is **not** passed. The formal zero-tolerance guard is unchanged.

## Packet

- `bench/`: source-only opt3/noLTO/CGU16 consumer. Path dependencies point at
  the frozen V4 production tree; V4 is not edited.
- `native/native_bench_b66.py`: stdlib-only Native b66 benchmark/diagnostic,
  verified 19-argument bridge, no NumPy, inherited graph flags/budgets.
- `control/bench_controller.py`: CPU dry-run and Root ABBA controller.
- `control/root_bench.sh`: single Root entry point.
- Fresh partial reports land in `reports/root-<run-id>/partial-*.json`;
  `PROGRESS.json` is updated after every process; `BALANCED.json` is the merge.

## One exact Root command

```sh
sudo env BENCH_ROOT_APPROVED=1 bash /tmp/oxide-docs-parity-20261102/gemma3-bench-v1/control/root_bench.sh
```

This performs the one opt3/noLTO/CGU16 release build, stages code/fixtures/gold
with `docker cp` only, then runs the balanced 270m B1 T=128 `cls` and `mean`
ABBA benchmark (`oxide, native, native, oxide`, 20 warmup / 100 measured per
process) under the GPU0 lock. No weights are staged and no host bind mount is
assumed.

Optional bounded 12B diagnostic, same binary, expected formal strict failure:

```sh
sudo env BENCH_ROOT_APPROVED=1 BENCH_MODEL=12b BENCH_MODE=diag BENCH_SKIP_BUILD=1 \
  bash /tmp/oxide-docs-parity-20261102/gemma3-bench-v1/control/root_bench.sh
```

It records all output vectors, max/relative error, L2, cosine, and the first
failing stage, but exits `2` because strict still fails. Full 12B performance is
unqualified.

## Native 12B attention profile audit (source-only hypothesis)

- 270m config Q4/KV1/d256 causal global matches Native mode 18
  `causal_wide4` via reduced ratio; mode 18 is inside the first 20 profiles.
- 12B config Q16/KV8/d256 causal needs mode 34 global and mode 35 local1024.
  Both are appended beyond the first 20.
- The b66 SDK contains `tei_torch_flash`/`flash_fwd_kernel` markers and no
  `gemma3_global_d256_gqa2` / `gemma3_local1024_d256_gqa2` strings.
- Therefore b66 auto-accepting the first 20 profiles makes a Torch Flash
  fallback possible for 12B, while Oxide explicitly uses FA4 modes 34/35.
  Treat this as a source hypothesis until the Native provider recipe is proved.
  No full 48-layer trace was taken.

## CPU validation completed

- `cargo test --offline --lib -j2`: **11 passed, 0 failed, 0 ignored**.
- `cargo check --offline --bin gemma3-latency-bench -j2`: passed.
- `cargo check --offline --bin gemma3-latency-bench --features oxide -j2`:
  passed (debug source check; the release build is the Root command above).
- Native b66 270m preflight: passed, 19-argument ABI verified, pinned b66 hash.
- Oxide 270m Rust preflight: passed, 115 device kernels, 84 FA4 kernels.
- Profile audits for 270m and 12B: passed; 12B flags the mode-34/35 fallback
  hypothesis.
- `reports/DRYRUN.json`: `SOURCE_READY_ROOT_GPU_PENDING`.

## Source hashes

| file | sha256 |
|---|---|
| `bench/Cargo.toml` | `ed69ee510791de179ffe6581a0c6573ba8427bc81fab92c761eae04fde2b6dc3` |
| `bench/Cargo.lock` | `ff3fc87746f4ad951c11e3e522a0c6cf8db15e5f4bd006982a635eb2aa3deb61` |
| `bench/src/lib.rs` | `3d9eaacc3f72fa14c3975a70ac5062b2df72870e6f54d8ffa0f0c8088290706e` |
| `bench/src/main.rs` | `241de9b3b035b02bcc20fdff29fcf4dd8acf1a5d9ec34f7b8b355852563223d4` |
| `native/native_bench_b66.py` | `14b0f48ea952243c875a75139b2309d4b20bbce6b4ab250c704aa7b83a4c7bbc` |
| `native/attention_profile_probe.py` | `5fe599adb9c82a27ba864fda9e7105182ebf4ea90d75aa350b82461d91c45b7a` |
| `native/native_gold_b66.py` | `2a1e2c19c149256e93cad09887253f8a900bb3cfef1c316540325745303ca138` |
| `control/bench_controller.py` | `4a4434db57811f1a2a78e5bd49ab874effc279597fc2257d2dd3c547eb5c12b9` |
| `control/root_bench.sh` | `0545f64533acb39dc7972b15a3463a4b90a72f2eb275d4084d29fbb8b6716c09` |
| `fixtures/manifest.json` | `fe791aa76623a1a64510225a9dfde989c6ac9b61e353fecdf13abccf240272cf` |
| `SOURCE-HASHES.json` | `3cc765805584cb5041c0bd9e263cae3465270448df9944ee1ddb6a86e256f0ef` |

Full packet and V4 provenance: `SOURCE-HASHES.json`.
