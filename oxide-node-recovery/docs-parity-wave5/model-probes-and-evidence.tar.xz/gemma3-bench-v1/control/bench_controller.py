#!/usr/bin/env python3
"""Root-only balanced Gemma3 latency benchmark/diagnostic controller.

Default mode is CPU-only dry-run: it validates frozen sources, fixtures, gold,
bundles, the path dependency on the private V4 production tree, and the light
Rust/Python CPU checks.  ``--run`` executes the balanced ABBA benchmark on GPU0
under an exclusive lock and uses ``docker cp`` for container staging.  No host
bind mount is assumed and no weights are copied.

The 270m balanced benchmark is the formal target.  ``--mode diag --model 12b``
is a bounded strict-fail diagnostic: it records all output vectors and
max/rel/L2/cosine/first-stage metrics, but never loosens the formal zero-
tolerance check.  Full 12B performance remains unqualified.
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import json
import math
import os
import pathlib
import shutil
import subprocess
import sys
import time

PACKET = pathlib.Path(__file__).resolve().parents[1]
BENCH = PACKET / "bench"
FIXTURES = PACKET / "fixtures"
NATIVE = PACKET / "native"
REPORTS = PACKET / "reports"
SOURCE_HASHES = PACKET / "SOURCE-HASHES.json"
TARGET_ROOT = PACKET / "target-root"
BINARY = TARGET_ROOT / "release/gemma3-latency-bench"
LOCK = pathlib.Path("/tmp/oxide-gemma3-bench-gpu0.lock")

V4 = pathlib.Path("/tmp/oxide-docs-parity-20261102/gemma3-runtime-v4")
V4_REPO = V4 / "repo"
V4_PINNED = V4 / "PINNED-SOURCE-HASHES.json"
GOLD_270 = V4 / "root-native-gold-270m"
GOLD_12B = V4 / "root-native-gold-12b"
DEVICE = pathlib.Path("/tmp/oxide-docs-parity-20261102/gemma3-wave4-device-all3-v1")
FA4 = pathlib.Path("/tmp/oxide-fa4-canonical38-all3-v2")
PROFILES_INC = V4_REPO / "libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4/profiles.inc"
HOST_SDK = pathlib.Path("/tmp/h5120-root-recovered-v5/sdk/libtei_torch.so")
CONTAINER_SDK = "/tmp/native214-fa4-mode20/install/lib/libtei_torch.so"
HOST_VENDOR = pathlib.Path("/usr/local/cuda-13.1/lib64")
CONTAINER_VENDOR = "/tmp/oxide-host-cublas-130200"
CONTAINER = "infinity-torch214-compare-sdk"
DOCKER_HOST = "unix:///var/run/docker.sock"
CONTAINER_PYTHON = "/opt/torch-sdk/bin/python3.12"
REMOTE_BASE = "/tmp/gemma3-native-stage-v4"
REMOTE_BENCH = REMOTE_BASE + "/bench-v1"
REMOTE_MODEL_270 = REMOTE_BASE + "/model-270m"
REMOTE_MODEL_12B = REMOTE_BASE + "/model-12b"

MODELS = {
    "270m": {
        "host": pathlib.Path("/root/.cache/huggingface/hub/models--microsoft--harrier-oss-v1-270m/snapshots/31de22b673913c7d658c0f03f792d77c2dcf8ebd"),
        "container": REMOTE_MODEL_270,
        "config_sha256": "f77ed9972d4c5d69e58c4e1ee831d8e38bdbacfa358dfe0ce9a9d1885528976c",
        "hidden": 640,
        "gold": GOLD_270,
        "qualified": True,
    },
    "12b": {
        "host": pathlib.Path("/root/.cache/huggingface/hub/models--tencent--KaLM-Embedding-Gemma3-12B-2511/snapshots/98c19ba34197906fbc93f6f1ef79402ca3a33956"),
        "container": REMOTE_MODEL_12B,
        "config_sha256": "652d7d58cd5fed9a1509d3b2e9b984a693ac2f638009abe1f114673917f1415a",
        "hidden": 3840,
        "gold": GOLD_12B,
        "qualified": False,
    },
}
EXPECTED_SDK_SHA = "b66d70b61b39e1bf0d565aca33bac7c5e21849677396ce5216f5baf73027d37e"
BUDGET_KEYS = (
    "INFINITY_TORCH_CUDA_GRAPH_MAX_TOKENS",
    "INFINITY_TORCH_CUDA_GRAPH_ENTRIES",
    "INFINITY_TORCH_CUDA_GRAPH_REUSE",
    "INFINITY_TORCH_CUDA_GRAPH_MAX_BYTES",
    "INFINITY_TORCH_CUDA_GRAPH_MAX_CAPTURES",
)
DOCKER_SELECTORS = ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS",
                    "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH")


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with pathlib.Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: pathlib.Path):
    return json.loads(pathlib.Path(path).read_text())


def write_json(path: pathlib.Path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temp.replace(path)


def cargo() -> str:
    for candidate in (os.environ.get("CARGO"), shutil.which("cargo"),
                      "/root/.cargo/bin/cargo",
                      str(pathlib.Path.home() / ".cargo/bin/cargo")):
        if candidate and pathlib.Path(candidate).is_file():
            return candidate
    return "cargo"


def docker_env() -> dict:
    env = dict(os.environ)
    for key in DOCKER_SELECTORS:
        env.pop(key, None)
    return env


def docker(*args, timeout=3600):
    return subprocess.run(
        ["docker", f"--host={DOCKER_HOST}", *map(str, args)],
        env=docker_env(), capture_output=True, text=True, timeout=timeout, check=False)


def checked_docker(*args, timeout=3600):
    done = docker(*args, timeout=timeout)
    if done.returncode:
        raise RuntimeError(f"docker {' '.join(map(str, args))} failed rc={done.returncode}: {done.stderr.strip()}")
    return done


def cp_to_container(source: pathlib.Path, target: str):
    checked_docker("cp", str(pathlib.Path(source)) + "/.", f"{CONTAINER}:{target}")


def cp_from_container(source: str, target: pathlib.Path):
    pathlib.Path(target).parent.mkdir(parents=True, exist_ok=True)
    checked_docker("cp", f"{CONTAINER}:{source}", str(target))


def container_sha(path: str) -> str:
    code = ("import hashlib,sys;"
            "h=hashlib.sha256();"
            "f=open(sys.argv[1],'rb');"
            "[h.update(c) for c in iter(lambda:f.read(1<<20),b'')];"
            "print(h.hexdigest())")
    done = checked_docker("exec", CONTAINER, CONTAINER_PYTHON, "-c", code, path)
    return done.stdout.strip()


def host_oxide_env() -> dict:
    env = dict(os.environ)
    inherited = env.get("LD_LIBRARY_PATH", "")
    env["CUDA_VISIBLE_DEVICES"] = "0"
    env["INFINITY_OXIDE_KERNEL_MODULE"] = str(DEVICE)
    env["INFINITY_FA4_ROOT"] = str(FA4)
    env["INFINITY_BENCH_REQUIRE_HOST_VENDOR"] = "1"
    env["INFINITY_TORCH_CUDA_GRAPHS"] = "1"
    env["LD_LIBRARY_PATH"] = f"{HOST_VENDOR}:{inherited}" if inherited else str(HOST_VENDOR)
    return env


def container_native_env() -> dict:
    return {
        "CUDA_VISIBLE_DEVICES": "0",
        "INFINITY_BENCH_REQUIRE_HOST_VENDOR": "1",
        "INFINITY_TORCH_CUDA_GRAPHS": "1",
        "LD_PRELOAD": f"{CONTAINER_VENDOR}/libcublas.so.13:{CONTAINER_VENDOR}/libcublasLt.so.13",
        "LD_LIBRARY_PATH": (f"{CONTAINER_VENDOR}:{pathlib.Path(CONTAINER_SDK).parent}:"
                            "/opt/torch-sdk/lib:/opt/torch-sdk/lib/python3.12/site-packages/torch/lib"),
    }


def env_record() -> dict:
    return {
        "host_inherited_env_preserved": True,
        "container_native_env_preserved": True,
        "overridden_selectors": {
            "host": ["CUDA_VISIBLE_DEVICES", "INFINITY_OXIDE_KERNEL_MODULE",
                     "INFINITY_FA4_ROOT", "INFINITY_BENCH_REQUIRE_HOST_VENDOR",
                     "INFINITY_TORCH_CUDA_GRAPHS", "LD_LIBRARY_PATH"],
            "container": ["CUDA_VISIBLE_DEVICES", "INFINITY_BENCH_REQUIRE_HOST_VENDOR",
                          "INFINITY_TORCH_CUDA_GRAPHS", "LD_PRELOAD", "LD_LIBRARY_PATH"],
        },
        "untouched_graph_budget_keys": list(BUDGET_KEYS),
        "inherited_budget_values": {key: os.environ.get(key) for key in BUDGET_KEYS},
        "environment_dump": False,
    }


@contextlib.contextmanager
def gpu0_lock(timeout=3600):
    fd = os.open(LOCK, os.O_CREAT | os.O_RDWR, 0o600)
    started = time.time()
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if time.time() - started > timeout:
                os.close(fd)
                raise RuntimeError(f"timed out acquiring {LOCK}")
            time.sleep(0.5)
    os.ftruncate(fd, 0)
    os.write(fd, f"pid={os.getpid()} started={int(time.time())}\n".encode())
    try:
        yield {"path": str(LOCK), "pid": os.getpid(), "started_unix_seconds": int(started)}
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def source_checks() -> dict:
    checks = {}
    if SOURCE_HASHES.is_file():
        frozen = read_json(SOURCE_HASHES)
        packet_files = frozen.get("packet_files", {})
        mismatches = {}
        for rel, expected in packet_files.items():
            path = PACKET / rel
            actual = sha(path) if path.is_file() else None
            if actual != expected:
                mismatches[rel] = {"expected": expected, "actual": actual}
        checks["packet_freeze"] = {
            "path": str(SOURCE_HASHES),
            "files": len(packet_files),
            "mismatches": mismatches,
            "ok": not mismatches,
        }
    else:
        checks["packet_freeze"] = {"path": str(SOURCE_HASHES), "exists": False, "ok": False}
    if V4_PINNED.is_file():
        pinned = read_json(V4_PINNED)
        mismatches = {}
        for rel, expected in pinned.get("source_files", {}).items():
            actual_path = V4_REPO / rel.removeprefix("repo/")
            actual = sha(actual_path) if actual_path.is_file() else None
            if actual != expected:
                mismatches[rel] = {"expected": expected, "actual": actual}
        checks["v4_frozen_production"] = {
            "path": str(V4_PINNED),
            "files": len(pinned.get("source_files", {})),
            "mismatches": mismatches,
            "ok": not mismatches,
        }
    else:
        checks["v4_frozen_production"] = {"path": str(V4_PINNED), "exists": False, "ok": False}
    cargo_text = (BENCH / "Cargo.toml").read_text()
    main_text = (BENCH / "src/main.rs").read_text()
    checks["consumer"] = {
        "path_dependency": "../../gemma3-runtime-v4/repo/libs/infinity-v3/backends" in cargo_text
                          and "../../gemma3-runtime-v4/repo/libs/infinity-v3/backends/core" in cargo_text,
        "oxide_feature": "features = [\"oxide\"]" in cargo_text,
        "opt_level_3": "opt-level = 3" in cargo_text,
        "lto_false": "lto = false" in cargo_text,
        "codegen_units_16": "codegen-units = 16" in cargo_text,
        "normal_factory": "Backend::new_selected" in main_text,
        "bf16": "DType::Bfloat16" in main_text,
        "oxide_kind": "BackendKind::Oxide" in main_text,
        "cuda_device": "TorchDevice::Cuda" in main_text,
        "submit_complete": "submit_embed" in main_text and ".complete()" in main_text,
        "no_ignored_tests": "#[ignore" not in (BENCH / "src/lib.rs").read_text()
                            and "#[ignore" not in main_text,
        "no_numpy": "import numpy" not in (NATIVE / "native_bench_b66.py").read_text(),
    }
    checks["consumer"]["ok"] = all(value for key, value in checks["consumer"].items() if key != "ok")
    manifest = read_json(FIXTURES / "manifest.json")
    fixture_ok = len(manifest.get("cases", [])) == 25
    fixture_ok &= sum(1 for case in manifest["cases"] if case.get("valid")) == 20
    for case in manifest.get("cases", []):
        fixture_ok &= sha(FIXTURES / case["file"]) == case["sha256"]
    checks["fixtures"] = {
        "manifest": str(FIXTURES / "manifest.json"),
        "manifest_sha256": sha(FIXTURES / "manifest.json"),
        "count": len(manifest.get("cases", [])),
        "valid": sum(1 for case in manifest.get("cases", []) if case.get("valid")),
        "invalid": sum(1 for case in manifest.get("cases", []) if not case.get("valid")),
        "ok": bool(fixture_ok),
    }
    gold_checks = {}
    for label, model in MODELS.items():
        path = model["gold"] / "native-gold.json"
        if not path.is_file():
            gold_checks[label] = {"path": str(path), "exists": False, "ok": False}
            continue
        gold = read_json(path)
        details = {}
        for case_name, pool in [("b1_t128_last", "cls"), ("b1_t128_last", "mean"),
                                ("b1_t7_last", "mean"), ("b1_t7_last", "last-token")]:
            case = next((item for item in gold.get("cases", []) if item.get("name") == case_name), None)
            if not case or pool not in case.get("pools", {}):
                details[f"{case_name}/{pool}"] = {"ok": False}
                continue
            entries = case["pools"][pool]["entries"]
            files_ok = all(sha(model["gold"] / entry["values_file"]) == entry["sha256"] for entry in entries)
            values = sum(int(entry.get("elements", 0)) for entry in entries)
            details[f"{case_name}/{pool}"] = {"entries": len(entries), "values": values, "files_ok": files_ok}
        ok = (gold.get("schema") == "oxide-gemma3-native-gold/v1"
              and gold.get("config_sha256") == model["config_sha256"]
              and int(gold.get("hidden_size", 0)) == model["hidden"]
              and all(item.get("files_ok") for item in details.values()))
        gold_checks[label] = {
            "path": str(path),
            "sha256": sha(path),
            "config_sha256": gold.get("config_sha256"),
            "hidden_size": gold.get("hidden_size"),
            "details": details,
            "ok": bool(ok),
        }
    checks["gold"] = {"models": gold_checks,
                      "ok": all(item["ok"] for item in gold_checks.values())}
    device_manifest = DEVICE / "manifest.json"
    fa4_manifest = FA4 / "sm_90/manifest.json"
    checks["bundles"] = {
        "device": {"path": str(DEVICE), "manifest_sha256": sha(device_manifest) if device_manifest.is_file() else None},
        "fa4": {"path": str(FA4), "manifest_sha256": sha(fa4_manifest) if fa4_manifest.is_file() else None},
        "profiles_inc": {"path": str(PROFILES_INC), "sha256": sha(PROFILES_INC) if PROFILES_INC.is_file() else None},
        "ok": device_manifest.is_file() and fa4_manifest.is_file() and PROFILES_INC.is_file(),
    }
    checks["paths"] = {
        "host_sdk": {"path": str(HOST_SDK), "sha256": sha(HOST_SDK) if HOST_SDK.is_file() else None,
                     "expected": EXPECTED_SDK_SHA},
        "host_vendor": {"path": str(HOST_VENDOR), "exists": HOST_VENDOR.is_dir()},
        "container_sdk": {"path": CONTAINER_SDK, "staged_by_controller": False},
        "container_vendor": {"path": CONTAINER_VENDOR, "staged_by_controller": False},
        "container": CONTAINER,
        "container_model_270m": REMOTE_MODEL_270,
        "container_model_12b": REMOTE_MODEL_12B,
        "assumed_bind_mount": False,
        "weights_staged_by_controller": False,
        "ok": HOST_SDK.is_file() and HOST_VENDOR.is_dir()
              and (sha(HOST_SDK) == EXPECTED_SDK_SHA if HOST_SDK.is_file() else False),
    }
    checks["ok"] = all(item.get("ok", False) for item in checks.values() if isinstance(item, dict))
    return checks


def run_cpu(command, cwd, log_name, env_extra=None, timeout=1800):
    env = dict(os.environ)
    env.update({"CARGO_NET_OFFLINE": "true", "CARGO_BUILD_JOBS": "2",
                "CARGO_TARGET_DIR": str(PACKET / "target-cpu")})
    if env_extra:
        env.update(env_extra)
    done = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    (REPORTS / log_name).write_text(done.stdout + done.stderr)
    return done


def used_path_checks() -> dict:
    records = {}
    cargo_bin = cargo()
    records["cargo_test_lib"] = run_cpu([cargo_bin, "test", "--offline", "--lib", "-j2"], BENCH, "cpu-tests.log").returncode
    records["cargo_check_bin"] = run_cpu([cargo_bin, "check", "--offline", "--bin", "gemma3-latency-bench", "-j2"], BENCH, "cpu-check.log").returncode
    model = MODELS["270m"]
    records["native_preflight_270m"] = run_cpu([
        sys.executable, str(NATIVE / "native_bench_b66.py"), "bench",
        "--model", str(model["host"]), "--cases", str(FIXTURES / "manifest.json"),
        "--case", "b1_t128_last", "--pool", "cls", "--gold", str(model["gold"] / "native-gold.json"),
        "--expected-config-sha256", model["config_sha256"], "--library", str(HOST_SDK),
        "--out", str(REPORTS / "native-preflight-270m.json"), "--preflight-only",
    ], PACKET, "native-preflight-270m.log").returncode
    for label in ("270m", "12b"):
        records[f"profile_audit_{label}"] = run_cpu([
            sys.executable, str(NATIVE / "attention_profile_probe.py"),
            "--model", str(MODELS[label]["host"]), "--label", label,
            "--profiles-inc", str(PROFILES_INC), "--fa4-bundle", str(FA4),
            "--sdk", str(HOST_SDK), "--out", str(REPORTS / f"profile-audit-{label}.json"),
        ], PACKET, f"profile-audit-{label}.log").returncode
    env = host_oxide_env()
    records["oxide_preflight_270m"] = run_cpu([
        cargo_bin, "run", "--offline", "--quiet", "--no-default-features",
        "--bin", "gemma3-latency-bench", "--", "bench",
        "--model", str(model["host"]), "--cases", str(FIXTURES / "manifest.json"),
        "--case", "b1_t128_last", "--pool", "cls", "--gold", str(model["gold"] / "native-gold.json"),
        "--expected-config-sha256", model["config_sha256"],
        "--out", str(REPORTS / "oxide-preflight-270m.json"), "--preflight-only",
    ], BENCH, "oxide-preflight-270m.log", env_extra={k: env[k] for k in (
        "CUDA_VISIBLE_DEVICES", "INFINITY_OXIDE_KERNEL_MODULE", "INFINITY_FA4_ROOT",
        "INFINITY_BENCH_REQUIRE_HOST_VENDOR", "INFINITY_TORCH_CUDA_GRAPHS", "LD_LIBRARY_PATH")}).returncode
    records["ok"] = all(value == 0 for value in records.values())
    return records


def build_binary(skip=False, record=None) -> dict:
    if skip:
        if not BINARY.is_file():
            raise RuntimeError(f"--skip-build requested but {BINARY} is absent")
        return {"skipped": True, "binary": str(BINARY), "sha256": sha(BINARY), "size": BINARY.stat().st_size}
    env = dict(os.environ)
    env.update({"CARGO_NET_OFFLINE": "true", "CARGO_BUILD_JOBS": "2",
                "CARGO_TARGET_DIR": str(TARGET_ROOT)})
    command = [cargo(), "build", "--offline", "--release", "--locked", "--features", "oxide", "-j2"]
    done = subprocess.run(command, cwd=BENCH, env=env, capture_output=True, text=True, timeout=3600)
    (REPORTS / "root-build.log").write_text(done.stdout + done.stderr)
    if done.returncode:
        raise RuntimeError(f"cargo build failed rc={done.returncode}; see reports/root-build.log")
    record = {
        "command": command,
        "cargo": subprocess.run([cargo(), "--version"], capture_output=True, text=True).stdout.strip(),
        "binary": str(BINARY),
        "sha256": sha(BINARY),
        "size": BINARY.stat().st_size,
        "opt_level_3": True,
        "lto_false": True,
        "codegen_units_16": True,
    }
    write_json(REPORTS / "BUILD.json", record)
    return record


def check_container_ready() -> dict:
    done = checked_docker("inspect", "-f", "{{.State.Running}}", CONTAINER)
    running = done.stdout.strip() == "true"
    if not running:
        raise RuntimeError(f"container {CONTAINER} is not running")
    sdk_sha = container_sha(CONTAINER_SDK)
    if sdk_sha != EXPECTED_SDK_SHA:
        raise RuntimeError(f"container SDK sha256 {sdk_sha} != pinned b66")
    return {"container": CONTAINER, "running": running, "container_sdk": CONTAINER_SDK,
            "container_sdk_sha256": sdk_sha, "container_vendor": CONTAINER_VENDOR}


def stage_container(model_label: str) -> dict:
    checked_docker("exec", CONTAINER, "mkdir", "-p",
                   REMOTE_BENCH,
                   f"{REMOTE_BENCH}/bench", f"{REMOTE_BENCH}/fixtures",
                   f"{REMOTE_BENCH}/native", f"{REMOTE_BENCH}/gold-270m",
                   f"{REMOTE_BENCH}/gold-12b", f"{REMOTE_BENCH}/reports")
    cp_to_container(BENCH, f"{REMOTE_BENCH}/bench")
    cp_to_container(FIXTURES, f"{REMOTE_BENCH}/fixtures")
    cp_to_container(NATIVE, f"{REMOTE_BENCH}/native")
    cp_to_container(GOLD_270, f"{REMOTE_BENCH}/gold-270m")
    cp_to_container(GOLD_12B, f"{REMOTE_BENCH}/gold-12b")
    staged = {
        "base": REMOTE_BASE,
        "bench": f"{REMOTE_BENCH}/bench",
        "fixtures": f"{REMOTE_BENCH}/fixtures",
        "native": f"{REMOTE_BENCH}/native",
        "gold_270m": f"{REMOTE_BENCH}/gold-270m",
        "gold_12b": f"{REMOTE_BENCH}/gold-12b",
        "model_270m": REMOTE_MODEL_270,
        "model_12b": REMOTE_MODEL_12B,
        "weights_staged": False,
        "docker_cp_only": True,
        "assumed_bind_mount": False,
    }
    write_json(REPORTS / "STAGED-CONTAINER.json", staged)
    return staged


def container_run(argv, log: pathlib.Path, timeout=3600, env_overrides=None):
    command = ["exec", "-w", REMOTE_BENCH]
    env = container_native_env() if env_overrides is None else dict(env_overrides)
    for key, value in env.items():
        command += ["-e", f"{key}={value}"]
    command += [CONTAINER, *map(str, argv)]
    done = docker(*command, timeout=timeout)
    pathlib.Path(log).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(log).write_text(done.stdout + done.stderr)
    return done


def host_run(argv, log: pathlib.Path, timeout=3600):
    done = subprocess.run(argv, env=host_oxide_env(), capture_output=True, text=True, timeout=timeout)
    pathlib.Path(log).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(log).write_text(done.stdout + done.stderr)
    return done


def nearest_rank(sorted_values, fraction):
    rank = min(max(int(math.ceil(fraction * len(sorted_values))), 1), len(sorted_values))
    return sorted_values[rank - 1]


def stats(samples_ns):
    ordered = sorted(samples_ns)
    count = len(ordered)
    total = sum(ordered)
    mean = total / count
    variance = sum((value - mean) ** 2 for value in ordered) / count
    return {
        "count": count,
        "min_ns": ordered[0],
        "max_ns": ordered[-1],
        "mean_ns": mean,
        "stdev_ns": math.sqrt(variance),
        "p50_ns": nearest_rank(ordered, 0.50),
        "p90_ns": nearest_rank(ordered, 0.90),
        "p99_ns": nearest_rank(ordered, 0.99),
        "sum_ns": total,
    }


def validate_partial(path: pathlib.Path, backend: str, label: str, expect_strict_fail=False) -> dict:
    report = read_json(path)
    failures = []
    if report.get("schema") != "oxide-gemma3-latency-bench/v1":
        failures.append("schema differs")
    if report.get("backend") != ("oxide-host" if backend == "oxide" else "native-b66"):
        failures.append("backend differs")
    if report.get("warmup") != 20 or report.get("measured") != 100:
        failures.append("warmup/measured defaults changed")
    samples_ns = report.get("samples_ns", [])
    samples = report.get("samples", [])
    if len(samples_ns) != 100 or len(samples) != 100:
        failures.append("sample count is not 100")
    if len(report.get("warmup_ns", [])) != 20:
        failures.append("warmup count is not 20")
    if samples_ns:
        recomputed = stats(samples_ns)
        stored = report.get("stats_ns") or {}
        for key in ("count", "min_ns", "max_ns", "p50_ns", "p90_ns", "p99_ns", "sum_ns"):
            if stored.get(key) != recomputed[key]:
                failures.append(f"stats {key} differs")
        for key in ("mean_ns", "stdev_ns"):
            if stored.get(key) is None or abs(float(stored[key]) - recomputed[key]) > 1e-9:
                failures.append(f"stats {key} differs")
    if expect_strict_fail:
        if report.get("status") != "strict-fail":
            failures.append("diagnostic did not record formal strict-fail")
        if report.get("qualification", {}).get("perf_claim") is not False:
            failures.append("diagnostic made a perf claim")
        if not report.get("first_failing_stage"):
            failures.append("diagnostic lacks first failing stage")
        if not report.get("first_failing_comparison"):
            failures.append("diagnostic lacks first failing comparison")
        if not report.get("qualification", {}).get("strict"):
            failures.append("diagnostic weakened strict guard")
    else:
        if report.get("status") != "ok":
            failures.append("benchmark did not pass")
        if not all(sample.get("exact") is True for sample in samples):
            failures.append("benchmark sample is not exact")
        if not all(sample.get("finite") is True for sample in samples):
            failures.append("benchmark sample is not finite")
        if report.get("reference", {}).get("source") != "native-gold":
            failures.append("benchmark reference is not native gold")
        if not report.get("comparison", {}).get("exact"):
            failures.append("benchmark comparison is not exact")
        if report.get("qualification", {}).get("perf_claim") is not True and label != "12b":
            failures.append("270m benchmark did not claim qualified performance")
    outputs = report.get("outputs") or []
    if not outputs:
        failures.append("outputs are hidden")
    elif not all(all(isinstance(value, (int, float)) and math.isfinite(value) for value in item.get("values", [])) for item in outputs):
        failures.append("outputs are nonfinite")
    if backend == "native":
        if not report.get("source", {}).get("library_is_pinned_b66"):
            failures.append("native SDK is not pinned b66")
        if not report.get("graph", {}).get("support"):
            failures.append("native graph support not recorded")
        if report.get("vendor", {}).get("cublas_preload", {}).get("cublas_130200_preload") is not True:
            failures.append("native cuBLAS 130200 preload not recorded")
    else:
        if not report.get("vendor", {}).get("host_vendor", {}).get("exists"):
            failures.append("oxide host vendor not recorded")
        if not report.get("vendor", {}).get("resolved_files"):
            failures.append("oxide cuBLAS source identity not recorded")
    return {"path": str(path), "backend": backend, "failures": failures,
            "ok": not failures, "report": report}


def summarize_run(report: dict) -> dict:
    stats_ns = report.get("stats_ns", {})
    return {
        "p50_ns": stats_ns.get("p50_ns"),
        "p90_ns": stats_ns.get("p90_ns"),
        "p99_ns": stats_ns.get("p99_ns"),
        "mean_ns": stats_ns.get("mean_ns"),
        "min_ns": stats_ns.get("min_ns"),
        "max_ns": stats_ns.get("max_ns"),
        "count": stats_ns.get("count"),
        "output_sha256": report.get("samples", [{}])[-1].get("output_sha256") if report.get("samples") else None,
        "first_failing_stage": report.get("first_failing_stage"),
        "graph_support": report.get("graph", {}).get("support"),
        "graph_statistics_after": report.get("graph", {}).get("statistics_after"),
        "observed_replay": report.get("graph", {}).get("observed_replay"),
        "observed_capture": report.get("graph", {}).get("observed_capture"),
    }


def aggregate_backend(runs: list) -> dict:
    combined_samples = []
    reports = []
    for run in runs:
        report = run.get("report") or read_json(run["host_path"])
        reports.append(report)
        combined_samples.extend(report.get("samples_ns", []))
    per_run = [summarize_run(report) for report in reports]
    return {
        "runs": per_run,
        "combined": stats(combined_samples) if combined_samples else None,
        "run_count": len(runs),
    }


def run_balanced(model_label: str, pools, case: str, include_ragged: bool,
                 run_id: str, force: bool, skip_build: bool) -> dict:
    if os.geteuid() != 0:
        raise RuntimeError("--run requires Root")
    model = MODELS[model_label]
    run_dir = REPORTS / f"root-{run_id}"
    if run_dir.exists() and any(run_dir.iterdir()) and not force:
        raise RuntimeError(f"{run_dir} is not empty; pass --force or a fresh --run-id")
    run_dir.mkdir(parents=True, exist_ok=True)
    lock_record = None
    with gpu0_lock() as lock_record:
        container = check_container_ready()
        staged = stage_container(model_label)
        build = build_binary(skip=skip_build)
        write_json(run_dir / "BUILD.json", build)
        write_json(run_dir / "CONTAINER.json", container)
        write_json(run_dir / "STAGED.json", staged)

        native_preflight = container_run([
            CONTAINER_PYTHON, f"{REMOTE_BENCH}/native/native_bench_b66.py", "bench",
            "--model", model["container"],
            "--cases", f"{REMOTE_BENCH}/fixtures/manifest.json",
            "--case", case, "--pool", "cls",
            "--gold", f"{REMOTE_BENCH}/gold-270m/native-gold.json" if model_label == "270m"
                      else f"{REMOTE_BENCH}/gold-12b/native-gold.json",
            "--expected-config-sha256", model["config_sha256"],
            "--library", CONTAINER_SDK,
            "--out", f"{REMOTE_BENCH}/reports/native-preflight-{model_label}.json",
            "--preflight-only",
        ], run_dir / "container-native-preflight.log",
           env_overrides={"CUDA_VISIBLE_DEVICES": ""})
        if native_preflight.returncode:
            raise RuntimeError("container native preflight failed")
        cp_from_container(f"{REMOTE_BENCH}/reports/native-preflight-{model_label}.json",
                          run_dir / "container-native-preflight.json")

        host_preflight = host_run([
            str(BINARY), "bench", "--model", str(model["host"]),
            "--cases", str(FIXTURES / "manifest.json"), "--case", case, "--pool", "cls",
            "--gold", str(model["gold"] / "native-gold.json"),
            "--expected-config-sha256", model["config_sha256"],
            "--out", str(run_dir / "host-oxide-preflight.json"), "--preflight-only",
        ], run_dir / "host-oxide-preflight.log")
        if host_preflight.returncode:
            raise RuntimeError("host oxide preflight failed")

        tasks = [(case, pool) for pool in pools]
        if include_ragged:
            tasks += [("ragged_growing_1_4_9_17_last", "last-token"),
                      ("ragged_shrinking_17_9_4_1_last", "last-token")]
        order = ["oxide", "native", "native", "oxide"]
        partials = []
        progress = {"schema": "oxide-gemma3-bench-progress/v1", "status": "running",
                    "run_id": run_id, "order": order, "tasks": tasks, "partials": partials}
        write_json(run_dir / "PROGRESS.json", progress)
        sequence = 0
        for task_case, pool in tasks:
            for position, backend in enumerate(order):
                sequence += 1
                host_path = run_dir / f"partial-{sequence:02d}-{pool}-{task_case}-{backend}.json"
                log_path = run_dir / f"partial-{sequence:02d}-{pool}-{task_case}-{backend}.log"
                if backend == "oxide":
                    done = host_run([
                        str(BINARY), "bench", "--model", str(model["host"]),
                        "--cases", str(FIXTURES / "manifest.json"), "--case", task_case,
                        "--pool", pool, "--gold", str(model["gold"] / "native-gold.json"),
                        "--expected-config-sha256", model["config_sha256"],
                        "--warmup", "20", "--measured", "100", "--label", model_label,
                        "--out", str(host_path),
                    ], log_path)
                    record_path = host_path
                else:
                    remote_path = f"{REMOTE_BENCH}/reports/partial-{sequence:02d}-{pool}-{task_case}-{backend}.json"
                    done = container_run([
                        CONTAINER_PYTHON, f"{REMOTE_BENCH}/native/native_bench_b66.py", "bench",
                        "--model", model["container"],
                        "--cases", f"{REMOTE_BENCH}/fixtures/manifest.json",
                        "--case", task_case, "--pool", pool,
                        "--gold", f"{REMOTE_BENCH}/gold-270m/native-gold.json" if model_label == "270m"
                                  else f"{REMOTE_BENCH}/gold-12b/native-gold.json",
                        "--expected-config-sha256", model["config_sha256"],
                        "--library", CONTAINER_SDK,
                        "--warmup", "20", "--measured", "100", "--label", model_label,
                        "--out", remote_path,
                    ], log_path)
                    try:
                        cp_from_container(remote_path, host_path)
                    finally:
                        pass
                    record_path = host_path
                partial = {
                    "sequence": sequence,
                    "position": position,
                    "task_case": task_case,
                    "pool": pool,
                    "backend": backend,
                    "returncode": done.returncode,
                    "host_path": str(record_path),
                    "log": str(log_path),
                }
                if record_path.is_file():
                    validation = validate_partial(record_path, backend, model_label)
                    partial["run_summary"] = summarize_run(validation.get("report", {}))
                    partial["validation"] = {key: value for key, value in validation.items() if key != "report"}
                else:
                    partial["validation"] = {"ok": False, "failures": ["partial report missing"]}
                partials.append(partial)
                progress["partials"] = partials
                write_json(run_dir / "PROGRESS.json", progress)
                if done.returncode != 0 or not partial["validation"]["ok"]:
                    progress["status"] = "failed"
                    progress["stop_reason"] = f"sequence {sequence} {backend} rc={done.returncode}"
                    write_json(run_dir / "PROGRESS.json", progress)
                    failure = {
                        "schema": "oxide-gemma3-balanced-latency/v1",
                        "status": "failed",
                        "run_id": run_id,
                        "model_label": model_label,
                        "failure": progress["stop_reason"],
                        "partials": partials,
                        "lock": lock_record,
                        "env": env_record(),
                    }
                    write_json(run_dir / "BALANCED.json", failure)
                    return failure

        grouped = {}
        for partial in partials:
            key = (partial["task_case"], partial["pool"], partial["backend"])
            grouped.setdefault(key, []).append(partial)
        pools_report = {}
        for (task_case, pool, backend), runs in sorted(grouped.items()):
            key = f"{task_case}/{pool}"
            pools_report.setdefault(key, {})
            pools_report[key][backend] = aggregate_backend(runs)
        balanced = {
            "schema": "oxide-gemma3-balanced-latency/v1",
            "status": "ok",
            "run_id": run_id,
            "model_label": model_label,
            "qualified": bool(model["qualified"]),
            "perf_claim": bool(model["qualified"]),
            "order": order,
            "balanced_counts": {"oxide": order.count("oxide"), "native": order.count("native")},
            "warmup": 20,
            "measured": 100,
            "tasks": [{"case": case_name, "pool": pool} for case_name, pool in tasks],
            "pools": pools_report,
            "partials": partials,
            "build": build,
            "container": container,
            "staged": staged,
            "lock": lock_record,
            "env": env_record(),
            "evidence": {
                "inherited_270m_strict": {
                    "values_per_pool": 49280,
                    "total_values": 147840,
                    "pools": ["cls", "mean", "last-token"],
                    "life": "passed",
                    "binary_sha256": "125e5eb70aba994fee80e115941bd15dcfa503bc35e16a8372ee12d55ec9d27d",
                },
                "inherited_12b": {
                    "life": "passed",
                    "strict_quality": "failed",
                    "first_failures": {
                        "cls_b1_t128": "abs=0.015625",
                        "mean_b1_t7": "abs=0.0625",
                        "last_token_b1_t7": "abs=1.25",
                    },
                    "perf_qualified": False,
                },
            },
            "notes": [
                "One backend per process; ABBA order per task.",
                "No fast-sample filtering; all 100 measured samples per process are retained and aggregated.",
                "Container staging uses docker cp only; weights are not copied and no host bind mount is assumed.",
                "No CUDA graphs or budget selectors are forced; inherited values are recorded.",
            ],
        }
        if not model["qualified"]:
            balanced["qualification_note"] = "Full 12B performance is unqualified until strict quality passes."
        write_json(run_dir / "BALANCED.json", balanced)
        return balanced


def run_diag_12b(run_id: str, force: bool, skip_build: bool) -> dict:
    if os.geteuid() != 0:
        raise RuntimeError("--run requires Root")
    model = MODELS["12b"]
    run_dir = REPORTS / f"diag-12b-{run_id}"
    if run_dir.exists() and any(run_dir.iterdir()) and not force:
        raise RuntimeError(f"{run_dir} is not empty; pass --force or a fresh --run-id")
    run_dir.mkdir(parents=True, exist_ok=True)
    with gpu0_lock() as lock_record:
        build = build_binary(skip=skip_build)
        write_json(run_dir / "BUILD.json", build)
        routes = [("b1_t128_last", "cls"), ("b1_t7_last", "mean"), ("b1_t7_last", "last-token")]
        results = []
        for index, (case_name, pool) in enumerate(routes, 1):
            out = run_dir / f"diag-{index:02d}-{pool}-{case_name}.json"
            log = run_dir / f"diag-{index:02d}-{pool}-{case_name}.log"
            done = host_run([
                str(BINARY), "diag", "--model", str(model["host"]),
                "--cases", str(FIXTURES / "manifest.json"), "--case", case_name,
                "--pool", pool, "--gold", str(model["gold"] / "native-gold.json"),
                "--expected-config-sha256", model["config_sha256"],
                "--warmup", "20", "--measured", "100", "--label", "12b",
                "--out", str(out),
            ], log, timeout=3600)
            validation = validate_partial(out, "oxide", "12b", expect_strict_fail=True) if out.is_file() else {
                "ok": False, "failures": ["diag report missing"]}
            results.append({
                "case": case_name, "pool": pool, "returncode": done.returncode,
                "report": str(out), "log": str(log), "validation": validation,
            })
            write_json(run_dir / "PROGRESS.json", {"schema": "oxide-gemma3-12b-diag-progress/v1",
                                                   "status": "running", "routes": results})
        audit = REPORTS / "profile-audit-12b.json"
        if not audit.is_file():
            subprocess.run([
                sys.executable, str(NATIVE / "attention_profile_probe.py"),
                "--model", str(model["host"]), "--label", "12b",
                "--profiles-inc", str(PROFILES_INC), "--fa4-bundle", str(FA4),
                "--sdk", str(HOST_SDK), "--out", str(audit),
            ], capture_output=True, text=True, timeout=600)
        profile_audit = read_json(audit) if audit.is_file() else None
        formal_failed = any(item["returncode"] != 0 for item in results)
        diag = {
            "schema": "oxide-gemma3-12b-diag/v1",
            "status": "diagnostic-complete-strict-fail" if formal_failed else "diagnostic-complete-unexpected-pass",
            "run_id": run_id,
            "model_label": "12b",
            "qualified": False,
            "perf_claim": False,
            "formal_strict_passed": not formal_failed,
            "note": "The formal zero-tolerance check still fails; metrics are diagnostic only. Full 12B performance remains unqualified.",
            "routes": results,
            "profile_audit": profile_audit,
            "build": build,
            "lock": lock_record,
            "env": env_record(),
        }
        write_json(run_dir / "DIAG-12B.json", diag)
        return diag


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--mode", choices=["bench", "diag"], default="bench")
    parser.add_argument("--model", choices=["270m", "12b"], default="270m")
    parser.add_argument("--pools", default="cls,mean")
    parser.add_argument("--case", default="b1_t128_last")
    parser.add_argument("--include-ragged", action="store_true")
    parser.add_argument("--include-12b-diag", action="store_true")
    parser.add_argument("--run-id", default=time.strftime("%Y%m%dT%H%M%S"))
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--skip-build", action="store_true")
    parser.add_argument("--skip-used-path", action="store_true")
    parser.add_argument("--out", default=str(REPORTS / "DRYRUN.json"))
    args = parser.parse_args()
    REPORTS.mkdir(parents=True, exist_ok=True)
    checks = source_checks()
    if not args.run:
        used = {} if args.skip_used_path else used_path_checks()
        plan = {
            "schema": "oxide-gemma3-latency-bench-dryrun/v1",
            "status": "SOURCE_READY_ROOT_GPU_PENDING" if checks["ok"] and all(
                value == 0 for key, value in used.items() if key != "ok" and isinstance(value, int)) else "SOURCE_BLOCKED",
            "source_checks": checks,
            "used_path_cpu_checks": used,
            "paths": {
                "host_sdk": str(HOST_SDK),
                "container_sdk": CONTAINER_SDK,
                "host_vendor": str(HOST_VENDOR),
                "container_vendor": CONTAINER_VENDOR,
                "device": str(DEVICE),
                "fa4": str(FA4),
                "host_model_270m": str(MODELS["270m"]["host"]),
                "host_model_12b": str(MODELS["12b"]["host"]),
                "container_model_270m": REMOTE_MODEL_270,
                "container_model_12b": REMOTE_MODEL_12B,
                "container": CONTAINER,
                "docker_host": DOCKER_HOST,
                "assumed_bind_mount": False,
            },
            "defaults": {"warmup": 20, "measured": 100, "order": ["oxide", "native", "native", "oxide"]},
            "root_command": "sudo env BENCH_ROOT_APPROVED=1 bash /tmp/oxide-docs-parity-20261102/gemma3-bench-v1/control/root_bench.sh",
        }
        write_json(pathlib.Path(args.out), plan)
        write_json(REPORTS / "DRYRUN.json", plan)
        print(json.dumps({"status": plan["status"], "source_ok": checks["ok"],
                          "used_path_ok": all(value == 0 for key, value in used.items() if key != "ok" and isinstance(value, int)),
                          "out": args.out}))
        return 0 if plan["status"] == "SOURCE_READY_ROOT_GPU_PENDING" else 1
    if not checks["ok"]:
        raise RuntimeError("source checks failed; refusing Root GPU execution")
    if os.environ.get("BENCH_ROOT_APPROVED") != "1":
        raise RuntimeError("set BENCH_ROOT_APPROVED=1 for Root GPU execution")
    if args.mode == "diag" or args.model == "12b":
        diag = run_diag_12b(args.run_id, args.force, args.skip_build)
        print(json.dumps({"status": diag["status"], "formal_strict_passed": diag["formal_strict_passed"],
                          "out": str(REPORTS / f"diag-12b-{args.run_id}/DIAG-12B.json")}))
        return 0 if diag["formal_strict_passed"] else 2
    pools = [pool.strip() for pool in args.pools.split(",") if pool.strip()]
    balanced = run_balanced(args.model, pools, args.case, args.include_ragged,
                            args.run_id, args.force, args.skip_build)
    result = {"status": balanced["status"], "out": str(REPORTS / f"root-{args.run_id}/BALANCED.json")}
    if args.include_12b_diag and balanced["status"] == "ok":
        diag = run_diag_12b(args.run_id + "-12b", args.force, True)
        result["diag_12b"] = {"status": diag["status"],
                              "formal_strict_passed": diag["formal_strict_passed"],
                              "out": str(REPORTS / f"diag-12b-{args.run_id}-12b/DIAG-12B.json")}
    print(json.dumps(result))
    return 0 if balanced["status"] == "ok" else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"bench controller failed: {error}", file=sys.stderr)
        raise SystemExit(1)
