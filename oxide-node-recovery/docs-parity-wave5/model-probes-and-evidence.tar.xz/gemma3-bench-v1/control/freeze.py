#!/usr/bin/env python3
"""Write the packet source freeze for the Gemma3 bench-v1 packet."""
from __future__ import annotations

import hashlib
import json
import pathlib

PACKET = pathlib.Path(__file__).resolve().parents[1]
V4 = pathlib.Path("/tmp/oxide-docs-parity-20261102/gemma3-runtime-v4")
DEVICE = pathlib.Path("/tmp/oxide-docs-parity-20261102/gemma3-wave4-device-all3-v1")
FA4 = pathlib.Path("/tmp/oxide-fa4-canonical38-all3-v2")
PROFILES_INC = V4 / "repo/libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4/profiles.inc"
MODELS = {
    "270m": pathlib.Path("/root/.cache/huggingface/hub/models--microsoft--harrier-oss-v1-270m/snapshots/31de22b673913c7d658c0f03f792d77c2dcf8ebd"),
    "12b": pathlib.Path("/root/.cache/huggingface/hub/models--tencent--KaLM-Embedding-Gemma3-12B-2511/snapshots/98c19ba34197906fbc93f6f1ef79402ca3a33956"),
}
GOLD = {"270m": V4 / "root-native-gold-270m", "12b": V4 / "root-native-gold-12b"}


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with pathlib.Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    files = {}
    relative = [
        "bench/Cargo.toml",
        "bench/Cargo.lock",
        "bench/src/lib.rs",
        "bench/src/main.rs",
        "native/native_bench_b66.py",
        "native/attention_profile_probe.py",
        "native/native_gold_b66.py",
        "control/bench_controller.py",
        "control/root_bench.sh",
        "control/freeze.py",
        "fixtures/manifest.json",
    ]
    relative += [str(path.relative_to(PACKET)) for path in sorted((PACKET / "native/verified").glob("*")) if path.is_file()]
    relative += [str(path.relative_to(PACKET)) for path in sorted((PACKET / "fixtures").glob("*.json")) if path.name != "manifest.json"]
    for rel in sorted(set(relative)):
        path = PACKET / rel
        if path.is_file():
            files[rel] = sha(path)
    origin = {}
    for rel in ["native/native_gold_b66.py", "native/verified/bridge.h"]:
        path = V4 / "native" / pathlib.Path(rel).name if "verified" not in rel else V4 / rel
        if path.is_file():
            origin[f"v4/{rel}"] = sha(path)
    for rel in ["native/verified/native_base.py", "native/verified/native_batch.py",
                "native/verified/native_raw_probe.py", "native/verified/model_checkpoint.py",
                "native/verified/bridge.h"]:
        path = V4 / rel
        if path.is_file():
            origin[f"v4/{rel}"] = sha(path)
    gold = {}
    for label, folder in GOLD.items():
        path = folder / "native-gold.json"
        if path.is_file():
            gold[label] = {"manifest": str(path), "sha256": sha(path)}
    bundles = {
        "device_manifest": {"path": str(DEVICE / "manifest.json"),
                            "sha256": sha(DEVICE / "manifest.json")},
        "fa4_manifest": {"path": str(FA4 / "sm_90/manifest.json"),
                         "sha256": sha(FA4 / "sm_90/manifest.json")},
        "profiles_inc": {"path": str(PROFILES_INC), "sha256": sha(PROFILES_INC)},
    }
    models = {}
    for label, folder in MODELS.items():
        config = folder / "config.json"
        models[label] = {"path": str(folder), "config_sha256": sha(config)}
    packet = {
        "schema": "oxide-gemma3-bench-source-freeze/v1",
        "packet": str(PACKET),
        "v4_frozen_production": str(V4),
        "packet_files": files,
        "copied_native_origin": origin,
        "gold": gold,
        "bundles": bundles,
        "models": models,
        "notes": [
            "V4 production is read-only and unchanged.",
            "Native wrappers and fixtures are byte copies from the frozen V4 packet.",
            "No weights are included or staged by the controller.",
        ],
    }
    out = PACKET / "SOURCE-HASHES.json"
    temp = out.with_suffix(".json.tmp")
    temp.write_text(json.dumps(packet, indent=2, allow_nan=False) + "\n")
    temp.replace(out)
    print(json.dumps({"status": "ok", "out": str(out), "files": len(files)}))


if __name__ == "__main__":
    raise SystemExit(main())
