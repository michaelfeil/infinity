#!/usr/bin/env bash
# Root-only balanced Gemma3 benchmark launcher. CPU dry-run must pass first.
# One exact command:
#   sudo env BENCH_ROOT_APPROVED=1 bash /tmp/oxide-docs-parity-20261102/gemma3-bench-v1/control/root_bench.sh
set -euo pipefail

PACKET=/tmp/oxide-docs-parity-20261102/gemma3-bench-v1
export BENCH_ROOT_APPROVED=1
MODEL=${BENCH_MODEL:-270m}
MODE=${BENCH_MODE:-bench}
RUN_ID=${BENCH_RUN_ID:-$(date +%Y%m%dT%H%M%S)}
ARGS=(--run --model "$MODEL" --mode "$MODE" --run-id "$RUN_ID")
if [[ "${BENCH_INCLUDE_12B_DIAG:-0}" == "1" ]]; then
  ARGS+=(--include-12b-diag)
fi
if [[ "${BENCH_INCLUDE_RAGGED:-0}" == "1" ]]; then
  ARGS+=(--include-ragged)
fi
if [[ "${BENCH_SKIP_BUILD:-0}" == "1" ]]; then
  ARGS+=(--skip-build)
fi
exec python3 "$PACKET/control/bench_controller.py" "${ARGS[@]}"
