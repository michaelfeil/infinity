/// \file
/// FP8 row quantization, linear operators, and ordinary-GEMM execution sessions.
/// Public wrappers expose eligibility and preserve their documented fallback paths.

#pragma once
#include <ATen/ATen.h>
#include <utility>
#include <memory>

namespace infinity {
// Real rows only: the first dimension is never aligned or padded.
/// Return dynamically quantized activation rows and their per-row scale tensor. The non-CUDA
/// implementation throws; callers must select an eligible execution path first.
std::pair<at::Tensor, at::Tensor> fp8_quantize_rows(const at::Tensor& input);

// Undefined output preserves the original ordinary ATen linear path.
// Bounded model-owned ordinary plans; graph capture never admits a new plan.
class OrdinaryLinearExecutor {
  struct Impl;
  std::shared_ptr<Impl> impl_;

public:
  /// Retains the execution state shared by ordinary linear calls in one session.
  class Session {
    struct State;
    std::shared_ptr<State> state_;
    friend class OrdinaryLinearExecutor;

  public:
    Session() = default;
  };

  OrdinaryLinearExecutor();
  // Request-local snapshot: retains its executor and captures policy, context,
  // stream and handle once. It stores no thread-local guard. Callers must keep
  // the same device, stream and policy while dispatching with it.
  Session prepare(const at::Tensor& input) const;
  /// Attempt a bias-free matrix projection using this session's captured execution context. An
  /// undefined tensor asks the caller to retain its ordinary ATen linear fallback.
  at::Tensor
  forward(const at::Tensor& input, const at::Tensor& weight, const Session& session) const;
  /// Prepare a one-call session and attempt the same qualified ordinary projection.
  at::Tensor forward(const at::Tensor& input, const at::Tensor& weight) const;
};

// Checkpoint weights are quantized once, activations once per invocation.
// Attention, normalization, bias and output heads retain their model dtype.
class Fp8Linear {
  at::Tensor matrix_, scales_, unit_;
  at::ScalarType dtype_;
  bool rowwise_;

public:
  /// Quantize checkpoint weights once and retain scales for subsequent activation projections.
  explicit Fp8Linear(const at::Tensor& weight);
  /// Quantize activation rows and project them, returning model-dtype rows with optional bias.
  at::Tensor forward(const at::Tensor& input, const at::Tensor& bias = {}) const;
  // Accept the identical rowwise recipe from a fused activation producer.
  at::Tensor forward_quantized(const at::Tensor& input,
                               const at::Tensor& scales,
                               const at::Tensor& bias = {}) const;

  int64_t input_width() const {
    return matrix_.size(1);
  }

  int64_t output_width() const {
    return matrix_.size(0);
  }

  const at::Tensor& matrix() const {
    return matrix_;
  }

  const at::Tensor& scales() const {
    return scales_;
  }
};
}
