// Pinned Torch Flash implementation and its BSD notices remain in vendor/torch_flash_attention.
/// \file
/// Native packed Flash attention interface for the head-width-64 ALiBi path.

#pragma once
#include <ATen/ATen.h>

namespace infinity {
bool torch_flash_alibi64_supported(c10::Device, at::ScalarType, int64_t);
/// Execute the qualified width-64 packed attention profile with per-head ALiBi slopes.
at::Tensor torch_flash_alibi64(const at::Tensor&,
                               const at::Tensor&,
                               const at::Tensor&,
                               const at::Tensor&,
                               const at::Tensor&,
                               int64_t,
                               double);
}
