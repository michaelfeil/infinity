//! Diagnostic-only layer0 trace. Compiled only with feature `layer0-trace`.

use crate::tensor::Bf16;
use cuda_core::{DeviceBuffer, Stream};
use infinity_v3_backend_core::BackendError;
use serde::Serialize;
use std::path::Path;

fn infer(error: impl std::fmt::Display) -> BackendError {
    BackendError::Inference(format!("Oxide Qwen3.5 layer0 trace: {error}"))
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct TracePoint {
    pub(crate) name: String,
    pub(crate) dtype: String,
    pub(crate) buffer_elements: usize,
    pub(crate) elements: usize,
    pub(crate) shape: Vec<usize>,
    pub(crate) words_u32: Vec<u32>,
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct Layer0Trace {
    pub(crate) schema: &'static str,
    pub(crate) status: &'static str,
    pub(crate) tokens: usize,
    pub(crate) hidden: usize,
    pub(crate) stop_after_layer0: bool,
    pub(crate) note: &'static str,
    pub(crate) points: Vec<TracePoint>,
}

pub(crate) struct Layer0TraceBuilder {
    tokens: usize,
    hidden: usize,
    points: Vec<TracePoint>,
}

impl Layer0TraceBuilder {
    pub(crate) fn new(tokens: usize, hidden: usize) -> Self {
        Self {
            tokens,
            hidden,
            points: Vec::new(),
        }
    }

    fn record(
        &mut self,
        name: &str,
        dtype: &str,
        buffer_elements: usize,
        elements: usize,
        shape: Vec<usize>,
        words_u32: Vec<u32>,
    ) -> Result<(), BackendError> {
        let expected = shape.iter().try_fold(1usize, |total, value| {
            total
                .checked_mul(*value)
                .ok_or_else(|| infer("shape extent overflow"))
        })?;
        if expected != elements || words_u32.len() != elements || elements > buffer_elements {
            return Err(infer(format!(
                "{name} shape/elements/buffer lengths disagree: shape product {expected}, elements {elements}, words {}, buffer {buffer_elements}",
                words_u32.len()
            )));
        }
        self.points.push(TracePoint {
            name: name.to_owned(),
            dtype: dtype.to_owned(),
            buffer_elements,
            elements,
            shape,
            words_u32,
        });
        Ok(())
    }

    pub(crate) fn push_bf16_prefix(
        &mut self,
        name: &str,
        buffer: &DeviceBuffer<Bf16>,
        stream: &Stream,
        prefix: usize,
        shape: Vec<usize>,
    ) -> Result<(), BackendError> {
        if prefix > buffer.len() {
            return Err(infer(format!(
                "{name} prefix {prefix} exceeds buffer {}",
                buffer.len()
            )));
        }
        // to_host_vec synchronizes on the diagnostic stream before returning.
        // On a failed fence it retains (leaks) the host Vec and storage lease
        // rather than dropping pageable memory under an in-flight DMA.
        let host = buffer.to_host_vec(stream).map_err(infer)?;
        let words = host
            .iter()
            .take(prefix)
            .map(|v| u32::from(v.to_bits()))
            .collect();
        self.record(name, "bf16", buffer.len(), prefix, shape, words)
    }

    pub(crate) fn push_bf16_range(
        &mut self,
        name: &str,
        buffer: &DeviceBuffer<Bf16>,
        stream: &Stream,
        range: std::ops::Range<usize>,
        shape: Vec<usize>,
    ) -> Result<(), BackendError> {
        if range.start > range.end || range.end > buffer.len() {
            return Err(infer(format!(
                "{name} range {range:?} exceeds buffer {}",
                buffer.len()
            )));
        }
        let host = buffer.to_host_vec(stream).map_err(infer)?;
        let words = host[range.clone()]
            .iter()
            .map(|v| u32::from(v.to_bits()))
            .collect();
        self.record(name, "bf16", buffer.len(), range.len(), shape, words)
    }

    pub(crate) fn push_half_bf16_prefix(
        &mut self,
        name: &str,
        buffer: &DeviceBuffer<half::bf16>,
        stream: &Stream,
        prefix: usize,
        shape: Vec<usize>,
    ) -> Result<(), BackendError> {
        if prefix > buffer.len() {
            return Err(infer(format!(
                "{name} prefix {prefix} exceeds buffer {}",
                buffer.len()
            )));
        }
        let host = buffer.to_host_vec(stream).map_err(infer)?;
        let words = host
            .iter()
            .take(prefix)
            .map(|v| u32::from(v.to_bits()))
            .collect();
        self.record(name, "bf16", buffer.len(), prefix, shape, words)
    }

    pub(crate) fn push_f32_prefix(
        &mut self,
        name: &str,
        buffer: &DeviceBuffer<f32>,
        stream: &Stream,
        prefix: usize,
        shape: Vec<usize>,
    ) -> Result<(), BackendError> {
        if prefix > buffer.len() {
            return Err(infer(format!(
                "{name} prefix {prefix} exceeds buffer {}",
                buffer.len()
            )));
        }
        let host = buffer.to_host_vec(stream).map_err(infer)?;
        let words = host.iter().take(prefix).map(|v| v.to_bits()).collect();
        self.record(name, "f32", buffer.len(), prefix, shape, words)
    }

    pub(crate) fn push_u32_prefix(
        &mut self,
        name: &str,
        buffer: &DeviceBuffer<u32>,
        stream: &Stream,
        prefix: usize,
        shape: Vec<usize>,
    ) -> Result<(), BackendError> {
        if prefix > buffer.len() {
            return Err(infer(format!(
                "{name} prefix {prefix} exceeds buffer {}",
                buffer.len()
            )));
        }
        let host = buffer.to_host_vec(stream).map_err(infer)?;
        let words = host.iter().take(prefix).copied().collect();
        self.record(name, "u32", buffer.len(), prefix, shape, words)
    }

    pub(crate) fn finish(self) -> Layer0Trace {
        Layer0Trace {
            schema: "oxide-q35moe-layer0-trace/v1",
            status: "ok",
            tokens: self.tokens,
            hidden: self.hidden,
            stop_after_layer0: true,
            note: "diagnostic instrumented fence; not a performance or warm-path claim",
            points: self.points,
        }
    }

    pub(crate) fn write(&self, path: &Path) -> Result<(), BackendError> {
        let trace = Layer0Trace {
            schema: "oxide-q35moe-layer0-trace/v1",
            status: "ok",
            tokens: self.tokens,
            hidden: self.hidden,
            stop_after_layer0: true,
            note: "diagnostic instrumented fence; not a performance or warm-path claim",
            points: self.points.clone(),
        };
        let data = serde_json::to_vec(&trace)
            .map_err(|error| infer(format!("serialize layer0 trace: {error}")))?;
        let temporary = path.with_extension("json.tmp");
        std::fs::write(&temporary, data)
            .map_err(|error| infer(format!("write {}: {error}", temporary.display())))?;
        std::fs::rename(&temporary, path)
            .map_err(|error| infer(format!("rename {}: {error}", path.display())))
    }

    #[cfg(test)]
    pub(crate) fn record_words_for_test(
        &mut self,
        name: &str,
        dtype: &str,
        shape: Vec<usize>,
        words: Vec<u32>,
    ) -> Result<(), BackendError> {
        let elements = words.len();
        self.record(name, dtype, elements, elements, shape, words)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn full_capacity_copies_are_zero_initialized_at_source() {
        let engine = include_str!("qwen35_moe_engine.rs");
        for allocation in [
            "DeviceBuffer::zeroed(stream, layout.hidden_elements)",
            "DeviceBuffer::zeroed(stream, layout.projection_elements)",
            "DeviceBuffer::zeroed(stream, layout.activation_elements)",
        ] {
            assert!(engine.contains(allocation), "{allocation}");
        }
        let gdn = include_str!("gdn_prepared.rs");
        for allocation in [
            "DeviceBuffer::zeroed(stream, layout.convolution_elements())",
            "DeviceBuffer::zeroed(stream, layout.qk_elements())",
            "DeviceBuffer::zeroed(stream, layout.decay_beta_elements())",
            "DeviceBuffer::zeroed(stream, layout.recurrence_elements())",
            "DeviceBuffer::zeroed(stream, layout.output_elements())",
        ] {
            assert!(gdn.contains(allocation), "{allocation}");
        }
    }

    #[test]
    fn projection_hook_is_after_join_and_before_output_projection() {
        let enqueue = include_str!("qwen35_execute/enqueue.rs");
        let join = enqueue.find("aux.join").expect("join launch");
        let hook = enqueue
            .find("trace_hook.as_mut()")
            .expect("projection hook call");
        let output = enqueue
            .find("let projected_input = match prepared")
            .expect("output projection");
        assert!(join < hook && hook < output);
        let full = include_str!("qwen35_moe_full.rs");
        let projection = full
            .find("gdn_qkv_projection")
            .expect("projection trace point");
        let attention_call = full
            .find("attention.enqueue_attention")
            .expect("attention enqueue");
        assert!(projection < attention_call);
    }

    #[test]
    fn builder_records_exact_words_and_rejects_shape_mismatch() {
        let mut builder = Layer0TraceBuilder::new(7, 2048);
        builder
            .record_words_for_test("moe_top_weights", "f32", vec![7, 8], vec![0; 56])
            .unwrap();
        let trace = builder.finish();
        assert!(trace.stop_after_layer0);
        assert_eq!(trace.points.len(), 1);
        assert_eq!(trace.points[0].elements, 56);
        let mut bad = Layer0TraceBuilder::new(7, 2048);
        assert!(bad
            .record_words_for_test("bad", "f32", vec![7, 8], vec![0; 55])
            .is_err());
    }
}
