# Qwen3.5-MoE layer0 Rust diagnostic V2

Status: **actual/Rust diagnostic code, CPU-checked; Root GPU trace pending.**
V1 and V3b are preserved and untouched. V2 is the only successor source.

## Blocker fixed

V1 captured `gdn_qkv_projection` after `attention.enqueue_attention`, but that
call ends with `blas.linear_bound(output)` writing `projection[0..T*H]` over the
qkv projection at `projection[0..T*channels]`. V1 therefore traced overwritten
words.

V2 adds a compile-time optional `LinearTraceHook` to the actual linear-attention
enqueue helper. The hook runs immediately after the four projections + `join`
launch and before `let projected_input = ...` / the output projection. It uses
the prepared frame's actual `qkv`/`z`/`ab` ranges, not renamed overwritten data.
Production passes `None` and is unchanged.

Source-order tests prove:
- `aux.join` < projection hook < `let projected_input`;
- the `gdn_qkv_projection` point is declared before `attention.enqueue_attention`.

GDN core buffers (conv/qk/decay-beta/recurrence/norm output) are captured while
live after attention/post and before FFN. `attention_residual` is captured after
`enqueue_post`; `moe_final_residual` is captured after the layer0 FFN residual.
Router BF16 logits, FP32 scores, routed output, shared gate logits and shared
down output are captured from their actual typed scratch owners. Top-k id/weight
workspace remains skipped because no typed owner exposes it.

Full-capacity `DeviceBuffer::to_host_vec` is used with exact range slicing. A
source proof test pins that every copied slab/core allocation is
`DeviceBuffer::zeroed` at construction, so capacity tails are initialized zeros.
The actual helper synchronizes and retains/leaks host Vec and storage lease on a
failed fence instead of dropping pageable memory under in-flight DMA.

## Concrete modified paths versus V1

- `repo/libs/infinity-v3/backends/oxide/src/qwen35_execute.rs`
- `repo/libs/infinity-v3/backends/oxide/src/qwen35_execute/enqueue.rs`
- `repo/libs/infinity-v3/backends/oxide/src/qwen35_moe_full.rs`
- `repo/libs/infinity-v3/backends/oxide/src/qwen35_layer0_trace.rs`
- `consumer/Cargo.toml` (dependency path to V2 repo)

Full V2 implementation paths also include the V1 files:
`oxide/Cargo.toml`, `oxide/src/lib.rs`, `qwen35_moe_engine.rs`,
`qwen35_moe_factory.rs`, `gdn_prepared.rs`, and consumer `src/lib.rs`,
`src/cli.rs`, `src/trace.rs`, `tests/cpu.rs`.

Patches:
- `SELECTIVE.patch` `c93a169f1aadf1081440512692f34a989e519c47662f83a49ef41328e76d2d54`
  (V3b repo + v4e consumer -> V2, 14 files)
- `V1-V2-DELTA.patch` `d69a212ad9315713d901e325769585bd8db4ec173b5382e9c1bfced65fd19926`
  (V1 -> V2, 5 files)

Both patches were applied to copies and reproduce the V2 trees exactly.

## CPU evidence (cores 100-103, jobs 2, offline, CVD empty)

- Default `cargo check -p infinity-backend-oxide` pass.
- Feature `cargo check ... --features layer0-trace` pass.
- `qwen35_moe` feature tests: 76 passed.
- `qwen35_layer0_trace` feature tests: 3 passed (word/shape, source-order,
  zero-initialized tail proof).
- Oxide clippy `--all-targets --features layer0-trace -- -D warnings` pass.
- Consumer default/feature check pass; consumer feature tests 15 passed.
- Product and consumer fmt pass.

No optimized build, GPU, CUDA context, device compile, Torch, Docker, network,
weights, Native gold or runtime output was used.

## Next

Native SDK still needs its own bounded actual b66 exported helper. Prefer a
small source helper/interposition using the actual `qwen35_reference_norm_cuda`,
`qwen35_reference_delta_cuda`, `routed_moe_cuda`, `gemma_gated_cuda` and exact
source at::linear stages for a first-layer GDN/MLP capture, rather than a full
SDK rebuild or invented `tei_trace` ABI. GDN final capture is the minimum.
