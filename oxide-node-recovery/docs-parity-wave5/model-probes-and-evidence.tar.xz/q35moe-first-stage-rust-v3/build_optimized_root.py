#!/usr/bin/env python3
"""One Root-granted optimized CPU build, with exact source and artifact pins."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
TARGET = Path("/tmp/oxide-q35moe-layer0-v3-opt3-target-v1")
CACHE = Path("/tmp/oxide-q35moe-unified-v4e-opt3-target-v1")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pins():
    return {str(p.relative_to(ROOT)): digest(p)
            for base in ("repo", "consumer", "fixtures") for p in (ROOT / base).rglob("*")
            if p.is_file() and not any(part in (".git", "__pycache__") or part.startswith("target")
                                       for part in p.relative_to(ROOT).parts) and p.suffix != ".pyc"}


def main():
    report_path = ROOT / "OPTIMIZED-BUILD.json"
    if report_path.exists() or TARGET.exists():
        raise SystemExit("one-build grant: refusing existing build report or output target")
    before = pins()
    (ROOT / "SOURCE-BEFORE.json").write_text(json.dumps(before, indent=2) + "\n")
    TARGET.mkdir()
    started = time.monotonic()
    if (CACHE / "release").is_dir():
        subprocess.run(["cp", "-a", "--reflink=auto", str(CACHE / "release"), str(TARGET / "release")], check=True)
    cache_seconds = time.monotonic() - started
    env = os.environ.copy()
    env.update({"CUDA_VISIBLE_DEVICES": "", "CARGO_NET_OFFLINE": "true", "CARGO_BUILD_JOBS": "2",
                "CARGO_TARGET_DIR": str(TARGET), "CARGO_INCREMENTAL": "0", "RUSTFLAGS": "",
                "CARGO_ENCODED_RUSTFLAGS": "", "CARGO_PROFILE_RELEASE_OPT_LEVEL": "3",
                "CARGO_PROFILE_RELEASE_LTO": "false", "CARGO_PROFILE_RELEASE_DEBUG": "1",
                "CARGO_PROFILE_RELEASE_CODEGEN_UNITS": "16", "CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS": "false"})
    argv = ["taskset", "-c", "104-107", "cargo", "+1.93.1", "build", "--release", "--offline", "--locked",
            "--jobs", "2", "--features", "layer0-trace", "--manifest-path", str(ROOT / "consumer/Cargo.toml"),
            "--message-format=json-render-diagnostics"]
    report = {"schema": "q35-layer0-v3-root-optimized-build/v1", "status": "running", "argv": argv,
              "target": str(TARGET), "cache_from": str(CACHE), "cache_copy_seconds": cache_seconds,
              "source_before_files": len(before), "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "profile": {"opt_level": 3, "lto": False, "debug": 1, "codegen_units": 16,
                          "debug_assertions": False, "panic": "abort"}, "cuda_visible_devices": ""}
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    started = time.monotonic()
    with (ROOT / "optimized-build.jsonl").open("w") as stdout, (ROOT / "optimized-build.stderr").open("w") as stderr:
        result = subprocess.run(argv, cwd=ROOT / "consumer", env=env, stdout=stdout, stderr=stderr)
    after = pins()
    (ROOT / "SOURCE-AFTER.json").write_text(json.dumps(after, indent=2) + "\n")
    changed = [name for name in before.keys() | after.keys() if before.get(name) != after.get(name)]
    report.update(exit_code=result.returncode, wall_seconds=time.monotonic() - started,
                  source_changed_paths=changed, status="failed")
    artifact = None
    for line in (ROOT / "optimized-build.jsonl").read_text().splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (item.get("reason") == "compiler-artifact" and item.get("target", {}).get("name") == "q35moe-unified-runtime"
                and item.get("executable")):
            artifact = Path(item["executable"])
            report["cargo_artifact_profile"] = item.get("profile")
    if result.returncode == 0 and not changed and artifact and artifact.is_file():
        dest = ROOT / "artifacts/q35moe-unified-runtime"
        dest.parent.mkdir()
        shutil.copy2(artifact, dest)
        report.update(status="passed", artifact={"path": str(dest), "sha256": digest(dest), "bytes": dest.stat().st_size})
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("status", "wall_seconds", "source_changed_paths")}))
    if report["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
