Corrected Rustlayer0V3 diagnostic successor, all980productsourcefiles byte-identicalV2.
Onlyconsumerdependencyabsolutepaths/traceCLIdispatch/testchanged. TraceLayer0now
earlyreturns actualtracewriter, preventinggenericReportfromoverwritingitsJSON.
MeaningfulusedCLIregression proves anexistingartifact survivestracefailure.
15CPUconsumertests PASS. ONE Rootgrantedopt3/noLTO/debug1/CGU16build PASS42.94s,
zero sourcebefore/afterchanges. OptimizedCLIvalidate-only andrealmodelmetadata
both passwithCVDempty; exactsevenT7fields matchsavedacceptedNativebatch.

Artifactartifacts/q35moe-unified-runtime SHA6e2f0c64708f7bbe55b3fa20cd2468a1e67746f30ed50dd501c193ceae4949f4.
ActualNativeV7trace12observedpoints438144B,full2048NativeT7exact, norms3/GDN1/
routed1/residual0. All12payloadextents/types/shapes/hashesaresealed, comparator
isbyte-identicalV2 (96f306fb...) andcompares10commonpoints. NoBF16attentiongate
patchmixed; sameV3bmath/Rootruntimeproviders+referenceCUDApins preserved.

Rootcommand (controlleracquiresGPU0lockitself; doNOTwrapinsecondflock):
python3 /tmp/oxide-docs-parity-20261102/q35moe-first-stage-rust-v3/run_root_trace.py --run --out /tmp/oxide-docs-parity-20261102/q35moe-first-stage-rust-v3/root-layer0-v1

Defaultwithout--run performsCPUinput/hashpreflightonly. Actualrunloadsoneengine,
tracesonlylayer0,thensource/runtime/nativepinsarerechecked andsame10commonpoint
comparison.json iswritten. Reportstatuscompleted-different isdiagnosticfinding,
notservingqualitypass. NoGPUperformedbycoordinator. Do nottuneMath/thresholds
untilfirstdivergencepoint isknown. Wholemodelquality/life/perfremainunqualified.
