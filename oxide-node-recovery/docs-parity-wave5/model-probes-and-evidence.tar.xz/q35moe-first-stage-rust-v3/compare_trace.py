"""Offline comparison of actual bounded SDK/Rust trace payloads; no GPU imports."""
import argparse
import json
from pathlib import Path
import struct

ORDER = (
    ('embedding', 'embedding'), ('pre_norm', 'pre_norm'),
    ('gdn_qkv_projection', 'gdn_qkv_projection'),
    ('gdn_z_projection', 'gdn_z_projection'), ('gdn_ab_projection', 'gdn_ab_projection'),
    ('gdn_norm_output', 'gdn_norm_output'), ('attention_residual', 'attention_residual'),
    ('moe_router_logits_f32', 'moe_router_scores_f32'),
    ('moe_expert_output', 'moe_expert_output'), ('moe_final_residual', 'moe_final_residual'),
)


def unique(items):
    result = {}
    for item in items:
        name = item['name']
        if name in result:
            raise ValueError('duplicate trace point: ' + name)
        result[name] = item
    return result


def extent(shape):
    count = 1
    if not shape:
        raise ValueError('trace shape must describe a matrix/tensor')
    for dim in shape:
        if type(dim) is not int or dim <= 0:
            raise ValueError('invalid trace extent')
        count *= dim
        if count > 262144:
            raise ValueError('trace extent exceeds diagnostic bound')
    return count


def compare(native_dir, rust_path):
    native_dir = Path(native_dir)
    native = json.loads((native_dir / 'trace.json').read_text())
    rust = json.loads(Path(rust_path).read_text())
    if native.get('schema') != 'q35moe-native-layer0-trace/v1' or native.get('status') != 'captured':
        raise ValueError('actual Native trace was not captured')
    if rust.get('schema') != 'oxide-q35moe-layer0-trace/v1' or rust.get('status') != 'ok':
        raise ValueError('actual Rust trace did not complete')
    if rust.get('tokens') != 7 or rust.get('hidden') != 2048 or rust.get('stop_after_layer0') is not True:
        raise ValueError('Rust diagnostic geometry differs')
    if native.get('hook_counts', {}).get('gdn') != 1 or native['hook_counts'].get('routed') != 1:
        raise ValueError('actual first-layer hook count proof missing')
    npoints, rpoints = unique(native['points']), unique(rust['points'])
    records = []
    for nn, rn in ORDER:
        n, r = npoints[nn], rpoints[rn]
        count = extent(n['shape'])
        if r['shape'] != n['shape'] or r['dtype'] != n['dtype'] or r['elements'] != count:
            raise ValueError('shape/dtype mismatch: ' + nn)
        if n['dtype'] not in ('bf16', 'f32'):
            raise ValueError('unsupported trace dtype')
        size, fmt = (2, 'H') if n['dtype'] == 'bf16' else (4, 'I')
        payload = (native_dir / (nn + '.bin')).read_bytes()
        if n['bytes'] != count * size or len(payload) != n['bytes']:
            raise ValueError('Native payload extent mismatch: ' + nn)
        words = [x[0] for x in struct.iter_unpack('<' + fmt, payload)]
        actual = r['words_u32']
        if len(actual) != count or any(type(x) is not int or not 0 <= x < 1 << (size * 8) for x in actual):
            raise ValueError('Rust payload word range mismatch: ' + nn)
        diffs = [i for i, (a, b) in enumerate(zip(words, actual)) if a != b]
        records.append(dict(point=nn, elements=count, differences=len(diffs), first_difference=diffs[0] if diffs else None))
    first = next((r['point'] for r in records if r['differences']), None)
    return dict(status='different' if first else 'exact', first_divergence=first, points=records,
                scope='diagnostic intermediate words only; no serving qualification or timing')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-dir', type=Path, required=True)
    parser.add_argument('--rust', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = compare(args.native_dir, args.rust)
    if args.output.exists():
        raise ValueError('fresh diagnostic comparison output required')
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status=result['status'], first_divergence=result['first_divergence'])))


if __name__ == '__main__':
    main()
