#![allow(unused_imports)]
use crate::cli::{ensure_model_is_directory, Args};
use crate::fixtures::{backend_batch, load_cases};
use infinity_backend_oxide::Qwen35MoeBackend;
use infinity_v3_backend::ModelType;
use serde_json::json;

#[cfg(feature = "layer0-trace")]
pub fn run(args: &Args) -> Result<(), String> {
    let model = args
        .model
        .as_ref()
        .ok_or_else(|| "--model is required".to_string())?;
    ensure_model_is_directory(model)?;
    let pool = args
        .pool
        .clone()
        .ok_or_else(|| "--pool is required".to_string())?;
    let cases = load_cases(&args.cases, args.limit)?;
    let item = cases
        .iter()
        .find(|case| case.case.name == "t7_a")
        .ok_or_else(|| "trace-layer0 requires the t7_a fixture".to_string())?;
    if !item.case.valid {
        return Err("trace-layer0 t7_a fixture is not valid".into());
    }
    let backend = Qwen35MoeBackend::new(model, "bfloat16", ModelType::Embedding(pool.clone()), 0)
        .map_err(|error| error.to_string())?;
    let batch = backend_batch(item)?;
    backend
        .trace_layer0(&batch, &args.report)
        .map_err(|error| error.to_string())?;
    println!(
        "{}",
        json!({
            "schema": "oxide-q35moe-trace-layer0-summary/v1",
            "status": "ok",
            "pool": pool.to_string(),
            "fixture": "t7_a",
            "trace": args.report.display().to_string(),
            "stop_after_layer0": true,
            "diagnostic_only": true,
        })
    );
    Ok(())
}

#[cfg(not(feature = "layer0-trace"))]
pub fn run(_args: &Args) -> Result<(), String> {
    Err("trace-layer0 requires building q35moe-unified-runtime with --features layer0-trace".into())
}
