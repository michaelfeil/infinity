// CPU-only test that compiles and executes the exact production helper source
// used by the corrected Qwen3.5-VL BF16 position-interpolation device export.
//
// Run with:
//   ~/.cargo/bin/rustc --edition 2021 --test \
//     libs/infinity-v3/backends/oxide/device/tests/pos_math_actual.rs \
//     -o /tmp/pos_math_actual
//   /tmp/pos_math_actual --nocapture
//
// It reads only the actual trained `model.visual.pos_embed.weight` rows from
// the frozen 0.8B safetensors checkpoint and the exact fixture metadata. No
// Torch, GPU, CUDA context, network, Docker, or model forward is used.

#[path = "../src/qwen35vl_pos_math.rs"]
mod pos_math;

use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;

const MODEL: &str = "/workspace/model-performance/michaelfeil/onejev-perf/backbone-comparison-20261023/models/Qwen3.5-0.8B";
const ST: &str = "/workspace/model-performance/michaelfeil/onejev-perf/backbone-comparison-20261023/models/Qwen3.5-0.8B/model.safetensors-00001-of-00001.safetensors";
const H: usize = 30;
const W: usize = 40;
const MERGE: usize = 2;
const HID: usize = 768;
const SIDE: usize = 48;

fn fnv64(values: &[u16]) -> u64 {
    let mut hash = 14695981039346656037u64;
    for value in values {
        for byte in value.to_le_bytes() {
            hash ^= byte as u64;
            hash = hash.wrapping_mul(1099511628211);
        }
    }
    hash
}

struct Table {
    file: File,
    base: u64,
}

impl Table {
    fn open(path: &Path) -> Self {
        let mut file = File::open(path).expect("open actual safetensors checkpoint");
        let mut length = [0u8; 8];
        file.read_exact(&mut length).expect("read header length");
        let length = u64::from_le_bytes(length) as usize;
        let mut header = vec![0u8; length];
        file.read_exact(&mut header).expect("read header");
        let header = String::from_utf8(header).expect("utf8 header");
        let key = "\"model.visual.pos_embed.weight\"";
        let start = header.find(key).expect("pos_embed header entry");
        let tail = &header[start..];
        let offsets = tail.find("\"data_offsets\"").expect("data_offsets");
        let after = &tail[offsets..];
        let open = after.find('[').expect("offset array") + 1;
        let close = after.find(']').expect("offset array end");
        let numbers: Vec<u64> = after[open..close]
            .split(',')
            .map(|item| item.trim().parse().expect("offset integer"))
            .collect();
        assert_eq!(numbers.len(), 2);
        Self {
            file,
            base: 8 + length as u64 + numbers[0],
        }
    }

    fn row(&mut self, row: usize) -> Vec<u16> {
        self.file
            .seek(SeekFrom::Start(self.base + (row * HID * 2) as u64))
            .expect("seek row");
        let mut bytes = vec![0u8; HID * 2];
        self.file.read_exact(&mut bytes).expect("read row");
        bytes
            .chunks_exact(2)
            .map(|pair| u16::from_le_bytes([pair[0], pair[1]]))
            .collect()
    }
}

#[derive(Clone, Copy)]
struct Case {
    token: usize,
    patch: usize,
    r0: usize,
    c0: usize,
    r1: usize,
    c1: usize,
    dr: f32,
    dc: f32,
    native_fn64: u64,
    runtime130_fn64: u64,
}

const CASES: &[Case] = &[
    Case {
        token: 0,
        patch: 0,
        r0: 0,
        c0: 0,
        r1: 0,
        c1: 0,
        dr: 0.0,
        dc: 0.0,
        native_fn64: 0x2e7bfea6b2f75a33,
        runtime130_fn64: 0x2e7bfea6b2f75a33,
    },
    Case {
        token: 0,
        patch: 1,
        r0: 0,
        c0: 1,
        r1: 0,
        c1: 2,
        dr: 0.0,
        dc: 0.20512819290161133,
        native_fn64: 0x6141abcbd3d3f93b,
        runtime130_fn64: 0x6141abcbd3d3f93b,
    },
    Case {
        token: 0,
        patch: 2,
        r0: 1,
        c0: 0,
        r1: 2,
        c1: 0,
        dr: 0.6206896305084229,
        dc: 0.0,
        native_fn64: 0xfc1d992780d020ff,
        runtime130_fn64: 0xfc1d992780d020ff,
    },
    Case {
        token: 0,
        patch: 3,
        r0: 1,
        c0: 1,
        r1: 2,
        c1: 2,
        dr: 0.6206896305084229,
        dc: 0.20512819290161133,
        native_fn64: 0x72c43508e7948023,
        runtime130_fn64: 0x9a66900b7119e6a2,
    },
    Case {
        token: 1,
        patch: 6,
        r0: 1,
        c0: 2,
        r1: 2,
        c1: 3,
        dr: 0.6206896305084229,
        dc: 0.41025638580322266,
        native_fn64: 0xcc91ccd27292a6e0,
        runtime130_fn64: 0x2a5b862443f1f04d,
    },
    Case {
        token: 1,
        patch: 7,
        r0: 1,
        c0: 3,
        r1: 2,
        c1: 4,
        dr: 0.6206896305084229,
        dc: 0.615384578704834,
        native_fn64: 0x488a37c96db7b0ce,
        runtime130_fn64: 0x454e6b6a0b4afde0,
    },
    Case {
        token: 150,
        patch: 600,
        r0: 22,
        c0: 24,
        r1: 23,
        c1: 25,
        dr: 0.6896553039550781,
        dc: 0.10256385803222656,
        native_fn64: 0x2aed6392e2b76212,
        runtime130_fn64: 0x4ffb96769894ab76,
    },
    Case {
        token: 294,
        patch: 1176,
        r0: 45,
        c0: 33,
        r1: 46,
        c1: 34,
        dr: 0.37931060791015625,
        dc: 0.74359130859375,
        native_fn64: 0x585010d0a7d3e245,
        runtime130_fn64: 0x398e0e6f889f981f,
    },
    Case {
        token: 299,
        patch: 1196,
        r0: 45,
        c0: 45,
        r1: 46,
        c1: 46,
        dr: 0.37931060791015625,
        dc: 0.7948722839355469,
        native_fn64: 0xc125a31a450d4bfa,
        runtime130_fn64: 0x613d3c68a20d5c4b,
    },
];

#[test]
fn actual_trained_rows_match_native_bf16_single_round() {
    let path = Path::new(ST);
    if !path.is_file() {
        eprintln!("SKIP: actual checkpoint absent at {ST}");
        return;
    }
    assert!(Path::new(MODEL).join("config.json").is_file());
    let mut table = Table::open(path);
    let mut differing = 0;
    for case in CASES {
        let geometry =
            pos_math::geometry(case.patch, SIDE, H, W, MERGE).expect("valid actual geometry");
        assert_eq!(
            (geometry.r0, geometry.c0, geometry.r1, geometry.c1),
            (case.r0, case.c0, case.r1, case.c1),
            "token {} patch {} corners",
            case.token,
            case.patch
        );
        assert_eq!(geometry.w00, (1.0 - case.dr) * (1.0 - case.dc));
        assert_eq!(geometry.w01, (1.0 - case.dr) * case.dc);
        assert_eq!(geometry.w10, case.dr * (1.0 - case.dc));
        assert_eq!(geometry.w11, case.dr * case.dc);
        let rows = [
            table.row(case.r0 * SIDE + case.c0),
            table.row(case.r0 * SIDE + case.c1),
            table.row(case.r1 * SIDE + case.c0),
            table.row(case.r1 * SIDE + case.c1),
        ];
        let mut native = Vec::with_capacity(HID);
        for column in 0..HID {
            native.push(pos_math::interpolate_bf16(
                rows[0][column],
                rows[1][column],
                rows[2][column],
                rows[3][column],
                geometry.w00,
                geometry.w01,
                geometry.w10,
                geometry.w11,
            ));
        }
        let native_hash = fnv64(&native);
        assert_eq!(
            native_hash, case.native_fn64,
            "actual helper output diverges from Native BF16 on token {} patch {}",
            case.token, case.patch
        );
        if native_hash != case.runtime130_fn64 {
            differing += 1;
        }
        let state = pos_math::bf16_from_f32(0.25);
        assert_eq!(
            pos_math::add_residual_bf16(state, native[0]),
            pos_math::bf16_from_f32(
                pos_math::f32_from_bf16(state) + pos_math::f32_from_bf16(native[0])
            )
        );
    }
    assert_eq!(
        differing, 6,
        "expected six actual patches where runtime130 differs"
    );
    eprintln!(
        "actual helper: {differing}/{} sampled patches differ from runtime130",
        CASES.len()
    );
}

#[test]
fn bf16_rounding_matches_expected_bits() {
    assert_eq!(pos_math::bf16_from_f32(1.0), 0x3f80);
    assert_eq!(pos_math::bf16_from_f32(-2.0), 0xc000);
    assert_eq!(pos_math::bf16_from_f32(f32::INFINITY), 0x7f80);
    assert_eq!(pos_math::bf16_from_f32(f32::NEG_INFINITY), 0xff80);
    assert!(f32::from_bits((pos_math::bf16_from_f32(f32::NAN) as u32) << 16).is_nan());
    assert_eq!(pos_math::f32_from_bf16(0x3f80), 1.0);
}
