// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Native-exact gated activation formulas for Mistral3/Pixtral.
//!
//! Device-independent so the host test compiles this exact file. The device
//! leaf supplies `libm` f32 `expf`/`tanhf`/`erff` and the BF16 convert
//! intrinsic; the host test supplies the same `libm` functions and the same
//! round-to-nearest-even BF16 contract.
//!
//! Native actual source: `libs/infinity-v3/backends/libtorch/cpp/kernels/
//! fast_kernels.cu::gated_value` and `fused_gated_activation`. The Mistral3
//! vision tower calls `fused_gated_activation(rows, silu ? 0 : 1)`:
//!
//! * activation 0 (SiLU): `gate / (1.f + expf(-gate))`
//! * activation 1 (exact GELU): `.5f * gate * (1.f + erff(gate * .7071067811865475f))`
//! * activation 2 (tanh GELU): `.5f * gate * (1.f + tanhf(.7978845608028654f *
//!   (gate + .044715f * gate * gate * gate)))`
//!
//! Every branch computes in f32, rounds the activation to the model dtype
//! (`T(activated)`), multiplies by the up operand in f32, then rounds the
//! product to BF16. There is no approximation substitution: mode 0 uses `erf`,
//! not the tanh approximation.
#![allow(dead_code)]

/// Public device-export mode: 0 exact GELU, 1 tanh GELU, 2 SiLU.
pub(crate) const MODE_EXACT_GELU: u32 = 0;
pub(crate) const MODE_TANH_GELU: u32 = 1;
pub(crate) const MODE_SILU: u32 = 2;

/// F32 words of the exact Native literals
/// `0.7071067811865475f`, `0.7978845608028654f`, `0.044715f`.
pub(crate) const ERF_SCALE: f32 = f32::from_bits(0x3F35_04F3);
pub(crate) const TANH_SCALE: f32 = f32::from_bits(0x3F4C_422A);
pub(crate) const TANH_CUBIC: f32 = f32::from_bits(0x3D37_2713);

pub(crate) trait ActivationOps {
    fn expf(value: f32) -> f32;
    fn tanhf(value: f32) -> f32;
    fn erff(value: f32) -> f32;
    fn from_bf16(bits: u16) -> f32;
    fn to_bf16(value: f32) -> u16;
}

/// Native activation before the model-dtype rounding and gated multiply.
#[inline(always)]
pub(crate) fn activation<O: ActivationOps>(gate: f32, mode: u32) -> f32 {
    match mode {
        MODE_TANH_GELU => {
            0.5f32
                * gate
                * (1.0f32 + O::tanhf(TANH_SCALE * (gate + TANH_CUBIC * gate * gate * gate)))
        }
        MODE_SILU => gate / (1.0f32 + O::expf(-gate)),
        // Exact GELU for every other mode, matching the repository's mode 0
        // contract and Native activation code 1.
        _ => 0.5f32 * gate * (1.0f32 + O::erff(gate * ERF_SCALE)),
    }
}

/// Activation rounded to the model dtype, as an f32 holder of the BF16 value.
#[inline(always)]
pub(crate) fn rounded_activation<O: ActivationOps>(gate: f32, mode: u32) -> f32 {
    O::from_bf16(O::to_bf16(activation::<O>(gate, mode)))
}

/// One gated element: rounded activation multiplied by `up`, rounded once.
#[inline(always)]
pub(crate) fn gated<O: ActivationOps>(gate: u16, up: u16, mode: u32) -> u16 {
    let gate = O::from_bf16(gate);
    let up = O::from_bf16(up);
    O::to_bf16(rounded_activation::<O>(gate, mode) * up)
}

/// One ungated activation element, rounded once to the model dtype.
#[inline(always)]
pub(crate) fn single<O: ActivationOps>(input: u16, mode: u32) -> u16 {
    let value = O::from_bf16(input);
    O::to_bf16(rounded_activation::<O>(value, mode))
}
