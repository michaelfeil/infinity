// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Source-derived ATen 5c488 global-reduction geometry for the Mistral3 mean.
//!
//! Device-independent so the host test can compile and exercise this exact file
//! while the device leaf uses it unchanged.
//!
//! For a contiguous `[T, H]` BF16 dim-0 reduction with `H % 4 == 0`,
//! `H >= 128` and an 8-byte-aligned logical base, pinned
//! `Reduce.cuh::setReduceConfig` selects output vectorization (`output_vec_size = 4`, block `32 x 4`, 128 threads,
//! `step_output = 32`). Its `ctas_per_output` then reduces to this formula using
//! the captured `multiProcessorCount` and `maxThreadsPerMultiProcessor` facts.
//! The CTA count is device-dependent and is never hard-coded.
#![allow(dead_code)]

/// Returns 1 when ATen does not enter the global-reduction branch.
#[inline(always)]
pub(crate) fn aten_ctas_per_output(
    rows: u32,
    width: u32,
    num_sm: u32,
    max_threads_per_sm: u32,
) -> u32 {
    if rows < 1021 || num_sm == 0 || max_threads_per_sm < 128 {
        return 1;
    }
    let blocks_per_sm = (max_threads_per_sm / 128) as u64;
    let target = (num_sm as u64) * blocks_per_sm;
    let grid = (width as u64).div_ceil(128);
    if grid == 0 || grid > target {
        return 1;
    }
    let values_per_thread = (rows as u64).div_ceil(4);
    let ctas1 = target.div_ceil(grid);
    let ctas2 = values_per_thread.div_ceil(16);
    let ctas3 = values_per_thread.div_ceil(256);
    let mut ctas = if ctas1 > ctas3 { ctas1 } else { ctas3 };
    if ctas > ctas2 {
        ctas = ctas2;
    }
    if ctas > 1 {
        ctas as u32
    } else {
        1
    }
}

/// The single shared width predicate for the pinned ATen layout above.
/// `src/decoder.rs` compiles this exact file for cold host admission and the
/// device leaf uses it for the kernel comments/tests, so the two cannot drift.
#[inline(always)]
pub(crate) const fn exact_mean_width(width: usize) -> bool {
    width >= 128 && width.is_multiple_of(4)
}
