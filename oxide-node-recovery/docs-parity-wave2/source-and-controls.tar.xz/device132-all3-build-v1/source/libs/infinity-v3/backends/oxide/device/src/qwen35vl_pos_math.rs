// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Pure BF16 arithmetic for Qwen3.5-VL four-corner learned-position
//! interpolation.
//!
//! Native BF16 CUDA (`exact_vision == false`, `multi_vector == false`) executes
//! `corners.sum(0)` in `qwen3_vl_models.cpp`: each scalar interpolation weight
//! is cast to BF16 before the BF16 table multiply, the four BF16 corner
//! products are accumulated in FP32 in stack order `(c00,c01,c10,c11)`, and a
//! single BF16 cast is applied at the end. This module contains the exact
//! production arithmetic used by the corrected device export and has no device
//! or `std` dependency, so a CPU test can compile and execute the same source.

/// Reinterpret stored BF16 bits as an exact FP32 value.
#[inline(always)]
pub fn f32_from_bf16(value: u16) -> f32 {
    f32::from_bits((value as u32) << 16)
}

/// Round FP32 to BF16 using round-to-nearest-even, preserving NaN and Inf.
#[inline(always)]
pub fn bf16_from_f32(value: f32) -> u16 {
    let bits = value.to_bits();
    if bits & 0x7f80_0000 == 0x7f80_0000 {
        return if bits & 0x007f_ffff == 0 {
            (bits >> 16) as u16
        } else {
            0x7fc0
        };
    }
    let least_significant = (bits >> 16) & 1;
    let rounded = bits.wrapping_add(0x7fff + least_significant) & 0xffff_0000;
    (rounded >> 16) as u16
}

/// Round an FP32 value through BF16 and back, matching a BF16 activation cast.
#[inline(always)]
pub fn rounded(value: f32) -> f32 {
    f32_from_bf16(bf16_from_f32(value))
}

/// One Native BF16 corner product: BF16 table value times the BF16-rounded
/// scalar weight, rounded back to BF16.
#[inline(always)]
pub fn corner_product(value: u16, scale: f32) -> f32 {
    rounded(f32_from_bf16(value) * rounded(scale))
}

/// Native BF16 `corners.sum(0)`: four BF16 products accumulated in FP32 stack
/// order with exactly one BF16 rounding at the end.
#[inline(always)]
pub fn interpolate_bf16(
    v00: u16,
    v01: u16,
    v10: u16,
    v11: u16,
    w00: f32,
    w01: f32,
    w10: f32,
    w11: f32,
) -> u16 {
    let c00 = corner_product(v00, w00);
    let c01 = corner_product(v01, w01);
    let c10 = corner_product(v10, w10);
    let c11 = corner_product(v11, w11);
    bf16_from_f32(c00 + c01 + c10 + c11)
}

/// BF16 residual add: `round_bf16(state + positional)`.
#[inline(always)]
pub fn add_residual_bf16(state: u16, positional: u16) -> u16 {
    bf16_from_f32(f32_from_bf16(state) + f32_from_bf16(positional))
}

/// Merge-major patch coordinate decode and the four interpolation corners.
#[derive(Clone, Copy, Debug)]
pub struct PositionGeometry {
    pub r0: usize,
    pub c0: usize,
    pub r1: usize,
    pub c1: usize,
    pub w00: f32,
    pub w01: f32,
    pub w10: f32,
    pub w11: f32,
}

/// Decode one patch row exactly as Native's merge-major coordinate recovery and
/// bilinear corner selection do. Returns `None` for the zero-dimension cases
/// the caller must reject instead of dividing by zero.
pub fn geometry(
    token: usize,
    side: usize,
    height: usize,
    width: usize,
    merge: usize,
) -> Option<PositionGeometry> {
    if merge == 0 || side == 0 || width == 0 || height == 0 {
        return None;
    }
    let frame_patches = height.checked_mul(width)?;
    let spatial = token % frame_patches;
    let merge_area = merge.checked_mul(merge)?;
    let width_blocks = width / merge;
    let height_blocks = height / merge;
    if width_blocks == 0 || height_blocks == 0 {
        return None;
    }
    let column_index = spatial % merge + ((spatial / merge_area) % width_blocks) * merge;
    let row_index =
        (spatial / merge) % merge + ((spatial / (merge * width)) % height_blocks) * merge;
    let row_scale = if height == 1 {
        0.0f32
    } else {
        (side - 1) as f32 / (height - 1) as f32
    };
    let column_scale = if width == 1 {
        0.0f32
    } else {
        (side - 1) as f32 / (width - 1) as f32
    };
    let row = row_index as f32 * row_scale;
    let column = column_index as f32 * column_scale;
    // Non-negative finite coordinates: truncation is floor, and one step above
    // the truncated integer is ceil. This keeps the shared helper free of std
    // float intrinsics so the same source compiles in the CUDA leaf and a plain
    // CPU test.
    let r0 = row as usize;
    let c0 = column as usize;
    let r1 = if row > r0 as f32 {
        (r0 + 1).min(side - 1)
    } else {
        r0.min(side - 1)
    };
    let c1 = if column > c0 as f32 {
        (c0 + 1).min(side - 1)
    } else {
        c0.min(side - 1)
    };
    let dr = row - r0 as f32;
    let dc = column - c0 as f32;
    Some(PositionGeometry {
        r0,
        c0,
        r1,
        c1,
        w00: (1.0 - dr) * (1.0 - dc),
        w01: (1.0 - dr) * dc,
        w10: dr * (1.0 - dc),
        w11: dr * dc,
    })
}
