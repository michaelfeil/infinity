# CPU-only structural guard for the central device132 V2 composition.
import hashlib
import re
import unittest
from pathlib import Path

DEVICE = Path(__file__).resolve().parents[1]
MAIN = DEVICE / "src/main.rs"
QV35 = DEVICE / "qwen35vl_exports.txt"
MISTRAL = DEVICE / "mistral3_exports.txt"
BUILD = DEVICE / "build.sh"
NOTICE = DEVICE / "NOTICE.qwen-vl"
OLD130_MISTRAL3_SHA = "84e3f79b571c28ab2fb1accba4aa273146a4673d75a437ba172d76cb0c85a971"
V8_GELU_HELPER_SHA = "3150eb941ec1f20b92a2776d9a5a97b24106492a3d1455aed02bb9d2f36e3f97"
V8_GEOMETRY_SHA = "5532370fe40fe8eb1f17e274f2776ab4ad23c65c837d400abb6a5352894e1c99"
V8_ORDER_SHA = "b7bf2bf22dc61f0b0e345cbd88edc575506ea320cf3f1588656fb72219ccdae6"
V8_MEAN_SHA = "fa72a003a5fd2e6888c914ae5bee1b11daf7a6721a24d6a3e77e2357eb2ca0e6"
QV35_HELPER_SHA = "7ea22183626660340e963d35b116c63b56dd9fc2d414036b8fbfd5555a7f1a16"
QV35_KERNEL_SHA = "82057050a7e806b3248b69001ec988ae6790b34f0825241d3496c11f211803fd"
OLD = [
    "infinity_qwen35vl_add_bf16",
    "infinity_qwen35vl_bias_bf16",
    "infinity_qwen35vl_gelu_tanh_bf16",
    "infinity_qwen35vl_pos_interp",
    "infinity_qwen35vl_rope2d_bf16",
    "infinity_qwen35vl_silu_bf16",
    "infinity_qwen35vl_temporal_slice_bf16",
]
NEW = [
    "infinity_mistral3_gelu_mul_bf16",
    "infinity_mistral3_model_dtype_mean_bf16",
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def exports():
    names = []
    text = BUILD.read_text()
    for block in re.findall(
        r"symbols\s*=\s*sorted\((?:symbols\s*\+\s*)?\[(.*?)\]\)", text, re.S
    ):
        names += re.findall(r'"([^"]+)"', block)
    for path in sorted(DEVICE.glob("*_exports.txt")):
        names += [line.strip() for line in path.read_text().splitlines() if line.strip()]
    return names


def function(text, name):
    start = text.index("pub unsafe fn " + name + "(")
    end = text.index("\n}\n", start) + 3
    return text[start:end]


class Device132V2ComposerTests(unittest.TestCase):
    def test_registry_and_union(self):
        self.assertEqual(
            [line.strip() for line in QV35.read_text().splitlines() if line.strip()], OLD
        )
        names = exports()
        self.assertEqual(len(names), 132)
        self.assertEqual(len(set(names)), 132)
        self.assertNotIn("infinity_qwen35vl_pos_interp_bf16", names)
        entries = [line.strip() for line in MISTRAL.read_text().splitlines() if line.strip()]
        self.assertEqual(entries[-2:], NEW)

    def test_old130_mistral_body_is_untouched(self):
        self.assertEqual(sha(DEVICE / "src/mistral3.rs"), OLD130_MISTRAL3_SHA)
        text = (DEVICE / "src/mistral3.rs").read_text()
        for name in ["mistral3_silu_mul_bf16", "mistral3_gelu_bf16"]:
            self.assertIn(name, text)
        self.assertNotIn("mistral3_gelu_mul_bf16", text)

    def test_gelu_export_uses_new_leaf_and_tested_shared_helper(self):
        main = MAIN.read_text()
        wrapper = function(main, "infinity_mistral3_gelu_mul_bf16")
        self.assertIn("crate::mistral3_gelu_mul_leaf::mistral3_gelu_mul_leaf_bf16", wrapper)
        self.assertNotIn("crate::mistral3::mistral3_gelu_mul_bf16", wrapper)
        leaf = (DEVICE / "src/mistral3_gelu_mul_leaf.rs").read_text()
        self.assertIn("crate::mistral3_gelu_mul::{gated", leaf)
        self.assertIn("gated::<Mistral3GeluMulLeafOps>", leaf)
        self.assertIn("Mistral3GeluMulLeafOps", leaf)
        self.assertEqual(sha(DEVICE / "src/mistral3_gelu_mul.rs"), V8_GELU_HELPER_SHA)

    def test_mean_uses_final_v8_shared_sources(self):
        self.assertEqual(sha(DEVICE / "src/mistral3_model_mean.rs"), V8_MEAN_SHA)
        self.assertEqual(sha(DEVICE / "src/mistral3_model_mean_geometry.rs"), V8_GEOMETRY_SHA)
        self.assertEqual(sha(DEVICE / "src/mistral3_model_mean_order.rs"), V8_ORDER_SHA)
        wrapper = function(MAIN.read_text(), "infinity_mistral3_model_dtype_mean_bf16")
        for argument in [
            "input: *const u16",
            "cu_seqlens: *const u32",
            "selected: *const u32",
            "out: *mut f32",
            "count: u32",
            "width: u32",
            "num_sm: u32",
            "max_threads_per_sm: u32",
        ]:
            self.assertIn(argument, wrapper)
        self.assertIn("crate::mistral3_model_mean::model_dtype_mean_bf16", wrapper)

    def test_qv35_final_leaf_and_abi(self):
        self.assertEqual(sha(DEVICE / "src/qwen35vl.rs"), QV35_KERNEL_SHA)
        self.assertEqual(sha(DEVICE / "src/qwen35vl_pos_math.rs"), QV35_HELPER_SHA)
        text = function((DEVICE / "src/qwen35vl.rs").read_text(), "qwen35vl_pos_interp")
        self.assertIn("qwen35vl_pos_math::interpolate_bf16", text)
        self.assertNotIn("first + second", text)
        math = (DEVICE / "src/qwen35vl_pos_math.rs").read_text()
        self.assertIn("bf16_from_f32(c00 + c01 + c10 + c11)", math)

    def test_notice_semantics(self):
        text = NOTICE.read_text()
        self.assertIn("corners.sum(0)", text)
        self.assertIn("base125/130", text)
        self.assertIn("mistral3_gelu_mul.rs", text)
        self.assertNotIn("(c00+c10)+(c01+c11)", text)


if __name__ == "__main__":
    unittest.main()
