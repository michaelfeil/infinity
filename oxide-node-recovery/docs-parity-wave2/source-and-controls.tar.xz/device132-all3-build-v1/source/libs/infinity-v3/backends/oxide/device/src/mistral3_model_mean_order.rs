// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Source-derived ATen 5c488 BF16 `sum(dim=0)` per-feature addition order.
//!
//! This file is intentionally device-independent: the device leaf supplies
//! `cuda_device::float` RN intrinsics, while the host test supplies plain IEEE
//! f32 operations and the same round-to-nearest-even BF16 conversion. The order
//! code itself is the single implementation used by the kernel source.
//!
//! Pinned primary source: `aten/src/ATen/native/cuda/Reduce.cuh`
//! (`thread_reduce_impl`, `block_y_reduce`, `global_reduce`) at
//! `pytorch/pytorch@5c4886908584029761b579af026dcfb627c84070` (BSD-3-Clause).
//! Original Rust order port; no upstream C++ text is copied.
//!
//! Preconditions (enforced by the host before load): `width >= 128`,
//! `width % 4 == 0`, and an input base at least 8-byte aligned. Under those
//! conditions ATen selects output_vec_size=4, block (32,4), so the `rows < 64`
//! stride-1 shortcut and the block-y/global trees below are the actual order.
//! Empty spans are not admitted by `validate_mistral3`; the raw device leaf
//! writes 0.0 defensively but service requests always have `T >= 1`.
#![allow(dead_code)]

pub(crate) trait OrderOps {
    fn add(a: f32, b: f32) -> f32;
    fn mul(a: f32, b: f32) -> f32;
    fn from_bf16(bits: u16) -> f32;
    fn to_bf16(value: f32) -> u16;
}

/// `Reduce.cuh::thread_reduce_impl`, vt0 = 4, for one output feature and one
/// thread's slice. `first_row` is `threadIdx.y + 4 * cta`; `row_stride` is
/// `1` (no warp split), `4` (one CTA warp split) or `4 * ctas` (global split).
#[inline(always)]
pub(crate) unsafe fn reduce_feature<O: OrderOps>(
    input: *const u16,
    width: usize,
    start: usize,
    rows: usize,
    feature: usize,
    first_row: usize,
    row_stride: usize,
) -> f32 {
    let mut acc = [0.0f32; 4];
    let mut row = first_row;
    while row + 3 * row_stride < rows {
        let base = (start + row) * width + feature;
        acc[0] = O::add(acc[0], O::from_bf16(unsafe { *input.add(base) }));
        acc[1] = O::add(
            acc[1],
            O::from_bf16(unsafe { *input.add(base + row_stride * width) }),
        );
        acc[2] = O::add(
            acc[2],
            O::from_bf16(unsafe { *input.add(base + 2 * row_stride * width) }),
        );
        acc[3] = O::add(
            acc[3],
            O::from_bf16(unsafe { *input.add(base + 3 * row_stride * width) }),
        );
        row += 4 * row_stride;
    }
    let mut i = 0;
    while i < 4 && row < rows {
        let index = (start + row) * width + feature;
        acc[i] = O::add(acc[i], O::from_bf16(unsafe { *input.add(index) }));
        row += row_stride;
        i += 1;
    }
    acc[0] = O::add(acc[0], acc[1]);
    acc[0] = O::add(acc[0], acc[2]);
    acc[0] = O::add(acc[0], acc[3]);
    acc[0]
}

/// Exact per-feature ATen sum order for one ragged span.
#[inline(always)]
pub(crate) unsafe fn aten_sum_feature<O: OrderOps>(
    input: *const u16,
    width: usize,
    start: usize,
    rows: usize,
    feature: usize,
    ctas: u32,
) -> f32 {
    if rows < 64 {
        // No warp split: one thread owns every row with four accumulators.
        return unsafe { reduce_feature::<O>(input, width, start, rows, feature, 0, 1) };
    }
    if ctas <= 1 {
        // Four block-y partials, then the halving tree ((p0+p2)+(p1+p3)).
        let p0 = unsafe { reduce_feature::<O>(input, width, start, rows, feature, 0, 4) };
        let p1 = unsafe { reduce_feature::<O>(input, width, start, rows, feature, 1, 4) };
        let p2 = unsafe { reduce_feature::<O>(input, width, start, rows, feature, 2, 4) };
        let p3 = unsafe { reduce_feature::<O>(input, width, start, rows, feature, 3, 4) };
        return O::add(O::add(p0, p2), O::add(p1, p3));
    }
    // Global reduction: stage q_b per CTA, then the last block folds CTAs in
    // increasing b into u_{b mod 4} and repeats the block-y halving tree.
    let stride = 4 * ctas as usize;
    let mut u = [0.0f32; 4];
    let mut cta = 0;
    while cta < ctas as usize {
        let base = 4 * cta;
        let p0 = unsafe { reduce_feature::<O>(input, width, start, rows, feature, base, stride) };
        let p1 =
            unsafe { reduce_feature::<O>(input, width, start, rows, feature, base + 1, stride) };
        let p2 =
            unsafe { reduce_feature::<O>(input, width, start, rows, feature, base + 2, stride) };
        let p3 =
            unsafe { reduce_feature::<O>(input, width, start, rows, feature, base + 3, stride) };
        let q = O::add(O::add(p0, p2), O::add(p1, p3));
        let y = cta % 4;
        u[y] = O::add(u[y], q);
        cta += 1;
    }
    O::add(O::add(u[0], u[2]), O::add(u[1], u[3]))
}

/// `Reduce.cuh` final F32 -> BF16 projection plus the `BinaryDivTrueKernel.cu`
/// CPU-scalar true-divide branch:
/// `BF16(f32(sum_bf16) * f32(f64(1)/T))`, widened to F32 by the caller.
#[inline(always)]
pub(crate) fn model_dtype_mean<O: OrderOps>(sum: f32, rows: usize) -> f32 {
    let rounded_sum = O::to_bf16(sum);
    let inverse = (1.0f64 / rows as f64) as f32;
    let mean = O::to_bf16(O::mul(O::from_bf16(rounded_sum), inverse));
    O::from_bf16(mean)
}
