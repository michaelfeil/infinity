// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Namespace-prefixed Qwen35VL device leaf for the additive Mistral3 gated
//! GELU-mul export. It does not modify the pre-existing `mistral3.rs` bodies;
//! it calls the copied, tested shared helper in `mistral3_gelu_mul.rs`.

use cuda_device::thread;
use crate::mistral3_gelu_mul::{gated, ActivationOps};
use crate::{bf16_from_f32, f32_from_bf16};

struct Mistral3GeluMulLeafOps;

impl ActivationOps for Mistral3GeluMulLeafOps {
    #[inline(always)]
    fn expf(value: f32) -> f32 { libm::expf(value) }
    #[inline(always)]
    fn tanhf(value: f32) -> f32 { libm::tanhf(value) }
    #[inline(always)]
    fn erff(value: f32) -> f32 { libm::erff(value) }
    #[inline(always)]
    fn from_bf16(bits: u16) -> f32 { f32_from_bf16(bits) }
    #[inline(always)]
    fn to_bf16(value: f32) -> u16 { bf16_from_f32(value) }
}

/// Additive gated activation: 0 exact erf GELU, 1 tanh GELU, 2 SiLU.
/// Grid=ceil(elements/256), block=256. Calls the tested shared helper.
pub(crate) unsafe fn mistral3_gelu_mul_leaf_bf16(
    gate: *const u16,
    up: *const u16,
    out: *mut u16,
    elements: u32,
    mode: u32,
) {
    let index = thread::blockIdx_x() as usize * 256 + thread::threadIdx_x() as usize;
    if index >= elements as usize {
        return;
    }
    let activated = gated::<Mistral3GeluMulLeafOps>(
        unsafe { *gate.add(index) },
        unsafe { *up.add(index) },
        mode,
    );
    unsafe { *out.add(index) = activated };
}
