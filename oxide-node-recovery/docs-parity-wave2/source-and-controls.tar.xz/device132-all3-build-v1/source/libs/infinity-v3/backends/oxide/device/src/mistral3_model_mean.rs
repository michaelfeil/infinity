// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Exact ATen 5c488 model-dtype masked mean for Native Mistral3.
//!
//! Native `mistral3_models.cpp::mean_pool` computes
//! `(value.sum(0, true) / value.size(0)).to(at::kFloat)` on a contiguous
//! `[tokens, hidden]` BF16 slice. At pinned PyTorch
//! `5c4886908584029761b579af026dcfb627c84070` that is a CUDA `sum(dim=0)`
//! BF16 reduction with F32 `arg_t`, one final BF16 projection, then the
//! `BinaryDivTrueKernel.cu` CPU-scalar reciprocal-multiply branch and the
//! caller's widening cast to F32.
//!
//! One thread owns one output feature and replays ATen's per-feature addition
//! order. The order is a pure function of the span length, width and captured
//! device facts; the parallel mapping differs from ATen without changing it.
//! See `mistral3_model_mean_order.rs` and `mistral3_model_mean_geometry.rs` for
//! the source-derived order and CTA geometry.
//!
//! Admitted exact domain (enforced by the host before cold load): contiguous
//! row-major BF16 input, `hidden % 4 == 0`, `hidden >= 128`, spans `T >= 1`.
//! Official Mistral3/Ministral3 widths 3072/4096/5120 satisfy this.
//!
//! Launch: block = 256, grid = (sequences, ceil(width/256), 1). Output is a
//! disjoint F32 row-major `[sequences, width]`. `cu_seqlens`/`selected` follow
//! start=cu_seqlens[selected[s]], end=cu_seqlens[selected[s]+1]. Empty spans
//! write 0.0; production validation rejects them. Inputs/outputs must remain
//! alive through stream completion and must not overlap.

use cuda_device::{float, thread};

use crate::mistral3_model_mean_geometry::aten_ctas_per_output;
use crate::mistral3_model_mean_order::{aten_sum_feature, model_dtype_mean, OrderOps};
use crate::{bf16_from_f32, f32_from_bf16};

struct CudaOps;

impl OrderOps for CudaOps {
    #[inline(always)]
    fn add(a: f32, b: f32) -> f32 {
        float::add_rn_f32(a, b)
    }
    #[inline(always)]
    fn mul(a: f32, b: f32) -> f32 {
        float::mul_rn_f32(a, b)
    }
    #[inline(always)]
    fn from_bf16(bits: u16) -> f32 {
        f32_from_bf16(bits)
    }
    #[inline(always)]
    fn to_bf16(value: f32) -> u16 {
        bf16_from_f32(value)
    }
}

/// Exact Native Mistral3 model-dtype masked mean.
#[allow(clippy::too_many_arguments)]
pub(crate) unsafe fn model_dtype_mean_bf16(
    input: *const u16,
    cu_seqlens: *const u32,
    selected: *const u32,
    out: *mut f32,
    count: u32,
    width: u32,
    num_sm: u32,
    max_threads_per_sm: u32,
) {
    if count == 0 || width == 0 {
        return;
    }
    let sequence = thread::blockIdx_x() as usize;
    let feature = thread::blockIdx_y() as usize * 256 + thread::threadIdx_x() as usize;
    if sequence >= count as usize || feature >= width as usize {
        return;
    }
    let w = width as usize;
    let destination = sequence * w + feature;
    let slot = unsafe { *selected.add(sequence) } as usize;
    let start = unsafe { *cu_seqlens.add(slot) } as usize;
    let end = unsafe { *cu_seqlens.add(slot + 1) } as usize;
    if end <= start {
        unsafe { *out.add(destination) = 0.0 };
        return;
    }
    let rows = end - start;
    let ctas = aten_ctas_per_output(rows as u32, width, num_sm, max_threads_per_sm);
    let sum = unsafe { aten_sum_feature::<CudaOps>(input, w, start, rows, feature, ctas) };
    unsafe { *out.add(destination) = model_dtype_mean::<CudaOps>(sum, rows) };
}
