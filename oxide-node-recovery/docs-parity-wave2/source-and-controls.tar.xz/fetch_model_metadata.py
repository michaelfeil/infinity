"""Fetch bounded, pinned public model metadata for the documented parity work."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path, PurePosixPath
import threading
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path('/tmp/oxide-docs-parity-20261102')
OUTPUT = ROOT / 'model-metadata'
TARGETS = json.loads((ROOT / 'DOCS-TARGETS.json').read_text())['rows']
LIMIT = 2 * 1024 * 1024
LOCK = threading.Lock()

def fetch(model, revision, filename, directory):
    path = PurePosixPath(filename)
    if path.is_absolute() or '..' in path.parts:
        raise ValueError('invalid metadata path')
    url = 'https://huggingface.co/' + urllib.parse.quote(model, safe='/') + '/resolve/' + urllib.parse.quote(revision, safe='') + '/' + urllib.parse.quote(filename, safe='/')
    request = urllib.request.Request(url, headers={'User-Agent': 'infinity-oxide-model-parity/1'})
    try:
        with urllib.request.urlopen(request, timeout=25) as response:
            data = response.read(LIMIT + 1)
            if len(data) > LIMIT:
                return {'file': filename, 'status': 'metadata-size-limit'}
            value = json.loads(data)
            commit = response.headers.get('X-Repo-Commit') or revision
        target = directory / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        return {'file': filename, 'status': 'saved', 'revision': commit, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'url': url, 'value': value}
    except urllib.error.HTTPError as error:
        return {'file': filename, 'status': 'http-' + str(error.code)}
    except Exception as error:
        return {'file': filename, 'status': type(error).__name__}

def one(row):
    model = row['model']
    directory = OUTPUT / model.replace('/', '--')
    directory.mkdir(parents=True, exist_ok=True)
    config = fetch(model, 'main', 'config.json', directory)
    records = [config]
    if config['status'] == 'saved':
        revision = config['revision']
        modules = fetch(model, revision, 'modules.json', directory)
        records.append(modules)
        if modules.get('status') == 'saved' and isinstance(modules.get('value'), list):
            for module in modules['value'][:24]:
                path = module.get('path', '')
                if path and isinstance(path, str):
                    records.append(fetch(model, revision, path + '/config.json', directory))
        if row['task_section'] in {'Typed decisions', 'Request examples'}:
            records.append(fetch(model, revision, 'decision_config.json', directory))
        if row['task_section'] == 'Multimodal embeddings':
            records.append(fetch(model, revision, 'preprocessor_config.json', directory))
    for record in records:
        record.pop('value', None)
    result = {'model': model, 'task': row['task_section'], 'files': records, 'weights_downloaded': False}
    (directory / 'METADATA-PROVENANCE.json').write_text(json.dumps(result, indent=2) + '\n')
    with LOCK:
        print(json.dumps({'model': model, 'config': config['status'], 'files_saved': sum(r['status'] == 'saved' for r in records)}), flush=True)
    return result

OUTPUT.mkdir(exist_ok=True)
results = []
with ThreadPoolExecutor(max_workers=4) as pool:
    for completed in as_completed([pool.submit(one, row) for row in TARGETS]):
        results.append(completed.result())
        temporary = OUTPUT / 'RESULTS.json.tmp'
        temporary.write_text(json.dumps({'schema': 'official-documented-model-metadata/v1', 'complete': len(results) == len(TARGETS), 'records': sorted(results, key=lambda r: r['model'])}, indent=2) + '\n')
        temporary.replace(OUTPUT / 'RESULTS.json')
print('metadata snapshot complete; no weights downloaded', flush=True)
