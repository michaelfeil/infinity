# Gemma3 text Oxide handoff

Status: buildable CPU implementation complete; GPU/device qualification is intentionally outstanding.

- Base: `252789b05ea2e09c14971c04dfcce458f863fead`
- Worktree: `/tmp/oxide-docs-parity-20261102/gemma3`
- Patch: `SELECTIVE.patch`
- Hashes: `SOURCE-HASHES.json`
- Evidence: `evidence/`
- Machine-readable state: `FINAL-STATE.json`

## Implemented

- New `gemma3_model`, `gemma3_prepared`, `gemma3_tables`, `gemma3_executor`, and test-only `gemma3_reference` modules.
- Gemma3 architecture routing for flat `gemma3_text` / `gemma3` configs and `Gemma3TextModel`, `Gemma3ForCausalLM`, `Gemma3Model`.
- Genuine Gemma normalization: BF16 checkpoint weight widened to F32 plus one; legacy Candle rsqrt/div reduction and BF16 rounding for every layer norm, q_norm/k_norm, post-attention, pre-feedforward, post-feedforward and final norm.
- Embedding rescale by Native BF16-rounded `sqrt(hidden_size)`.
- Per-layer local/global attention from `_sliding_window_pattern` / `sliding_window_pattern`; causal local left `sliding_window - 1`, right 0; global full attention.
- Local RoPE uses `rope_local_base_freq`; global RoPE uses `rope_theta` with `rope_scaling` `linear` factor.
- Gated tanh-GELU MLP, q/k normalization plus split-half NeoX rotary, packed QKV, residual branch additions in Native order.
- Last-token, CLS, mean and raw output paths over the shared decoder arena; selected-row final-layer fast path; trained Dense head reuse through `DenseChainHost`.
- Generalization to 270m (H640/d256), 12B (H3840/d256, linear factor 8), 27B (H5376/d128, query scalar 168, linear factor 8), and 128/256 rotary widths.
- FA4 append-only canonical29 profiles for 12B/27B global and local1024 attention.
- Device exports: `infinity_gemma3_rms_norm_bf16_f32scale`, `infinity_gemma3_residual_norm_bf16_f32scale`, `infinity_gemma3_qk_norm_rope_bf16`; shared Gemma2 gated-GELU and rope-table kernels are reused.

## Provenance

The new module family starts from the previously qualified private Gemma3 text candidate snapshot at
`/tmp/infinity-oxide-parity-20261101/gemma3-engine-v2-candidate/source`, copied into this NEW
detached worktree and then generalized. Old snapshots were not modified. The semantic reference is
the public-base Native implementation in `backends/libtorch/cpp/models/gemma_models.cpp`,
`backends/libtorch/cpp/kernels/qwen35_kernels.cu`, and
`backends/libtorch/cpp/vendor/candle_kernels/kernels/gemma_rms_norm.cu`.

## Shared-file deltas

- `backends/oxide/src/lib.rs`: Gemma architecture, factory, dispatch, workspace and validation wiring.
- `backends/oxide/src/decoder.rs`: geometry-based workspace constructors and an immutable pooled accessor.
- `backends/oxide/src/fa4.rs`, `vendor/infinity_fa4/profiles.inc`, `build.py`, `build_contract.py`: appended canonical29 profiles and fingerprints.
- `backends/oxide/device/src/main.rs`, `device/build.sh`: Gemma3 exports and source hash.
- No EmbeddingGemma2 or Gemma4 implementation files were changed.

## Verification performed

All commands used `CUDA_VISIBLE_DEVICES=` empty, `CARGO_NET_OFFLINE=true`, `-j2`, CPUs `120-127`, and no GPU/device compilation.

- `cargo fmt --all -- --check`: pass.
- `cargo clippy -p infinity-backend-oxide --lib --bins -j2`: pass with no warnings.
- `cargo build --locked -p infinity-backend-oxide --lib -j2`: pass.
- Gemma3 unit filter: 41 passed, 0 failed, 6 ignored.
- FA4 unit filter: 41 passed, 0 failed, 8 ignored.
- Gemma3 lifecycle CPU test: 1 passed, 1 ignored.
- Factory routing and Gemma3 batch-validation tests: pass.
- Actual local checkpoint metadata: harrier-270m pass (109 norm sources, 55,936 scales); KaLM-12B pass (289 norm sources, 765,696 scales); harrier-27b config metadata pass.
- Python FA4 contract: 29 rows, fingerprint `ec5f1a271ca29f3914a57e3aa62aea450c9bc19fedf0cce83753b851946f09ca`.

## Remaining gaps

See `REMAINING-GAPS.md`. The implementation is not a numeric or performance claim. Root must compile the canonical29 FA4 bundle and the device exports, then run Native/GPU parity and serving lifecycle qualification.
