# Remaining numeric and runtime gaps

1. No CUDA execution, device/AOT compilation, `cuda-oxide`, `ptxas`, FA4 bundle build, or GPU query was performed. The actual forward source builds as a Rust CPU-side library but its device entry points have not been assembled into a cubin.
2. The canonical29 FA4 bundle has not been compiled for SM90, SM100 or SM120. The new profiles `gemma3_global_d256_gqa2`, `gemma3_local1024_d256_gqa2`, and `gemma3_local1024_d128_gqa2` are append-only source/profile requests for Root composition.
3. No Native-versus-Oxide vector parity, tolerance qualification, lifecycle/HTTP test, cancellation test or performance measurement was run.
4. harrier-oss-v1-270m and KaLM-Embedding-Gemma3-12B weight headers and all offset-norm sources were checked on CPU. harrier-oss-v1-27b weights are not present locally; only its config metadata was checked against the local `model-metadata` copy.
5. Exact device arithmetic is source-equivalent by construction to Native Candle/qwen35 kernels, including dynamic Native reduction widths (32/128/256), BF16 rounding, BF16 rotary fma/mul, and BF16 residual adds. This has not been numerically qualified on hardware.
6. The shared `decoder.rs` geometry constructor and pooled accessor refactor compiles and its CPU tests pass, but existing decoder families have not been re-run on GPU.
7. The shared Dense projection path is reused and its module admission is CPU-tested, but no actual trained Dense module exists in the two local checkpoints; the three local checkpoints use Transformer/Pooling/Normalize only.
8. FA4 Python build-contract validation passes for the 29-row source profile registry; the Python build/test modules that import torch/cutlass were not run because the environment is offline/CPU-only.
9. `fa4_source_lock.json` is unchanged because only `profiles.inc` and the mode registry changed; the flash-attn source lock was not modified.
10. Root should preserve the previous qualified canonical26 behaviour when composing: the loader still accepts complete canonical26 bundles and rejects canonical29-only geometry from a 26-mode manifest.
