#!/usr/bin/env python3
# Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
"""Portable CPU checks binding documented contracts to explicit implementation gaps."""
import copy
import importlib.util
import json
from pathlib import Path
import re
import unittest

TOOL = Path(__file__).resolve().parents[1] / 'oxide_model_catalog.py'
SPEC = importlib.util.spec_from_file_location('oxide_model_catalog', TOOL)
catalog = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(catalog)

class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.data = catalog.generate()

    def test_actual_docs_have_no_silently_untracked_checkpoint_or_task(self):
        catalog.validate(self.data)
        # Independent first-cell link extraction also catches Vela tables in
        # request examples rather than trusting the launch tables alone.
        ids = set()
        for line in catalog.MODEL_DOC.read_text().splitlines():
            match = re.match(r'^\| \[[^]]+\]\(https://huggingface.co/([^)/]+/[^)/]+)', line)
            if match:
                ids.add(match[1])
        self.assertEqual(ids, {r['id'] for r in self.data['models']})

    def test_vela_short_aliases_are_kept_beside_canonical_hf_ids(self):
        vela = [r for r in self.data['models'] if r['id'].startswith('vllm-sr/vela3-')]
        self.assertEqual(len(vela), 6)
        for row in vela:
            self.assertEqual(row['aliases'], [row['id'].split('/', 1)[1]])
            self.assertEqual((row['task'], row['endpoint']), ('typed_decision', '/v1/systemone'))

    def test_family_implementation_is_not_named_checkpoint_qualification(self):
        self.assertTrue(all(r['oxide']['checkpoint_quality'] == 'not_claimed' for r in self.data['models']))
        for name in ['ProsusAI/finbert', 'Jean-Baptiste/camembert-ner', 'BAAI/bge-reranker-base']:
            row = next(r for r in self.data['models'] if r['id'] == name)
            self.assertEqual(row['oxide']['status'], 'restricted_published_head')

    def test_sparse_and_colbert_do_not_pass_because_bert_embeddings_exist(self):
        for name in ['colbert-ir/colbertv2.0', 'naver/splade_v2_max']:
            row = next(r for r in self.data['models'] if r['id'] == name)
            self.assertEqual(row['oxide']['status'], 'missing_task_path')
            self.assertEqual(row['oxide']['owner'], 'sparse-colbert')

    def test_protocol_specific_decisions_are_not_inferred_from_qwen35(self):
        for name in ['Cloudflare/clef', 'vllm-sr/d3-ultra', 'perplexity-ai/pplx-decider-v1.2']:
            row = next(r for r in self.data['models'] if r['id'] == name)
            self.assertEqual(row['oxide']['status'], 'missing_task_path')
        elephant = next(r for r in self.data['models'] if r['id'] == 'baselabs/elephant-1')
        self.assertEqual(elephant['oxide']['status'], 'conditional_published_path')

    def test_documented_native_exclusions_are_not_promoted_to_supported_rows(self):
        excluded = {r['id'] for r in self.data['explicitly_excluded_native_examples']}
        self.assertIn('cross-encoder/ms-marco-electra-base', excluded)
        self.assertFalse(excluded & {r['id'] for r in self.data['models']})

    def test_new_doc_row_missing_row_and_duplicate_cannot_silently_pass(self):
        for mutation in ['missing', 'duplicate', 'invented']:
            data = copy.deepcopy(self.data)
            if mutation == 'missing': data['models'].pop()
            elif mutation == 'duplicate': data['models'].append(copy.deepcopy(data['models'][0]))
            else: data['models'][0]['id'] = 'invented/not-a-documented-model'
            with self.assertRaisesRegex(ValueError, 'lost, duplicated or invented'):
                catalog.validate(data)

    def test_false_qualification_and_missing_implementation_source_fail_closed(self):
        data = copy.deepcopy(self.data); data['models'][0]['oxide']['checkpoint_quality'] = 'passed'
        with self.assertRaisesRegex(ValueError, 'manufacture checkpoint qualification'):
            catalog.validate(data)
        data = copy.deepcopy(self.data); data['models'][0]['oxide']['source_paths'] = ['backends/oxide/src/absent.rs']
        with self.assertRaisesRegex(ValueError, 'invalid implementation source'):
            catalog.validate(data)

    def test_checked_in_catalog_matches_current_docs_and_implementation_map(self):
        self.assertEqual(json.loads(catalog.OUTPUT.read_text()), self.data)

if __name__ == '__main__': unittest.main()
