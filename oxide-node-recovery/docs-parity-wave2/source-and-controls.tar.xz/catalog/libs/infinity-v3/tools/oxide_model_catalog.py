#!/usr/bin/env python3
# Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
"""Inventory documented checkpoint/task contracts without inferring qualification.

This is a development catalog, never runtime admission. A source path is not a
checkpoint qualification: geometry, weights, tokenizer, dtype and task modifiers
must still pass the actual loader and paired Native controls.
"""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

V3 = Path(__file__).resolve().parents[1]
MODEL_DOC = V3 / 'docs/supported-models.md'
FAMILY_DOC = V3 / 'docs/libtorch-model-coverage.md'
OUTPUT = V3 / 'docs/oxide-model-catalog.json'
TASKS = {
    'Dense text embeddings': ('dense_embedding', '/v1/embeddings'),
    'Multimodal embeddings': ('multimodal_embedding', '/v1/embeddings'),
    'Late-interaction embeddings': ('token_vectors', '/v1/embeddings'),
    'Rerankers': ('rerank', '/rerank'),
    'Token classification and NER': ('token_classification', '/predict_tokens'),
    'Text classification and reward scoring': ('sequence_classification', '/v1/classify'),
    'Typed decisions': ('typed_decision', '/v1/systemone'),
    'Sparse embeddings': ('sparse_embedding', '/embed_sparse'),
    'Request examples': ('typed_decision', '/v1/systemone'),
}
FAMILIES = [
    ('UltraVBERT', 'ultravbert'), ('UltraBERT', 'ultrabert'),
    ('Pinned D3', 'qwen35'), ('Qwen3.5', 'qwen35'),
    ('Bidirectional Qwen3-VL', 'qwen3_vl'), ('Qwen3-VL', 'qwen3_vl'),
    ('Bidirectional Qwen3', 'qwen3'), ('Qwen3', 'qwen3'), ('Qwen2', 'qwen2'),
    ('Bidirectional Ministral3', 'mistral3'), ('Bidirectional Mistral3', 'mistral3'),
    ('Mistral3', 'mistral3'), ('Mistral', 'mistral'),
    ('Bidirectional Llama', 'llama'), ('Llama', 'llama'),
    ('EmbeddingGemma2', 'embedding_gemma2'), ('Gemma4', 'gemma4'),
    ('Gemma3', 'gemma3'), ('Experimental DeBERTa', 'deberta'),
    ('XLM-RoBERTa', 'xlm_roberta'), ('RoBERTa', 'roberta'),
    ('CamemBERT', 'camembert'), ('DistilBERT', 'distilbert'),
    ('GTE', 'gte'), ('ModernBERT', 'modernbert'), ('Nomic BERT MoE', 'nomic_moe'),
    ('Nomic BERT', 'nomic'), ('JinaCode', 'jinacode'), ('Jina BERT', 'jina'),
    ('Packed BERT', 'bert'), ('BERT', 'bert'), ('MPNet', 'mpnet'),
    ('ModernBERT encoder', 'modernbert'),
]
BACKBONES = {
    'bert': ('model.rs', 'BertWeights'),
    'roberta': ('model.rs', 'BertWeights'),
    'xlm_roberta': ('model.rs', 'BertWeights'),
    'camembert': ('model.rs', 'BertWeights'),
    'distilbert': ('model.rs', 'BertWeights'),
    'gte': ('rotary_encoder_model.rs', 'RotaryEncoder'),
    'modernbert': ('modern_encoder_model.rs', 'Modern'),
    'nomic': ('nomic_encoder_model.rs', 'Nomic'),
    'jina': ('jina_encoder_model.rs', 'Jina'),
    'jinacode': ('jina_code_encoder_model.rs', 'Jina'),
    'mpnet': ('mpnet.rs', 'MPNet'),
    'deberta': ('deberta_encoder_model.rs', 'Deberta'),
    'qwen2': ('decoder_model.rs', 'DecoderWeights'),
    'qwen3': ('decoder_model.rs', 'DecoderWeights'),
    'llama': ('decoder_model.rs', 'DecoderWeights'),
    'mistral': ('decoder_model.rs', 'DecoderWeights'),
    'qwen35': ('qwen35_runtime.rs', 'Qwen35Model'),
}
ENCODER_HEAD_FAMILIES = {'bert', 'roberta', 'xlm_roberta', 'camembert', 'distilbert'}
DECODE_HEAD_FAMILIES = {'qwen2', 'qwen3', 'llama'}

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def family_for(basis: str) -> str:
    for prefix, family in FAMILIES:
        if basis.startswith(prefix):
            return family
    raise ValueError(f'unclassified documented Native basis: {basis!r}')

def parse_models(text: str) -> tuple[list[dict], list[dict]]:
    section = ''; records = []; excluded = []
    for line_number, line in enumerate(text.splitlines(), 1):
        if line.startswith('## '):
            section = line[3:]
        if not line.startswith('| '):
            continue
        cells = [cell.strip() for cell in line.strip('|').split('|')]
        if section == 'Similar models that need additional integration':
            if cells[0].startswith('`'):
                excluded.append({'id': cells[0].strip('`'), 'reason': cells[1], 'line': line_number})
            continue
        if section not in TASKS:
            continue
        match = re.search(r'\[([^]]+)\]\(https://huggingface.co/([^)/]+/[^)/]+)', cells[0])
        if match is None:
            continue
        task, endpoint = TASKS[section]
        model_id, label = match[2], match[1]
        records.append({'id': model_id, 'aliases': [] if label == model_id else [label],
            'task': task, 'endpoint': endpoint, 'section': section, 'line': line_number,
            'native_basis': cells[1], 'native_family': family_for(cells[1]),
            'launch_settings': cells[2] if len(cells) > 2 else ''})
    keys = [(r['id'], r['task']) for r in records]
    if len(keys) != len(set(keys)):
        raise ValueError('duplicate checkpoint/task in supported tables')
    return records, excluded

def parse_families(text: str) -> list[dict]:
    result = []
    for line_number, line in enumerate(text.splitlines(), 1):
        if not line.startswith('| '):
            continue
        cells = [cell.strip() for cell in line.strip('|').split('|')]
        if len(cells) == 2 and cells[0] not in {'Model family / aliases', '---'}:
            result.append({'family': cells[0], 'native_implementation': cells[1], 'line': line_number})
    return result

def execution_for(row: dict) -> dict:
    family, task = row['native_family'], row['task']
    path = BACKBONES.get(family)
    result = {'status': 'missing_task_path', 'checkpoint_admission': 'not_verified_by_this_catalog',
        'checkpoint_quality': 'not_claimed', 'dtype': 'configuration-dependent',
        'source_paths': [], 'conditions': [], 'owner': 'root',
        'factory_entrypoint': 'backends/oxide/src/lib.rs::OxideBackend::new_with_dense_paths',
        'feature_proof': {
            'raw_hidden_tokens': 'checkpoint/task dependent; not qualified by this inventory',
            'dynamic_fp8': 'not claimed', 'prefix_reuse': 'not claimed',
            'media': 'required by task' if task == 'multimodal_embedding' else 'not implied',
        }}
    if path:
        result['source_paths'].append('backends/oxide/src/' + path[0])
    if family == 'llama' and row['native_basis'].startswith('Bidirectional Llama'):
        result.update(owner='root-decoder', conditions=['Published Llama executor requires causal H2048/default RoPE; bidirectional Llama is not this task path'])
    elif family == 'qwen35' and task == 'typed_decision':
        if row['id'] in {'baselabs/elephant-1', 'baselabs/mammoth-1'}:
            result.update(status='conditional_published_path', conditions=['OneJev head and admitted H4096/H5120 block-attention metadata', 'BF16; no dynamic FP8 Decision claim'])
            result['source_paths'].append('backends/oxide/src/qwen35_serving.rs')
        else:
            result.update(owner='q35-decisions', conditions=['Protocol-specific readout/backbone metadata is not implied by OneJev support'])
    elif task == 'typed_decision':
        result['conditions'] = ['Requires its own decision-trained backbone and head; text embeddings do not qualify this route']
    elif task in {'multimodal_embedding', 'token_vectors'}:
        result['owner'] = 'sparse-colbert' if family == 'bert' else 'root-media'
        result['conditions'] = ['Native document/query token semantics, learned projection and media readout must be implemented separately']
    elif task == 'sparse_embedding':
        result.update(owner='sparse-colbert', conditions=['MLM head, model-dtype nonlinearities and sparse/raw output geometry required'])
    elif family == 'deberta':
        result.update(owner='deberta', status='conditional_published_path' if task == 'dense_embedding' else 'restricted_published_head', conditions=['Current explicit H768/relative-attention/no-convolution/no-embedding-projection guard; no family-wide admission'])
        if task != 'dense_embedding':
            result['source_paths'].append('backends/oxide/src/classifier_head.rs')
    elif task in {'rerank', 'sequence_classification', 'token_classification'}:
        if family in DECODE_HEAD_FAMILIES:
            result.update(status='conditional_published_path', conditions=['Trained root score or Native-supported LM-row head and admitted decoder math; no head synthesized for base models'])
            result['source_paths'].append('backends/oxide/src/decoder_classifier.rs')
        elif family in ENCODER_HEAD_FAMILIES:
            known = row['id'] in {'cross-encoder/ms-marco-MiniLM-L-6-v2', 'dslim/bert-base-NER'}
            result.update(status='conditional_published_path' if known else 'restricted_published_head', owner='encoder-heads', conditions=['Published classic classifier admission is restricted to the two explicit MiniLM/DSLIM geometry/task contracts; broad family task support is pending'])
            result['source_paths'].append('backends/oxide/src/classifier_head.rs')
        elif family in {'gte', 'modernbert'}:
            result.update(owner='encoder-heads', conditions=['Embedding executor exists; architecture-specific head and task-dependent backbone policy remain separate'])
    elif task == 'dense_embedding' and path:
        result.update(status='conditional_published_path', conditions=['Exact config, saved Dense chain, geometry, pooling, dtype and tokenizer must pass actual loader; this is not named-checkpoint qualification'])
        result['source_paths'].append('backends/oxide/src/lib.rs')
    else:
        result['conditions'] = ['Backbone/task not present in public252789; private candidates are not published support']
    if 'saved Dense' in row['native_basis']:
        result['source_paths'].append('backends/oxide/src/dense.rs')
        result['conditions'].append('Saved Dense projection applies to pooled vectors; raw hidden width stays distinct')
    if not result['conditions']:
        result['conditions'] = ['This documented architecture/task requires its own executable readout; an existing backbone does not establish that feature']
    result['source_paths'] = sorted(set(result['source_paths']))
    return result

def generate(v3: Path = V3) -> dict:
    docs = v3 / 'docs/supported-models.md'; families = v3 / 'docs/libtorch-model-coverage.md'
    models, excluded = parse_models(docs.read_text())
    for model in models:
        model['oxide'] = execution_for(model)
    return {'schema': 'infinity.oxide.documented-model-catalog/v1',
        'basis': 'public252789b05ea2e09c14971c04dfcce458f863fead',
        'scope': 'Documentation-to-task/source-path inventory; never runtime admission or a blanket accuracy/performance claim',
        'documents': {'supported-models.md': digest(docs), 'libtorch-model-coverage.md': digest(families)},
        'models': models, 'native_families': parse_families(families.read_text()),
        'explicitly_excluded_native_examples': excluded}

def validate(catalog: dict, v3: Path = V3) -> None:
    """Fail closed on stale docs, lost contracts or unsupported support claims."""
    actual, _ = parse_models((v3 / 'docs/supported-models.md').read_text())
    expected = {(r['id'], r['task']) for r in actual}
    rows = catalog['models']; keys = [(r['id'], r['task']) for r in rows]
    if len(keys) != len(set(keys)) or set(keys) != expected:
        raise ValueError('catalog lost, duplicated or invented a documented checkpoint/task')
    valid_states = {'conditional_published_path', 'restricted_published_head', 'missing_task_path'}
    for row in rows:
        state = row['oxide']
        if state['status'] not in valid_states or state['checkpoint_quality'] != 'not_claimed':
            raise ValueError('catalog cannot manufacture checkpoint qualification')
        if not state['conditions']:
            raise ValueError('every route must state its concrete admission or missing-feature conditions')
        if state['status'] == 'conditional_published_path' and not state['source_paths']:
            raise ValueError('published route lacks implementation source')
        for source in state['source_paths']:
            path = Path(source)
            if path.is_absolute() or '..' in path.parts or not (v3 / path).is_file():
                raise ValueError(f'invalid implementation source: {source}')

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check', action='store_true', help='fail if checked-in catalog differs from current docs')
    args = ap.parse_args(); catalog = generate(); validate(catalog)
    rendered = json.dumps(catalog, indent=2, ensure_ascii=False) + '\n'
    if args.check:
        if not OUTPUT.is_file() or OUTPUT.read_text() != rendered:
            raise SystemExit('oxide model catalog is stale: run tools/oxide_model_catalog.py')
    else:
        OUTPUT.write_text(rendered)
    print(json.dumps({'models': len(generate()['models']), 'native_families': len(generate()['native_families']), 'catalog': str(OUTPUT)}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
