# Dense gaps v2 on 09fbb71

Successor to the preserved v1 tree. Base `09fbb71`; Root H5120, canonical31 FA4
and encoder/classifier-head changes are retained.

## FA4 proof result (108 official configs)

`fa4-profile-uniqueness.py` reads `fa4.rs` and all official configs in
`../model-metadata`, matching by reduced ratio, exact `head_dim`, causal bit and
mask kind:

| Request | Old-31 | New |
| --- | --- | --- |
| Qwen2 14/2 d64 causal (jina-code 0.5B) | none | mode 31 |
| Qwen2 12/2 d128 causal (jina-code 1.5B) | none | mode 32 |
| Llama 32/8 d64 noncausal (Nemotron rerank 1B v2) | none | mode 33 |
| Qwen3 16/8 d128 noncausal (pplx 0.6B, voyage-4-nano) | mode 3 `voyage` | already covered |

So the correct extension is **3 new profiles / 34 entries**, not 4/35. The
34-bit mask `0x3ffffffff` exceeds ABI7's i32 query, so `fa4.rs` now selects
`infinity_fa4_modes_v2() -> u64` only for declared counts >31. Manifests with
<=31 modes keep `infinity_fa4_modes_v1() -> i32` and the old load path. No
manifest ABI bump; extended manifests omit registry metadata unless Root adds a
new prefix identity. Full contract in `FA4-REQUEST.md`.

## Dense source deltas

- Real Qwen2 H896/d64 masked Candle RMS + HFMA RoPE, isolated device leaf
  `rms896_exports.txt` / `src/rms896_exact_vector.rs`.
- Llama3 NTK-by-parts scaled RoPE.
- `llama_bidirec`, noncausal Llama, bidirectional mean-pool + temperature head.
- `layer_types`, PPLXQwen3Model, last/mean pooling, FlexibleQuantizer no-op,
  noncausal root `linear.weight` Dense projection.
- 13 exact-config fixtures from `model-metadata`, not synthetic geometry.

## Evidence

- `cargo test -p infinity-backend-oxide --lib --offline -j2`: 687 passed.
- `cargo test -p infinity_v3-backend --no-default-features --features oxide`: 24 passed.
- H5120 focused: 5/5 pass; H896, documented-config and extended-profile tests pass.
- Oxide + facade-oxide clippy `-D warnings` clean; rustfmt clean.
- Device registry tests 4/4 and build tests 13/13.
- CPU-only, offline, `CUDA_VISIBLE_DEVICES` empty, `-j2`.

Not run: GPU, Torch, Docker, device/AOT compile, optimized host build, provider
compile, Native gold gate. Root owns FA4 publication and the GPU gate.
