# FA4 extended-profile request (dense gaps)

Owner: `remaining_latency_audit` (FA4 publication/registry). Requester: `dense_gaps`.
Base: `09fbb71f27536f99713abc696b749e94e145b735`. Source-only; **no provider compile was run**.

## Result of the uniqueness proof

Matching in `backends/oxide/src/fa4.rs` uses the reduced Q/KV ratio, exact
`head_dim`, exact causal bit, and global/local mask kind. Absolute head counts
are runtime dimensions. The script `fa4-profile-uniqueness.py` reads the shared
profile table and all `../model-metadata/*/config.json` files (108 configs carry
attention geometry) and produced `FA4-UNIQUENESS.json`.

| Requested dense-gap geometry | Old-31 match | Result |
| --- | --- | --- |
| Qwen2 14 Q/2 KV d64 causal (jina-code 0.5B) | none | **new mode 31** |
| Qwen2 12 Q/2 KV d128 causal (jina-code 1.5B) | none | **new mode 32** |
| Llama 32 Q/8 KV d64 noncausal (Nemotron rerank 1B v2) | none | **new mode 33** |
| Qwen3 16 Q/8 KV d128 noncausal (pplx 0.6B, voyage-4-nano) | mode 3 `voyage` | **already covered, no new mode** |

Consequences:
- Three unique profiles, not four. Total declared prefix becomes **34**, modes 31..33.
- `0x3ffffffff` (34 bits) exceeds the ABI7 `infinity_fa4_modes_v1() -> i32` mask, so the extended prefix needs the u64 query below. The old 31-mode prefix remains exactly `0x7fffffff`.
- No duplicate profile key remains among the 34 entries. The proof also verifies that near geometries do not borrow another profile by causal narrowing (for example 14/2 d64 noncausal, 12/2 d128 noncausal -> mode 4, 32/8 d64 causal -> none, 16/8 d128 causal -> mode 11).

## Backward-compatible capability contract

Shared source (`backends/oxide/src/fa4.rs`) now implements:

- Legacy path (`declared <= 31`): load `infinity_fa4_modes_v1() -> i32`, validate against the unchanged 31-bit mask, keep native ABI1 / export ABI7.
- Extended path (`declared > 31`): load the additional `infinity_fa4_modes_v2() -> u64`, validate against the `declared`-bit mask (`0x3ffffffff` for 34), and keep the same ABI1/ABI7 manifest fields and forward symbol.
- A legacy provider is never asked for `infinity_fa4_modes_v2`; a 32+ manifest fails typed if the symbol is absent.
- Extended manifests must omit `registry` metadata unless Root adds a new prefix identity. Registry validation for the existing 19/20/23/24/26/31 prefixes is unchanged.

Provider publication must therefore add, for **both F16 and BF16** and each SM90/SM100/SM120 target:

1. `infinity_fa4_modes_v2()` returning the declared mask (34 bits for this prefix).
2. Ordered exports at modes 31..33 named
   `fa4_qwen2_q14kv2_d64_causal_<dtype>`,
   `fa4_qwen2_q12kv2_d128_causal_<dtype>`,
   `fa4_llama_q32kv8_d64_noncausal_<dtype>`.
3. The existing mode 0..30 symbols, windows, and manifest indexes unchanged.
4. Manifest `mode_mask: "0x3ffffffff"` and no `registry` block, or a new coordinated registry identity.

The host selector already exposes the new specs:

- `Fa4::supports` admits modes 31..33.
- `Fa4::supports_published` deliberately stays on the 20-profile auto-routing prefix; explicit decoder construction can use the extended prefix.
- Generic global matching never narrows a noncausal request to a causal profile or vice versa.

## Dense-gap model coverage after publication

| Model | Mode |
| --- | --- |
| jinaai/jina-code-embeddings-0.5b | 31 |
| jinaai/jina-code-embeddings-1.5b | 32 |
| nvidia/llama-nemotron-rerank-1b-v2 | 33 |
| perplexity-ai/pplx-embed-v1-0.6b | 3 `voyage` |
| voyageai/voyage-4-nano | 3 `voyage` |
| Alibaba-NLP/gte-Qwen2-1.5B-instruct | 4 `gqa6` |
| Alibaba-NLP/gte-Qwen2-7B-instruct | 14 `gqa7` |
| Qwen/Qwen3-Embedding-0.6B, harrier-oss-v1-0.6b, Skywork reward | 11 `causal_gqa2` |
| Qwen/Qwen3-Embedding-4B/8B | 22 `causal_gqa8` |
| perplexity-ai/pplx-embed-v1-4b | 13 `gqa4` |

## Files

- Shared source contract: `libs/infinity-v3/backends/oxide/src/fa4.rs`
- Machine-readable request: `libs/infinity-v3/docs/dense-gaps-fa4-profile-request.json`
- Proof inputs/output: `fa4-profile-uniqueness.py`, `FA4-UNIQUENESS.json`
- Dense executor deltas: `libs/infinity-v3/backends/oxide/{src,device}` plus `SELECTIVE.patch`

Root still owns provider compilation, publication, registry metadata and the
Native gold GPU gate. Until that gate passes, the new modes are source-admitted
only and no runtime/numeric claim is made.
