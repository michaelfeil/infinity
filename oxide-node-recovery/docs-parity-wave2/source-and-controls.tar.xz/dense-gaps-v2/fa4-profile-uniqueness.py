#!/usr/bin/env python3
"""Prove dense-gap FA4 profile uniqueness against the official model catalog.

Reads the shared-source profile table and every config in ../model-metadata.
Matching mirrors oxide/src/fa4.rs: reduced Q/KV ratio, exact head_dim, exact
causal bit, and global-vs-local mask kind. Absolute head counts never match.
"""
import json, math, pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parent
FA4 = ROOT / "libs/infinity-v3/backends/oxide/src/fa4.rs"
META = ROOT.parent / "model-metadata"

def ratio(heads, kv):
    g = math.gcd(heads, kv)
    return (heads // g, kv // g)

def parse_profiles():
    text = FA4.read_text()
    table = text.split("const PROFILES:", 1)[1].split("];", 1)[0]
    entries = re.findall(
        r'Profile::new\(\s*"([^"]+)",\s*(\d+),\s*(\d+),\s*(\d+),\s*(true|false),\s*'
        r'Window::(Global|Local)\s*\{?\s*(?:left:\s*(-?\d+),\s*right:\s*(-?\d+))?',
        table,
    )
    profiles = []
    for name, h, kv, d, causal, kind, left, right in entries:
        profiles.append({
            "name": name, "heads": int(h), "kv_heads": int(kv), "head_dim": int(d),
            "causal": causal == "true", "window": kind.lower(),
            "left": int(left) if left else None, "right": int(right) if right else None,
        })
    return profiles

def config_signature(cfg):
    mt = cfg.get("model_type")
    if mt == "bidirectional_pplx_qwen3":
        family, causal = "qwen3", False
    elif mt == "llama_bidirec":
        family, causal = "llama", cfg.get("is_causal", False)
    elif mt in ("ministral3", "mistral3"):
        family = "mistral"
        causal = cfg.get("is_causal", not cfg.get("use_bidirectional_attention", False))
    elif mt == "ultrabert":
        family, causal = "ultrabert", False
    elif mt in ("qwen2", "qwen3", "qwen3_moe", "llama", "mistral"):
        family = mt
        if "is_causal" in cfg:
            causal = bool(cfg["is_causal"])
        else:
            causal = not cfg.get("use_bidirectional_attention", False)
    elif mt in ("gemma2", "gemma3", "gemma3_text", "gemma4", "gemma4_text"):
        family = mt
        causal = not cfg.get("use_bidirectional_attention", False) and cfg.get("is_causal", True)
    else:
        # Encoder families are noncausal global for catalog completeness.
        family, causal = mt, False
    heads = cfg.get("num_attention_heads")
    kv = cfg.get("num_key_value_heads", heads)
    if not heads or not kv:
        return None
    head_dim = cfg.get("head_dim") or (cfg.get("hidden_size", 0) // heads if heads else 0)
    if not head_dim:
        return None
    window = "global"
    sliding = cfg.get("sliding_window")
    maximum = cfg.get("max_position_embeddings")
    if family in ("mistral", "gemma2", "gemma3", "gemma3_text", "gemma4", "gemma4_text"):
        if isinstance(sliding, int) and sliding > 0 and (maximum is None or sliding < maximum):
            window = "local"
    return {"family": family, "heads": heads, "kv_heads": kv, "head_dim": head_dim,
            "causal": causal, "window": window, "ratio": ratio(heads, kv)}

def matches(profile, sig):
    if ratio(profile["heads"], profile["kv_heads"]) != sig["ratio"]:
        return False
    if profile["head_dim"] != sig["head_dim"] or profile["causal"] != sig["causal"]:
        return False
    return profile["window"] == sig["window"]

TARGETS = [
    ("Qwen2 14Q/2KV d64 causal (jina-code 0.5B)", 14, 2, 64, True),
    ("Qwen2 12Q/2KV d128 causal (jina-code 1.5B)", 12, 2, 128, True),
    ("Llama 32Q/8KV d64 noncausal (Nemotron rerank 1B v2)", 32, 8, 64, False),
    ("Qwen3 16Q/8KV d128 noncausal (pplx 0.6B, voyage-4-nano)", 16, 8, 128, False),
]

def main():
    profiles = parse_profiles()
    official = []
    for path in sorted(META.glob("*/config.json")):
        try:
            cfg = json.loads(path.read_text())
        except Exception:
            continue
        sig = config_signature(cfg)
        if sig is None:
            continue
        sig["model"] = path.parent.name.replace("--", "/")
        official.append(sig)

    old31 = profiles[:31]
    targets = []
    for label, h, kv, d, causal in TARGETS:
        sig = {"family": "target", "heads": h, "kv_heads": kv, "head_dim": d,
               "causal": causal, "window": "global", "ratio": ratio(h, kv)}
        old_hits = [i for i, p in enumerate(old31) if matches(p, sig)]
        new_hits = [i for i, p in enumerate(profiles) if i >= 31 and matches(p, sig)]
        catalog_hits = [o["model"] for o in official if matches_dict(sig, o)]
        targets.append({
            "label": label, "signature": {k: sig[k] for k in
                ("heads", "kv_heads", "head_dim", "causal", "window", "ratio")},
            "old31_matching_modes": old_hits,
            "new_matching_modes": new_hits,
            "already_covered": bool(old_hits),
            "official_configs_with_same_signature": catalog_hits,
        })

    # All old and new profile signatures must be distinct under FA4 matching.
    def key(p):
        return (ratio(p["heads"], p["kv_heads"]), p["head_dim"], p["causal"],
                p["window"], p["left"] if p["window"] == "local" else None,
                p["right"] if p["window"] == "local" else None)
    keys = [key(p) for p in profiles]
    duplicate_keys = sorted({k for k in keys if keys.count(k) > 1})
    result = {
        "profiles_total": len(profiles),
        "old_profiles": 31,
        "appended_unique_profiles": len(profiles) - 31,
        "appended_mode_range": [31, len(profiles) - 1],
        "extended_mask": f"0x{(1 << len(profiles)) - 1:x}",
        "official_configs_scanned": len(official),
        "targets": targets,
        "unique_requests": sum(1 for t in targets if not t["already_covered"]),
        "duplicate_profile_keys": duplicate_keys,
    }
    out = ROOT / "FA4-UNIQUENESS.json"
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if not duplicate_keys else 1

def matches_dict(sig, o):
    return (ratio(o["heads"], o["kv_heads"]) == sig["ratio"]
            and o["head_dim"] == sig["head_dim"]
            and o["causal"] == sig["causal"]
            and o["window"] == sig["window"])

if __name__ == "__main__":
    sys.exit(main())
