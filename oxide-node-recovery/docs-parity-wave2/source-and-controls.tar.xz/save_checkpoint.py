"""Save live source and reproducibility evidence without weights/build caches."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile

source = Path('/tmp/oxide-docs-parity-20261102')
base = Path('/tmp/infinity-plain-cuda')
destination = Path('/tmp/oxide-node-recovery/oxide-node-recovery/docs-parity-wave2')
destination.mkdir(exist_ok=False)
allowed = {'.rs', '.toml', '.lock', '.py', '.sh', '.bash', '.cpp', '.cc', '.c', '.cu', '.cuh', '.h', '.hpp', '.inc', '.json', '.md', '.txt', '.patch', '.diff', '.yml', '.yaml', '.cmake', '.log', '.stdout', '.stderr', '.jpg', '.jpeg', '.png'}
pruned = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', '.work', '.cache', 'artifacts', 'target', 'models', 'weights', 'kernels.work'}
manifest = {'base_public_commit': subprocess.check_output(['git', '-C', str(base), 'rev-parse', 'HEAD'], text=True).strip(), 'status': 'live unfinished source snapshot; frozen component manifests take precedence', 'files': {}, 'excluded': []}
archive = destination / 'source-and-controls.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=3) as output:
    for current, dirs, names in os.walk(source, followlinks=False):
        current = Path(current)
        dirs[:] = sorted(d for d in dirs if d not in pruned and not d.startswith(('target-', 'target_', '.target')))
        # Nested worktrees include the monorepo; only V3 was modified here.
        if (current / '.git').exists():
            dirs[:] = [d for d in dirs if d == 'libs']
        if current.name == 'libs' and (current / 'infinity-v3').is_dir():
            dirs[:] = [d for d in dirs if d == 'infinity-v3']
        for name in sorted(names):
            path = current / name
            relative = path.relative_to(source)
            if path.is_symlink() or not path.is_file():
                continue
            if name.lower() in {'opencode.json', 'auth.json', 'credentials.json', 'token.json'} or name.startswith('.env'):
                continue
            native_gold = str(relative).startswith('root-native-mean-control-v1/gold/') and path.suffix == '.bin'
            if path.suffix not in allowed and name not in {'Makefile', 'CMakeLists.txt', 'LICENSE', 'NOTICE', 'Dockerfile', 'stdout', 'stderr'} and not native_gold:
                continue
            if path.stat().st_size > (64 * 1024 * 1024 if native_gold else 4 * 1024 * 1024):
                manifest['excluded'].append(str(relative))
                continue
            data = path.read_bytes()
            marker = 'libs/infinity-v3/'
            offset = str(relative).find(marker)
            original = base / str(relative)[offset:] if offset >= 0 else None
            if original is not None and original.is_file() and original.read_bytes() == data:
                continue
            info = tarfile.TarInfo(str(relative))
            info.size = len(data)
            info.mode = 0o755 if os.access(path, os.X_OK) else 0o644
            output.addfile(info, io.BytesIO(data))
            manifest['files'][str(relative)] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
manifest['archive'] = {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
native = Path('/tmp/h5120-root-recovered-v5/sdk/libtei_torch.so')
if native.exists():
    data = native.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != 'b66d70b61b39e1bf0d565aca33bac7c5e21849677396ce5216f5baf73027d37e':
        raise ValueError('Native SDK identity changed')
    compressed = destination / 'native-sdk-b66.so.gz'
    compressed.write_bytes(gzip.compress(data, compresslevel=6, mtime=0))
    manifest['native_sdk'] = {'file': compressed.name, 'uncompressed_sha256': digest, 'compressed_sha256': hashlib.sha256(compressed.read_bytes()).hexdigest(), 'requires': 'Torch2.14.1+cu130 git5c4886908584029761b579af026dcfb627c84070 and vendor cuBLAS130200; external runtime libraries not bundled'}
for notice in ['LICENSE', 'NOTICE', 'THIRD_PARTY_NOTICES.md']:
    path = base / 'libs/infinity-v3' / notice
    if path.is_file():
        (destination / notice).write_bytes(path.read_bytes())
(destination / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
(destination / 'README.md').write_text('Live work toward all140 documented model/task contracts, based on the public commit in MANIFEST.json. Source snapshots may be incomplete during active edits; immutable component freezes and SELECTIVE.patch identify reviewed milestones. No all-model or performance qualification is claimed. The Native mean-control payloads and thin pinned Native SDK are saved to avoid losing reproducibility; model weights, build caches and external Torch/CUDA runtime libraries are excluded.\n')
print(json.dumps({'files': len(manifest['files']), 'archive_bytes': archive.stat().st_size, 'native_sdk_bytes': compressed.stat().st_size if native.exists() else None}))
