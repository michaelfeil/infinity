# Canonical31 FA4 source review v2

Scope: bounded re-review of the corrected `fa4.rs`, actual `sm90`/`sm100`/`sm120` manifests, `profiles.inc`, `SELECTIVE.patch`, and `prefix-fingerprints.json`. Original `REVIEW.json`/`REVIEW.md` are preserved. No edits to `fa4.rs`; no build/run/GPU/network/Docker/Torch inspection.

## Result: clean

The original ABI9 blocker is withdrawn. All supplied actual manifests declare export ABI7/native ABI1, which is the corrected target. No ABI widening was introduced.

## Corrections verified

- `validate_manifest_abi` preserves the exact old predicate: only `abi_version == 7` and `native_abi_version == 1` are accepted (`fa4.rs:900-913`).
- `Fa4::new` calls that helper directly (`fa4.rs:943`).
- ABI9 and native ABI2 remain rejected; the actual canonical31 fixture asserts its real 7/1 header is accepted and 9/native2 are rejected (`fa4.rs:2043-2048`).
- `sm90-manifest.json`, `sm100-manifest.json`, and `sm120-manifest.json` are all 7/1, canonical31, mode_count 31, with the full fingerprint `187defa...a87f1`.
- The partial-prefix comment now correctly says each partial prefix uses its own ordered fingerprint (`fa4.rs:432-433`).
- Diffing the previously reviewed patch against the updated file shows only these bounded corrections. Profiles and registry paths are unchanged.
- The 31 ordinary fp16 exports in each actual manifest match source name/Q/KV/dimension/causal/window, including mode29 `[4096, -1]`.

## Preserved prior checks

Old 19/20/23/24/25/26 acceptance, `supports_published == 20`, Q40/KV8 d128 27/28, Q64/KV8 d128 22/5, Qwen3.5-MoE d256 26/30, inventory-only mode29 non-execution, and reordered/unknown export rejection are unchanged by the bounded correction.

The actual-manifest test remains an explicit `#[ignore]` test with no silent skip; it now exercises the ABI helper as well as the registry checks.
