# Independent Source-Only Review: Encoder Heads Increment v1

**Verdict:** PASS WITH FINDINGS. No blocking arithmetic/head-execution defect was found in the new head code. The main actionable items are an overstated DeBERTa coverage claim, a cold-admission/test semantics mismatch, and minor Dense policy-ordering/documentation gaps.

**Review date:** 2026-11-02  
**Review mode:** source only. No builds, GPU, Torch, Docker, network, compiler/device compile, weights, gold, runtime, benchmark, credentials, or private FA4 access. Only this review directory was written.

## Inputs and frozen-state checks

| Input | State |
|---|---|
| `/tmp/oxide-docs-parity-20261102/encoder-heads-increment-v1/source` | 4 files; hashes match `SOURCE-FREEZE.json` |
| `/tmp/oxide-docs-parity-20261102/encoder-heads` | READ ONLY; HEAD `252789b05ea2e09c14971c04dfcce458f863fead`; only the 4 expected files modified |
| `/tmp/infinity-plain-cuda` | Native C++ reference at HEAD `252789b...`; its Oxide Rust/device worktree is dirty with unrelated modifications, so only `git show HEAD:...` / the C++ files were used as the reference |
| `SELECTIVE.patch` | sha256 `b42c7cf16b5bf74e776819fc649e58e5a711f750ac9babeccabe301c84b919bc`; byte-for-byte equal to `git diff` in the assembled worktree |

Source hashes verified: `classifier_head.rs` `23d837a9...ec8a7`, `model.rs` `7e8c7f4e...5578`, `backends/src/lib.rs` `10e8ad35...350e`, `docs/oxide-backend.md` `95ad411f...d9b6`.

## What was checked against Native

Native references: `backends/libtorch/cpp/models/bert_model.h`, `dense_models.cpp`, `helpers/dense_mlp.cpp`.

| Native contract | Oxide source | Result |
|---|---|---|
| Sequence: gather each sequence's first packed token, then MLP if present, else optional `bert.pooler.dense` + tanh, then `classifier` | `classifier_head.rs` gather path + `enqueue`; `gather_first` uses device boundaries | Matches |
| Token: all packed tokens through MLP when present, otherwise one root linear; BERT pooler ignored | `classifier_head.rs:975-1051`, `1193-1275`; tokens are all packed rows | Matches |
| MLP order: `dense` -> tanh -> `out_proj` | `classifier_head.rs:1233-1244`, `enqueue` token MLP; `dense_mlp.cpp:257-288` | Matches |
| Root namespaces `classifier.*`, `bert.pooler.dense.*` independent of backbone prefix | `classifier_head.rs:263-286`; `bert_model.h:448-455`, `497-509` | Matches |
| Width from `out_proj.weight` else `classifier.weight` first dim | `classifier_head.rs:187-201`, `245-267`; `bert_model.h:457-462` | Matches |
| Complete-or-absent head groups | `classifier_head.rs:235-286` | Stricter than Native; see F4 |
| Sequence shape/row counts | `validate_bounds`, `require_canonical`, `rows`, `preflight` | Matches |
| Prepared BF16 GEMM path, FP32 accumulation, one BF16 rounding | `biased_linear.rs` `NativeLt`/`GemmEx`; N=1 caveat in F7 | Matches in intent |
| Final F32 cast before host packing | `cast_to_f32`; `classifier_head.rs:1333-1361` | Matches planned contract |
| Deferred result/lease/cancel/drop/oversize ownership | No `classifier_head.rs` diff to lease/ownership; `lib.rs` classifier branch `3291-3315` is unchanged | Untouched by this increment |

The increment does **not** modify `biased_linear.rs`, device shaders, `HostIoLease`, the workspace retirement path, or the normal engine factory. The new head plugs into the pre-existing `Work::classifier_parts` / `head.prepare` / `head.enqueue` / `download_output_range` path.

## Executable factory -> forward -> Deferred trace

This is a real executable path, not names-only admission:

1. `backends/src/lib.rs:533-619` `init_backend` routes Oxide classifiers through `OxideBackend::new_with_dense_paths`.
2. `oxide/src/lib.rs:4451-4458` -> `new_internal`; `4490-4523` performs early architecture detection, classifier precision rejection, and `classifier_head::validate_admission` before `Context::new` (`4556`).
3. `oxide/src/lib.rs:4579-4602` loads `BertWeights::load_classifier` / DeBERTa host, then `ClassifierHeadHost::load` or `from_deberta`, builds the encoder, and constructs `ClassifierHead::new` with uploaded BF16 head weights.
4. `oxide/src/lib.rs:3170-3315` stages the classifier batch, calls `head.prepare` before the first upload, then `head.enqueue` and `download_output_range` into the lease output slot.
5. `oxide/src/lib.rs:5973-6043` `submit_predict` and `6044-6128` `submit_predict_tokens` return `Inference::Deferred`; the closures wait on the lease, validate finite output, and call `pack_predictions` / `pack_token_predictions`.

## Findings

### F1 (Low, policy ordering): Classifier Dense ignore helper runs after Dense resolution/download

`backends/src/lib.rs:587-604` resolves and downloads Dense modules from `modules.json` **before** applying `oxide_effective_dense_paths` (`518-530`). `resolve_oxide_dense_modules` (`1497-1512`) turns a `modules.json` fetch/parse failure or a required Dense download failure into a startup error. For a classifier, the Dense result is then discarded and replaced by `Some(Vec::new())`.

Important qualifier: the Native libtorch path also calls `download_dense_modules` before setting classifier Dense paths to `None` (`backends/src/lib.rs:649-673`, `download_dense_modules` at `1541-1600`), so this is **not a new Native/Oxide parity divergence**. It is still an avoidable startup-failure/work path relative to the new helper's stated "ignored" policy, and it means `docs/oxide-backend.md:114-115` describes only application, not resolution.

Action: either document that "ignored" means "not applied" (matching Native's download-then-discard behavior) or, if robustness is the goal, move the classifier ignore decision before resolution. Add an integration test with a classifier plus `modules.json` containing a Dense module to pin the chosen behavior.

### F2 (Medium): HANDOFF `covered_source_executable` overstates DeBERTa coverage

`HANDOFF.json:43-45` lists all three `mixedbread-ai/mxbai-rerank-*` DeBERTa checkpoints as `covered_source_executable`, while `HANDOFF.json:21-25` explicitly says DeBERTa is not implemented here (Family C owns it), and `HANDOFF.json:148-150` repeats all three as leads.

Actual DeBERTa admission requires `hidden_size=768`, `num_attention_heads=12`, `intermediate_size=3072`, head size 64 (`deberta_encoder_model.rs:13`, `486-494`). Metadata:
- `mixedbread-ai/mxbai-rerank-base-v1`: 768/12/3072 -> potentially executable through the existing DeBERTa path.
- `mixedbread-ai/mxbai-rerank-large-v1`: 1024/16/4096 -> rejected by `require_exact("hidden_size", ..., 768)`.
- `mixedbread-ai/mxbai-rerank-xsmall-v1`: 384/6/1536 -> rejected by `require_exact("hidden_size", ..., 768)`.

Action: remove the large/xsmall IDs from `covered_source_executable` (or move them to Family C / unsupported), and distinguish "existing DeBERTa path" from this increment's generic head. Do not claim the generic head covers DeBERTa.

### F3 (Low, test/claim mismatch): Discovered-Dense fail-closed branch is unreachable through production; DeBERTa message differs

`classifier_head.rs:339-343` says malformed discovered Dense metadata "still fails closed", and `classifier_head.rs:1995-1999` asserts that deleting a declared Dense weight makes `validate_admission(..., None)` fail. But production classifier construction always passes `Some(Vec::new())` from `backends/src/lib.rs:604`, so the `dense_paths.is_none()` branch is skipped. Discovered Dense is then ignored (and a missing declared Dense weight is not rejected) in the real facade path. This production behavior matches Native's classifier "discover but do not apply" behavior; the defect is that the code comment and unit test claim a different fail-closed policy and do not exercise the facade.

For DeBERTa, `classifier_head.rs:316-327` similarly rejects a discovered Dense module only when `dense_paths` is `None`; the production `Some(Vec::new())` path accepts and ignores it, despite the "DeBERTa classifier does not accept Dense modules" message.

Action: make code comments/tests match production. If ignore is intended (consistent with Native), replace the fail-closed assertion with a facade-level ignore test. If fail-closed is intended, pass `None` through the facade and add that test. Apply the same decision to DeBERTa.

### F4 (Low): Pooler/MLP metadata handling is stricter than Native and can reject odd Native-supported checkpoints

- Native keys MLP presence only on `classifier.dense.weight` (`bert_model.h:448-455`) and only validates the pooler when a valid-shaped root `bert.pooler.dense.weight` exists (`bert_model.h:499-507`). Rust requires all four MLP tensors or none (`classifier_head.rs:235-244`) and requires a complete root pooler pair (`classifier_head.rs:272-286`).
- A token-classification checkpoint with a stray/incomplete/wrong-shaped root `bert.pooler` is rejected by Rust even though token readout ignores the pooler (`classifier_head.rs:1193-1275`) and Native's tokenwise `predict` never inspects it (`bert_model.h:491-508`).
- An `out_proj.*`-only checkpoint that Native would treat as a plain `classifier.weight` head is rejected by Rust's partial-group check.

This is fail-closed rather than silently wrong, but it is not Native-equivalent. Action: mirror Native's presence/shape gates or explicitly document the stricter admission and add tests for token + malformed pooler and `out_proj`-only heads.

### F5 (Future merge, no change requested now): `from_deberta` hardcodes hidden 768

`classifier_head.rs:205-221` sets `hidden: 768`; `deberta_encoder_model.rs:13` and `486-488` currently enforce 768/12/3072. This is correct today. If Family C widens DeBERTa geometry, this hardcode will cause `ClassifierHead::new` to reject or mis-size valid 384/1024 DeBERTa heads (`classifier_head.rs:753-785`, `817-827`). Per the task, do not change A1 here, but record the merge dependency in `HANDOFF.json:186-191` and update `hidden` from the actual DeBERTa head/config at merge.

### F6 (Qualification gap): No gold/oracle coverage for the new MLP stages

`classifier_head/gold_control.rs:8-18` defines only `minilm` (H384, width 1) and `ner` (H768, width 9) stages: `input`, `gold_token_score`, `gold_pooler`, `gold_tanh`, `gold_score`. The new `classifier.dense -> tanh -> out_proj` and token-MLP paths are not represented in the ignored Native oracle (`gold_control.rs:401-402`). CPU tests cover layout/admission only; `prepare`/`enqueue` GPU tests are ignored (`classifier_head.rs:2106`, `2227`).

Action: extend the ignored Native oracle manifest/cases to include at least one sequence-MLP and one token-MLP checkpoint and stage comparison. Until then, the HANDOFF status `source_implemented_cpu_tested_gpu_unqualified` is accurate; do not describe the new MLP as numerically qualified.

### F7 (Numeric risk / claim precision): N=1 uses GemmEx while Native may use the cached cuBLASLt bias path

`biased_linear.rs:212-214` selects the prepared default-Lt path only for `rows>0 && input>1 && output>1`; `output==1` uses `GemmEx` with a BF16 bias-preseed (`biased_linear.rs:333-361`, `417-477`). `classifier_head.rs:1878-1885` calls this the "native bias pointer shape gate".

Native's `classifier_projection` cached path explicitly allows `!gelu && matrix.size(0)==1` (`bert_model.h:101-113`) and uses `CUBLASLT_EPILOGUE_BIAS` when eligible; otherwise it falls back to `at::linear` (`bert_model.h:229-231`). The Rust GemmEx route is a reasonable equivalent (FP32 accumulate, bias added before the single BF16 round), but it is **not the same selector** as Native and its numeric equality is unproven. This matters for single-logit sequence heads and MLP `out_proj` widths of 1.

Action: keep the implementation if Root's GPU stage comparison accepts it, but soften the "source-faithful/native gate" wording and add an explicit N=1 comparison case (including hidden 768/384 and 1024).

### F8 (Low/Info): Classifier-specific backbone kernel/GEMM policy is expanded to all new families/widths

`lib.rs:1113-1123` sends every classifier config to `DownPolicy::ClassifierNativeDefault`; `lib.rs:705-706` sends every hidden-384 classifier to the classifier-specific exact kernels; `lib.rs:721-783` chooses exact-768/rounded-1024/generic-rounded recipes by width. Native's `cached_classifier_gemm` is narrower (hidden 768/384, heads 12, cudaLt/backend/alignment gates: `bert_model.h:101-113`, `316-384`), and its exact norm selector is width-based (`bert_model.h:272-275`, `362-365`). The Rust math recipes align with Native's width-based norm choice, but the classifier-specific kernel/GEMM policy is applied more broadly than Native's exact cached eligibility. This is a policy expansion, not a proven math defect.

Action: qualify the new widths (H128/H512/H1024) and non-BERT families under the GPU gate; if Native parity depends on the exact cached selector, restrict or document the broader policy.

### F9 (Info): Cold admission validates the head, not the full backbone

`validate_admission` opens the checkpoint and validates the actual head tensors before `Context::new` (`classifier_head.rs:344-347`; `lib.rs:4521` before `4556`), satisfying the "head tensors before CUDA" claim. The backbone namespace/shape and `validate_modules` run later in `BertWeights::load_classifier` (`lib.rs:4593`; `model.rs:2098-2101`) but still before weight upload/first enqueue. If Root wants all malformed-checkpoint rejection before context creation, the backbone loader must be moved earlier. Not a correctness defect for the current path.

## Exact docs-ID audit (config metadata only; no weights read)

The 27 IDs in `HANDOFF.json:33-75` split as follows. The generic head admits the four BERT-style families (`BertConfig::load_classifier`, `model.rs:604-628`); DeBERTa is the separate existing path.

| ID | model_type / architecture | hidden / heads / layers | Status |
|---|---|---|---|
| BAAI/bge-reranker-base | xlm-roberta / XLMRobertaForSequenceClassification | 768 / 12 / 12 | Generic head |
| BAAI/bge-reranker-large | xlm-roberta / XLMRobertaForSequenceClassification | 1024 / 16 / 24 | Generic head |
| BAAI/bge-reranker-v2-m3 | xlm-roberta / XLMRobertaForSequenceClassification | 1024 / 16 / 24 | Generic head |
| cross-encoder/mmarco-mMiniLMv2-L12-H384-v1 | xlm-roberta / XLMRobertaForSequenceClassification | 384 / 12 / 12 | Generic head |
| cross-encoder/ms-marco-MiniLM-L-12-v2 | bert / BertForSequenceClassification | 384 / 12 / 12 | Generic head |
| cross-encoder/ms-marco-MiniLM-L-6-v2 | bert / BertForSequenceClassification | 384 / 12 / 6 | Generic head |
| cross-encoder/ms-marco-MiniLM-L4-v2 | bert / BertForSequenceClassification | 384 / 12 / 4 | Generic head |
| cross-encoder/ms-marco-TinyBERT-L2-v2 | bert / BertForSequenceClassification | 128 / 2 / 2 | Generic head; H128 unqualified |
| mixedbread-ai/mxbai-rerank-base-v1 | deberta-v2 / DebertaV2ForSequenceClassification | 768 / 12 / 12 | Existing DeBERTa path only |
| mixedbread-ai/mxbai-rerank-large-v1 | deberta-v2 / DebertaV2ForSequenceClassification | 1024 / 16 / 24 | **Rejected**: DeBERTa requires 768/12/3072 |
| mixedbread-ai/mxbai-rerank-xsmall-v1 | deberta-v2 / DebertaV2ForSequenceClassification | 384 / 6 / 12 | **Rejected**: DeBERTa requires 768/12/3072 |
| Babelscape/wikineural-multilingual-ner | bert / BertForTokenClassification | 768 / 12 / 12 | Generic head |
| Davlan/bert-base-multilingual-cased-ner-hrl | bert / BertForTokenClassification | 768 / 12 / 12 | Generic head |
| Davlan/xlm-roberta-base-ner-hrl | xlm-roberta / XLMRobertaForTokenClassification | 768 / 12 / 12 | Generic head |
| dbmdz/bert-large-cased-finetuned-conll03-english | bert / BertForTokenClassification | 1024 / 16 / 24 | Generic head |
| dslim/bert-base-NER | bert / BertForTokenClassification | 768 / 12 / 12 | Generic head |
| dslim/bert-large-NER | bert / BertForTokenClassification | 1024 / 16 / 24 | Generic head |
| gravitee-io/bert-small-pii-detection | bert / BertForTokenClassification | 512 / 8 / 4 | Generic head; H512 unqualified |
| Jean-Baptiste/camembert-ner | camembert / CamembertForTokenClassification | 768 / 12 / 12 | Generic head |
| Jean-Baptiste/roberta-large-ner-english | roberta / RobertaForTokenClassification | 1024 / 16 / 24 | Generic head |
| obi/deid_bert_i2b2 | bert / BertForTokenClassification | 768 / 12 / 12 | Generic head |
| obi/deid_roberta_i2b2 | roberta / RobertaForTokenClassification | 1024 / 16 / 24 | Generic head |
| OpenMed/OpenMed-NER-DiseaseDetect-BioMed-335M | bert / BertForTokenClassification | 1024 / 16 / 24 | Generic head |
| OpenMed/OpenMed-NER-OncologyDetect-MultiMed-568M | xlm-roberta / XLMRobertaForTokenClassification | 1024 / 16 / 24 | Generic head |
| OpenMed/OpenMed-NER-PharmaDetect-BigMed-278M | xlm-roberta / XLMRobertaForTokenClassification | 768 / 12 / 12 | Generic head |
| cardiffnlp/twitter-roberta-base-sentiment-latest | roberta / RobertaForSequenceClassification | 768 / 12 / 12 | Generic head |
| ProsusAI/finbert | bert / BertForSequenceClassification | 768 / 12 / 12 | Generic head |

Count: 24 generic-head configs, 1 potentially executable DeBERTa config, 2 DeBERTa configs rejected by the existing DeBERTa geometry. Config metadata alone cannot prove the plain-vs-MLP tensor layout for each ID; that requires weights, which this review was not authorized to read.

## Checks that found no blocking defect

- Token MLP materializes all packed token rows and packs outputs by sequence boundaries, not just CLS.
- CLS-first gather uses the uploaded cumulative boundary table; host validation matches the same table.
- Optional `bert.pooler` is applied only on sequence readout and only from the root namespace.
- Scratch capacity covers both readout modes and the token hidden/logit extents (`classifier_head.rs:446-478`); checked products are used.
- Prepared source/stream/pointer and per-projection boundaries are revalidated at enqueue; failures are fatal, not silent.
- `prepare` occurs before the first upload/enqueue; no CPU math substitutes for the head.
- No new device export is required for the new head recipe: `infinity_classifier_bias_bf16`, `infinity_classifier_gather_first_bf16`, `infinity_dense_tanh_bf16_inplace`, `infinity_bf16_to_f32`, and `infinity_gelu_exact` already exist in the frozen device source/export list. The claim "new shaders not needed" is source-backed for this increment.
- `SELECTIVE.patch` applies cleanly and matches the assembled worktree.

## Scope limits

- No actual weights, tensors, gold files, runtime logs, benchmark data, credentials, or private FA4 source were read.
- No build, no Cargo test execution, no GPU/CUDA/torch/Docker/network/compiler/device compile.
- CPU test counts in `independent-head-cpu.log` and `HANDOFF.json` were noted but not independently re-run.
- Numeric equality, trained-checkpoint accuracy, and performance remain unqualified. This review does not assert generic full support or performance.
- DeBERTa widening, ModernBERT/GTE integration, and decoder task heads remain outside this increment; they were not reviewed as new functionality.
