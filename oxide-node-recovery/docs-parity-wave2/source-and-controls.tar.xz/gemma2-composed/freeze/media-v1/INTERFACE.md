# EmbeddingGemma2 media interface (gemma2-media worker)

Tree: `/tmp/oxide-docs-parity-20261102/gemma2-media/work` (detached from public
`252789b05ea2e09c14971c04dfcce458f863fead`).
Kernel names are the stable, additive `infinity_gemma2_media_*` set (24 exports).

## Modules this worker owns

| file | role |
| --- | --- |
| `backends/oxide/src/gemma2_media.rs` | typed config/inventory, `MediaTokens`, `MediaConfig`, `MediaHost`, `MediaRequest` |
| `backends/oxide/src/gemma2_media_vision.rs` | actual Gemma4 vision tower forward (patch, axial RoPE, Q/K/V norm, packed noncausal attention, gated GELU MLP, 3x3 pool, unit norm, 768->512 projector) |
| `backends/oxide/src/gemma2_media_audio.rs` | actual Gemma4 conformer audio tower forward (masked stride-2 conv subsampling, ff1, chunked relative attention, GLU depthwise causal conv, ff2/norm_out, output projection, unit norm, 1536->512 projector, selected rows) |
| `backends/oxide/src/gemma2_media_exec.rs` | `MediaRuntime`, `PreparedMedia`, `MediaKernels`, scatter/copy owners (re-exported from `gemma2_media`) |
| `backends/oxide/src/gemma2_media_prepared.rs` | BF16->F32 norm staging (`upload_norm`) |
| `backends/oxide/src/gemma2_media_bridge.rs` | `MediaLayout` -> existing checked `TensorRef`/`TensorMut` |
| `backends/oxide/device/src/gemma2_media.rs` | 24 device kernel bodies |
| `backends/core/src/media/*` | shared packed layout / policy / cold upload foundation |

## API the shared text executor adopts

```rust
// config: media-owned view, independent of the text config type.
let media = gemma2_media::MediaConfig::from_config_value(&config_json, text_hidden)?;
// or construct the fields directly: text_hidden, vision_layers, audio_layers,
// vision_config (Option<Value>), audio_config (Option<Value>), tokens (Option<MediaTokens>).

// cold, once per model
let host: Option<gemma2_media::MediaHost> =
    gemma2_media::MediaHost::load(model_root, &media)?;
let runtime: gemma2_media_exec::MediaRuntime = gemma2_media_exec::MediaRuntime::load(
    &context, &stream, &host, text_hidden, kernel_module_path)?;

// warm, per request
let request: Option<gemma2_media::MediaRequest> = gemma2_media::MediaRequest::plan(
    &batch, &media, text_hidden, media.tokens)?;
let prepared: gemma2_media_exec::PreparedMedia =
    runtime.prepare(&plain_blas, &stream, request)?;

// after the text gather and before the first text layer, on the same stream
runtime.scatter(&stream, &mut state_device_buffer /* BF16 [tokens, hidden] */, &prepared)?;
// retain `prepared` until the stream has drained and the output D2H completed.
```

`MediaTokens` fields: `image`, `video`, `audio`, `begin_image`, `end_image`,
`begin_audio`, `end_audio`. `MediaRequest::plan` already:

- maps `Batch.multimodal` sequence spans to absolute packed-token rows,
- sorts interleaved image/audio spans by `token_start`,
- validates grid/patch/mask geometry through the shared `PackedMedia` policy,
- rejects non-placeholder destination rows and duplicate rows,
- retains each `Arc<MultimodalEncoding>` until the request is dropped.

## Contract details

- Media rows are produced in `spans` order; `row_indices` is the matching sorted
  absolute destination-row list. `PreparedMedia.rows` is BF16
  `[row_indices.len(), text_hidden]`.
- `runtime.prepare` performs every tower launch; `runtime.scatter` is a single
  packed row-scatter kernel. Both use the caller stream.
- Ownership: `PreparedMedia` owns tower scratch, index buffer and row arena. On
  an uncertain stream state the drop path retains device owners instead of
  freeing them (failed-fence quarantine).
- Opt-in: `INFINITY_OXIDE_GEMMA2_MEDIA=1` enables host media validation/runtime;
  text-only default is unchanged.
- No CPU math, Torch, Python or LibTorch fallback exists in the media path.

## What this worker needs from the text side

Only a BF16 `[tokens, hidden]` gathered state buffer and the plain cuBLAS handle
plus kernel module loaded on the same context/stream. The text executor keeps
the 7 media token ids from its config parser; it can pass them to
`MediaConfig::from_config_value` or build `MediaConfig` directly.

## Native semantics reference

`backends/libtorch/cpp/models/gemma_models.cpp` (`vision()` / `audio()`) and
`backends/libtorch/cpp/helpers/gemma_media_reference.h`. Numeric equivalence is
source-level only; Root owns the actual GPU comparison.
