# EmbeddingGemma2 text implementation (selective source patch)

Status: **SOURCE_ONLY_CPU_GATES_PASS_ROOT_GPU_PENDING**. No GPU, CUDA context,
device compilation, Torch, Docker, or network was used.

- Base: `252789b05ea2e09c14971c04dfcce458f863fead`
- Worktree: `work/` (detached)
- Patch: `SELECTIVE.patch` (applies cleanly to the base)
- Evidence: `EVIDENCE.json`
- Media coordination: `INTERFACE.md`

## Real implementation

New standalone Oxide modules own the actual EmbeddingGemma2 text forward:

- `gemma2_text.rs`: Native config/weight admission, nested `text_config`,
  per-layer 05/11/17/23 d512/kv1 overrides, doubled sliding window, shared-KV
  producer map, PLE `[T,24,512]`, saved `embedding_projection [768,512]`.
- `gemma2_prepared.rs`: exact DivSqrt/BF16 norm admission, BF16 scale expansion,
  Native split-half RoPE table construction.
- `gemma2_attention.rs`: d256 local uses the existing FA4
  `embedding_gemma2_local256` profile; d512 full H4/KV1 uses the new
  `infinity_gemma2_full_attention_bf16` SIMT kernel. No fallback.
- `gemma2_forward.rs`: graph-free BF16 executor with embedding gather, PLE,
  per-layer norms, q/k norm + RoPE, unit V, shared KV, O projection, packed
  gate/up GELU-tanh, down, PLE gate/projection, `layer_scalar`, final norm,
  saved projection, mean/CLS/last pooling, raw 768-wide rows, and the internal
  media injection hook.
- Factory: `embedding_gemma2` architecture detection, BF16-only pooled
  Cls/Mean/LastToken service, `ExecutableModel::Gemma2`, `Workspace::Gemma2`,
  Engine dispatch and raw-output capacity.

Image/audio towers are intentionally outside this patch. `Gemma2MediaInjection`
accepts already-projected hidden-512 BF16 rows per packed span; see
`INTERFACE.md`.

## CPU gates

- focused Gemma2 tests: 37 passed, 0 failed, 1 ignored
- clippy `--lib --tests -D warnings`: pass
- fmt `--all --check`: pass
- `cargo check -p infinity_v3-backend --no-default-features --features oxide`: pass
- patch `git apply --check` against base: pass

Root still needs the SM90/SM100/SM120 bundle build, an actual first-forward /
pooled Native-vs-Oxide comparison, media tower composition, and numerical
qualification.
