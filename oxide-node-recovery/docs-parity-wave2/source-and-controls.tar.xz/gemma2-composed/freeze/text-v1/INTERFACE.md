# EmbeddingGemma2 text / media coordination interface

Status: text owner contract. Media tower implementation is owned by a separate
Root worker. This document is the early, stable hand-off for that worker.

## Ownership split

- This worktree owns `google/embeddinggemma-2` **text**:
  `embed_tokens`, PLE (`per_layer_model_projection` +
  `per_layer_projection_norm`), 24 packed Gemma layers (local d256/kv2 and full
  d512/kv1), shared-KV producers, per-layer entry `ple_block.*`, per-layer
  `layer_scalar`, final `norm`, saved `embedding_projection`, and
  mean / last-token / CLS pooling metadata.
- The media worker owns the 16-layer Gemma4 vision tower, the 12-layer conformer
  audio tower, their exact weight inventory, image/audio preprocessing, and the
  media routes. It must not edit the text modules.
- The text model accepts already-projected BF16 rows in the text hidden width
  (`[sum(tokens), 512]`). It never loads tower weights and never invents tower
  math.

## Injection call shape

The text executor exposes an internal, non-public hook:

```rust
pub(crate) struct Gemma2MediaInjection<'a> {
    /// Absolute packed text-token row spans, ascending and non-overlapping.
    pub(crate) spans: &'a [Gemma2MediaSpan],
    /// BF16 rows in packed-span order, `[total_span_tokens, hidden_size]`.
    pub(crate) rows: &'a cuda_core::DeviceBuffer<crate::tensor::Bf16>,
}

pub(crate) struct Gemma2MediaSpan {
    pub(crate) token_start: usize,
    pub(crate) token_count: usize,
}
```

`enqueue` takes `Option<Gemma2MediaInjection<'_>>`. When present, the text
executor first gathers `embed_tokens`, then overwrites exactly the injected rows
with `rows` before the PLE model projection and layer stack. This is the Native
order in `backends/libtorch/cpp/models/gemma_models.cpp` (`inject_images`, then
`states.narrow(...).copy_(features)` for audio, then PLE).

Validation is host-side and typed, before any pointer is bound:

- `spans` are ascending, each `token_count > 0`, and
  `token_start + token_count <= tokens`.
- `rows` is BF16 and has exactly `sum(token_count) * hidden_size` elements.
- The injection owner (rows allocation + stream/event) must outlive the text
  stream completion or be quarantined on uncertain device state.
- Text-only requests pass `None`; `Batch.multimodal` must be empty for the text
  route. Media requests are admitted only after the media worker supplies a
  completed projection with the same CUDA context.

The text executor returns its pooled/raw BF16->F32 output only after the
embedding projection; a media caller never sees hidden-512 rows, only the final
768-wide vectors. To coordinate row selection, the media worker must publish
the exact `Batch.cumulative_seq_lengths`, placeholder token ids, and expected
span layout into the same packed `Batch` consumed by text.

## Config / task metadata used by text

- Container `model_type = embedding_gemma2`, architecture
  `EmbeddingGemma2Model`; nested `text_config.model_type =
  embedding_gemma2_text`.
- `hidden_size=512`, `intermediate_size=2048`, `num_hidden_layers=24`,
  `num_attention_heads=4`, `num_key_value_heads=2`, `head_dim=256`,
  `hidden_size_per_layer_input=512`, `embedding_dim=768`, `vocab_size=262144`.
- `per_layer_config` overrides layers `5,11,17,23` to `head_dim=512`,
  `num_key_value_heads=1`; no layer sharing in the released checkpoint.
- `sliding_window=512` (Native doubles it to a symmetric 512/512 mask).
- RoPE: sliding theta `10000`, full theta `1000000`; split-half NeoX.
- Norm: Gemma2 DivSqrt F32 statistics, BF16 scale from checkpoint (no +1),
  epsilon `1e-6`; V uses unit norm; attention scale is exactly `1.0`.
- Activation: `gelu_pytorch_tanh` with Native composed BF16 rounding.
- Output: saved `embedding_projection [768,512]` before pooling. Task metadata
  admits `Pool::Mean`, `Pool::LastToken`, and `Pool::Cls`; raw token rows are the
  768-wide projected rows.

## Media worker deliverables

1. Projected BF16 span owner implementing the shape above (or a wrapper that can
   be copied into a text-owned staging buffer before enqueue).
2. Exact inventory/labels/shapes for both towers, the final `embed_vision` /
   `embed_audio` 768-wide projections (or 512-wide rows if the worker keeps the
   last projection in text; the text hook accepts hidden-512 rows only).
3. Evidence that image/audio spans are sorted and match placeholder ids.
