# Dense Qwen2/Qwen3/Llama parity deltas

Base `252789b05ea2e09c14971c04dfcce458f863fead`. Source-only; CPU evidence only.

## Real geometry implemented

- **Qwen2 H896/d64**: `DecoderMath::Qwen2H896MaskedCandle` binds the Native
  `exact_norm<1024,4,1,bf16,false>` masked registration (`1/896`, lanes 16..31
  skip the fourth 8-value group) through new device exports
  `infinity_rms_norm_896_exact_masked_vector` /
  `infinity_add_rms_norm_896_exact_masked_vector`, plus model-dtype HFMA
  split-half RoPE. This is not a relaxed guard: the executor previously had no
  recipe for the masked reduction.
- **Llama3 scaled RoPE**: `BaseRopeTables::new_llama3` reproduces Candle's F32
  NTK-by-parts stages and BF16 table ABI. `DecoderConfig` carries the validated
  scale; cold load selects the scaled builder.
- **Bidirectional Llama classifier**: `llama_bidirec` alias, noncausal trunk,
  `LlamaBidirectionalForSequenceClassification`, avg-pooled model-dtype mean
  over logical spans, optional temperature divisor, dynamic `id2label` /
  `num_labels` (including 1-label reward heads).
- **Dense Qwen config/task geometry**: all-`full_attention` `layer_types` with
  exact layer count, `PPLXQwen3Model` for the bidirectional pplx alias,
  `rope_parameters` default theta, exactly-one last-token/mean decoder pooling,
  Perplexity's floating-point `FlexibleQuantizer` no-op, and noncausal root
  `linear.weight` projection as a real BF16 Dense chain (voyage-4-nano
  1024 -> 2048).

## Covered fixtures

gte-Qwen2 1.5B/7B, jina-code 0.5B/1.5B, Qwen3-Embedding 0.6B/4B/8B,
harrier-oss-v1-0.6b, voyage-4-nano, pplx-embed-v1 0.6B/4B, Skywork reward
Qwen3 0.6B, llama-nemotron-rerank-1b-v2. The regression test selects the same
recipe the loader/executor will bind.

## Green CPU evidence

- `cargo test -p infinity-backend-oxide --lib --offline -j2`: 671 passed, 0 failed, 73 ignored.
- `cargo clippy -p infinity-backend-oxide --offline -j2 -- -D warnings`: clean.
- `cargo fmt -p infinity-backend-oxide -- --check`: clean.
- device registry: `test_qwen35_export_registry.py` 4 passed, `test_build.py` 13 passed.
- `CUDA_VISIBLE_DEVICES` empty, offline, CPU only.

## Pending (Root-owned / numeric)

FA4 still needs four shared profiles before those models can execute:
Qwen2 14/2 d64 causal, Qwen2 12/2 d128 causal, Llama 32/8 d64 noncausal,
Qwen3 16/8 d128 noncausal. The exact request is in
`libs/infinity-v3/docs/dense-gaps-fa4-profile-request.json`. Existing profiles
already cover gte-Qwen2 1.5B/7B, all Qwen3 Embedding sizes, harrier, Skywork
and pplx-4B. No bundle was compiled here.

Not run: GPU, Torch, Docker, device/AOT compile, optimized host build, actual
checkpoint movement or Native numeric comparison.
