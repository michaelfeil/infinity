// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Cold Work-miss preparation for the Clef joint head.

use crate::{
    clef_decision_head::ClefHead,
    clef_decision_plan::plan_requests,
    clef_decision_prepared::ClefPrepared,
    decision_head::PackedDecisionBatch,
    start,
};
use cuda_core::Stream;
use infinity_v3_backend_core::{BackendError, DecisionInput};
use std::sync::Arc;

impl ClefHead {
    /// Validate one request plan at a cold Work miss. This performs no device
    /// allocation or synchronization; `ClefPrepared` owns the host metadata
    /// tail until the outer completion fence.
    pub(crate) fn prepare(
        &self,
        batch: &PackedDecisionBatch<'_>,
        ids: &[u32],
        requests: &[DecisionInput],
        stream: &Arc<Stream>,
    ) -> Result<ClefPrepared, BackendError> {
        if !Arc::ptr_eq(stream.context(), &self.context)
            || !std::ptr::eq(stream.as_ref(), self.stream.as_ref())
        {
            return Err(start("Clef preparation requires its cold stream"));
        }
        Ok(ClefPrepared::new(plan_requests(batch, ids, requests)?, stream))
    }
}
