# Desired `decision_refinement.rs` interface for Clef

Status: coordination only. The draft at
`/tmp/oxide-docs-parity-20261102/modern-decisions/repo/libs/infinity-v3/backends/oxide/src/decision_refinement.rs`
was read as an interface reference only. That live file was not copied, edited,
or written. This Clef tree has its own `clef_decision_*` leaves so it can build
without taking ownership of the shared refinement module.

## What Clef needs from the shared module

The existing public data owners are the right abstraction:

- `AffineNorm { gamma, beta }` in BF16.
- `BiasedProjection { weight, bias }` in BF16.
- `RefinementBlock { norm1, norm2, qkv, out, ffn1, ffn2 }`.
- `RefinementPlan`/`LinearPlan<Bf16>` built once from exact row counts.
- `RefinementBuffers<'a>` referencing caller-owned scratch.
- The same ownership rule: the outer `Work`/completion fence retains all
  buffers; the block performs no allocation, context query, or synchronization.

Clef cannot consume the current `enqueue_block` as-is because it assumes a
single packed self-attention boundary set shared by Q and K/V, and it only
selects ReLU or tanh-GELU. Clef needs three things:

1. **Exact GELU.** Add `RefinementActivation::GeluExact` (Native
   `MlpActivation::Gelu` is `at::gelu(x, "none")`, not tanh GELU). The existing
   public artifact entry is `infinity_gelu_exact`.
2. **Separate Q and K/V extents.** Routing attention queries option rows
   `[options, width]` against token memory `[tokens, width]`; field-decoder
   cross-attention queries field rows `[fields, width]` against token memory.
   Add an offset descriptor such as:

   ```rust
   pub(crate) struct RefinementAttentionOffsets {
       pub(crate) q: u64,          // device u32 [batch + 1], query rows
       pub(crate) kv: u64,         // device u32 [batch + 1], memory rows
       pub(crate) q_tokens: usize,
       pub(crate) kv_tokens: usize,
       pub(crate) batch: usize,
       pub(crate) max_q: usize,
   }
   ```

   The launch should use the existing FA4 typed borrowed view
   (`Fa4::forward_batch_bound` with noncausal global BF16, RsqrtHeadDim), not a
   new attention implementation. Q/K/V projections stay biasless GEMMs followed
   by the Native packed `in_proj_bias` add; `out_proj` is a biased GEMM.
3. **Clef's two block shapes.** Expose two allocation-free enqueue functions
   over the same `RefinementBlock`/`RefinementBuffers`:

   ```rust
   pub(crate) unsafe fn enqueue_routing_block(
       blas: &Blas,
       fa4: &Fa4,
       stream: &Stream,
       kernels: &RefinementKernels<'_>,
       block: &RefinementBlock,
       plan: &RefinementPlan,
       buffers: &mut RefinementBuffers<'_>,
       offsets: &RefinementAttentionOffsets,
       hidden: usize,
       heads: usize,
       activation: RefinementActivation,
   ) -> Result<(), BackendError>;

   pub(crate) unsafe fn enqueue_decoder_block(
       blas: &Blas,
       fa4: &Fa4,
       stream: &Stream,
       kernels: &RefinementKernels<'_>,
       self_block: &RefinementBlock,
       cross_block: &RefinementBlock,
       self_plan: &RefinementPlan,
       cross_plan: &RefinementPlan,
       buffers: &mut RefinementBuffers<'_>,
       self_offsets: &RefinementAttentionOffsets,
       cross_offsets: &RefinementAttentionOffsets,
       hidden: usize,
       heads: usize,
       activation: RefinementActivation,
   ) -> Result<(), BackendError>;
   ```

   `enqueue_routing_block` computes:
   `x = q + attention(query_norm(q), memory_norm(memory))`, then
   `x = x + ffn(feedforward_norm(x))`.

   `enqueue_decoder_block` computes:
   `y = x + self(norm1(x), norm1(x))`;
   `y = y + cross(norm2(y), memory)`;
   `y = y + ffn(norm3(y))`.

   Both use separate Q/K/V projections exactly as Native `Attention` does.

## What can be reused immediately

`AffineNorm`, `BiasedProjection`, `RefinementBlock`, `RefinementPlan` and the
caller-owned-buffer rule are directly compatible with
`clef_decision_head.rs`. The following helpers in the draft should become
`pub(crate)` reusable entries when Root composes the shared API:

- `layer_norm` (BF16 affine, epsilon `1e-5`, optional null residual/bias).
- `bias_add`/`activation` (including exact GELU).
- `enqueue_block` internals for QKV projection, residual add, FFN and plan
  capacity checks.

Once these are exported, Clef can delete its local
`clef_decision_attention.rs`, `clef_decision_ops.rs` norm/linear/bias paths and
the duplicate `ClefAttention`/`ClefRouting`/`ClefDecoder` launch composition.
Only the Clef-specific span means, lexical prior, softmax summary, normalized
cosine/feature and final gated logits remain in `clef_decision_*`.

## Non-negotiable semantics

- BF16 prepared storage and BF16 weight sources only on the current public route.
- No allocation, stream synchronization, context query, plan construction or
  weight read in the request enqueue path.
- No CPU forward fallback and no generic option-token head.
- `RefinementActivation::GeluExact` must remain distinct from `GeluTanh`.
- Cross attention must accept distinct query and memory token counts.

## Q35 head-worker leaf boundary

The leaf exposes exactly the pieces the Q35 work owner can place in its cached
head enum without copying the live Q35 pipeline:

```rust
enum DecisionHeadScratch {
    // existing worker-owned variants stay untouched
    Clef {
        capacity: ClefCapacity,
        workspace: ClefWorkspace,
    },
}
```

Per Work key:

1. `ClefCapacity::device_bytes()` is the arena charge for this variant.
2. Cold Work construction calls `ClefWorkspace::new(&stream, capacity)`.
3. Cold request admission / Work miss calls
   `ClefHead::prepare(batch, ids, requests, &stream)`.
4. `prepared.metadata()` is appended to the worker's **single** `Work.input`
   tail; `prepared.metadata_words()` is the exact u32 capacity requirement.
   The worker's existing one upload publishes it.
5. The request enqueue calls:

   ```rust
   unsafe fn enqueue_bound(
       head: &ClefHead,
       activation: &DeviceBuffer<Bf16>,
       lexical: &DeviceBuffer<Bf16>,
       workspace: &mut ClefWorkspace,
       prepared: &ClefPrepared,
       blas: &Blas,
       stream: &Stream,
       host_out: *mut f32,          // request-owned HostIoLease slice
       metadata_base: u64,          // already-uploaded Work.input tail
   ) -> Result<(), BackendError>;
   ```

   This entry does no H2D metadata upload, no allocation and no synchronization.
   The standalone `enqueue` wrapper is only the leaf's self-contained fallback.
6. The output request lease remains the worker's. The leaf writes only option
   logits to `host_out`; after completion the worker calls
   `prepared.finish(leased_host_slice)`, which writes Native action `1.0`,
   splits field/option order, and marks the host metadata owner drained.
7. On any partial enqueue failure the worker retains/quarantines both
   `ClefPrepared` and the `Clef` variant until its existing fence proves drain.

`ClefPrepared` owns the host metadata tail. `ClefWorkspace` owns device scratch.
Neither creates a CUDA context, stream, event, lease, or second H2D path.
