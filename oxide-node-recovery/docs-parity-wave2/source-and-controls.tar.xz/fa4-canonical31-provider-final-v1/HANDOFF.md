Canonical31 provider source handoff

Apply only SELECTIVE.patch; eight vendor source/docs/test files. The actual profiles.inc, bridge.cpp, build.py and build_contract.py are byte-identical to the qualified31 producer. Existing --architectures and --only-symbol tooling remains present. All3 actual manifests validate,180 actual baseline object hashes match, and fresh CPU processes queried compile-time31/mask/namespace/portable/target constants from each actual linkedDSO. ABI7/native1 comes from the pinned manifests and unchanged C signature; no nonexistent binary ABI-version query is claimed.

15 CPU tests pass, including selected new-tail fake exports and full70-object producer path, import/foreignJIT guards and development-manifest isolation. No new AOT or GPU validation run. Original CPU constant-query attempt failed because loading three independent TVM FFI copies into one process double-registered a global type; failure preserved, corrected to three fresh CPU processes.

Old26 objects and helper order remain exact; selected development exports cannot be loaded as production providers. Mode29 is provider inventory only in the current Rust route. H5120 model/runtime remains separately gated.

Root should apply this vendor-only patch alongside final canonical31 fa4.rs host patch. Rebuilding the provider is reproducible with the existing README build_all.py command; no private /tmp paths are introduced into public source.
