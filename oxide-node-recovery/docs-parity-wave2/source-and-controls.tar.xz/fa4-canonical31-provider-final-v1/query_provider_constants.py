#!/usr/bin/env python3
"""Read only compile-time registry constants; never call a forward/GPU API."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import sys

if os.environ.get("CUDA_VISIBLE_DEVICES") != "":
    raise SystemExit("CUDA_VISIBLE_DEVICES must be empty")
root = Path(sys.argv[1]).resolve(strict=True)
records = []
keep = []
for sm, capability in (("sm90", 90), ("sm100", 100), ("sm120", 120)):
    directory = root / sm
    manifest = json.loads((directory / "manifest.json").read_text())
    assert manifest["abi_version"] == 7 and manifest["native_abi_version"] == 1
    for dep in ("libtvm_ffi.so", "libcute_dsl_runtime.so"):
        keep.append(ctypes.CDLL(str(directory / dep), mode=ctypes.RTLD_GLOBAL))
    library = ctypes.CDLL(str(directory / "libinfinityfa4.so"), mode=ctypes.RTLD_LOCAL)
    keep.append(library)
    values = {}
    for symbol, expected in (
        ("infinity_fa4_registry_mode_count_v1", 31),
        ("infinity_fa4_modes_v1", 0x7fffffff),
        ("infinity_fa4_compute_capability_v1", capability),
        ("infinity_fa4_portable_host_v1", 1),
    ):
        fn = getattr(library, symbol)
        fn.argtypes = []
        fn.restype = ctypes.c_int
        actual = fn()
        assert actual == expected, (sm, symbol, actual, expected)
        values[symbol] = actual
    fn = library.infinity_fa4_registry_namespace_v1
    fn.argtypes = []
    fn.restype = ctypes.c_char_p
    namespace = fn().decode("ascii")
    assert namespace == "canonical31"
    values["infinity_fa4_registry_namespace_v1"] = namespace
    records.append({"architecture": sm, "binary_constants": values,
                    "manifest_abi_version": manifest["abi_version"],
                    "manifest_native_abi_version": manifest["native_abi_version"],
                    "library_sha256": hashlib.sha256((directory / "libinfinityfa4.so").read_bytes()).hexdigest()})
print(json.dumps({"status": "passed", "scope": "compile-time CPU constant entrypoints only; no forward, CUDA driver, context or device API called", "records": records}, indent=2))
