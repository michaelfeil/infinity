# Canonical31 FA4 source review

Scope: static review of `fa4.before.rs`, `fa4.rs`, `profiles.inc`, `SELECTIVE.patch`, and `prefix-fingerprints.json`. No edits to `fa4.rs`; no build/run/GPU/network/Docker/Torch/weights inspection.

## Blocker

**ABI9 canonical31 bundle is still rejected by the loader.** `Fa4::new` hard-requires `abi_version == 7` and `native_abi_version == 1` (`fa4.rs:930-939`); the source still describes the contract as ABI7 (`fa4.rs:4,34`). The patch appends the 31-mode registry but never accepts ABI9, so the target ABI9 bundle cannot be loaded. The added actual-manifest tests only call `validate_profile_order`/`select_profile` (`fa4.rs:2036-2075`, `fa4.rs:3042-3064`), so they miss the loader guard; the GPU load tests that call `Fa4::new` are `#[ignore]`.

## Non-blocking

The comment at `fa4.rs:432-435` says every accepted canonical31 prefix carries the same full-registry fingerprint. The code and tests correctly use distinct prefix-specific fingerprints for 27-30. Behavior is correct; fix the comment.

## Verified

- Old 19/20/23/24/25/26 prefix acceptance: rows and ordered prefix validation are unchanged.
- `supports_published` remains the 20-profile published prefix.
- Registry rows 27-31 match `prefix-fingerprints.json`; I also recomputed them from `profiles.inc` and all 19-31 hashes match.
- Partial fingerprints 27-30 are prefix-specific and exact; reusing the full 31 hash on a partial prefix is rejected.
- Q40/KV8 d128 causal 27 and noncausal 28 match `profiles.inc`; Q64/KV8 d128 stays on 22/5; Qwen3.5-MoE Q16/KV2 d256 stays on 26/30.
- Mode 29 accepts the exact manifest window `[4096,-1]` but is not selectable/executable: negative extents fail `Window::canonical_local_extents`, support/selection, and `check_batch`. GPU loops skip it with an explicit `supports == false` assertion.
- Reordered and unknown exports are rejected by the strict ordered scan and covered by the added tests.
- The two added actual-manifest tests are explicitly `#[ignore]` and panic if their env binding is missing; there is no silent skip. Their separate execution cannot be confirmed from these files, and neither exercises the ABI9 loader guard.
