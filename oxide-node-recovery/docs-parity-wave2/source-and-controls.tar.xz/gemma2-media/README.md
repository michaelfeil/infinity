# EmbeddingGemma2 image + audio media (source-only)

Status: **SOURCE_ONLY_CPU_GATES_PASS_ROOT_GPU_PENDING**. No GPU, CUDA context,
NVCC/device build, Torch, Docker or network was used.

Base: public `252789b05ea2e09c14971c04dfcce458f863fead` (detached worktree at
`work/`). Patch: `patch/gemma2_media_selective.patch`
(sha256 `072568f11773d874fab78c4bca462f88f52782379d786bc2c070b0ac55b7f4c7`).

## Owned scope

- `gemma2_media.rs`: typed tower config/inventory, media-owned
  `MediaTokens`/`MediaConfig`, `MediaHost`, `MediaRequest` packed-row plan.
- `gemma2_media_vision.rs`: actual Gemma4 vision forward.
- `gemma2_media_audio.rs`: actual Gemma4 conformer audio forward.
- `gemma2_media_exec.rs`: `MediaRuntime`, `PreparedMedia`, cold weights,
  per-request scratch, row scatter and failed-fence retention.
- `gemma2_media_prepared.rs`: BF16->F32 norm staging.
- `gemma2_media_bridge.rs`: shared media layout -> checked tensor views.
- `device/src/gemma2_media.rs` + 24 additive `infinity_gemma2_media_*` exports.
- Shared media foundation in `backends/core/src/media/*` and processor deltas.
- Native C++ scalar reference helper and CPU test.

The old private text executor and the `/tmp` head512 path dependency are not in
this tree. `INTERFACE.md` documents the exact injection API for the shared text
executor.

## CPU gates

- oxide focused gemma2: 29 passed, 0 failed, 1 ignored (GPU)
- backend-core media: 23 passed, 0 failed
- core EmbeddingGemma2 processor: 5 passed, 0 failed
- clippy `--lib --tests -D warnings`: pass
- rustfmt `--all --check`: pass
- Native C++ reference `g++ -std=c++20 -Wall -Wextra -Werror`: pass
- Patch applies cleanly to the public base.

All commands ran with `CUDA_VISIBLE_DEVICES=`, `CARGO_NET_OFFLINE=true`,
`taskset -c 160-167`, `-j2`.

## Root gates (not run)

See `ROOT-GATES.md` and `evidence/EVIDENCE.json`. Numeric/runtime quality is
not claimed. The current audio fixture uses deterministic sandbox decimation and
must be regenerated with the production ffmpeg path before parity.
