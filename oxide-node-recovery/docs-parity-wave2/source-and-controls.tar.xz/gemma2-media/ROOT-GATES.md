# Root gates

1. Device source build (Root only):
   - `cd work/libs/infinity-v3/backends/oxide/device && ./build.sh <out>`
   - Build SM90, SM100, SM120.
   - Require the pre-existing 86 gemma2/legacy exports' `.text` and driver
     resources to match the published bundle; the 24 `infinity_gemma2_media_*`
     exports are additive (110 literal gemma2/legacy symbols).
   - The inventory test `gemma2_math::tests::source_inventory_keeps_legacy_78_and_appends_exactly_eight`
     already pins the 78 legacy symbols, 8 prior gemma2 exports, 24 media names
     and the unchanged `gemma2.rs` source hash.

2. Actual media forward:
   - Apply `patch/gemma2_media_selective.patch` to public `252789b`.
   - Set `INFINITY_OXIDE_GEMMA2_MODEL` and `INFINITY_OXIDE_KERNEL_MODULE`
     (media bundle).
   - Run:
     `CUDA_VISIBLE_DEVICES=0 cargo test --release -p infinity-backend-oxide --lib actual_image_and_audio_towers_scatter_projected_rows -- --ignored --nocapture`
   - This loads the real towers, runs `MediaRuntime::prepare`, scatters the
     projected BF16 rows into a gathered text state and drains the stream.

3. Fixture refresh:
   - Regenerate `cat_meow.features.f32` with the production ffmpeg 16k mono
     decode path (`EmbeddingGemma2Processor` + `extract_audio_features`) and
     update the pinned SHA in `core/src/multimodal/embedding_gemma2.rs` and
     `evidence/SOURCE-HASHES.json`.

4. Numeric qualification:
   - Capture actual image-only, audio-only and interleaved outputs from Native
     and Oxide on the same fixtures. Compare within Root tolerance and keep the
     records outside generated source. No quality/performance claim before this.

5. Admission:
   - The shared text executor adopts `INTERFACE.md`; do not wire a public route
     or factory until Root parity passes.
