import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/oxide-docs-parity-20261102/root-native-mean-control-v1')
root.mkdir(exist_ok=False)
remote = '/tmp/oxide-docs-native-mean-control-v1'
container = 'infinity-torch214-compare-sdk'
env = os.environ.copy()
for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'):
    env.pop(key, None)
docker = ['docker', '--host=unix:///var/run/docker.sock']

def run(args, timeout=120):
    result = subprocess.run(docker + args, env=env, capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(result.stderr[-2500:])
    return result

source = Path('/tmp/oxide-mistral3-aten-mean-analysis-v2/NativeTorchCUDAcontrol.py')
guard = Path('/tmp/oxide-all-model-feature-matrix-v1/qwen-vl-current-v1/native-b66-cpu-stage/remote_guard.py')
report = {'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'source': str(source), 'gpu': 0}
(root / 'run.json').write_text(json.dumps(report, indent=2) + '\n')
run(['exec', '-e', 'CUDA_VISIBLE_DEVICES=', container, 'mkdir', remote])
run(['cp', str(source), container + ':' + remote + '/control.py'])
run(['cp', str(guard), container + ':' + remote + '/guard.py'])
args = ['exec', '-e', 'CUDA_VISIBLE_DEVICES=0', '-e', 'OMP_NUM_THREADS=1', '-e', 'MKL_NUM_THREADS=1', container,
        '/opt/torch-sdk/bin/python3.12', remote + '/guard.py', '--state', remote + '/guard-state.json',
        '--seconds', '180', '--', 'taskset', '-c', '184-191', '/opt/torch-sdk/bin/python3.12',
        remote + '/control.py', '--out', remote + '/gold', '--suite', 'first']
try:
    result = subprocess.run(docker + args, env=env, capture_output=True, text=True, timeout=210)
    (root / 'stdout').write_text(result.stdout)
    (root / 'stderr').write_text(result.stderr)
    report['returncode'] = result.returncode
    if result.returncode == 0:
        run(['cp', container + ':' + remote + '/gold', str(root / 'gold')])
        report['status'] = 'native-controls-generated'
    else:
        report['status'] = 'failed'
    print(json.dumps(report))
except subprocess.TimeoutExpired:
    run(['exec', '-e', 'CUDA_VISIBLE_DEVICES=', container, '/opt/torch-sdk/bin/python3.12',
         remote + '/guard.py', '--state', remote + '/guard-state.json', '--stop'], timeout=30)
    report['status'] = 'timed-out-owned-group-stopped'
    raise
finally:
    (root / 'run.json').write_text(json.dumps(report, indent=2) + '\n')
