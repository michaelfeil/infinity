# Gemma4 text/vision/Rune interface

This worktree owns `gemma4`, `gemma4_text`, `gemma4_unified` and the Rune
`option_tokens` decision contract. It does not modify Gemma3 or
EmbeddingGemma2 model implementations.

## Factory

`OxideBackend::new*` detects the checkpoint marker before CUDA-context creation.
`gemma4*` selects `ExecutableModel::Gemma4` and `LoadedConfig::Gemma4`.

- `ModelType::Embedding(Pool::Cls | Mean | LastToken)` loads the embedding
  contract (`Gemma4Contract::Embedding`).
- `ModelType::Decision` loads the Rune contract
  (`Gemma4Contract::RuneOptionTokens`) and is accepted only through
  `submit_decide`.
- `ModelType::Classifier` and `Pool::Splade` are rejected before device work.
- Runtime dtype is BF16; the FP16 path is not admitted for Gemma4.

Required artifacts after cold admission:

- `INFINITY_OXIDE_KERNEL_MODULE` or a full `kernels.cubin` path.
- `INFINITY_FA4_ROOT` for the canonical local d256 profiles.
- `INFINITY_HEAD512_ROOT` for d512 full attention; optional
  `INFINITY_HEAD512_ARCH` and `INFINITY_HEAD512_MAX_OPTIN`.

## Text forward contract (Native `gemma_models.cpp`)

Implemented in `gemma4_e2b_model.rs` and wired in `gemma4_runtime.rs`:

- `embed_tokens * bf16(sqrt(hidden_size))`.
- Optional PLE: `per_layer_model_projection * 1/sqrt(hidden)`, projection norm,
  `embed_tokens_per_layer * sqrt(ple_width)`, and `(token + projected)/sqrt(2)`.
- Per-layer producer/shared KV election from `num_kv_shared_layers`; shared
  layers reuse the complete producer K/V for their sliding/global category.
- Sliding/global `layer_types`, `global_head_dim`, `attention_k_eq_v`,
  `num_global_key_value_heads`, proportional/full rotary policy, Q/K RMS norm,
  unit V RMS norm, and the exact two-axis (split-half) rotary indexing.
- Gated GELU-tanh MLP, per-layer PLE input gate/projection, post norms,
  `layer_scalar`, and final unit RMS norm.
- Directional embedding is noncausal; Rune `option_tokens` is causal.
- Packed logical token rows are preserved. Compact/radix requests are rejected
  rather than silently unfolded.

The text executor is the source of truth for dense E2B/E4B geometry. It
currently rejects Sparse-MoE plans with a typed `MoePending` error; the Native
MoE contract below is not yet attached to this forward.

## Vision forward contract

`gemma4_vision_model.rs` implements the Native vision tower:

- patches `16`, spatial pool `3`, hidden `768`, 12 heads, head_dim `64`,
  16 layers, intermediate `3072`, theta `100`, eps `1e-6` for the released E2B
  checkpoint.
- FP32 pixel `(x-.5)*2`, patch projection plus trained two-axis position add,
  Q/K RMS norm, unit V RMS norm, exact 2-D rotary, packed bidirectional FA4
  (`bert` 16/16x64), output projection, gated GELU-tanh, residual/post norms,
  spatial pool with BF16 rounding then `sqrt(hidden)`, final unit norm, and
  `embed_vision.embedding_projection`.
- Trained clipped-linear bounds are applied exactly as released.
- `encode_request` returns retained projected BF16 rows. `Gemma4Model::encode_vision`
  maps `MultimodalEncoding.images` starts to text rows and rejects spans outside
  the packed token count.
- `gemma4_e2b_model.rs` injects those rows into the embedding arena after PLE
  construction and before the first layer, matching Native ordering.
- Vision work is retained by the request `HostIoLease` until completion, and
  the text Work's completion ticket covers the scatter launch.

## Rune decision contract

`gemma4_option_head.rs` implements Native `OptionHead::lexical` for Gemma4:

- one `OptionTokens` request per packed sequence; `Warmup` reads option row `0`
  with one logit.
- reads the last real chunked-prefill row of each sequence;
- tied canonical BF16 embedding (or explicit `lm_head.weight` when untied);
- gathers requested vocabulary rows in request order, duplicates included;
- one prepared `M=1, N=option_count` BF16 projection per sequence;
- publisher softcap `tanh(logits / cap) * cap` with BF16 rounding after each
  scalar operation, then widen to F32;
- `action_probability = 1.0`; logits are packed per request and charge the
  shared result-memory pool.

`submit_decide` uses the same packed Batch, unpooled logical rows, retained
host option-ID tail and deferred completion closure as the text route. Images
are injected through the same vision path before the causal backbone.

This head is not the current `decision_head_gpu.rs` Qwen lexical F32 SGEMM
recipe; Gemma4 requires the BF16 tied-row contract above.

## Native MoE contract (not wired to forward)

`gemma4_text_model.rs` validates and loads the Native fused MoE checkpoint
geometry (`router.scale`, FP32 `router.proj.weight`, FP32
`router.per_expert_scale`, `experts.gate_up_proj`, `experts.down_proj`,
`pre_feedforward_layernorm_2`, `post_feedforward_layernorm_{1,2}`).

The Native arithmetic to attach is:

1. `routing = (unit_norm(residual) * 1/sqrt(hidden) * router.scale).to(F32)`
2. `logits = routing @ router.proj.weight.T` in F32.
3. Stable descending sort, `top_k_experts`; softmax over all experts, gather
   selected, renormalize, multiply selected `per_expert_scale`.
4. Fused-expert dispatch through `MODEL_GEMMA4_E128_TOP8`
   (`hidden=2816`, `intermediate=704`, 128 experts, top 8, required FP32 expert
   scales, renormalize).
5. `norm(dense_mlp, post_feedforward_layernorm_1) +
   norm(routed, post_feedforward_layernorm_2)`, followed by the outer
   `post_feedforward_layernorm` residual.

`moe_abi.rs`, `moe_api.rs`, `moe_runtime.rs` and the sidecar already advertise
the Gemma4 ABI. Remaining work is to extend the text executor Work/scratch to
hold router F32 logits and `MoeScratch`, upload the fused expert tensors, and
dispatch one sidecar call per routed layer. Until then Sparse-MoE checkpoints are
rejected at cold admission.

## Latency-audit coordination

`remaining_latency_audit` can call these crate-private pieces without changing
the ABI:

- `Gemma4Model::workspace_bytes(WorkKey)` and `workspace(stream, key)`.
- `Gemma4E2bWork::allocation_bytes(key, weights, raw_rows)`.
- `PreparedGemma4OptionHead::{tokens, total_options, counts, last_rows, layout}`.
- `Gemma4OptionWork::{new, layout, fits, output}`.
- `Gemma4VisionEngine::{encode_request, executor}` and
  `Gemma4VisionWork::{soft_tokens, projected, set_scatter_rows}`.

No CUDA graph is captured or replayed. No Torch path is used.
