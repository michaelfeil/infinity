# Gemma4 source evidence

Base: `252789b05ea2e09c14971c04dfcce458f863fead` (`/tmp/infinity-plain-cuda`).
Worktree: `/tmp/oxide-docs-parity-20261102/gemma4` (detached).

## CPU gates executed

Environment: `CUDA_VISIBLE_DEVICES=` empty, Cargo offline, `taskset -c 136-143`,
`-j2`. No GPU, Torch, Docker, NVCC, cargo-oxide, device build, optimized build
or CUDA graph was executed.

| gate | command | result |
|---|---|---|
| package check | `cargo check -p infinity-backend-oxide --offline -j2` | pass |
| test compile | `cargo test -p infinity-backend-oxide --lib --no-run --offline -j2` | pass |
| Clippy | `cargo clippy -p infinity-backend-oxide --offline -j2 -- -D warnings` | pass |
| rustfmt | `cargo fmt -p infinity-backend-oxide` | applied |
| text loader/plan | `cargo test ... gemma4_text_model::tests` | 15 passed, 1 ignored, 0 failed |
| option head | `cargo test ... gemma4_option_head::tests` | 16 passed, 3 ignored, 0 failed |
| vision tower | `cargo test ... gemma4_vision_model::tests` | 12 passed, 2 ignored, 0 failed |
| dense text executor host plans | `cargo test ... gemma4_e2b_model::tests` | 18 passed, 5 ignored, 0 failed |
| factory marker | `cargo test ... gemma4_marker_selects` | 1 passed |

Logs and exact output are in `evidence/`.

The option-head gate includes the actual released E2B checkpoint header plan
(`actual_rune_option_plan_admits_duplicate_and_warmup_rows`) and the Native CPU
reference parsers. The dense executor gates include the actual E2B header
geometry, causal Rune plan, packed raw-tail retention and the Native thread/rope
fixtures. GPU-numerical tests remain `#[ignore]` and were not run.

## Source hashes

```
344438c67ce07270304a9d323043b5d0553a39aa8a449306ea04882fb8b7e3ac  backends/oxide/src/gemma4_text_model.rs
bfb2d679e3cdfdd47f8232cba7f2b12b3aa9fad9fa8d4891cd763f8a7bcbadf7  backends/oxide/src/gemma4_e2b_model.rs
b4662e1556c3b562a1305a4ef9e79b4f54f87744141ebabf9e4f780cc0411538  backends/oxide/src/gemma4_option_head.rs
c8406caae1d4e1acf85ce050d728a231b2cdf4477590159d5acbf595734cc3bb  backends/oxide/src/gemma4_vision_model.rs
81a63492a425329f06067717e662ab11b16ce8a61d8354bd0a4589d3a5ad3af8  backends/oxide/src/gemma4_runtime.rs
c657232ea0a4eff9320b1d19b3e4fdd6aa0247a0f84b8cc870594594243f1a39  backends/oxide/device/src/gemma4.rs
d0687c5209f28d5e49f34afa906aa757740edf2ad245037fea18eca79d862556  backends/oxide/device/src/gemma4_vision.rs
941ec6eff232e7822d453bf7caca1f575ec55278c746d0a24b826ed6de2d2f6a  ../head512_aot/src/lib.rs
```

## Delivered source

- New `libs/head512_aot` provider crate for d512 full attention (ABI2), copied
  from the named private source and linked as a path dependency.
- New host modules: `gemma4_text_model.rs` (typed checkpoint/config/PLE/shared
  KV/MoE views and plans), `gemma4_e2b_model.rs` (dense text forward),
  `gemma4_option_head.rs` (Rune BF16 tied option head),
  `gemma4_vision_model.rs` (vision tower + projection), and
  `gemma4_runtime.rs` (factory composition, image span mapping, packed
  request ownership).
- New device sources: `device/src/gemma4.rs` and
  `device/src/gemma4_vision.rs`, with matching `main.rs` exports and `build.sh`
  symbol inventory. The private six vision exports and twelve text/Rune exports
  are present.
- Factory/Engine integration in `lib.rs`: checkpoint marker detection,
  `ExecutableModel::Gemma4`, `Workspace::Gemma4`, completion-ticket retirement,
  packed staging, raw-row output and Rune deferred completion.
- Shared compatibility deltas: `model.rs` wide tensor views (`source_wide`),
  `cublas.rs` metadata identity + subrange dispatch, `staging.rs` model-owned
  lease, retained vision owner, completion ticket helpers. Gemma3 and
  EmbeddingGemma2 implementations were not edited.

## Specific remaining runtime gaps

1. **Rune 26B A4B (Sparse-MoE) forward is not attached.** The text loader
   validates the fused Native MoE checkpoint (128 experts, top 8, hidden 2816,
   expert intermediate 704, FP32 router/per-expert scales) and the sidecar
   advertises `MODEL_GEMMA4_E128_TOP8`, but `Gemma4E2bMath::admit` still rejects
   Sparse-MoE with `MoePending`. Missing work: router F32 logits + `MoeScratch`
   buffers in the request Work, fused expert upload, and one sidecar dispatch
   per routed layer with Native routing/renormalization/per-expert scaling.
2. **E4B dense geometry is not admitted.** The dense executor is the qualified
   E2B H1536/L35/PLE256 geometry. E4B H2560/L42 and other Gemma4 dense
   geometries are rejected as typed geometry errors.
3. **GPU/runtime qualification not executed.** No CUDA context, FA4/Head512
   artifact load, device build, memcheck or numeric comparison was run by the
   author; those remain Root gates. No performance or all-model claim is made.
4. **No Oxide CUDA graph.** Native graph capture is not reproduced; Oxide runs
   the explicit ordered launch sequence. LibTorch/Torch fallback was not added.
5. **Vision request scratch is model-owned.** `Gemma4VisionWork` is bounded by
   `VISION_WORKSPACE_LIMIT` and retained through the text lease, but it is not
   charged through the Engine `LIVE_ARENA_BYTES` accounting. Root should either
   add that accounting or accept the separate model-owned bound before public
   media admission.
