# Remaining gaps

1. Native b66 gold and GPU consumer runs are Root-only and have not run. No numeric/quality/lifecycle/performance claim is made.
2. 27B weights are absent locally; producer fails closed with a partial failed report. Config/sidecars only.
3. Gold is absent now. Root must run `native-270m`, then `host-270m`; proceed to `native-12b`/`host-12b` only after 270m passes. `control/freeze.py` records gold hashes after the run.
4. Default acceptance is exact (`atol=0`, `rtol=0`); Root must explicitly supply any approved tolerance.
5. Native pooled CLS/last with `INFINITY_TORCH_CUDA_GRAPHS=1` uses full-token graph math; Oxide uses selected-row math. Per-route gold is the gate; graphs are never disabled to force equality.
6. The opt3/noLTO consumer release build is a Root command and was not run.
7. Root is actively integrating A3/B2/C3; live Root files drifted after this packet's pinned snapshot. Refresh only after Root publishes a compiling tree, then regenerate `PINNED-SOURCE-HASHES.json` and the freeze.
8. Device/FA4 bundles are inspected read-only; they were built by Root/workers, not this author.
