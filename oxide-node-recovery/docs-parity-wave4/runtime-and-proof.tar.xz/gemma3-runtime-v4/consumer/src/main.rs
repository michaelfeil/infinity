// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! One unified Gemma3 text runtime consumer.
//!
//! CPU modes never touch CUDA. GPU modes cold-construct one normal production
//! `Backend::new_selected(... Oxide ...)` factory and then run the same 25 text
//! fixtures per route. Native gold is a separate required input for quality.

use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use infinity_v3_backend::{
    Backend, BackendKind, DType, Embedding, Embeddings, ModelType, Submission, TorchDevice,
};
use infinity_v3_backend_core::{BackendError, Batch, Pool};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};

mod schedule;
use schedule::{schedule_life, schedule_quality, ScheduleHost, MAX_HELD};

const SCHEMA_REPORT: &str = "oxide-gemma3-unified-runtime-report/v1";
const SCHEMA_FIXTURES: &str = "oxide-gemma3-unified-fixtures/v1";
const SCHEMA_GOLD: &str = "oxide-gemma3-native-gold/v1";
const FIXTURE_COUNT: usize = 25;

#[derive(Clone, Debug, Deserialize)]
struct CaseMeta {
    name: String,
    file: String,
    sha256: String,
    input_ids_sha256: String,
    valid: bool,
    #[serde(default)]
    expected_error_variant: Option<String>,
    token_count: usize,
    sequence_count: usize,
    pooled_count: usize,
    raw_count: usize,
}

#[derive(Clone, Debug, Deserialize)]
struct Manifest {
    schema: String,
    cases: Vec<CaseMeta>,
}

#[derive(Clone, Debug, Deserialize)]
struct BatchJson {
    input_ids: Vec<u32>,
    position_ids: Vec<u32>,
    token_type_ids: Vec<u32>,
    cumulative_seq_lengths: Vec<u32>,
    pooled_indices: Vec<u32>,
    raw_indices: Vec<u32>,
    max_length: u32,
}

impl BatchJson {
    fn to_backend(&self) -> Batch {
        Batch {
            multimodal: Vec::new(),
            input_ids: self.input_ids.clone(),
            token_type_ids: self.token_type_ids.clone(),
            position_ids: self.position_ids.clone(),
            cumulative_seq_lengths: self.cumulative_seq_lengths.clone(),
            max_length: self.max_length,
            pooled_indices: self.pooled_indices.clone(),
            raw_indices: self.raw_indices.clone(),
            compact_input_ids: None,
            compact_position_ids: None,
            fold_gather: None,
            scatter_unfold: None,
            tokens: Vec::new(),
            offsets: Vec::new(),
        }
    }
}

#[derive(Clone, Debug)]
struct LoadedCase {
    meta: CaseMeta,
    batch: BatchJson,
}

#[derive(Clone, Debug, Deserialize)]
struct GoldEntry {
    index: usize,
    kind: String,
    shape: Vec<usize>,
    values_file: String,
    sha256: String,
}

#[derive(Clone, Debug, Deserialize)]
struct GoldPool {
    entries: Vec<GoldEntry>,
}

#[derive(Clone, Debug, Deserialize)]
struct GoldCase {
    name: String,
    fixture_sha256: String,
    input_ids_sha256: String,
    pools: BTreeMap<String, GoldPool>,
}

#[derive(Clone, Debug, Deserialize)]
struct Acceptance {
    atol: f64,
    rtol: f64,
}

#[derive(Clone, Debug, Deserialize)]
struct Gold {
    schema: String,
    model: String,
    config_sha256: String,
    hidden_size: usize,
    cases: Vec<GoldCase>,
    acceptance: Acceptance,
}

#[derive(Debug, Serialize)]
struct Report {
    schema: &'static str,
    mode: String,
    status: String,
    started_unix_seconds: u64,
    finished_unix_seconds: Option<u64>,
    model: Option<String>,
    pool: Option<String>,
    normal_factory_route: bool,
    engine_count: usize,
    fixture_manifest: String,
    phases: Vec<Value>,
    cases: Vec<Value>,
    failures: Vec<String>,
    typed_errors: Vec<Value>,
}

impl Report {
    fn new(mode: &str, manifest: &Path) -> Self {
        Self {
            schema: SCHEMA_REPORT,
            mode: mode.to_string(),
            status: "running".into(),
            started_unix_seconds: now(),
            finished_unix_seconds: None,
            model: None,
            pool: None,
            normal_factory_route: false,
            engine_count: 0,
            fixture_manifest: manifest.display().to_string(),
            phases: Vec::new(),
            cases: Vec::new(),
            failures: Vec::new(),
            typed_errors: Vec::new(),
        }
    }
    fn phase(&mut self, name: &str, status: &str, detail: Value) {
        self.phases.push(json!({"name":name,"status":status,"detail":detail}));
    }
    fn backend_error(&mut self, stage: &str, error: &BackendError) -> String {
        let variant = variant_name(error);
        self.typed_errors.push(json!({"stage":stage,"variant":variant,"message":error.to_string()}));
        format!("{stage}: {variant}: {error}")
    }
    fn finish(&mut self, status: &str) {
        self.status = status.into();
        self.finished_unix_seconds = Some(now());
    }
}

fn now() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |d| d.as_secs())
}
fn sha_bytes(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn variant_name(error: &BackendError) -> &'static str {
    match error {
        BackendError::Overloaded(_) => "Overloaded",
        BackendError::NoBackend => "NoBackend",
        BackendError::Start(_) => "Start",
        BackendError::Inference(_) => "Inference",
        BackendError::Unhealthy => "Unhealthy",
        BackendError::WeightsNotFound(_) => "WeightsNotFound",
    }
}
fn write_report(path: &Path, report: &Report) -> Result<(), String> {
    if let Some(parent) = path.parent() { std::fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
    let temp = path.with_extension("json.tmp");
    let data = serde_json::to_vec_pretty(report).map_err(|e| e.to_string())?;
    std::fs::write(&temp, data).map_err(|e| e.to_string())?;
    std::fs::rename(&temp, path).map_err(|e| e.to_string())
}

struct Args {
    mode: String,
    cases: PathBuf,
    report: PathBuf,
    model: Option<PathBuf>,
    pool: Option<Pool>,
    gold: Option<PathBuf>,
    expected_config_sha256: Option<String>,
    limit: Option<usize>,
}

fn usage() -> &'static str {
    "usage: gemma3-unified-runtime <quality|life|metadata|validate-only> --cases MANIFEST --report FILE [--model DIR] [--pool cls|mean|last-token] [--gold NATIVE-GOLD.json] [--expected-config-sha256 HEX] [--limit N]"
}
fn parse_pool(value: &str) -> Result<Pool, String> {
    match value { "cls" => Ok(Pool::Cls), "mean" => Ok(Pool::Mean), "last-token" => Ok(Pool::LastToken), _ => Err(format!("invalid pool {value:?}")) }
}
fn pool_key(pool: &Pool) -> &'static str {
    match pool { Pool::Cls => "cls", Pool::Mean => "mean", Pool::LastToken => "last-token", Pool::Splade => "splade" }
}
fn parse_args() -> Result<Args, String> {
    let values = std::env::args().collect::<Vec<_>>();
    if values.len() < 2 || values[1].starts_with('-') { return Err(usage().into()); }
    let mode = values[1].clone();
    if !matches!(mode.as_str(), "quality"|"life"|"metadata"|"validate-only") { return Err(format!("unknown mode {mode:?}\n{}", usage())); }
    let mut seen = BTreeSet::new();
    let mut cases = None; let mut report = None; let mut model = None; let mut pool = None; let mut gold = None; let mut expected = None; let mut limit = None;
    let mut i = 2;
    while i < values.len() {
        let flag = &values[i];
        if !flag.starts_with("--") { return Err(format!("unexpected positional {flag:?}")); }
        if !seen.insert(flag.clone()) { return Err(format!("duplicate argument {flag}")); }
        if matches!(flag.as_str(), "--cases"|"--report"|"--model"|"--pool"|"--gold"|"--expected-config-sha256"|"--limit") {
            let value = values.get(i+1).ok_or_else(|| format!("{flag} requires a value"))?;
            if value.starts_with("--") { return Err(format!("{flag} requires a value")); }
            match flag.as_str() {
                "--cases" => cases = Some(PathBuf::from(value)),
                "--report" => report = Some(PathBuf::from(value)),
                "--model" => model = Some(PathBuf::from(value)),
                "--pool" => pool = Some(parse_pool(value)?),
                "--gold" => gold = Some(PathBuf::from(value)),
                "--expected-config-sha256" => expected = Some(value.clone()),
                "--limit" => { let n = value.parse::<usize>().map_err(|_| format!("invalid --limit {value:?}"))?; if n == 0 { return Err("--limit must be positive".into()); } limit = Some(n); }
                _ => unreachable!(),
            }
            i += 2;
        } else { return Err(format!("unknown argument {flag}")); }
    }
    let cases = cases.ok_or_else(|| "--cases is required".to_string())?;
    let report = report.ok_or_else(|| "--report is required".to_string())?;
    if matches!(mode.as_str(), "quality"|"life") && pool.is_none() { return Err("--pool is required for quality and life".into()); }
    Ok(Args { mode, cases, report, model, pool, gold, expected_config_sha256: expected, limit })
}

fn load_manifest(path: &Path) -> Result<Manifest, String> {
    let data = std::fs::read(path).map_err(|e| format!("read {}: {e}", path.display()))?;
    let manifest: Manifest = serde_json::from_slice(&data).map_err(|e| format!("parse manifest: {e}"))?;
    if manifest.schema != SCHEMA_FIXTURES { return Err(format!("unsupported fixture schema {}", manifest.schema)); }
    if manifest.cases.len() != FIXTURE_COUNT { return Err(format!("expected {FIXTURE_COUNT} fixtures, found {}", manifest.cases.len())); }
    Ok(manifest)
}
fn load_cases(args: &Args) -> Result<Vec<LoadedCase>, String> {
    let manifest = load_manifest(&args.cases)?;
    let root = args.cases.parent().ok_or_else(|| "fixture manifest has no parent".to_string())?;
    let mut out = Vec::new();
    for meta in manifest.cases.into_iter().take(args.limit.unwrap_or(usize::MAX)) {
        let path = root.join(&meta.file);
        let bytes = std::fs::read(&path).map_err(|e| format!("read {}: {e}", path.display()))?;
        let digest = sha_bytes(&bytes);
        if digest != meta.sha256 { return Err(format!("{} fixture sha256 mismatch", path.display())); }
        let batch: BatchJson = serde_json::from_slice(&bytes).map_err(|e| format!("parse {}: {e}", path.display()))?;
        let ids = serde_json::to_vec(&batch.input_ids).map_err(|e| e.to_string())?;
        if sha_bytes(&ids) != meta.input_ids_sha256 { return Err(format!("{} input_ids_sha256 mismatch", path.display())); }
        if batch.input_ids.len() != meta.token_count || batch.cumulative_seq_lengths.len() != meta.sequence_count + 1
            || batch.pooled_indices.len() != meta.pooled_count || batch.raw_indices.len() != meta.raw_count {
            return Err(format!("{} counts disagree with manifest", path.display()));
        }
        out.push(LoadedCase { meta, batch });
    }
    Ok(out)
}

fn load_gold(path: &Path, config_sha256: &str, hidden: usize) -> Result<Gold, String> {
    let gold: Gold = serde_json::from_slice(&std::fs::read(path).map_err(|e| format!("read gold {}: {e}", path.display()))?)
        .map_err(|e| format!("parse gold: {e}"))?;
    if gold.schema != SCHEMA_GOLD { return Err(format!("unsupported gold schema {}", gold.schema)); }
    if gold.config_sha256 != config_sha256 { return Err("gold config_sha256 differs from checkpoint config".into()); }
    if gold.hidden_size != hidden { return Err("gold hidden width differs".into()); }
    Ok(gold)
}
fn read_gold_values(root: &Path, entry: &GoldEntry) -> Result<Vec<f32>, String> {
    let path = root.join(&entry.values_file);
    let bytes = std::fs::read(&path).map_err(|e| format!("read {}: {e}", path.display()))?;
    if sha_bytes(&bytes) != entry.sha256 { return Err(format!("{} gold sha256 mismatch", path.display())); }
    let elements = entry.shape.iter().product::<usize>();
    if bytes.len() != elements * 4 { return Err(format!("{} gold length mismatch", path.display())); }
    let mut out = Vec::with_capacity(elements);
    for chunk in bytes.chunks_exact(4) { out.push(f32::from_le_bytes(chunk.try_into().unwrap())); }
    if out.iter().any(|v| !v.is_finite()) { return Err(format!("{} nonfinite gold", path.display())); }
    Ok(out)
}

fn output_map(embeddings: &Embeddings, hidden: usize) -> Result<BTreeMap<usize, (String, Vec<usize>, Vec<f32>)>, String> {
    let mut out = BTreeMap::new();
    for (&index, value) in embeddings.iter() {
        let (kind, shape, values) = match value {
            Embedding::Pooled(row) => ("pooled".to_string(), vec![row.len()], row.clone()),
            Embedding::All(rows) => ("raw".to_string(), vec![rows.len(), if rows.is_empty() { hidden } else { rows[0].len() }], rows.iter().flat_map(|r| r.iter().copied()).collect()),
        };
        if let Some(width) = shape.last() { if *width != hidden { return Err(format!("index {index} width {width} != {hidden}")); } }
        if values.iter().any(|v| !v.is_finite()) { return Err(format!("index {index} nonfinite output")); }
        if out.insert(index, (kind, shape, values)).is_some() { return Err(format!("duplicate output index {index}")); }
    }
    Ok(out)
}

fn compare_gold(name: &str, pool: &str, output: &BTreeMap<usize,(String,Vec<usize>,Vec<f32>)>, gold_case: &GoldCase, gold_root: &Path, acceptance: &Acceptance) -> Result<Value, String> {
    let gold_pool = gold_case.pools.get(pool).ok_or_else(|| format!("{name}: gold lacks pool {pool}"))?;
    let mut expected = BTreeMap::new();
    for entry in &gold_pool.entries {
        expected.insert(entry.index, (entry.kind.clone(), entry.shape.clone(), read_gold_values(gold_root, entry)?));
    }
    if output.len() != expected.len() { return Err(format!("{name}/{pool}: output entries {} expected {}", output.len(), expected.len())); }
    let mut max_abs = 0.0f64; let mut max_rel = 0.0f64; let mut compared = 0usize;
    for (index, (kind, shape, values)) in output {
        let (ekind, eshape, evalues) = expected.get(index).ok_or_else(|| format!("{name}/{pool}: unexpected index {index}"))?;
        if kind != ekind || shape != eshape || values.len() != evalues.len() { return Err(format!("{name}/{pool}: index {index} kind/shape differs")); }
        for (a,b) in values.iter().zip(evalues) {
            let abs = (*a as f64 - *b as f64).abs();
            let rel = if *b == 0.0 { abs } else { abs / (*b as f64).abs() };
            max_abs = max_abs.max(abs); max_rel = max_rel.max(rel); compared += 1;
            if abs > acceptance.atol && rel > acceptance.rtol {
                return Err(format!("{name}/{pool}: index {index} exceeds tolerance abs={abs} rel={rel}"));
            }
        }
    }
    Ok(json!({"name":name,"pool":pool,"status":"ok","compared_values":compared,"max_abs":max_abs,"max_rel":max_rel,"atol":acceptance.atol,"rtol":acceptance.rtol,"fixture_sha256":gold_case.fixture_sha256,"input_ids_sha256":gold_case.input_ids_sha256}))
}

fn config_metadata(model: &Path, expected_sha: Option<&str>) -> Result<(Value, String, usize), String> {
    let config_path = model.join("config.json");
    let config_bytes = std::fs::read(&config_path).map_err(|e| format!("read {}: {e}", config_path.display()))?;
    let config_sha = sha_bytes(&config_bytes);
    if let Some(expected) = expected_sha { if expected != config_sha { return Err("checkpoint config_sha256 differs from pinned expected".into()); } }
    let config: Value = serde_json::from_slice(&config_bytes).map_err(|e| e.to_string())?;
    if config["model_type"] != "gemma3_text" { return Err("metadata requires gemma3_text".into()); }
    let hidden = config["hidden_size"].as_u64().ok_or_else(|| "missing hidden_size".to_string())? as usize;
    Ok((config, config_sha, hidden))
}
fn metadata_mode(args: &Args, report: &mut Report) -> Result<(), String> {
    let model = args.model.as_ref().ok_or_else(|| "--model is required for metadata".to_string())?;
    let (_config, config_sha, hidden) = config_metadata(model, args.expected_config_sha256.as_deref())?;
    let modules = std::fs::read(model.join("modules.json")).ok().map(|b| serde_json::from_slice::<Vec<Value>>(&b)).transpose().map_err(|e| e.to_string())?.unwrap_or_default();
    let module_types = modules.iter().filter_map(|m| m["type"].as_str()).collect::<Vec<_>>();
    if module_types.iter().any(|kind| kind.contains("Dense") || kind.contains("Projection")) { return Err("trained Dense/CustomProjection is outside these pinned Gemma3 checkpoints".into()); }
    let pooling = modules.iter().find(|m| m["type"] == "sentence_transformers.models.Pooling")
        .and_then(|m| m["path"].as_str()).map(|p| model.join(p).join("config.json"));
    let pooling_last = pooling.as_ref().and_then(|p| std::fs::read(p).ok()).and_then(|b| serde_json::from_slice::<Value>(&b).ok())
        .and_then(|v| v["pooling_mode_lasttoken"].as_bool()).unwrap_or(false);
    if !pooling_last { return Err("pinned Gemma3 sidecar must declare last-token pooling".into()); }
    report.model = Some(model.display().to_string());
    report.phase("metadata","ok",json!({"config_sha256":config_sha,"hidden_size":hidden,"module_types":module_types,"pooling_lasttoken":pooling_last}));
    Ok(())
}

fn validate_only(args: &Args, report: &mut Report) -> Result<(), String> {
    let manifest = load_manifest(&args.cases)?;
    let cases = load_cases(args)?;
    let valid = cases.iter().filter(|c| c.meta.valid).count();
    report.phase("fixtures","ok",json!({"manifest":args.cases.display().to_string(),"manifest_total":manifest.cases.len(),"loaded":cases.len(),"valid":valid,"invalid":cases.len()-valid,"model_loaded":false,"engine_count":0,"gpu_path_taken":false}));
    Ok(())
}

fn output_bits(
    result: &Embeddings,
    hidden: usize,
) -> Result<BTreeMap<usize, (String, Vec<usize>, Vec<u32>)>, String> {
    let mut output = BTreeMap::new();
    for (&index, value) in result.iter() {
        let (kind, shape, values) = match value {
            Embedding::Pooled(row) => (
                "pooled".to_string(),
                vec![row.len()],
                row.iter().map(|value| value.to_bits()).collect::<Vec<_>>(),
            ),
            Embedding::All(rows) => (
                "raw".to_string(),
                vec![rows.len(), rows.first().map_or(hidden, Vec::len)],
                rows.iter().flat_map(|row| row.iter().map(|value| value.to_bits())).collect(),
            ),
        };
        output.insert(index, (kind, shape, values));
    }
    Ok(output)
}

struct QualityHost<'a> {
    backend: Backend,
    cases: BTreeMap<String, LoadedCase>,
    pending: BTreeMap<usize, Submission<Embeddings>>,
    held_names: BTreeMap<usize, String>,
    next_id: usize,
    report: &'a mut Report,
    gold_cases: &'a BTreeMap<String, &'a GoldCase>,
    gold_root: &'a Path,
    acceptance: &'a Acceptance,
    report_path: &'a Path,
    hidden: usize,
    pool_name: &'a str,
    first: Option<Value>,
    max_held: usize,
}

impl ScheduleHost for QualityHost<'_> {
    async fn submit(&mut self, name: &str) -> Result<usize, String> {
        let case = self.cases.get(name).ok_or_else(|| format!("missing quality case {name}"))?;
        let submission = self
            .backend
            .submit_embed(case.batch.to_backend())
            .await
            .map_err(|error| self.report.backend_error(&format!("quality/{name}/submit"), &error))?;
        let id = self.next_id;
        self.next_id += 1;
        self.pending.insert(id, submission);
        self.held_names.insert(id, name.to_string());
        self.max_held = self.max_held.max(self.pending.len());
        if self.max_held > MAX_HELD {
            return Err(format!("quality exceeded two HostIo slots: {}", self.max_held));
        }
        Ok(id)
    }
    async fn complete(&mut self, id: usize) -> Result<(), String> {
        let submission = self.pending.remove(&id).ok_or_else(|| format!("unknown quality id {id}"))?;
        let case_name = self.held_names.remove(&id).unwrap_or_else(|| format!("quality-id-{id}"));
        let started = Instant::now();
        let (embeddings, backend_duration) = submission
            .complete()
            .await
            .map_err(|error| self.report.backend_error(&format!("quality/{case_name}/complete"), &error))?;
        let output = output_map(&embeddings, self.hidden)?;
        let gold_case = self
            .gold_cases
            .get(&case_name)
            .ok_or_else(|| format!("{case_name}: missing gold case"))?;
        let comparison = compare_gold(&case_name, self.pool_name, &output, gold_case, self.gold_root, self.acceptance)?;
        if self.first.is_none() {
            self.first = Some(json!({"case":case_name,"submission":"Deferred","wall_ns":started.elapsed().as_nanos(),"backend_ns":backend_duration.as_nanos(),"values":comparison}));
        }
        self.report.cases.push(json!({"name":case_name,"valid":true,"status":"ok","comparison":comparison,"wall_ns":started.elapsed().as_nanos(),"backend_ns":backend_duration.as_nanos()}));
        write_report(self.report_path, self.report)?;
        Ok(())
    }
    fn cancel(&mut self, id: usize) {
        self.pending.remove(&id);
    }
    async fn health(&mut self) -> Result<(), String> {
        self.backend
            .health()
            .await
            .map_err(|error| self.report.backend_error("quality/health", &error))
    }
    fn drop_engine(&mut self) {}
}

async fn quality(args: &Args, report: &mut Report) -> Result<(), String> {
    let model = args.model.clone().ok_or_else(|| "--model is required".to_string())?;
    let (_, config_sha, hidden) = config_metadata(&model, args.expected_config_sha256.as_deref())?;
    let pool = args.pool.clone().ok_or_else(|| "--pool is required".to_string())?;
    let pool_name = pool_key(&pool).to_string();
    let gold_path = args.gold.as_ref().ok_or_else(|| "--gold is required for quality".to_string())?;
    let gold = load_gold(gold_path, &config_sha, hidden)?;
    report.phase("gold", "ok", json!({"model": gold.model, "config_sha256": gold.config_sha256, "atol": gold.acceptance.atol, "rtol": gold.acceptance.rtol}));
    let gold_root = gold_path.parent().ok_or_else(|| "gold has no parent".to_string())?.to_path_buf();
    let gold_cases = gold.cases.iter().map(|case| (case.name.clone(), case)).collect::<BTreeMap<_, _>>();
    let cases = load_cases(args)?;
    report.model = Some(model.display().to_string());
    report.pool = Some(pool_name.clone());
    report.phase("constructor", "start", json!({"route":"infinity_v3_backend::Backend::new_selected","kind":"oxide","dtype":"bfloat16","pool":pool_name,"gpu":"cuda"}));
    let backend = Backend::new_selected(model, None, DType::Bfloat16, ModelType::Embedding(pool), None, 0, false, BackendKind::Oxide, TorchDevice::Cuda)
        .await
        .map_err(|error| report.backend_error("quality/constructor", &error))?;
    report.normal_factory_route = true;
    report.engine_count = 1;
    report.phase("constructor", "ok", json!({"engine_count":1}));

    let mut case_map = BTreeMap::new();
    let mut valid_names = Vec::new();
    for case in cases {
        if case.meta.valid {
            valid_names.push(case.meta.name.clone());
            case_map.insert(case.meta.name.clone(), case);
        } else {
            let name = case.meta.name.clone();
            match backend.submit_embed(case.batch.to_backend()).await {
                Ok(_) => report.failures.push(format!("{name}: invalid case unexpectedly admitted")),
                Err(error) => {
                    let actual = variant_name(&error);
                    let expected = case.meta.expected_error_variant.as_deref().unwrap_or("Inference");
                    if actual != expected {
                        let failure = report.backend_error(&format!("quality/{name}/invalid"), &error);
                        report.failures.push(failure);
                    }
                    report.cases.push(json!({"name":name,"valid":false,"status":if actual==expected{"ok"}else{"variant-mismatch"},"expected_error_variant":expected,"actual_error_variant":actual}));
                }
            }
            write_report(&args.report, report)?;
        }
    }

    let mut host = QualityHost {
        backend,
        cases: case_map,
        pending: BTreeMap::new(),
        held_names: BTreeMap::new(),
        next_id: 0,
        report,
        gold_cases: &gold_cases,
        gold_root: &gold_root,
        acceptance: &gold.acceptance,
        report_path: &args.report,
        hidden,
        pool_name: &pool_name,
        first: None,
        max_held: 0,
    };
    schedule_quality(&mut host, &valid_names).await?;
    host.health().await?;
    let first = host.first.take();
    let max_held = host.max_held;
    drop(host);
    report_finalize_quality(report, first, max_held)?;
    if report.failures.is_empty() {
        Ok(())
    } else {
        Err(format!("quality failures: {}", report.failures.iter().take(6).cloned().collect::<Vec<_>>().join("; ")))
    }
}

fn report_finalize_quality(report: &mut Report, first: Option<Value>, max_held: usize) -> Result<(), String> {
    report.phase("health", "ok", json!({"after":true,"max_held":max_held}));
    report.phase("first_forward", "ok", first.unwrap_or(Value::Null));
    Ok(())
}

struct LifeHost<'a> {
    backend: Option<Backend>,
    cases: BTreeMap<String, LoadedCase>,
    baseline: BTreeMap<String, BTreeMap<usize, (String, Vec<usize>, Vec<u32>)>>,
    pending: BTreeMap<usize, Submission<Embeddings>>,
    next_id: usize,
    held_names: BTreeMap<usize, String>,
    report: &'a mut Report,
    report_path: &'a Path,
    hidden: usize,
    max_held: usize,
    events: Vec<Value>,
    completed_after_drop: usize,
}

impl ScheduleHost for LifeHost<'_> {
    async fn submit(&mut self, name: &str) -> Result<usize, String> {
        let backend = self.backend.as_ref().ok_or_else(|| "engine already dropped".to_string())?;
        let case = self.cases.get(name).ok_or_else(|| format!("missing life case {name}"))?;
        let submission = backend.submit_embed(case.batch.to_backend()).await
            .map_err(|error| self.report.backend_error(&format!("life/{name}/submit"), &error))?;
        let id = self.next_id;
        self.next_id += 1;
        self.pending.insert(id, submission);
        self.held_names.insert(id, name.to_string());
        self.max_held = self.max_held.max(self.pending.len());
        if self.max_held > MAX_HELD {
            return Err(format!("life exceeded two HostIo slots: {}", self.max_held));
        }
        self.events.push(json!({"event":"submit","name":name,"id":id,"held":self.pending.len()}));
        Ok(id)
    }
    async fn complete(&mut self, id: usize) -> Result<(), String> {
        let submission = self.pending.remove(&id).ok_or_else(|| format!("unknown life id {id}"))?;
        let name = self.held_names.remove(&id).unwrap_or_else(|| format!("life-id-{id}"));
        let started = Instant::now();
        let (embeddings, duration) = submission.complete().await
            .map_err(|error| self.report.backend_error(&format!("life/{name}/complete"), &error))?;
        let actual = output_bits(&embeddings, self.hidden)?;
        let expected = self.baseline.get(&name).ok_or_else(|| format!("missing life baseline {name}"))?;
        if &actual != expected {
            return Err(format!("{name}: same-route life output differs from its exact baseline"));
        }
        let after_drop = self.backend.is_none();
        if after_drop { self.completed_after_drop += 1; }
        self.events.push(json!({"event":"complete","name":name,"id":id,"after_engine_drop":after_drop,"exact_baseline":true,"entries":actual.len(),"backend_ns":duration.as_nanos(),"wall_ns":started.elapsed().as_nanos()}));
        self.report.cases.push(json!({"name":name,"after_engine_drop":after_drop,"exact_baseline":true,"entries":actual.len(),"backend_ns":duration.as_nanos()}));
        write_report(self.report_path, self.report)?;
        Ok(())
    }
    fn cancel(&mut self, id: usize) {
        if let Some(name) = self.held_names.remove(&id) {
            self.pending.remove(&id);
            self.events.push(json!({"event":"cancel","name":name,"id":id,"held":self.pending.len()}));
        }
    }
    async fn health(&mut self) -> Result<(), String> {
        let backend = self.backend.as_ref().ok_or_else(|| "engine already dropped".to_string())?;
        backend.health().await.map_err(|error| self.report.backend_error("life/health", &error))?;
        self.events.push(json!({"event":"health"}));
        Ok(())
    }
    fn drop_engine(&mut self) {
        self.backend.take();
        self.events.push(json!({"event":"drop_engine"}));
    }
}

async fn life(args: &Args, report: &mut Report) -> Result<(), String> {
    let model = args.model.clone().ok_or_else(|| "--model is required".to_string())?;
    let (_, _, hidden) = config_metadata(&model, args.expected_config_sha256.as_deref())?;
    let pool = args.pool.clone().ok_or_else(|| "--pool is required".to_string())?;
    let cases = load_cases(args)?;
    let names = [
        "b1_t7_last",
        "ragged_growing_1_4_9_17_last",
        "b1_t33_last",
        "ragged_shrinking_17_9_4_1_last",
        "b1_t7_raw",
        "ragged_mixed",
    ];
    let selected = names.iter()
        .map(|name| cases.iter().find(|case| case.meta.valid && case.meta.name == *name).cloned().ok_or_else(|| format!("missing life fixture {name}")))
        .collect::<Result<Vec<_>, _>>()?;
    report.model = Some(model.display().to_string());
    report.pool = Some(pool_key(&pool).to_string());
    report.phase("constructor", "start", json!({"route":"infinity_v3_backend::Backend::new_selected","kind":"oxide","dtype":"bfloat16","pool":pool_key(&pool),"gpu":"cuda"}));
    let backend = Backend::new_selected(model, None, DType::Bfloat16, ModelType::Embedding(pool), None, 0, false, BackendKind::Oxide, TorchDevice::Cuda)
        .await
        .map_err(|error| report.backend_error("life/constructor", &error))?;
    report.normal_factory_route = true;
    report.engine_count = 1;
    report.phase("constructor", "ok", json!({"engine_count":1}));
    let mut baseline = BTreeMap::new();
    for case in &selected {
        let (output, _) = backend.embed(case.batch.to_backend()).await
            .map_err(|error| report.backend_error(&format!("life/{}/baseline", case.meta.name), &error))?;
        baseline.insert(case.meta.name.clone(), output_bits(&output, hidden)?);
    }
    let mut case_map = BTreeMap::new();
    for case in selected {
        case_map.insert(case.meta.name.clone(), case);
    }
    let mut host = LifeHost {
        backend: Some(backend),
        cases: case_map,
        baseline,
        pending: BTreeMap::new(),
        next_id: 0,
        held_names: BTreeMap::new(),
        report,
        report_path: &args.report,
        hidden,
        max_held: 0,
        events: Vec::new(),
        completed_after_drop: 0,
    };
    let names = names.map(ToString::to_string);
    schedule_life(&mut host, &names).await?;
    if host.max_held > MAX_HELD {
        return Err(format!("life observed {} held submissions", host.max_held));
    }
    if host.completed_after_drop != 1 {
        return Err("life did not complete exactly one request after engine drop".into());
    }
    host.report.phase("schedule", "ok", json!({"events":host.events,"max_held":host.max_held,"completed_after_drop":host.completed_after_drop}));
    Ok(())
}

async fn run() -> Result<(), String> {
    let args = parse_args()?;
    let mut report = Report::new(&args.mode, &args.cases);
    let result = match args.mode.as_str() {
        "validate-only" => validate_only(&args, &mut report),
        "metadata" => metadata_mode(&args, &mut report),
        "quality" => quality(&args, &mut report).await,
        "life" => life(&args, &mut report).await,
        _ => unreachable!(),
    };
    match result {
        Ok(()) => { report.finish("ok"); write_report(&args.report, &report) }
        Err(error) => { report.failures.push(error.clone()); report.finish("error"); let _ = write_report(&args.report, &report); Err(error) }
    }
}

#[tokio::main]
async fn main() {
    if let Err(error) = run().await { eprintln!("{error}"); std::process::exit(2); }
}
