// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Bounded submission schedule shared by production and the CPU mock proof.
//!
//! The production host has exactly two blocking HostIo slots. This module never
//! requests more than two in-flight submissions and never widens the slot pool.

use std::collections::VecDeque;

pub const MAX_HELD: usize = 2;

#[allow(async_fn_in_trait)]
pub trait ScheduleHost {
    async fn submit(&mut self, name: &str) -> Result<usize, String>;
    async fn complete(&mut self, id: usize) -> Result<(), String>;
    fn cancel(&mut self, id: usize);
    async fn health(&mut self) -> Result<(), String>;
    fn drop_engine(&mut self);
}

/// Complete the oldest held request whenever a second slot is occupied.
pub async fn schedule_quality<H: ScheduleHost>(
    host: &mut H,
    names: &[String],
) -> Result<(), String> {
    let mut held = VecDeque::new();
    for name in names {
        let id = host.submit(name).await?;
        held.push_back(id);
        while held.len() >= MAX_HELD {
            let id = held.pop_front().ok_or_else(|| "quality held queue empty".to_string())?;
            host.complete(id).await?;
        }
    }
    while let Some(id) = held.pop_front() {
        host.complete(id).await?;
    }
    Ok(())
}

/// Exact two-slot lifecycle:
/// A+B held -> cancel A -> complete B -> health -> recover C -> hold D+E ->
/// complete E then D -> hold F -> drop engine -> complete F.
pub async fn schedule_life<H: ScheduleHost>(
    host: &mut H,
    names: &[String; 6],
) -> Result<(), String> {
    let a = host.submit(&names[0]).await?;
    let b = host.submit(&names[1]).await?;
    host.cancel(a);
    host.complete(b).await?;
    host.health().await?;
    let c = host.submit(&names[2]).await?;
    host.complete(c).await?;
    let d = host.submit(&names[3]).await?;
    let e = host.submit(&names[4]).await?;
    host.complete(e).await?;
    host.complete(d).await?;
    let f = host.submit(&names[5]).await?;
    host.drop_engine();
    host.complete(f).await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;
    use std::sync::Arc;
    use std::time::Duration;
    use tokio::sync::{OwnedSemaphorePermit, Semaphore};

    struct MockHost {
        permits: Arc<Semaphore>,
        next_id: usize,
        held: BTreeMap<usize, (String, OwnedSemaphorePermit)>,
        max_held: usize,
        events: Vec<String>,
        engine_dropped: bool,
        completed_after_drop: usize,
    }

    impl MockHost {
        fn new() -> Self {
            Self {
                permits: Arc::new(Semaphore::new(MAX_HELD)),
                next_id: 1,
                held: BTreeMap::new(),
                max_held: 0,
                events: Vec::new(),
                engine_dropped: false,
                completed_after_drop: 0,
            }
        }
    }

    impl ScheduleHost for MockHost {
        async fn submit(&mut self, name: &str) -> Result<usize, String> {
            if self.engine_dropped {
                return Err("engine already dropped".into());
            }
            let permit = self.permits.clone().acquire_owned().await.map_err(|e| e.to_string())?;
            let id = self.next_id;
            self.next_id += 1;
            self.held.insert(id, (name.to_string(), permit));
            self.max_held = self.max_held.max(self.held.len());
            self.events.push(format!("submit:{name}"));
            Ok(id)
        }
        async fn complete(&mut self, id: usize) -> Result<(), String> {
            let (name, permit) = self.held.remove(&id).ok_or_else(|| format!("unknown id {id}"))?;
            drop(permit);
            self.events.push(format!("complete:{name}"));
            if self.engine_dropped {
                self.completed_after_drop += 1;
            }
            Ok(())
        }
        fn cancel(&mut self, id: usize) {
            if let Some((name, permit)) = self.held.remove(&id) {
                drop(permit);
                self.events.push(format!("cancel:{name}"));
            }
        }
        async fn health(&mut self) -> Result<(), String> {
            self.events.push("health".into());
            Ok(())
        }
        fn drop_engine(&mut self) {
            self.engine_dropped = true;
            self.events.push("drop_engine".into());
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn quality_schedule_never_exceeds_two_slots() {
        let names = (0..25).map(|index| format!("case-{index}")).collect::<Vec<_>>();
        let mut host = MockHost::new();
        tokio::time::timeout(Duration::from_secs(2), schedule_quality(&mut host, &names))
            .await
            .expect("quality schedule deadlocked on the two-slot reservation")
            .unwrap();
        assert_eq!(host.max_held, MAX_HELD);
        assert_eq!(
            host.events.iter().filter(|event| event.starts_with("complete:")).count(),
            names.len()
        );
        assert!(host.held.is_empty());
    }

    #[tokio::test(flavor = "current_thread")]
    async fn life_schedule_cancels_recovers_reorders_and_drops_engine() {
        let names = [
            "A".to_string(),
            "B".to_string(),
            "C-recover".to_string(),
            "D".to_string(),
            "E".to_string(),
            "F-after-drop".to_string(),
        ];
        let mut host = MockHost::new();
        tokio::time::timeout(Duration::from_secs(2), schedule_life(&mut host, &names))
            .await
            .expect("life schedule deadlocked on the two-slot reservation")
            .unwrap();
        assert_eq!(host.max_held, MAX_HELD);
        assert_eq!(host.completed_after_drop, 1);
        assert!(host.held.is_empty());
        assert_eq!(
            host.events,
            vec![
                "submit:A",
                "submit:B",
                "cancel:A",
                "complete:B",
                "health",
                "submit:C-recover",
                "complete:C-recover",
                "submit:D",
                "submit:E",
                "complete:E",
                "complete:D",
                "submit:F-after-drop",
                "drop_engine",
                "complete:F-after-drop",
            ]
        );
    }
}
