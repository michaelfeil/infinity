# Interface

## Consumer

`gemma3-unified-runtime <validate-only|metadata|quality|life> --cases MANIFEST --report FILE`

- `validate-only`: checks all 25 fixture and input-id hashes; no model/GPU.
- `metadata`: checks pinned config SHA, Gemma3 sidecars and last-token pooling; no GPU.
- `quality --model DIR --pool cls|mean|last-token --gold NATIVE-GOLD.json --expected-config-sha256 SHA`:
  cold-constructs one normal production factory, runs invalid cases and all valid
  cases through `schedule_quality` (maximum two held submissions), and compares
  every valid route against the separate Native gold by index/kind/shape and
  `atol/rtol`.
- `life --model DIR --pool cls|mean|last-token --expected-config-sha256 SHA`:
  computes exact same-route baseline F32 bits first, then runs `schedule_life`:
  A+B held, cancel A, complete B, health/recover C, D+E held, complete E then D,
  F held, drop engine, complete F. Every completion must match its baseline bits.

Reports are checkpointed after every case. `--limit` is available for focused runs.

## Schedule proof

`cargo test --offline --bins -j2` in `consumer/` runs `schedule.rs` tests. The mock
host uses a real two-permit reservation and a 2-second timeout; any third
concurrent submit would block and fail the test. Assertions cover maximum held 2,
cancel rollback, health/recovery, out-of-order completion, and completion after
engine drop.

## Native gold

`native/native_gold_b66.py --model DIR --cases fixtures/manifest.json --out DIR --library <b66> --capi-cpp <bridge-dir> --expected-config-sha256 SHA`

CPU `--preflight-only` reads config/headers only. `--run` is Root-only and requires
explicit CUDA. Graph options are not set by the producer; existing production
environment is recorded. Partial `native-gold.json` is written after each
case/pool and on failure. Missing weights/non-BF16/repeat-bit/nonfinite failures
are fail-closed.
