# Gemma3 runtime v4

Bounded-schedule correction of runtime-v3, preserving v3 unchanged. Source packet for Root GPU qualification on the pinned Gemma3 source snapshot from public `c57c661`. The author did not edit Root, run CUDA/Torch, compile device code, run Docker, build optimized Rust or download weights.

- `repo/`: detached c57 worktree with the compiling Gemma3 source snapshot; production files unchanged.
- `consumer/`: one opt3/noLTO runtime consumer. `schedule.rs` is the shared two-slot schedule used by production and the CPU mock proof.
- `native/`: b66 Native gold producer using copied verified 19-argument wrappers.
- `fixtures/`: 25 text fixtures (20 valid/5 invalid) with fixture and input-id hashes.
- `control/`: fixture generator, used-path CPU controller, freeze tool, Root command packet.
- `PACKET.json`, `SOURCE-FREEZE.json`, `FREEZE-MANIFEST.sha256`, `GOLD-TEST-DELTA.patch`, `reports/`.

Deadlock fix: quality now completes the oldest held request at exactly 2 in flight; life uses A+B held -> cancel A -> complete B -> health/recover C -> D+E held -> complete E then D -> F held -> drop engine -> complete F. The same `schedule_quality`/`schedule_life` functions are exercised by a CPU mock with a real 2-permit reservation, so a third submit would deadlock and be caught by a timeout.

Status: `SOURCE_READY_ROOT_GPU_PENDING`. No Native gold or optimized Rust build was run by the author.
