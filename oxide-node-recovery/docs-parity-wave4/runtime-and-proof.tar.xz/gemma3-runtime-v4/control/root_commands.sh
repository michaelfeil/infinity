#!/usr/bin/env bash
# Gemma3 runtime-v4 Root command packet. ROOT-ONLY; author did not execute these.
# Concrete existing paths. Host paths are assumed bind-mounted at the same paths
# inside the container; only the Native SDK/vendor paths differ by design.
#
# HOST: /tmp/oxide-docs-parity-20261102/gemma3-runtime-v4
# HOST SDK: /tmp/h5120-root-recovered-v5/sdk/libtei_torch.so (b66)
# HOST vendor: /usr/local/cuda-13.1/lib64
# CONTAINER SDK: /tmp/native214-fa4-mode20/install/lib/libtei_torch.so (b66)
# CONTAINER vendor: /tmp/oxide-host-cublas-130200
# Weights (host): /root/.cache/huggingface/hub/models--microsoft--harrier-oss-v1-270m/snapshots/31de22b673913c7d658c0f03f792d77c2dcf8ebd
#                 /root/.cache/huggingface/hub/models--tencent--KaLM-Embedding-Gemma3-12B-2511/snapshots/98c19ba34197906fbc93f6f1ef79402ca3a33956
set -euo pipefail

ROOT=/tmp/oxide-docs-parity-20261102/gemma3-runtime-v4
DEVICE=/tmp/oxide-docs-parity-20261102/gemma3-wave4-device-all3-v1
FA4=/tmp/oxide-fa4-canonical38-all3-v2
C270=/root/.cache/huggingface/hub/models--microsoft--harrier-oss-v1-270m/snapshots/31de22b673913c7d658c0f03f792d77c2dcf8ebd
C12B=/root/.cache/huggingface/hub/models--tencent--KaLM-Embedding-Gemma3-12B-2511/snapshots/98c19ba34197906fbc93f6f1ef79402ca3a33956
SHA270=f77ed9972d4c5d69e58c4e1ee831d8e38bdbacfa358dfe0ce9a9d1885528976c
SHA12B=652d7d58cd5fed9a1509d3b2e9b984a693ac2f638009abe1f114673917f1415a
CONTAINER_SDK=/tmp/native214-fa4-mode20/install/lib/libtei_torch.so
CONTAINER_VENDOR=/tmp/oxide-host-cublas-130200

model_path() { case "$1" in 270m) echo "$C270";; 12b) echo "$C12B";; *) echo "unknown model $1" >&2; exit 2;; esac; }
model_sha() { case "$1" in 270m) echo "$SHA270";; 12b) echo "$SHA12B";; esac; }

case "${1:?usage: root_commands.sh native-270m|native-12b|host-270m|host-12b}" in
  native-270m|native-12b)
    MODEL=${1#native-}
    PATH_IN=$(model_path "$MODEL"); SHA=$(model_sha "$MODEL")
    export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:?Root must select GPU0 explicitly}
    export LD_PRELOAD="$CONTAINER_VENDOR/libcublas.so.13:$CONTAINER_VENDOR/libcublasLt.so.13"
    export LD_LIBRARY_PATH="$CONTAINER_VENDOR:$(dirname "$CONTAINER_SDK")${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    export INFINITY_BENCH_REQUIRE_HOST_VENDOR=1
    export INFINITY_TORCH_CUDA_GRAPHS=1
    unset INFINITY_TORCH_CUDA_GRAPH_MAX_TOKENS INFINITY_TORCH_CUDA_GRAPH_ENTRIES \
          INFINITY_TORCH_CUDA_GRAPH_REUSE INFINITY_TORCH_CUDA_GRAPH_MAX_BYTES \
          INFINITY_TORCH_CUDA_GRAPH_MAX_CAPTURES
    cd "$ROOT"
    python3 native/native_gold_b66.py --model "$PATH_IN" \
      --cases fixtures/manifest.json --out "reports/gold-$MODEL" \
      --library "$CONTAINER_SDK" \
      --capi-cpp "$ROOT/repo/libs/infinity-v3/backends/libtorch/cpp" \
      --expected-config-sha256 "$SHA" --pools cls,mean,last-token --repeat 2
    ;;
  host-270m|host-12b)
    MODEL=${1#host-}
    PATH_IN=$(model_path "$MODEL"); SHA=$(model_sha "$MODEL")
    export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:?Root must select GPU0 explicitly}
    export INFINITY_OXIDE_KERNEL_MODULE="$DEVICE"
    export INFINITY_FA4_ROOT="$FA4"
    export LD_LIBRARY_PATH="/usr/local/cuda-13.1/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    cd "$ROOT/consumer"
    if [[ ! -x target/release/gemma3-unified-runtime ]]; then
      # Build only after explicit Root grant. opt-level 3, lto=false.
      CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=2 cargo build --offline --release --locked -j2
    fi
    CONSUMER="$ROOT/consumer/target/release/gemma3-unified-runtime"
    for POOL in cls mean last-token; do
      "$CONSUMER" quality --cases ../fixtures/manifest.json --model "$PATH_IN" --pool "$POOL" \
        --gold "../reports/gold-$MODEL/native-gold.json" --expected-config-sha256 "$SHA" \
        --report "../reports/quality-$MODEL-$POOL.json"
    done
    "$CONSUMER" life --cases ../fixtures/manifest.json --model "$PATH_IN" --pool last-token \
      --expected-config-sha256 "$SHA" --report "../reports/life-$MODEL.json"
    ;;
  *) echo "usage: $0 native-270m|native-12b|host-270m|host-12b" >&2; exit 2;;
esac
