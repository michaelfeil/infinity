#!/usr/bin/env python3
"""Generate the frozen 25-case Gemma3 text fixture set. CPU-only, no weights/CUDA/Torch."""
from __future__ import annotations
import hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIX = ROOT / "fixtures"
FIELDS = ["input_ids", "position_ids", "token_type_ids", "cumulative_seq_lengths",
          "pooled_indices", "raw_indices", "max_length"]

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def batch(seed: int, lengths: list[int], pooled: list[int], raw: list[int],
          ids_override: dict[int, int] | None = None,
          positions_override: dict[int, int] | None = None,
          cumulative_override: list[int] | None = None) -> dict:
    ids, positions, types, cumulative = [], [], [], [0]
    for sequence, length in enumerate(lengths):
        for position in range(length):
            index = len(ids)
            value = 100 + ((seed * 977 + index * 13 + sequence * 37) % 20000)
            if ids_override and index in ids_override:
                value = ids_override[index]
            pos = positions_override.get(index, position) if positions_override else position
            ids.append(value)
            positions.append(pos)
            types.append(0)
        cumulative.append(len(ids))
    if cumulative_override is not None:
        cumulative = cumulative_override
    return {
        "input_ids": ids,
        "position_ids": positions,
        "token_type_ids": types,
        "cumulative_seq_lengths": cumulative,
        "pooled_indices": pooled,
        "raw_indices": raw,
        "max_length": max(lengths) if lengths else 0,
    }

cases: list[tuple[str, dict, bool, str | None]] = []
def add(name, value, valid=True, expected=None):
    cases.append((name, value, valid, expected))

add("b1_t1_last", batch(1, [1], [0], []))
add("b1_t7_last", batch(2, [7], [0], []))
add("b1_t33_last", batch(3, [33], [0], []))
add("b1_t128_last", batch(4, [128], [0], []))
add("b1_t64_last", batch(5, [64], [0], []))
add("b1_t7_cls", batch(6, [7], [0], []))
add("b1_t7_mean", batch(7, [7], [0], []))
add("b1_t7_raw", batch(8, [7], [], [0]))
add("b1_t7_mixed", batch(9, [7], [0], [0]))
add("b1_t7_duplicate_pooled", batch(10, [7], [0, 0], []))
add("b1_t7_duplicate_raw", batch(11, [7], [], [0, 0]))
add("ragged_growing_2_3_5_last", batch(12, [2, 3, 5], [0, 1, 2], []))
add("ragged_growing_1_4_9_17_last", batch(13, [1, 4, 9, 17], [3, 3, 0], []))
add("ragged_shrinking_17_9_4_1_last", batch(14, [17, 9, 4, 1], [0, 2, 3], []))
add("ragged_growing_raw", batch(15, [2, 5, 9], [], [0, 1, 2]))
add("ragged_shrinking_raw", batch(16, [9, 5, 2], [], [0, 1, 2]))
add("ragged_mixed", batch(17, [3, 4, 5], [2, 0], [1]))
add("ragged_single_pooled_growing", batch(18, [3, 2, 4, 1], [3], []))
add("ragged_single_pooled_shrinking", batch(19, [1, 4, 2, 3], [0], []))
add("empty_selection", batch(20, [1], [], []))

add("invalid_token_id", batch(21, [1], [0], [], ids_override={0: 262208}), False, "Inference")
add("invalid_position", batch(22, [1], [0], [], positions_override={0: 131072}), False, "Inference")
add("invalid_cumulative", batch(23, [2], [0], [], cumulative_override=[0, 3]), False, "Inference")
add("invalid_selection", batch(24, [1], [1], []), False, "Inference")
add("invalid_empty_length", batch(25, [2, 0], [0], []), False, "Inference")

assert len(cases) == 25
valid = sum(1 for _, _, ok, _ in cases if ok)
assert valid == 20 and len(cases) - valid == 5
FIX.mkdir(parents=True, exist_ok=True)
manifest_cases = []
for name, value, ok, expected in cases:
    data = json.dumps(value, separators=(",", ":"), sort_keys=False).encode()
    path = FIX / f"{name}.json"
    path.write_bytes(data)
    file_sha = sha(data)
    ids_sha = sha(json.dumps(value["input_ids"], separators=(",", ":")).encode())
    manifest_cases.append({
        "name": name,
        "file": path.name,
        "sha256": file_sha,
        "input_ids_sha256": ids_sha,
        "valid": ok,
        "expected_error_variant": expected,
        "token_count": len(value["input_ids"]),
        "sequence_count": len(value["cumulative_seq_lengths"]) - 1,
        "pooled_count": len(value["pooled_indices"]),
        "raw_count": len(value["raw_indices"]),
    })
manifest = {
    "schema": "oxide-gemma3-unified-fixtures/v1",
    "batch_fields": FIELDS,
    "cases": manifest_cases,
}
(FIX / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"generated {len(manifest_cases)} fixtures: {valid} valid, {len(cases)-valid} invalid")
