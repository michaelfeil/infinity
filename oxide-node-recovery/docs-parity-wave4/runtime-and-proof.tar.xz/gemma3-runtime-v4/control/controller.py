#!/usr/bin/env python3
"""CPU-only controller for Gemma3 runtime-v4.

Runs the actual used-path CPU modes (consumer validate-only/metadata, cargo
checks, Native CPU preflight), inspects the already-built device/FA4 bundles,
and writes a fail-closed Root command packet. No Torch import, CUDA query,
NVCC/device compile, Docker run or optimized build.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "repo"
CONSUMER = ROOT / "consumer"
FIXTURES = ROOT / "fixtures"
REPORTS = ROOT / "reports"
ROOT_PUBLIC = Path("/tmp/infinity-plain-cuda")
HOST_SDK = Path("/tmp/h5120-root-recovered-v5/sdk/libtei_torch.so")
CONTAINER_SDK = Path("/tmp/native214-fa4-mode20/install/lib/libtei_torch.so")
HOST_VENDOR = Path("/usr/local/cuda-13.1/lib64")
CONTAINER_VENDOR = Path("/tmp/oxide-host-cublas-130200")
DEVICE_BUNDLE = Path("/tmp/oxide-docs-parity-20261102/gemma3-wave4-device-all3-v1")
FA4_ROOT = Path("/tmp/oxide-fa4-canonical38-all3-v2")
MODELS = {
    "microsoft/harrier-oss-v1-270m": {
        "path": "/root/.cache/huggingface/hub/models--microsoft--harrier-oss-v1-270m/snapshots/31de22b673913c7d658c0f03f792d77c2dcf8ebd",
        "config_sha256": "f77ed9972d4c5d69e58c4e1ee831d8e38bdbacfa358dfe0ce9a9d1885528976c",
        "hidden": 640,
    },
    "tencent/KaLM-Embedding-Gemma3-12B-2511": {
        "path": "/root/.cache/huggingface/hub/models--tencent--KaLM-Embedding-Gemma3-12B-2511/snapshots/98c19ba34197906fbc93f6f1ef79402ca3a33956",
        "config_sha256": "652d7d58cd5fed9a1509d3b2e9b984a693ac2f638009abe1f114673917f1415a",
        "hidden": 3840,
    },
    "microsoft/harrier-oss-v1-27b": {
        "path": "/tmp/oxide-docs-parity-20261102/model-metadata/microsoft--harrier-oss-v1-27b",
        "config_sha256": "7a3f1a062ea71b0ecb52dc604e1722ca532e7268ca8dc767d355d25f96dd90a6",
        "hidden": 5376,
        "weights_available": False,
    },
}
EXPECTED_SDK_SHA = "b66d70b61b39e1bf0d565aca33bac7c5e21849677396ce5216f5baf73027d37e"
CASE_COUNT = 25
VALID_COUNT = 20
SOURCE_FILES = [
    "libs/infinity-v3/backends/oxide/device/build.sh",
    "libs/infinity-v3/backends/oxide/device/src/main.rs",
    "libs/infinity-v3/backends/oxide/device/src/gemma3.rs",
    "libs/infinity-v3/backends/oxide/src/decoder.rs",
    "libs/infinity-v3/backends/oxide/src/gemma2_math.rs",
    "libs/infinity-v3/backends/oxide/src/lib.rs",
    "libs/infinity-v3/backends/oxide/src/gemma3_executor.rs",
    "libs/infinity-v3/backends/oxide/src/gemma3_model.rs",
    "libs/infinity-v3/backends/oxide/src/gemma3_prepared.rs",
    "libs/infinity-v3/backends/oxide/src/gemma3_reference.rs",
    "libs/infinity-v3/backends/oxide/src/gemma3_tables.rs",
    "libs/infinity-v3/backends/oxide/tests/gemma3_lifecycle.rs",
]
TEST_FILE = "libs/infinity-v3/backends/oxide/tests/gemma3_factory_consumer.rs"

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temp.replace(path)

def source_checks():
    pinned = json.loads((ROOT / "PINNED-SOURCE-HASHES.json").read_text())
    checks = {}
    for rel in SOURCE_FILES:
        ours = REPO / rel
        root = ROOT_PUBLIC / rel
        expected = pinned["source_files"].get(rel) or pinned["source_files"]["repo/" + rel]
        checks[rel] = {
            "sha256": sha(ours) if ours.is_file() else None,
            "pinned_sha256": expected,
            "matches_pinned_root_snapshot": ours.is_file() and sha(ours) == expected,
            "live_root_sha256": sha(root) if root.is_file() else None,
            "matches_current_root": ours.is_file() and root.is_file() and sha(ours) == sha(root),
        }
    ours_test = REPO / TEST_FILE
    checks[TEST_FILE] = {
        "sha256": sha(ours_test) if ours_test.is_file() else None,
        "pinned_root_sha256": pinned["factory_test"]["root_sha256"],
        "differs_only_test_file": (ours_test.is_file()
                                   and sha(ours_test) == pinned["factory_test"]["corrected_sha256"]
                                   and pinned["factory_test"]["root_sha256"] == pinned["factory_test"]["root_sha256"]),
    }
    device_manifest = json.loads((DEVICE_BUNDLE / "manifest.json").read_text())
    symbols = None
    for arch in device_manifest.get("architectures", []):
        if arch.get("architecture") == "sm_90":
            symbols = arch.get("symbols_verified")
    required = ["infinity_gemma3_rms_norm_bf16_f32scale",
                "infinity_gemma3_residual_norm_bf16_f32scale",
                "infinity_gemma3_qk_norm_rope_bf16"]
    checks["device_bundle"] = {
        "path": str(DEVICE_BUNDLE),
        "kernel_count": len(symbols or []),
        "required_exports_present": all(name in (symbols or []) for name in required),
        "source_hash_gemma3": device_manifest.get("sources", {}).get("src/gemma3.rs"),
        "matches_repo_gemma3": device_manifest.get("sources", {}).get("src/gemma3.rs") == sha(REPO / "libs/infinity-v3/backends/oxide/device/src/gemma3.rs"),
    }
    fa4_manifest = json.loads((FA4_ROOT / "sm_90" / "manifest.json").read_text())
    names = {kernel.get("symbol") for kernel in fa4_manifest.get("kernels", [])}
    checks["fa4_bundle"] = {
        "path": str(FA4_ROOT),
        "registry": fa4_manifest.get("registry"),
        "kernel_entries": len(fa4_manifest.get("kernels", [])),
        "required_exports_present": all(
            f"fa4_{name}_{dtype}" in names for name in
            ("gemma3_global_d256_gqa2", "gemma3_local1024_d256_gqa2", "gemma3_local1024_d128_gqa2")
            for dtype in ("fp16", "bf16")),
        "modes_34_36_present": all(
            any(kernel.get("symbol") == f"fa4_{name}_{dtype}" for kernel in fa4_manifest.get("kernels", []))
            for name in ("gemma3_global_d256_gqa2", "gemma3_local1024_d256_gqa2", "gemma3_local1024_d128_gqa2")
            for dtype in ("fp16", "bf16")),
    }
    checks["host_sdk"] = {
        "path": str(HOST_SDK),
        "exists": HOST_SDK.is_file(),
        "sha256": sha(HOST_SDK) if HOST_SDK.is_file() else None,
        "expected_b66": EXPECTED_SDK_SHA,
        "container_path_not_hashed_on_host": True,
        "container_path": str(CONTAINER_SDK),
    }
    checks["host_vendor"] = {"path": str(HOST_VENDOR), "exists": HOST_VENDOR.is_dir(),
                             "container_path": str(CONTAINER_VENDOR)}
    manifest = json.loads((FIXTURES / "manifest.json").read_text())
    case_hashes_ok = all(sha(FIXTURES / case["file"]) == case["sha256"] and len(case["input_ids_sha256"]) == 64
                         for case in manifest["cases"])
    checks["fixtures"] = {
        "manifest_sha256": sha(FIXTURES / "manifest.json"),
        "count": len(manifest["cases"]),
        "valid": sum(1 for case in manifest["cases"] if case["valid"]),
        "invalid": sum(1 for case in manifest["cases"] if not case["valid"]),
        "hashes_ok": case_hashes_ok,
    }
    cargo = (CONSUMER / "Cargo.toml").read_text()
    checks["consumer_opt3_no_lto"] = {
        "opt_level_3": "opt-level = 3" in cargo,
        "lto_false": "lto = false" in cargo,
        "one_binary_source": (CONSUMER / "src/main.rs").is_file(),
        "bounded_schedule_source": (CONSUMER / "src/schedule.rs").is_file(),
        "max_held_two": "pub const MAX_HELD: usize = 2;" in (CONSUMER / "src/schedule.rs").read_text(),
        "main_uses_schedule_quality": "schedule_quality(&mut host, &valid_names)" in (CONSUMER / "src/main.rs").read_text(),
        "main_uses_schedule_life": "schedule_life(&mut host, &names)" in (CONSUMER / "src/main.rs").read_text(),
    }
    checks["schedule_source"] = {"sha256": sha(CONSUMER / "src/schedule.rs"), "max_held": 2}
    return checks

def run(command, cwd, log, env_extra=None, timeout=1800):
    env = dict(os.environ, CUDA_VISIBLE_DEVICES="", CARGO_NET_OFFLINE="true",
               CARGO_TARGET_DIR="/tmp/oxide-docs-parity-20261102/gemma3-runtime-v3-cpu-target",
               CARGO_BUILD_JOBS="2")
    if env_extra: env.update(env_extra)
    proc = subprocess.run(["taskset", "-c", "120-127"] + command, cwd=cwd, env=env,
                          capture_output=True, text=True, timeout=timeout)
    (REPORTS / log).write_text(proc.stdout + proc.stderr)
    return proc.returncode

def used_path_checks():
    cargo = shutil.which("cargo") or str(Path.home() / ".cargo/bin/cargo")
    records = {}
    records["consumer_check"] = run([cargo, "check", "--offline", "--quiet"], CONSUMER, "consumer-check.log")
    records["consumer_schedule_proof"] = run([cargo, "test", "--offline", "--quiet", "--bins", "-j2"], CONSUMER, "consumer-schedule-proof.log")
    for label, model in (("270m", MODELS["microsoft/harrier-oss-v1-270m"]),
                         ("12b", MODELS["tencent/KaLM-Embedding-Gemma3-12B-2511"]),
                         ("27b", MODELS["microsoft/harrier-oss-v1-27b"])):
        records[f"consumer_metadata_{label}"] = run([
            cargo, "run", "--offline", "--quiet", "--", "metadata",
            "--cases", "../fixtures/manifest.json", "--model", model["path"],
            "--expected-config-sha256", model["config_sha256"],
            "--report", f"../reports/metadata-{label}.json"], CONSUMER, f"metadata-{label}.log")
    records["consumer_validate"] = run([
        cargo, "run", "--offline", "--quiet", "--", "validate-only",
        "--cases", "../fixtures/manifest.json", "--report", "../reports/validate-only.json"],
        CONSUMER, "validate-only.log")
    python = sys.executable
    for label, model in (("270m", MODELS["microsoft/harrier-oss-v1-270m"]),
                         ("12b", MODELS["tencent/KaLM-Embedding-Gemma3-12B-2511"])):
        records[f"native_preflight_{label}"] = run([
            python, "native/native_gold_b66.py", "--model", model["path"],
            "--cases", "fixtures/manifest.json", "--out", f"reports/native-preflight-{label}",
            "--expected-config-sha256", model["config_sha256"], "--preflight-only"],
            ROOT, f"native-preflight-{label}.log")
    model27 = Path(MODELS["microsoft/harrier-oss-v1-27b"]["path"])
    if (model27 / "model.safetensors").is_file() or (model27 / "model.safetensors.index.json").is_file():
        records["native_preflight_27b"] = run([
            python, "native/native_gold_b66.py", "--model", str(model27),
            "--cases", "fixtures/manifest.json", "--out", "reports/native-preflight-27b",
            "--expected-config-sha256", MODELS["microsoft/harrier-oss-v1-27b"]["config_sha256"], "--preflight-only"],
            ROOT, "native-preflight-27b.log")
    else:
        records["native_preflight_27b"] = None
        (REPORTS / "native-preflight-27b.log").write_text("skipped: 27B weights unavailable; numeric claim forbidden\n")
    return records

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-used-path", action="store_true")
    parser.add_argument("--out", default=str(REPORTS / "ROOT-DRYRUN.json"))
    args = parser.parse_args()
    REPORTS.mkdir(parents=True, exist_ok=True)
    checks = source_checks()
    used = {} if args.skip_used_path else used_path_checks()
    weights = {}
    for name, model in MODELS.items():
        path = Path(model["path"])
        weights[name] = {
            "path": model["path"],
            "config_present": (path / "config.json").is_file(),
            "config_sha256": sha(path / "config.json") if (path / "config.json").is_file() else None,
            "expected_config_sha256": model["config_sha256"],
            "modules_present": (path / "modules.json").is_file(),
            "weights_present": (path / "model.safetensors").is_file() or (path / "model.safetensors.index.json").is_file(),
        }
    source_ok = all(v["matches_pinned_root_snapshot"] for k, v in checks.items() if k in SOURCE_FILES)
    source_ok &= checks[TEST_FILE]["differs_only_test_file"]
    source_ok &= checks["device_bundle"]["required_exports_present"] and checks["device_bundle"]["matches_repo_gemma3"]
    source_ok &= checks["fa4_bundle"]["required_exports_present"] and checks["fa4_bundle"]["modes_34_36_present"]
    source_ok &= checks["host_sdk"]["sha256"] == EXPECTED_SDK_SHA
    source_ok &= checks["fixtures"]["hashes_ok"] and checks["fixtures"]["count"] == CASE_COUNT
    source_ok &= all(checks["consumer_opt3_no_lto"].values())
    used_ok = all(code == 0 for code in used.values() if code is not None)
    plan = {
        "schema": "oxide-gemma3-runtime-v3-root-dryrun/v1",
        "status": "SOURCE_READY_ROOT_GPU_PENDING" if source_ok else "SOURCE_BLOCKED",
        "base_commit": "c57c6611533f237f68129625a164eb30adb9d46c",
        "source_checks": checks,
        "source_checks_ok": source_ok,
        "live_root_drift": [k for k, v in checks.items() if k in SOURCE_FILES and not v["matches_current_root"]],
        "pinned_source_hashes": "PINNED-SOURCE-HASHES.json",
        "used_path_cpu_checks": used,
        "used_path_cpu_ok": used_ok,
        "models": weights,
        "paths": {
            "host_sdk": str(HOST_SDK),
            "container_sdk": str(CONTAINER_SDK),
            "host_vendor": str(HOST_VENDOR),
            "container_vendor": str(CONTAINER_VENDOR),
            "device_bundle": str(DEVICE_BUNDLE),
            "fa4_root": str(FA4_ROOT),
            "container_source_mount": "<ROOT mount> -> /work/gemma3-runtime-v3",
        },
        "pools": ["cls", "mean", "last-token"],
        "fixtures": {"count": CASE_COUNT, "valid": VALID_COUNT, "invalid": CASE_COUNT - VALID_COUNT,
                     "manifest_sha256": checks["fixtures"]["manifest_sha256"]},
        "gold": {
            "producer": "native/native_gold_b66.py",
            "required_for_quality": True,
            "default_acceptance": {"atol": 0.0, "rtol": 0.0,
                                   "note": "fail closed; Root must supply approved tolerance explicitly"},
            "graph_policy": "Existing qualified Native production control: INFINITY_TORCH_CUDA_GRAPHS=1 with all graph budgets left at defaults. Actual flags/counters recorded; never disabled to win.",
        },
        "consumer_commands": {
            "quality": "gemma3-unified-runtime quality --cases fixtures/manifest.json --model <CHECKPOINT> --pool <cls|mean|last-token> --gold <NATIVE_GOLD> --expected-config-sha256 <SHA> --report reports/quality-<pool>.json",
            "life": "gemma3-unified-runtime life --cases fixtures/manifest.json --model <CHECKPOINT> --pool last-token --expected-config-sha256 <SHA> --report reports/life.json",
            "build_release": "CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=2 cargo build --offline --release --locked",
        },
        "root_sequence": [
            "Host controller CPU checks and the bounded two-slot schedule proof must pass.",
            "Container native-270m: run the b66 Native gold producer with existing production graph defaults; record actual flags/stats.",
            "Host host-270m: build the opt3/noLTO consumer only after Root grant; run cls/mean/last-token quality and life.",
            "Only after 270m passes, repeat container native-12b then host host-12b.",
            "No extra ignored test binaries are part of the Root packet; the consumer is the unified gate.",
            "Keep partial reports on failure; 27B stays fail-closed until weights are staged.",
        ],
    }
    write(Path(args.out), plan)
    write(REPORTS / "ROOT-DRYRUN.json", plan)
    print(json.dumps({"status": plan["status"], "source_ok": source_ok, "used_path_ok": used_ok,
                      "used_paths": used, "out": str(args.out)}))
    return 0 if source_ok and used_ok else 1

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"controller failed: {error}", file=sys.stderr)
        raise SystemExit(1)
