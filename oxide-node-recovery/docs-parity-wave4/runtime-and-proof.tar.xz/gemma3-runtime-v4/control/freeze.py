#!/usr/bin/env python3
"""CPU-only source/artifact freeze. Never hashes container-only SDK paths."""
from __future__ import annotations
import hashlib, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

source = [
    "repo/libs/infinity-v3/backends/oxide/device/build.sh",
    "repo/libs/infinity-v3/backends/oxide/device/src/main.rs",
    "repo/libs/infinity-v3/backends/oxide/device/src/gemma3.rs",
    "repo/libs/infinity-v3/backends/oxide/src/decoder.rs",
    "repo/libs/infinity-v3/backends/oxide/src/gemma2_math.rs",
    "repo/libs/infinity-v3/backends/oxide/src/lib.rs",
    "repo/libs/infinity-v3/backends/oxide/src/gemma3_executor.rs",
    "repo/libs/infinity-v3/backends/oxide/src/gemma3_model.rs",
    "repo/libs/infinity-v3/backends/oxide/src/gemma3_prepared.rs",
    "repo/libs/infinity-v3/backends/oxide/src/gemma3_reference.rs",
    "repo/libs/infinity-v3/backends/oxide/src/gemma3_tables.rs",
    "repo/libs/infinity-v3/backends/oxide/tests/gemma3_lifecycle.rs",
    "repo/libs/infinity-v3/backends/oxide/tests/gemma3_factory_consumer.rs",
]
artifacts = [
    "consumer/Cargo.toml", "consumer/Cargo.lock", "consumer/src/main.rs", "consumer/src/schedule.rs",
    "fixtures/manifest.json",
    "native/native_gold_b66.py",
    "native/verified/native_base.py", "native/verified/native_batch.py",
    "native/verified/native_raw_probe.py", "native/verified/model_checkpoint.py",
    "native/verified/bridge.h",
    "control/generate_fixtures.py", "control/controller.py", "control/root_commands.sh",
    "reports/ROOT-DRYRUN.json", "PACKET.json", "INTERFACE.md", "README.md",
    "GOLD-TEST-DELTA.patch", "PINNED-SOURCE-HASHES.json",
] + [str(path.relative_to(ROOT)) for path in sorted((ROOT / "reports").glob("*"))
     if path.is_file() and path.suffix in (".json", ".log")]
def file_hashes(paths):
    return {p: {"sha256": sha(ROOT / p), "bytes": (ROOT / p).stat().st_size}
            for p in paths if (ROOT / p).is_file()}
doc = {
    "schema": "oxide-gemma3-runtime-v3-source-freeze/v1",
    "base_commit": "c57c6611533f237f68129625a164eb30adb9d46c",
    "root_working_tree": "/tmp/infinity-plain-cuda",
    "frozen_note": "Production Gemma3 source matches Root current c57+uncommitted; only the factory consumer test is corrected locally.",
    "source_files": file_hashes(source),
    "artifacts": file_hashes(artifacts),
    "fixture_manifest": {
        "path": str(ROOT / "fixtures/manifest.json"),
        "sha256": sha(ROOT / "fixtures/manifest.json"),
        "cases": json.loads((ROOT / "fixtures/manifest.json").read_text())["cases"],
    },
    "gold": {
        "required": True,
        "paths": [str(ROOT / "reports/gold-270m/native-gold.json"),
                  str(ROOT / "reports/gold-12b/native-gold.json")],
        "present": {str(p): p.is_file() for p in [ROOT / "reports/gold-270m/native-gold.json",
                                                    ROOT / "reports/gold-12b/native-gold.json"]},
        "hashes": {str(p): sha(p) for p in [ROOT / "reports/gold-270m/native-gold.json",
                                             ROOT / "reports/gold-12b/native-gold.json"] if p.is_file()},
    },
    "sdk": {
        "host_path": "/tmp/h5120-root-recovered-v5/sdk/libtei_torch.so",
        "host_sha256": sha(pathlib.Path("/tmp/h5120-root-recovered-v5/sdk/libtei_torch.so")) if pathlib.Path("/tmp/h5120-root-recovered-v5/sdk/libtei_torch.so").is_file() else None,
        "container_path": "/tmp/native214-fa4-mode20/install/lib/libtei_torch.so",
        "container_path_hashed_on_host": False,
        "expected_b66": "b66d70b61b39e1bf0d565aca33bac7c5e21849677396ce5216f5baf73027d37e",
    },
    "no_cuda": True, "torch_imported": False, "device_compiled": False, "optimized_build": False,
}
(ROOT / "SOURCE-FREEZE.json").write_text(json.dumps(doc, indent=2) + "\n")
lines = [f"{v['sha256']}  {p}" for section in ("source_files", "artifacts") for p, v in doc[section].items()]
lines.append(f"{doc['fixture_manifest']['sha256']}  fixtures/manifest.json")
for p, h in doc["gold"]["hashes"].items():
    lines.append(f"{h}  {pathlib.Path(p).relative_to(ROOT)}")
(ROOT / "FREEZE-MANIFEST.sha256").write_text("\n".join(sorted(lines)) + "\n")
print(json.dumps({"source_files": len(doc["source_files"]), "artifacts": len(doc["artifacts"]),
                  "gold_present": doc["gold"]["present"], "out": str(ROOT / "SOURCE-FREEZE.json")}))
