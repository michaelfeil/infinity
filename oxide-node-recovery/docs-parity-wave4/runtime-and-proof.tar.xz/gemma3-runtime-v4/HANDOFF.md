# Gemma3 runtime v4 handoff

Status: `SOURCE_READY_ROOT_GPU_PENDING`; two-slot schedule deadlock fixed and CPU-proven. V3 is preserved unchanged at `/tmp/oxide-docs-parity-20261102/gemma3-runtime-v3`.

- Pinned source: public `c57c6611533f237f68129625a164eb30adb9d46c` plus imported Gemma3 source; `PINNED-SOURCE-HASHES.json`.
- Worktree: `/tmp/oxide-docs-parity-20261102/gemma3-runtime-v4`.
- Production source: unchanged from the pinned Gemma3 snapshot. Only test delta: `GOLD-TEST-DELTA.patch` adds the per-route Native-gold test; Root inc23 already owns the same-route repeatability fix.
- Consumer: one opt3/noLTO `gemma3-unified-runtime` source. Shared `schedule.rs` uses `MAX_HELD=2`; quality flushes oldest at 2; life performs A+B -> cancel A -> complete B -> health/recover C -> D+E -> complete E then D -> F -> drop engine -> complete F. Life compares exact same-route F32 bit vectors.
- CPU proof: `cargo test --offline --bins -j2`, two mock tests with a real 2-permit reservation and 2-second timeout; both pass.
- Native producer: `native/native_gold_b66.py` with copied verified 19-argument wrappers; no graph setter, actual graph env/counters recorded, partial output on failure, missing weights fail closed.
- Concrete Root paths: device `gemma3-wave4-device-all3-v1` (115 kernels), FA4 `oxide-fa4-canonical38-all3-v2` (modes 34/35/36), host SDK b66 `/tmp/h5120-root-recovered-v5/sdk/libtei_torch.so`, container SDK `/tmp/native214-fa4-mode20/install/lib/libtei_torch.so`, host vendor `/usr/local/cuda-13.1/lib64`, container vendor `/tmp/oxide-host-cublas-130200`.
- Fixtures: 25 text cases (20 valid, 5 invalid), exact fixture/input-id hashes.
- Root packet: `control/root_commands.sh` subcommands `native-270m`, `host-270m`, then `native-12b`, `host-12b`. No extra ignored test binaries. Host opt3/noLTO build only after Root grant.

No CUDA, Torch, NVCC, device compile, Docker, optimized build or weight download was run by the author.
