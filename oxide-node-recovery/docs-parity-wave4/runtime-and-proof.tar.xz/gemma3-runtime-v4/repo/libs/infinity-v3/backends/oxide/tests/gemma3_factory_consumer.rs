// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Unified production-factory consumer gate for the three Gemma3 text checkpoints.
//!
//! Ignored by default: this is the Root GPU0 qualification recipe, not a CPU
//! stand-in. It uses only the public `OxideBackend` factory and `Backend`
//! contract, proving cold factory construction, shared Work ownership,
//! `Inference::Deferred` completion, and raw/pooled parity. Native LibTorch
//! graphs stay at their unchanged defaults in the controller; Oxide remains
//! graph-free.

use std::collections::BTreeMap;

use infinity_backend_oxide::OxideBackend;
use infinity_v3_backend_core::{
    Backend, BackendError, Batch, Embedding, Embeddings, Inference, ModelType, Pool,
};

fn model_path() -> std::path::PathBuf {
    std::env::var_os("INFINITY_OXIDE_TEST_GEMMA3_MODEL")
        .map(std::path::PathBuf::from)
        .expect("set INFINITY_OXIDE_TEST_GEMMA3_MODEL to a Gemma3 text checkpoint")
}

fn model_config(path: &std::path::Path) -> (usize, u32, u32) {
    let config: serde_json::Value =
        serde_json::from_slice(&std::fs::read(path.join("config.json")).unwrap()).unwrap();
    assert_eq!(config["model_type"], "gemma3_text");
    let hidden = config["hidden_size"].as_u64().unwrap() as usize;
    assert!(
        matches!(hidden, 640 | 3840 | 5376),
        "unexpected Gemma3 hidden width {hidden}"
    );
    (
        hidden,
        config["vocab_size"].as_u64().unwrap() as u32,
        config["max_position_embeddings"].as_u64().unwrap() as u32,
    )
}

fn factory(path: &std::path::Path) -> OxideBackend {
    OxideBackend::new(path, "bfloat16", ModelType::Embedding(Pool::LastToken), 0)
        .expect("cold Gemma3 production factory")
}

fn fixture(lengths: &[u32], pooled: &[u32], raw: &[u32], vocab: u32, max_positions: u32) -> Batch {
    let mut cumulative_seq_lengths = vec![0];
    let mut input_ids = Vec::new();
    let mut position_ids = Vec::new();
    for &length in lengths {
        assert!(length > 0 && length <= max_positions);
        for position in 0..length {
            input_ids.push(20 + (input_ids.len() as u32 * 13) % (vocab - 32));
            position_ids.push(position);
        }
        cumulative_seq_lengths.push(input_ids.len() as u32);
    }
    Batch {
        multimodal: Vec::new(),
        token_type_ids: vec![0; input_ids.len()],
        input_ids,
        position_ids,
        cumulative_seq_lengths,
        max_length: lengths.iter().copied().max().unwrap_or(0),
        pooled_indices: pooled.to_vec(),
        raw_indices: raw.to_vec(),
        compact_input_ids: None,
        compact_position_ids: None,
        scatter_unfold: None,
        fold_gather: None,
        tokens: Vec::new(),
        offsets: Vec::new(),
    }
}

fn rows(result: &Embeddings, batch: &Batch, hidden: usize) -> BTreeMap<usize, Vec<Vec<u32>>> {
    let mut out = BTreeMap::new();
    for (&index, value) in result.iter() {
        let rows: Vec<&[f32]> = match value {
            Embedding::Pooled(row) => vec![row],
            Embedding::All(tokens) => tokens.iter().map(Vec::as_slice).collect(),
        };
        let bits = rows
            .into_iter()
            .map(|row| {
                assert_eq!(row.len(), hidden);
                assert!(row.iter().all(|value| value.is_finite()));
                row.iter().map(|value| value.to_bits()).collect()
            })
            .collect();
        assert!(out.insert(index, bits).is_none());
    }
    let expected = batch
        .pooled_indices
        .iter()
        .chain(&batch.raw_indices)
        .map(|&index| index as usize)
        .collect::<std::collections::BTreeSet<_>>();
    let actual = out
        .keys()
        .copied()
        .collect::<std::collections::BTreeSet<_>>();
    assert_eq!(actual, expected);
    out
}

#[test]
#[ignore = "Root GPU0: actual Gemma3 cold factory, Work/Deferred lifecycle and raw/pooled parity"]
fn gemma3_factory_work_deferred_and_raw_pooled_parity() {
    let path = model_path();
    let (hidden, vocab, max_positions) = model_config(&path);
    let backend = factory(&path);
    backend.health().unwrap();

    // Same-route repeats remain bit-identical. Cross-route pooled/raw equality is
    // intentionally NOT asserted: Native pooled selection and full-token math use
    // different GEMM M and are checked by the separate Native-gold gate below.
    for lengths in [vec![7u32, 3], vec![1, 17, 5], vec![33], vec![2, 71, 1]] {
        let selected = (0..lengths.len() as u32).collect::<Vec<_>>();
        let pooled = fixture(&lengths, &selected, &[], vocab, max_positions);
        let raw = fixture(&lengths, &[], &selected, vocab, max_positions);
        let pooled_first = rows(&backend.embed(pooled.clone()).unwrap(), &pooled, hidden);
        let pooled_second = rows(&backend.embed(pooled.clone()).unwrap(), &pooled, hidden);
        assert_eq!(pooled_first, pooled_second);
        let raw_first = rows(&backend.embed(raw.clone()).unwrap(), &raw, hidden);
        let raw_second = rows(&backend.embed(raw.clone()).unwrap(), &raw, hidden);
        assert_eq!(raw_first, raw_second);
    }

    // Duplicate/public selection order must not change canonical rows.
    let base = fixture(&[7, 3, 11], &[1, 0, 2], &[], vocab, max_positions);
    let duplicate = fixture(&[7, 3, 11], &[2, 0, 2, 1, 0], &[], vocab, max_positions);
    let base_rows = rows(&backend.embed(base.clone()).unwrap(), &base, hidden);
    let duplicate_rows = rows(
        &backend.embed(duplicate.clone()).unwrap(),
        &duplicate,
        hidden,
    );
    for (index, expected) in &base_rows {
        assert_eq!(duplicate_rows.get(index).unwrap(), expected);
    }

    // Deferred completion keeps its own arena/stream owner and completes out of order.
    let a = fixture(&[7, 3], &[1, 0, 1], &[], vocab, max_positions);
    let b = fixture(&[1, 17, 5], &[2, 0, 1], &[1, 1], vocab, max_positions);
    let expected_a = rows(&backend.embed(a.clone()).unwrap(), &a, hidden);
    let expected_b = rows(&backend.embed(b.clone()).unwrap(), &b, hidden);
    let held_a = backend.submit_embed(a.clone()).unwrap();
    let held_b = backend.submit_embed(b.clone()).unwrap();
    assert!(matches!(&held_a, Inference::Deferred(_)));
    assert!(matches!(&held_b, Inference::Deferred(_)));
    assert_eq!(rows(&held_b.complete().unwrap(), &b, hidden), expected_b);
    assert_eq!(rows(&held_a.complete().unwrap(), &a, hidden), expected_a);

    // Dropping a pending request must leave the engine healthy and the Work reusable.
    let held = backend.submit_embed(b.clone()).unwrap();
    drop(held);
    backend.health().unwrap();
    assert_eq!(
        rows(&backend.embed(b.clone()).unwrap(), &b, hidden),
        expected_b
    );
    let held = backend.submit_embed(a.clone()).unwrap();
    drop(backend);
    assert_eq!(rows(&held.complete().unwrap(), &a, hidden), expected_a);
}

#[test]
#[ignore = "Root GPU0: actual Gemma3 admission rejects without poisoning the factory"]
fn gemma3_factory_rejections_leave_health_green() {
    let path = model_path();
    let (hidden, vocab, max_positions) = model_config(&path);
    let backend = factory(&path);
    let good = fixture(&[7, 3], &[0, 1], &[], vocab, max_positions);
    let expected = rows(&backend.embed(good.clone()).unwrap(), &good, hidden);

    let mut invalid = good.clone();
    invalid.input_ids[0] = vocab;
    assert!(matches!(
        backend.submit_embed(invalid),
        Err(BackendError::Inference(_))
    ));
    backend.health().unwrap();
    let mut invalid = good.clone();
    invalid.position_ids[0] = max_positions;
    assert!(matches!(
        backend.submit_embed(invalid),
        Err(BackendError::Inference(_))
    ));
    backend.health().unwrap();
    let mut ignored_types = good;
    ignored_types.token_type_ids.fill(u32::MAX);
    let actual = rows(
        &backend.embed(ignored_types).unwrap(),
        &fixture(&[7, 3], &[0, 1], &[], vocab, max_positions),
        hidden,
    );
    assert_eq!(actual, expected);
    backend.health().unwrap();
}

#[derive(serde::Deserialize)]
struct GoldManifestCase {
    name: String,
    file: String,
    sha256: String,
    input_ids_sha256: String,
    valid: bool,
    expected_error_variant: Option<String>,
    token_count: usize,
    sequence_count: usize,
    pooled_count: usize,
    raw_count: usize,
}

#[derive(serde::Deserialize)]
struct GoldManifest {
    schema: String,
    cases: Vec<GoldManifestCase>,
}

#[derive(serde::Deserialize)]
struct GoldEntry {
    index: usize,
    kind: String,
    shape: Vec<usize>,
    values_file: String,
    sha256: String,
}

#[derive(serde::Deserialize)]
struct GoldPool {
    entries: Vec<GoldEntry>,
}

#[derive(serde::Deserialize)]
struct GoldCase {
    name: String,
    fixture_sha256: String,
    input_ids_sha256: String,
    pools: std::collections::BTreeMap<String, GoldPool>,
}

#[derive(serde::Deserialize)]
struct Acceptance {
    atol: f64,
    rtol: f64,
}

#[derive(serde::Deserialize)]
struct NativeGold {
    schema: String,
    config_sha256: String,
    hidden_size: usize,
    cases: Vec<GoldCase>,
    acceptance: Acceptance,
}

fn sha_hex(bytes: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    format!("{:x}", Sha256::digest(bytes))
}

fn batch_json(value: &serde_json::Value) -> Batch {
    let array = |name: &str| {
        value[name]
            .as_array()
            .unwrap()
            .iter()
            .map(|item| item.as_u64().unwrap() as u32)
            .collect::<Vec<_>>()
    };
    Batch {
        multimodal: Vec::new(),
        input_ids: array("input_ids"),
        position_ids: array("position_ids"),
        token_type_ids: array("token_type_ids"),
        cumulative_seq_lengths: array("cumulative_seq_lengths"),
        pooled_indices: array("pooled_indices"),
        raw_indices: array("raw_indices"),
        max_length: value["max_length"].as_u64().unwrap() as u32,
        compact_input_ids: None,
        compact_position_ids: None,
        scatter_unfold: None,
        fold_gather: None,
        tokens: Vec::new(),
        offsets: Vec::new(),
    }
}

fn output_values(
    result: &Embeddings,
    hidden: usize,
) -> Result<BTreeMap<usize, (String, Vec<usize>, Vec<f32>)>, String> {
    let mut output = BTreeMap::new();
    for (&index, value) in result.iter() {
        let (kind, shape, values) = match value {
            Embedding::Pooled(row) => ("pooled".to_string(), vec![row.len()], row.clone()),
            Embedding::All(rows) => (
                "raw".to_string(),
                vec![rows.len(), rows.first().map_or(hidden, Vec::len)],
                rows.iter().flat_map(|row| row.iter().copied()).collect(),
            ),
        };
        if values.iter().any(|value| !value.is_finite()) {
            return Err(format!("index {index} has nonfinite output"));
        }
        output.insert(index, (kind, shape, values));
    }
    Ok(output)
}

fn load_gold_pool(
    case: &GoldCase,
    pool: &str,
    gold_root: &std::path::Path,
) -> Result<(), String> {
    let gold_pool = case
        .pools
        .get(pool)
        .ok_or_else(|| format!("{}: gold lacks pool {pool}", case.name))?;
    for entry in &gold_pool.entries {
        let path = gold_root.join(&entry.values_file);
        let bytes = std::fs::read(&path).map_err(|error| format!("{}: {error}", path.display()))?;
        if sha_hex(&bytes) != entry.sha256 {
            return Err(format!("{}: gold sha256 differs", path.display()));
        }
        let elements = entry.shape.iter().product::<usize>();
        if bytes.len() != elements * 4 {
            return Err(format!("{}: gold byte length differs", path.display()));
        }
        let expected = bytes
            .chunks_exact(4)
            .map(|chunk| f32::from_le_bytes(chunk.try_into().unwrap()))
            .collect::<Vec<_>>();
        if expected.len() != elements {
            return Err("gold element count differs".into());
        }
        // The caller compares the returned expected values by index.
        GOLD_VALUES.with(|cell| cell.borrow_mut().insert(entry.index, (entry.kind.clone(), entry.shape.clone(), expected)));
    }
    Ok(())
}

thread_local! {
    static GOLD_VALUES: std::cell::RefCell<BTreeMap<usize, (String, Vec<usize>, Vec<f32>)>> =
        std::cell::RefCell::new(BTreeMap::new());
}

#[test]
#[ignore = "Root GPU0 required: per-route Native b66 gold comparison over the same 25 fixtures"]
fn gemma3_native_gold_required_per_route() {
    let manifest_path = std::env::var_os("INFINITY_OXIDE_TEST_GEMMA3_FIXTURES")
        .map(std::path::PathBuf::from)
        .expect("set INFINITY_OXIDE_TEST_GEMMA3_FIXTURES to fixtures/manifest.json");
    let gold_path = std::env::var_os("INFINITY_OXIDE_TEST_GEMMA3_NATIVE_GOLD")
        .map(std::path::PathBuf::from)
        .expect("set INFINITY_OXIDE_TEST_GEMMA3_NATIVE_GOLD to native-gold.json");
    let pool_name = std::env::var("INFINITY_OXIDE_TEST_GEMMA3_POOL").unwrap_or_else(|_| "last-token".into());
    let pool = match pool_name.as_str() {
        "cls" => Pool::Cls,
        "mean" => Pool::Mean,
        "last-token" => Pool::LastToken,
        other => panic!("invalid INFINITY_OXIDE_TEST_GEMMA3_POOL {other}"),
    };
    let manifest_root = manifest_path.parent().expect("fixture manifest has no parent");
    let manifest: GoldManifest = serde_json::from_slice(
        &std::fs::read(&manifest_path).expect("read fixture manifest"),
    )
    .expect("parse fixture manifest");
    assert_eq!(manifest.schema, "oxide-gemma3-unified-fixtures/v1");
    assert_eq!(manifest.cases.len(), 25);
    let gold: NativeGold = serde_json::from_slice(&std::fs::read(&gold_path).expect("read native gold"))
        .expect("parse native gold");
    assert_eq!(gold.schema, "oxide-gemma3-native-gold/v1");
    let gold_root = gold_path.parent().expect("gold has no parent");
    let model = model_path();
    let (hidden, _vocab, _max_positions) = model_config(&model);
    assert_eq!(gold.hidden_size, hidden);
    let config: serde_json::Value =
        serde_json::from_slice(&std::fs::read(model.join("config.json")).unwrap()).unwrap();
    assert_eq!(sha_hex(&std::fs::read(model.join("config.json")).unwrap()), gold.config_sha256);
    let _ = config;
    let gold_cases = gold
        .cases
        .iter()
        .map(|case| (case.name.clone(), case))
        .collect::<BTreeMap<_, _>>();
    let backend = OxideBackend::new(
        &model,
        "bfloat16",
        ModelType::Embedding(pool),
        0,
    )
    .expect("cold Gemma3 production factory");
    let mut compared_cases = 0usize;
    for case in &manifest.cases {
        let path = manifest_root.join(&case.file);
        let bytes = std::fs::read(&path).unwrap_or_else(|error| panic!("{}: {error}", path.display()));
        assert_eq!(sha_hex(&bytes), case.sha256);
        let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        let ids_sha = sha_hex(&serde_json::to_vec(&value["input_ids"].as_array().unwrap()).unwrap());
        assert_eq!(ids_sha, case.input_ids_sha256);
        let batch = batch_json(&value);
        assert_eq!(batch.input_ids.len(), case.token_count);
        assert_eq!(batch.cumulative_seq_lengths.len(), case.sequence_count + 1);
        assert_eq!(batch.pooled_indices.len(), case.pooled_count);
        assert_eq!(batch.raw_indices.len(), case.raw_count);
        if !case.valid {
            let expected = case.expected_error_variant.as_deref().unwrap_or("Inference");
            match backend.submit_embed(batch) {
                Ok(_) => panic!("{}: invalid case admitted", case.name),
                Err(error) => {
                    let actual = match error {
                        BackendError::Overloaded(_) => "Overloaded",
                        BackendError::Inference(_) => "Inference",
                        BackendError::Start(_) => "Start",
                        BackendError::NoBackend => "NoBackend",
                        BackendError::Unhealthy => "Unhealthy",
                        BackendError::WeightsNotFound(_) => "WeightsNotFound",
                    };
                    assert_eq!(actual, expected, "{}", case.name);
                }
            }
            continue;
        }
        let actual = output_values(&backend.embed(batch).unwrap(), hidden).unwrap();
        let gold_case = gold_cases.get(&case.name).unwrap_or_else(|| panic!("{}: missing gold", case.name));
        assert_eq!(gold_case.fixture_sha256, case.sha256);
        assert_eq!(gold_case.input_ids_sha256, case.input_ids_sha256);
        let gold_pool = gold_case.pools.get(&pool_name).unwrap_or_else(|| panic!("{}: missing gold pool", case.name));
        assert_eq!(actual.len(), gold_pool.entries.len());
        GOLD_VALUES.with(|cell| cell.borrow_mut().clear());
        load_gold_pool(gold_case, &pool_name, gold_root).unwrap();
        GOLD_VALUES.with(|cell| {
            let expected = cell.borrow();
            for (index, (kind, shape, values)) in &actual {
                let (gold_kind, gold_shape, gold_values) = expected.get(index).unwrap_or_else(|| panic!("{}: extra index {index}", case.name));
                assert_eq!(kind, gold_kind, "{} index {index}", case.name);
                assert_eq!(shape, gold_shape, "{} index {index}", case.name);
                assert_eq!(values.len(), gold_values.len());
                for (a, b) in values.iter().zip(gold_values) {
                    let abs = (*a as f64 - *b as f64).abs();
                    let rel = if *b == 0.0 { abs } else { abs / (*b as f64).abs() };
                    assert!(abs <= gold.acceptance.atol || rel <= gold.acceptance.rtol,
                        "{} index {index} abs={abs} rel={rel} atol={} rtol={}", case.name, gold.acceptance.atol, gold.acceptance.rtol);
                }
            }
        });
        compared_cases += 1;
    }
    assert_eq!(compared_cases, 20);
    backend.health().unwrap();
}
