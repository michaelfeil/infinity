# Remaining gaps (v2)

1. **Root gold**: no gold exists in this packet. Run the producer inside the
   existing container SDK; host Torch is forbidden.
2. **B2 reduction order**: actual Native `at::linalg_vector_norm` order is not
   proven equal to the kernel `block_sum`. Exact words are reported; the gate
   applies a one-BF16-ulp relative tolerance.
3. **9-arg width**: `infinity_deberta_plain_norm_bf16_aten` serves only
   H384/H1024. H768 uses the 7-arg entry.
4. **compute-sanitizer**: wrappers are source-only until Root runs them on
   GPU0. `controller-init`/`controller-mem` are not sanitizer runs.
5. **ABI check**: `cuFuncGetParamInfo` is required; the control rejects instead
   of silently skipping it.
6. **No numeric/performance claim**: CPU tests are structural only.
7. **Canaries**: fixed guard words are structural, not a security boundary.
