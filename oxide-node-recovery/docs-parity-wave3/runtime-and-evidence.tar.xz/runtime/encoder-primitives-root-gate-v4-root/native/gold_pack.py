#!/usr/bin/env python3
"""Pure-stdlib packing, case planning, and container helpers.

This module never imports Torch, NumPy, ctypes CUDA, or any GPU library. It is
shared by the Root-only Native gold producer (which adds actual Torch CUDA
gold), the ctypes control, and the CPU-only packet tests. Nothing here computes
a LayerNorm or an L2 reference: the only math is BF16 word encoding for input
fixtures.
"""
from __future__ import annotations

import hashlib
import json
import random
import struct
from pathlib import Path

CONTAINER_MAGIC = b"EPGGOLD1"
CONTAINER_SCHEMA = "oxide-encoder-primitives-gold/v1"
PLAN_SCHEMA = "oxide-encoder-primitives-cases/v1"
MANIFEST_SCHEMA = "oxide-encoder-primitives-root-gate/v1"
ARTIFACT_LOCK_SCHEMA = "oxide-encoder-primitives-artifact-lock/v1"

BF16_GUARD_WORD = 0xA5A5
F32_GUARD_WORD = 0xDEADBEEF
BF16_INIT_WORD = 0x3F80  # 1.0
F32_INIT_WORD = 0x3F800000
GUARD_PREFIX_WORDS = 8
GUARD_SUFFIX_WORDS = 8

DTYPE_BYTES = {"bfloat16": 2, "float32": 4}

# The three source contracts this packet freezes. Widths, rows, eps and
# patterns are expanded deterministically by build_case_plan().
FAMILIES = {
    "a3_plain_norm": {
        "symbol": "infinity_plain_layer_norm_bf16_aten",
        "kernel_id": "A3.plain_layer_norm_bf16_aten",
        "kind": "plain_norm",
        "widths": [384, 768, 1024],
        "rows": [1, 5, 33],
        "eps": [1e-5, 1e-6, 1e-3],
        "patterns": ["normal", "offset", "near_constant"],
        "extra_beta_absent": True,
    },
    "c3_deberta_residual_norm": {
        "symbol": "infinity_deberta_plain_norm_bf16_aten",
        "kernel_id": "C3.deberta_plain_norm_bf16_aten",
        "kind": "residual_norm",
        # The 9-arg entry intentionally matches only H384/H1024.
        "widths": [384, 1024],
        "rows": [1, 5, 33],
        "eps": [1e-5, 1e-3],
        "patterns": ["both", "residual_only", "bias_only", "near_constant_both"],
        "extra_beta_absent": False,
    },
    "b2_colbert_l2": {
        "symbol": "infinity_colbert_l2_bf16_f32",
        "kernel_id": "B2.colbert_l2_bf16_f32",
        "kind": "colbert_l2",
        "widths": [64, 96, 128],
        "rows": [1, 5, 33],
        "eps": [1e-12, 1e-6, 1e-3],
        "patterns": ["zero", "tiny", "mixed", "normal"],
        "extra_beta_absent": False,
    },
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json_bytes(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def f32_to_bf16_bits(value: float) -> int:
    """Round a finite Python float to BF16 bits using round-to-nearest-even."""
    if not (value == value) or value in (float("inf"), float("-inf")):
        raise ValueError("fixture generator only admits finite floats")
    bits = struct.unpack("<I", struct.pack("<f", value))[0]
    lsb = (bits >> 16) & 1
    rounded = (bits + 0x7FFF + lsb) >> 16
    return rounded & 0xFFFF


def bf16_bits_to_f32(bits: int) -> float:
    if not 0 <= bits <= 0xFFFF:
        raise ValueError("BF16 word out of range")
    return struct.unpack("<f", struct.pack("<I", bits << 16))[0]


def is_finite_bf16(bits: int) -> bool:
    return ((bits >> 7) & 0xFF) != 0xFF


def _rng(case_id: str, salt: str) -> random.Random:
    seed = int(hashlib.sha256(f"{case_id}|{salt}".encode()).hexdigest()[:16], 16)
    return random.Random(seed)


def _normal_words(rng: random.Random, count: int, offset: float = 0.0) -> list[int]:
    words = []
    for _ in range(count):
        value = rng.uniform(-4.0, 4.0) + offset
        if rng.random() < 0.05:
            value = 0.0
        words.append(f32_to_bf16_bits(value))
    return words


def _near_constant_words(rng: random.Random, count: int, width: int) -> list[int]:
    words = []
    for index in range(count):
        row_slot = index % width
        if row_slot in (0, 1, width - 1):
            value = 1.0
        else:
            value = 1.0 + rng.uniform(-5e-4, 5e-4)
        words.append(f32_to_bf16_bits(value))
    return words


def _tiny_words(rng: random.Random, count: int) -> list[int]:
    tiny = [0x0000, 0x8000, 0x0001, 0x0002, 0x0080, 0x0100, 0x0200, 0x8001, 0x8080]
    return [tiny[rng.randrange(len(tiny))] for _ in range(count)]


def _mixed_words(rng: random.Random, count: int) -> list[int]:
    words = []
    for index in range(count):
        lane = index % 4
        if lane == 0:
            words.append(0x0000)
        elif lane == 1:
            words.append([0x0001, 0x0080, 0x0100][rng.randrange(3)])
        elif lane == 2:
            words.append(f32_to_bf16_bits(rng.uniform(0.25, 2.0)))
        else:
            words.append(f32_to_bf16_bits(rng.uniform(-2.0, -0.25)))
    return words


def _input_words(case: dict, count: int, salt: str = "input") -> list[int]:
    pattern = case["pattern"]
    rng = _rng(case["id"], salt)
    if pattern in ("normal", "both", "residual_only", "bias_only"):
        return _normal_words(rng, count)
    if pattern == "offset":
        return _normal_words(rng, count, offset=64.0)
    if pattern in ("near_constant", "near_constant_both"):
        return _near_constant_words(rng, count, case["width"])
    if pattern == "zero":
        return [0x0000] * count
    if pattern == "tiny":
        return _tiny_words(rng, count)
    if pattern == "mixed":
        return _mixed_words(rng, count)
    raise ValueError(f"unknown pattern {pattern!r}")


def _gamma_words(case: dict) -> list[int]:
    rng = _rng(case["id"], "gamma")
    return [f32_to_bf16_bits(rng.uniform(0.5, 1.5)) for _ in range(case["width"])]


def _beta_words(case: dict) -> list[int]:
    rng = _rng(case["id"], "beta")
    return [f32_to_bf16_bits(rng.uniform(-0.25, 0.25)) for _ in range(case["width"])]


def _residual_words(case: dict, count: int) -> list[int]:
    rng = _rng(case["id"], "residual")
    if case["pattern"] == "near_constant_both":
        return [f32_to_bf16_bits(rng.uniform(-1e-4, 1e-4)) for _ in range(count)]
    return _normal_words(rng, count, offset=0.0)


def _bias_words(case: dict) -> list[int]:
    rng = _rng(case["id"], "bias")
    if case["pattern"] == "near_constant_both":
        return [f32_to_bf16_bits(rng.uniform(-1e-4, 1e-4)) for _ in range(case["width"])]
    return [f32_to_bf16_bits(rng.uniform(-0.5, 0.5)) for _ in range(case["width"])]


def _eps_tag(eps: float) -> str:
    return f"{eps:.0e}".replace("-", "m").replace("+", "p")


def build_case_plan() -> list[dict]:
    cases = []
    for family, spec in FAMILIES.items():
        for width in spec["widths"]:
            for rows in spec["rows"]:
                for eps in spec["eps"]:
                    for pattern in spec["patterns"]:
                        case_id = f"{family}.w{width}.r{rows}.e{_eps_tag(eps)}.{pattern}"
                        cases.append(
                            {
                                "id": case_id,
                                "family": family,
                                "kind": spec["kind"],
                                "symbol": spec["symbol"],
                                "width": width,
                                "rows": rows,
                                "eps": eps,
                                "pattern": pattern,
                                "beta_absent": False,
                            }
                        )
        if spec.get("extra_beta_absent"):
            for width in spec["widths"]:
                for rows in (1, 33):
                    eps = 1e-6
                    pattern = "normal"
                    case_id = f"{family}.w{width}.r{rows}.e{_eps_tag(eps)}.{pattern}.beta_absent"
                    cases.append(
                        {
                            "id": case_id,
                            "family": family,
                            "kind": spec["kind"],
                            "symbol": spec["symbol"],
                            "width": width,
                            "rows": rows,
                            "eps": eps,
                            "pattern": pattern,
                            "beta_absent": True,
                        }
                    )
    cases.sort(key=lambda case: case["id"])
    return cases


def case_plan_sha256() -> str:
    return sha256_bytes(canonical_json_bytes({"schema": PLAN_SCHEMA, "cases": build_case_plan()}))


def make_guarded_bf16(words: list[int], prefix: int = GUARD_PREFIX_WORDS,
                      suffix: int = GUARD_SUFFIX_WORDS) -> tuple[bytes, int, int]:
    full = [BF16_GUARD_WORD] * prefix + list(words) + [BF16_GUARD_WORD] * suffix
    payload = struct.pack(f"<{len(full)}H", *full)
    logical_offset = prefix * 2
    logical_bytes = len(words) * 2
    return payload, logical_offset, logical_bytes


def make_guarded_f32(words: list[int], prefix: int = GUARD_PREFIX_WORDS,
                     suffix: int = GUARD_SUFFIX_WORDS) -> tuple[bytes, int, int]:
    full = [F32_GUARD_WORD] * prefix + list(words) + [F32_GUARD_WORD] * suffix
    payload = struct.pack(f"<{len(full)}I", *full)
    logical_offset = prefix * 4
    logical_bytes = len(words) * 4
    return payload, logical_offset, logical_bytes


def make_init_bf16(count: int) -> list[int]:
    return [BF16_INIT_WORD if index % 2 == 0 else 0xBF80 for index in range(count)]


def make_init_f32(count: int) -> list[int]:
    return [F32_INIT_WORD if index % 2 == 0 else 0xBF800000 for index in range(count)]


def case_input_blobs(case: dict) -> list[dict]:
    """Return every non-gold buffer for a case as guarded bytes.

    A blob dict has: id, role, dtype, shape, bytes, logical_offset,
    logical_bytes, guard_prefix_words, guard_suffix_words, nullable.
    """
    width = case["width"]
    rows = case["rows"]
    count = width * rows
    blobs = []

    def add(role: str, words: list[int], dtype: str, shape: list[int],
            nullable: bool = False):
        if dtype == "bfloat16":
            payload, logical_offset, logical_bytes = make_guarded_bf16(words)
        else:
            payload, logical_offset, logical_bytes = make_guarded_f32(words)
        blobs.append(
            {
                "id": f"{case['id']}/{role}",
                "role": role,
                "case": case["id"],
                "dtype": dtype,
                "shape": shape,
                "bytes": payload,
                "logical_offset": logical_offset,
                "logical_bytes": logical_bytes,
                "guard_prefix_words": GUARD_PREFIX_WORDS,
                "guard_suffix_words": GUARD_SUFFIX_WORDS,
                "nullable": nullable,
                "present": True,
            }
        )

    add("input", _input_words(case, count), "bfloat16", [rows, width])
    add("gamma", _gamma_words(case), "bfloat16", [width])
    if not case["beta_absent"]:
        add("beta", _beta_words(case), "bfloat16", [width], nullable=True)
    if case["kind"] == "residual_norm":
        if case["pattern"] in ("both", "residual_only", "near_constant_both"):
            add("residual", _residual_words(case, count), "bfloat16", [rows, width], nullable=True)
        if case["pattern"] in ("both", "bias_only", "near_constant_both"):
            add("bias", _bias_words(case), "bfloat16", [width], nullable=True)
    return blobs


def output_blob_spec(case: dict) -> dict:
    if case["kind"] == "colbert_l2":
        dtype = "float32"
        shape = [case["rows"], case["width"]]
        init = make_init_f32(case["rows"] * case["width"])
        payload, logical_offset, logical_bytes = make_guarded_f32(init)
    else:
        dtype = "bfloat16"
        shape = [case["rows"], case["width"]]
        init = make_init_bf16(case["rows"] * case["width"])
        payload, logical_offset, logical_bytes = make_guarded_bf16(init)
    return {
        "id": f"{case['id']}/gold_init",
        "role": "gold_init",
        "case": case["id"],
        "dtype": dtype,
        "shape": shape,
        "bytes": payload,
        "logical_offset": logical_offset,
        "logical_bytes": logical_bytes,
        "guard_prefix_words": GUARD_PREFIX_WORDS,
        "guard_suffix_words": GUARD_SUFFIX_WORDS,
        "nullable": False,
        "present": True,
    }


def blob_header(blob: dict, offset: int) -> dict:
    return {
        "id": blob["id"],
        "role": blob["role"],
        "case": blob["case"],
        "dtype": blob["dtype"],
        "shape": list(blob["shape"]),
        "offset": offset,
        "bytes": len(blob["bytes"]),
        "sha256": sha256_bytes(blob["bytes"]),
        "logical_offset": blob["logical_offset"],
        "logical_bytes": blob["logical_bytes"],
        "guard_prefix_words": blob["guard_prefix_words"],
        "guard_suffix_words": blob["guard_suffix_words"],
        "nullable": blob.get("nullable", False),
    }


def write_container(path: Path, header: dict, blob_bytes: list[tuple[dict, bytes]]) -> dict:
    payload = bytearray()
    blob_headers = []
    for blob, raw in blob_bytes:
        blob_headers.append(blob_header({**blob, "bytes": raw}, len(payload)))
        payload.extend(raw)
    header = dict(header)
    header["schema"] = CONTAINER_SCHEMA
    header["blobs"] = blob_headers
    header["payload_bytes"] = len(payload)
    header["payload_sha256"] = sha256_bytes(bytes(payload))
    header_bytes = canonical_json_bytes(header)
    container = CONTAINER_MAGIC + struct.pack("<I", len(header_bytes)) + header_bytes + bytes(payload)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(container)
    return {
        "path": str(path),
        "bytes": len(container),
        "sha256": sha256_bytes(container),
        "header": header,
    }


def read_container(path: Path) -> tuple[dict, bytes]:
    data = path.read_bytes()
    if len(data) < 12 or data[:8] != CONTAINER_MAGIC:
        raise ValueError(f"bad container magic: {path}")
    (header_len,) = struct.unpack("<I", data[8:12])
    if header_len == 0 or 12 + header_len > len(data):
        raise ValueError(f"bad container header length: {path}")
    header = json.loads(data[12:12 + header_len])
    payload = data[12 + header_len:]
    if header.get("schema") != CONTAINER_SCHEMA:
        raise ValueError(f"bad container schema: {header.get('schema')!r}")
    if header.get("payload_bytes") != len(payload):
        raise ValueError("container payload length disagrees with header")
    if header.get("payload_sha256") != sha256_bytes(payload):
        raise ValueError("container payload hash mismatch")
    for blob in header.get("blobs", []):
        offset = blob["offset"]
        size = blob["bytes"]
        if offset < 0 or size < 0 or offset + size > len(payload):
            raise ValueError(f"blob out of bounds: {blob['id']}")
        raw = payload[offset:offset + size]
        if sha256_bytes(raw) != blob["sha256"]:
            raise ValueError(f"blob hash mismatch: {blob['id']}")
        if blob["logical_offset"] + blob["logical_bytes"] > size:
            raise ValueError(f"logical region outside blob: {blob['id']}")
    return header, payload


def validate_case_plan(plan: list[dict], manifest: dict) -> list[str]:
    errors = []
    expected = manifest.get("case_plan", {})
    expected_hash = manifest.get("case_plan_sha256") or expected.get("sha256")
    if expected_hash != case_plan_sha256():
        errors.append("case plan hash does not match manifest")
    if expected.get("count") != len(plan):
        errors.append(f"case count {len(plan)} != manifest {expected.get('count')}")
    families = {}
    widths = {}
    rows = {}
    eps = {}
    patterns = {}
    for case in plan:
        family = case["family"]
        families[family] = families.get(family, 0) + 1
        widths.setdefault(family, set()).add(case["width"])
        rows.setdefault(family, set()).add(case["rows"])
        eps.setdefault(family, set()).add(case["eps"])
        patterns.setdefault(family, set()).add(case["pattern"])
    for family, spec in FAMILIES.items():
        if widths.get(family) != set(spec["widths"]):
            errors.append(f"{family} widths do not match the contract")
        if rows.get(family) != set(spec["rows"]):
            errors.append(f"{family} rows do not match the contract")
        if eps.get(family) != set(spec["eps"]):
            errors.append(f"{family} eps values do not match the contract")
        if not set(spec["patterns"]).issubset(patterns.get(family, set())):
            errors.append(f"{family} patterns do not match the contract")
    return errors


def _self_check() -> None:
    plan = build_case_plan()
    assert len(plan) == len({case["id"] for case in plan})
    assert all(is_finite_bf16(word) for case in plan for word in _input_words(case, 8))
    for case in plan:
        blobs = case_input_blobs(case)
        assert any(blob["role"] == "input" for blob in blobs)
        assert all(blob["logical_offset"] % 4 == 0 for blob in blobs)
    print(json.dumps({"ok": True, "cases": len(plan), "plan_sha256": case_plan_sha256()},
                     sort_keys=True))


if __name__ == "__main__":
    _self_check()
