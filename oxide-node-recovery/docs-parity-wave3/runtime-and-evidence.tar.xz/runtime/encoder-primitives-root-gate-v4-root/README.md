# Encoder primitive Root gate v2

V2 preserves v1 and fixes both Root review findings.

| Wave | Export | Contract | Real host launch |
| --- | --- | --- | --- |
| A3 | `infinity_plain_layer_norm_bf16_aten` | 7 args, BF16 ATen Welford LN | grid `(rows,1,1)`, block `(128,1,1)` |
| C3 | `infinity_deberta_plain_norm_bf16_aten` | 9 args, BF16-rounded bias/residual then LN | grid `(rows,1,1)`, block `(128,1,1)` |
| B2 | `infinity_colbert_l2_bf16_f32` | 5 args, BF16 norm/clamp/divide then F32 widen | grid `(rows,1,1)`, block `(256,1,1)` |

The Rust source uses `threadIdx_x` only (`tid`, `lane=tid%32`, `warp=tid/32`),
so the real host block is **128x1x1**. The old v1 `(32,4,1)` would launch four
duplicate warps in x. V2 rejects `(32,4,1)` in the manifest and CPU test.

## Actual compiled bundle

No compile is performed by this packet. V2 pins the existing actual all3 bundle:

```text
/tmp/oxide-docs-parity-20261102/dense-wave3-device-all3-v1
manifest sha256 5039465628ed3850ef722e0ae74d6de5de600d570ae71e2afbced3dc1969e963
SM90/SM100/SM120, 112 symbols each, all three exports present
```

`frozen/main.rs`, `frozen/plain_layer_norm_aten.rs` and `frozen/colbert.rs` are
the ACTUAL current `/tmp/infinity-plain-cuda` leaves (private `#[device]` helper
prefixes included), not the old A3/B2 snapshots. `scripts/freeze_artifact.py`
copies one existing cubin and verifies the bundle manifest leaves, the three
symbols, the 112-symbol count, and the cubin SHA.

## Modes and sanitizers

`controller-init` and `controller-mem` are **controller phases only**; they are
not compute-sanitizer. Actual sanitizer wrappers run `--mode plain` around the
same frozen artifact and gold:

- `scripts/sanitize-memcheck.sh`
- `scripts/sanitize-initcheck.sh`

Both require `ERROR SUMMARY: 0 errors` and the same artifact SHA as the
controller phases. Canaries, input immutability, ABI parameter info and repeats
remain in the control.

## Gold

Gold is produced only inside the existing comparison container SDK
(`/opt/torch-sdk/bin/python3.12`), never on the host, never by NumPy, never by a
CPU reference. Actual `native_layer_norm` and the Native BF16 L2/clamp/divide
recipe are used. The producer has no Python-path or Torch-git-mismatch escape.

## CPU gates (worker)

`14 tests pass` (packing, guards, 7/9/5 args, block-2D rejection, source pins,
artifact-lock mismatch, freeze-existing-bundle verification, synthetic-fixture
rejection, no-Torch/no-NumPy hygiene). No GPU, Torch, NumPy, NVCC, Docker, or
device compile was used. See `evidence/CPU-EVIDENCE.json`.
