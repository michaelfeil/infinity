# Frozen Root commands (v2)

Root stages this packet into the existing container; the worker ran none of
these commands.

## 0. CPU preflight (worker-run)

```sh
cd /tmp/oxide-docs-parity-20261102/encoder-primitives-root-gate-v2
CUDA_VISIBLE_DEVICES='' python3 root_control.py --check-only --allow-missing-gold
CUDA_VISIBLE_DEVICES='' taskset -c 160-167 python3 -m unittest discover -s cpu_tests -v
```

## 1. Freeze the existing actual compiled bundle (NO BUILD)

```sh
cd /tmp/oxide-docs-parity-20261102/encoder-primitives-root-gate-v2
BUNDLE=/tmp/oxide-docs-parity-20261102/dense-wave3-device-all3-v1 \
ARCH=sm_90 SOURCE_ROOT=/tmp/infinity-plain-cuda \
  scripts/freeze-existing.sh
```

The script verifies the bundle manifest SHA (`50394656...`), the exact actual
`src/main.rs`, `src/plain_layer_norm_aten.rs`, `src/colbert.rs` leaves, the
three symbols, 112 verified symbols per arch, and the cubin SHA. It copies one
cubin and writes `artifacts/artifact-lock.json`.

## 2. Produce actual gold inside the existing container SDK

Run inside the existing comparison container (not on the host):

```sh
cd <staged-packet>
export CUDA_VISIBLE_DEVICES=0
export INFINITY_ENCODER_PRIMITIVES_GOLD=1
export INFINITY_NATIVE_SDK_SHA256=<b66-fingerprint>
/opt/torch-sdk/bin/python3.12 native/primitive_gold_producer.py --out gold
```

There is no interpreter escape and no Torch git-mismatch escape. The producer
requires `/opt/torch-sdk/bin/python3.12`, Torch `2.14.1+cu130`, the pinned
Native git version, a real CUDA device, and the b66 SDK fingerprint.

## 3. Controller phases and actual compute-sanitizer

```sh
cd <staged-packet>
export CUDA_VISIBLE_DEVICES=0
export INFINITY_ENCODER_PRIMITIVES_ROOT=1
export COMPOSED_ROOT=/path/to/composed/repo   # contains libs/infinity-v3

ARTIFACT=$PWD/artifacts/encoder_primitives.sm_90.cubin \
ARCH=sm_90 REPEAT=3 scripts/run-root.sh
```

Or explicitly, with the same `--artifact` everywhere:

```sh
python3 root_control.py --mode controller-init --artifact ... --repeat 3 ...
python3 root_control.py --mode controller-mem  --artifact ... --repeat 3 ...
python3 root_control.py --mode plain           --artifact ... --repeat 3 ...

compute-sanitizer --tool memcheck --error-exitcode 1 --target-processes all \
  python3 root_control.py --mode plain --artifact ... --repeat 1 ...
compute-sanitizer --tool initcheck --error-exitcode 1 --target-processes all \
  python3 root_control.py --mode plain --artifact ... --repeat 1 ...
```

The wrappers are `scripts/sanitize-memcheck.sh` and
`scripts/sanitize-initcheck.sh`; both require `ERROR SUMMARY: 0 errors` and the
same artifact SHA. `controller-init`/`controller-mem` are controller phases,
not sanitizer runs.

## Reports

`reports/controller-init.json`, `controller-mem.json`, `plain.json`,
`plain-memcheck.json`, `plain-initcheck.json`, plus the sanitizer logs. A3/C3
are bit-exact BF16 word gates; B2 reports exact words and the manifest one-BF16-
ulp tolerance.
