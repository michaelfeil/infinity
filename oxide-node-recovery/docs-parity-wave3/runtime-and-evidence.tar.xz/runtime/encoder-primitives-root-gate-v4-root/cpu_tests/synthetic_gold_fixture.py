#!/usr/bin/env python3
"""CPU-only structural fixture. This is NOT numeric gold.

It writes a container with the exact case/blob layout so the CPU tests and
``root_control.py --check-only --allow-synthetic-fixture`` can validate packing,
guards, case coverage, and artifact/source plumbing without Torch or a GPU. The
logical gold words are zeros. Real modes reject this fixture.
"""
from __future__ import annotations

import json
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "native"))

import gold_pack  # noqa: E402


def make(root: Path) -> dict:
    plan = gold_pack.build_case_plan()
    container_blobs = []
    cases = []
    for case in plan:
        for blob in gold_pack.case_input_blobs(case):
            container_blobs.append((blob, blob["bytes"]))
        init_blob = gold_pack.output_blob_spec(case)
        dtype = init_blob["dtype"]
        count = case["rows"] * case["width"]
        if dtype == "bfloat16":
            words = [0] * count
            prefix = [gold_pack.BF16_GUARD_WORD] * gold_pack.GUARD_PREFIX_WORDS
            suffix = [gold_pack.BF16_GUARD_WORD] * gold_pack.GUARD_SUFFIX_WORDS
            gold_bytes = struct.pack(f"<{len(prefix) + count + len(suffix)}H",
                                     *(prefix + words + suffix))
        else:
            words = [0] * count
            prefix = [gold_pack.F32_GUARD_WORD] * gold_pack.GUARD_PREFIX_WORDS
            suffix = [gold_pack.F32_GUARD_WORD] * gold_pack.GUARD_SUFFIX_WORDS
            gold_bytes = struct.pack(f"<{len(prefix) + count + len(suffix)}I",
                                     *(prefix + words + suffix))
        gold_blob = {
            "id": f"{case['id']}/gold",
            "role": "gold",
            "case": case["id"],
            "dtype": dtype,
            "shape": [case["rows"], case["width"]],
            "bytes": gold_bytes,
            "logical_offset": gold_pack.GUARD_PREFIX_WORDS * (2 if dtype == "bfloat16" else 4),
            "logical_bytes": count * (2 if dtype == "bfloat16" else 4),
            "guard_prefix_words": gold_pack.GUARD_PREFIX_WORDS,
            "guard_suffix_words": gold_pack.GUARD_SUFFIX_WORDS,
            "nullable": False,
            "present": True,
        }
        container_blobs.append((gold_blob, gold_blob["bytes"]))
        container_blobs.append((init_blob, init_blob["bytes"]))
        cases.append({
            "id": case["id"],
            "family": case["family"],
            "kind": case["kind"],
            "width": case["width"],
            "rows": case["rows"],
            "eps": case["eps"],
            "pattern": case["pattern"],
            "gold_dtype": dtype,
            "gold_words": count,
            "gold_sha256": gold_pack.sha256_bytes(gold_bytes),
        })
    provenance = {
        "synthetic_structure_only": True,
        "producer": "cpu_tests/synthetic_gold_fixture.py",
        "torch_version": "SYNTHETIC",
        "native_sdk_sha256": "SYNTHETIC",
        "no_numpy": True,
        "note": "zeros, not numeric gold; root_control rejects this in real modes",
    }
    header = {
        "schema": gold_pack.CONTAINER_SCHEMA,
        "case_plan_sha256": gold_pack.case_plan_sha256(),
        "case_count": len(plan),
        "provenance": provenance,
        "cases": cases,
    }
    out = root / "gold" / "primitive_gold.bin"
    written = gold_pack.write_container(out, header, container_blobs)
    (root / "gold" / "primitive_gold.manifest.json").write_text(
        json.dumps({"schema": "oxide-encoder-primitives-gold-manifest/v1",
                    "container": written, "provenance": provenance},
                   indent=2, sort_keys=True) + "\n")
    return written


if __name__ == "__main__":
    print(json.dumps(make(ROOT), sort_keys=True))
