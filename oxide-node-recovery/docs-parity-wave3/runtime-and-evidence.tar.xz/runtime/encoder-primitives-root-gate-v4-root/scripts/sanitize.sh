#!/usr/bin/env bash
# Actual compute-sanitizer wrapper around --mode plain, same artifact and gold.
set -euo pipefail
TOOL="${1:?usage: sanitize.sh memcheck|initcheck}"
PACKET_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${CUDA_VISIBLE_DEVICES:?set CUDA_VISIBLE_DEVICES for the Root GPU}"
: "${INFINITY_ENCODER_PRIMITIVES_ROOT:?set INFINITY_ENCODER_PRIMITIVES_ROOT=1}"
: "${COMPOSED_ROOT:?set COMPOSED_ROOT to the composed repo root}"
SANITIZER="${COMPUTE_SANITIZER:-compute-sanitizer}"
if [[ ! -f "$PACKET_DIR/artifacts/artifact-lock.json" ]]; then
  echo "sanitize: missing artifact lock" >&2; exit 2
fi
if [[ -z "${ARTIFACT:-}" && -f "$PACKET_DIR/artifacts/ARTIFACT.path" ]]; then
  ARTIFACT="$PACKET_DIR/$(cat "$PACKET_DIR/artifacts/ARTIFACT.path")"
fi
: "${ARTIFACT:?set ARTIFACT or create artifacts/ARTIFACT.path}"
REPORT="$PACKET_DIR/reports/plain-$TOOL.json"
LOG="$PACKET_DIR/reports/compute-sanitizer-$TOOL.log"
mkdir -p "$PACKET_DIR/reports"
export INFINITY_ENCODER_PRIMITIVES_SANITIZER=1
"$SANITIZER" --tool "$TOOL" --error-exitcode 1 --target-processes all \
  python3 "$PACKET_DIR/root_control.py" --mode plain \
    --artifact "$ARTIFACT" --repeat 1 \
    --composed-root "$COMPOSED_ROOT" --native-source-root "$COMPOSED_ROOT" \
    --report "$REPORT" 2>&1 | tee "$LOG"
grep -q "ERROR SUMMARY: 0 errors" "$LOG"
echo "sanitize: $TOOL 0 errors (report $REPORT)"
