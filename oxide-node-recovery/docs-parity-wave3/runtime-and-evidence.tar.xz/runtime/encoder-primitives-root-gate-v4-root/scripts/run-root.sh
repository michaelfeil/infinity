#!/usr/bin/env bash
# Frozen Root sequence: freeze the existing actual all3 bundle, run controller
# phases, then actual compute-sanitizer memcheck/initcheck around --mode plain.
set -euo pipefail

PACKET_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${COMPOSED_ROOT:?set COMPOSED_ROOT to the composed repo root (contains libs/infinity-v3)}"
: "${CUDA_VISIBLE_DEVICES:?set CUDA_VISIBLE_DEVICES to the Root GPU}"
: "${INFINITY_ENCODER_PRIMITIVES_ROOT:?set INFINITY_ENCODER_PRIMITIVES_ROOT=1}"

PYTHON="${PYTHON:-/opt/torch-sdk/bin/python3.12}"
REPEAT="${REPEAT:-3}"
ARCH="${ARCH:-sm_90}"
if [[ -z "${ARTIFACT:-}" && -f "$PACKET_DIR/artifacts/ARTIFACT.path" ]]; then
  ARTIFACT="$PACKET_DIR/$(cat "$PACKET_DIR/artifacts/ARTIFACT.path")"
fi
ARTIFACT="${ARTIFACT:-$PACKET_DIR/artifacts/encoder_primitives.$ARCH.cubin}"
GOLD_DIR="$PACKET_DIR/gold"
REPORTS="$PACKET_DIR/reports"
mkdir -p "$REPORTS" "$GOLD_DIR"

if [[ ! -f "$PACKET_DIR/artifacts/artifact-lock.json" ]]; then
  echo "run-root: missing artifact lock; run scripts/freeze_artifact.py --bundle ... first" >&2
  exit 2
fi
if [[ ! -f "$ARTIFACT" ]]; then
  echo "run-root: missing artifact $ARTIFACT" >&2
  exit 2
fi

echo "run-root: structural check without gold"
python3 "$PACKET_DIR/root_control.py" --check-only --allow-missing-gold \
  --composed-root "$COMPOSED_ROOT" --native-source-root "$COMPOSED_ROOT"

if [[ ! -f "$GOLD_DIR/primitive_gold.bin" || "${REGENERATE_GOLD:-0}" == "1" ]]; then
  : "${INFINITY_NATIVE_SDK_SHA256:?set the frozen b66 SDK fingerprint}"
  : "${INFINITY_ENCODER_PRIMITIVES_GOLD:?set INFINITY_ENCODER_PRIMITIVES_GOLD=1}"
  echo "run-root: producing actual Torch-CUDA gold inside the container SDK"
  "$PYTHON" "$PACKET_DIR/native/primitive_gold_producer.py" --out "$GOLD_DIR"
fi

echo "run-root: full structural + gold provenance check"
python3 "$PACKET_DIR/root_control.py" --check-only \
  --composed-root "$COMPOSED_ROOT" --native-source-root "$COMPOSED_ROOT"

: > "$REPORTS/artifact-use.txt"
for mode in controller-init controller-mem plain; do
  echo "run-root: controller phase mode=$mode"
  python3 "$PACKET_DIR/root_control.py" \
    --mode "$mode" --artifact "$ARTIFACT" --repeat "$REPEAT" \
    --composed-root "$COMPOSED_ROOT" --native-source-root "$COMPOSED_ROOT" \
    --report "$REPORTS/$mode.json"
  python3 - "$REPORTS/$mode.json" "$mode" >> "$REPORTS/artifact-use.txt" <<'PY'
import json, sys
print(sys.argv[2], json.load(open(sys.argv[1]))["artifact"]["sha256"], sep="\t")
PY
done

echo "run-root: actual compute-sanitizer memcheck (same artifact/gold)"
"$PACKET_DIR/scripts/sanitize-memcheck.sh"
python3 - "$REPORTS/plain-memcheck.json" memcheck >> "$REPORTS/artifact-use.txt" <<'PY'
import json, sys
print(sys.argv[2], json.load(open(sys.argv[1]))["artifact"]["sha256"], sep="\t")
PY

echo "run-root: actual compute-sanitizer initcheck (same artifact/gold)"
"$PACKET_DIR/scripts/sanitize-initcheck.sh"
python3 - "$REPORTS/plain-initcheck.json" initcheck >> "$REPORTS/artifact-use.txt" <<'PY'
import json, sys
print(sys.argv[2], json.load(open(sys.argv[1]))["artifact"]["sha256"], sep="\t")
PY

python3 - "$REPORTS/artifact-use.txt" <<'PY'
import sys
rows = [line.split() for line in open(sys.argv[1]) if line.strip()]
if len(rows) != 5:
    raise SystemExit("run-root: expected controller-init/controller-mem/plain/memcheck/initcheck records")
hashes = {row[1] for row in rows}
if len(hashes) != 1:
    raise SystemExit("run-root: phases/sanitizers used different artifacts")
print("run-root: same artifact used by all phases/sanitizers:", hashes.pop())
PY

echo "run-root: PASS (reports in $REPORTS)"
