#!/usr/bin/env bash
# Freeze the existing actual compiled all3 bundle. No build.
set -euo pipefail
PACKET_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUNDLE="${BUNDLE:-/tmp/oxide-docs-parity-20261102/dense-wave3-device-all3-v1}"
ARCH="${ARCH:-sm_90}"
SOURCE_ROOT="${SOURCE_ROOT:-/tmp/infinity-plain-cuda}"
python3 "$PACKET_DIR/scripts/freeze_artifact.py" \
  --bundle "$BUNDLE" --arch "$ARCH" --source-root "$SOURCE_ROOT"
echo "freeze-existing: copied actual $ARCH cubin and wrote artifacts/artifact-lock.json"
