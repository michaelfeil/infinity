#!/usr/bin/env python3
"""Freeze the EXISTING actual compiled all3 bundle into this packet.

No compile, no GPU, no Torch. Root copied the already-successful bundle from
/tmp/oxide-docs-parity-20261102/dense-wave3-device-all3-v1 (SM90/100/120,
112 symbols). This script verifies the actual bundle manifest source leaves and
the three symbol leaves, then copies one cubin and binds the artifact lock.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "native"))

import gold_pack  # noqa: E402
import root_control  # noqa: E402

LEAF_MAP = {
    "frozen/main.rs": "src/main.rs",
    "frozen/plain_layer_norm_aten.rs": "src/plain_layer_norm_aten.rs",
    "frozen/colbert.rs": "src/colbert.rs",
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_bundle(manifest: dict, bundle: Path, source_root: Path | None) -> dict:
    bundle_manifest_path = bundle / "manifest.json"
    if not bundle_manifest_path.is_file():
        raise SystemExit(f"freeze_artifact: missing bundle manifest {bundle_manifest_path}")
    bundle_manifest = json.loads(bundle_manifest_path.read_text())
    bundle_sha = sha256_file(bundle_manifest_path)
    expected_bundle_sha = manifest["artifact"]["source_bundle_manifest_sha256"]
    if bundle_sha != expected_bundle_sha:
        raise SystemExit(f"freeze_artifact: bundle manifest {bundle_sha} != pinned {expected_bundle_sha}")
    sources = bundle_manifest.get("sources", {})
    pins = {pin["path"]: pin["sha256"] for pin in manifest["source_pins"]}
    checked = []
    for frozen, leaf in LEAF_MAP.items():
        actual = sources.get(leaf)
        if actual != pins[frozen]:
            raise SystemExit(f"freeze_artifact: bundle leaf {leaf} {actual} != packet pin {pins[frozen]}")
        if source_root is not None:
            live = source_root / "libs/infinity-v3/backends/oxide/device" / leaf
            if not live.is_file():
                raise SystemExit(f"freeze_artifact: missing live source {live}")
            live_sha = sha256_file(live)
            if live_sha != pins[frozen]:
                raise SystemExit(f"freeze_artifact: live source {leaf} {live_sha} != packet pin")
        checked.append({"leaf": leaf, "sha256": actual})
    symbols = set(manifest["artifact"]["expected_symbols"])
    arch_entries = []
    for arch in manifest["artifact"]["allowed_architectures"]:
        entries = [a for a in bundle_manifest.get("architectures", [])
                   if a.get("architecture") == arch]
        if len(entries) != 1:
            raise SystemExit(f"freeze_artifact: bundle has no unique {arch} entry")
        entry = entries[0]
        verified = set(entry.get("symbols_verified", []))
        missing = symbols - verified
        if missing:
            raise SystemExit(f"freeze_artifact: {arch} missing verified symbols {sorted(missing)}")
        if len(verified) != manifest["artifact"]["bundle_symbols_verified_per_arch"]:
            raise SystemExit(f"freeze_artifact: {arch} symbol count {len(verified)} is not the pinned 112")
        arch_entries.append({"arch": arch, "cubin": entry["cubin"],
                             "cubin_sha256": entry["cubin_sha256"],
                             "symbols_verified": len(verified)})
    return {"manifest_sha256": bundle_sha, "leaves": checked, "architectures": arch_entries}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--bundle", default=None)
    parser.add_argument("--arch", required=True, choices=["sm_90", "sm_100", "sm_120"])
    parser.add_argument("--source-root", default="/tmp/infinity-plain-cuda")
    parser.add_argument("--artifact-out", default=None)
    parser.add_argument("--lock-out", default=None)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    manifest, manifest_sha = root_control.load_manifest(root)
    bundle = Path(args.bundle or manifest["artifact"]["source_bundle"]).resolve()
    checked = verify_bundle(manifest, bundle, Path(args.source_root) if args.source_root else None)
    entry = next(item for item in checked["architectures"] if item["arch"] == args.arch)
    source = bundle / entry["cubin"]
    if not source.is_file():
        raise SystemExit(f"freeze_artifact: missing cubin {source}")
    actual_sha = sha256_file(source)
    if actual_sha != entry["cubin_sha256"]:
        raise SystemExit(f"freeze_artifact: cubin {actual_sha} != bundle manifest {entry['cubin_sha256']}")
    artifact_out = Path(args.artifact_out or (root / "artifacts" /
                                             f"encoder_primitives.{args.arch}.cubin"))
    artifact_out.parent.mkdir(parents=True, exist_ok=True)
    if source.resolve() != artifact_out.resolve():
        shutil.copy2(source, artifact_out)
    lock_path = Path(args.lock_out or (root / "artifacts" / "artifact-lock.json"))
    lock = {
        "schema": gold_pack.ARTIFACT_LOCK_SCHEMA,
        "artifact": str(artifact_out.relative_to(root)),
        "arch": args.arch,
        "sha256": gold_pack.sha256_file(artifact_out),
        "bytes": artifact_out.stat().st_size,
        "frozen_manifest_sha256": manifest_sha,
        "source_pins_sha256": gold_pack.sha256_bytes(
            gold_pack.canonical_json_bytes(manifest["source_pins"])),
        "source_pins": manifest["source_pins"],
        "bundle": str(bundle),
        "bundle_manifest_sha256": checked["manifest_sha256"],
        "bundle_manifest_sha256_expected": manifest["artifact"]["source_bundle_manifest_sha256"],
        "bundle_architectures": checked["architectures"],
        "symbols": manifest["artifact"]["expected_symbols"],
        "freeze_mode": "copy-existing-compiled-bundle-no-build",
        "created_by": "scripts/freeze_artifact.py",
        "compiled": True,
        "compiled_by_root_elsewhere": True,
    }
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock_path.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n")
    (root / "artifacts" / "ARTIFACT.sha256").write_text(lock["sha256"] + "\n")
    (root / "artifacts" / "ARTIFACT.path").write_text(
        str(artifact_out.relative_to(root)) + "\n")
    print(json.dumps({"ok": True, "bundle": str(bundle), "arch": args.arch,
                      "artifact": str(artifact_out), "sha256": lock["sha256"],
                      "bytes": lock["bytes"], "bundle_manifest_sha256": checked["manifest_sha256"],
                      "symbols": lock["symbols"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
