// SPDX-License-Identifier: MIT
// Torch-free Qwen3.5 GDN Native-reference CUDA source.
//
// Reference conv/prepare/norm are the original Candle bodies retained in
// libs/infinity-v3/backends/libtorch/cpp/vendor/candle_kernels/kernels/
// qwen35_gdn.cu and compiled here with --fmad=false, matching the Native
// qwen35_reference.cu translation unit. The recurrence is the optimized
// qwen35_recurrent.cu recurrent<COLUMNS=2, FMA=false> body, whose explicit
// __fadd_rn/__fmul_rn operations preserve the Native separate-rounding tree.
// Only the exported symbol spelling changed.
/*
MIT License

Copyright (c) Candle contributors

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
*/
#include <cuda_bf16.h>
#include <cuda_runtime.h>
#include <stdint.h>

__device__ float reference_gdn_sum(float x) {
  for (int d = 16; d; d >>= 1)
    x += __shfl_down_sync(0xffffffff, x, d);
  return __shfl_sync(0xffffffff, x, 0);
}

// Original Candle qwen35_conv_bf16 body. Compile this translation unit with
// --fmad=false so the plain multiply/add remain the reference roundings.
extern "C" __global__ void infinity_qwen35_reference_conv_bf16(
    const __nv_bfloat16* x,
    const __nv_bfloat16* weight,
    const uint32_t* cu,
    __nv_bfloat16* out,
    int tokens,
    int channels,
    int kernel,
    int sequences) {
  const uint64_t idx = uint64_t(blockIdx.x) * blockDim.x + threadIdx.x;
  if (idx >= uint64_t(tokens) * channels)
    return;
  int t = idx / channels, c = idx % channels, lo = 0, hi = sequences;
  while (lo + 1 < hi) {
    int m = (lo + hi) / 2;
    if (cu[m] <= t)
      lo = m;
    else
      hi = m;
  }
  float sum = 0;
  for (int j = 0; j < kernel; ++j) {
    int src = t + j - kernel + 1;
    if (src >= int(cu[lo]))
      sum += __bfloat162float(x[uint64_t(src) * channels + c]) *
             __bfloat162float(weight[c * kernel + j]);
  }
  // Preserve the Transformers conv -> BF16 -> SiLU rounding contract.
  sum = __bfloat162float(__float2bfloat16_rn(sum));
  out[idx] = __float2bfloat16_rn(sum / (1.f + expf(-sum)));
}

// Original Candle qwen35_gdn_prepare body.
extern "C" __global__ void infinity_qwen35_reference_gdn_prepare(
    const __nv_bfloat16* qkv,
    const __nv_bfloat16* ab,
    const float* alog,
    const float* dt,
    float* qk,
    float* decay_beta,
    int tokens,
    int kh,
    int vh) {
  const int row = blockIdx.x, head = row % kh, t = row / kh, j = threadIdx.x;
  const int channels = (2 * kh + vh) * 128;
  float q = __bfloat162float(qkv[uint64_t(t) * channels + head * 128 + j]);
  float k = __bfloat162float(qkv[uint64_t(t) * channels + kh * 128 + head * 128 + j]);
  __shared__ float qs[4], ks[4];
  float qsum = reference_gdn_sum(q * q), ksum = reference_gdn_sum(k * k);
  if (j % 32 == 0) {
    qs[j / 32] = qsum;
    ks[j / 32] = ksum;
  }
  __syncthreads();
  qsum = qs[0] + qs[1] + qs[2] + qs[3];
  ksum = ks[0] + ks[1] + ks[2] + ks[3];
  qk[uint64_t(row) * 256 + j] = q * rsqrtf(qsum + 1e-6f) * rsqrtf(128.f);
  qk[uint64_t(row) * 256 + 128 + j] = k * rsqrtf(ksum + 1e-6f);
  if (head == 0 && j < vh) {
    float a = __bfloat162float(ab[uint64_t(t) * 2 * vh + j]) + dt[j];
    float softplus = a > 20.f ? a : log1pf(expf(a));
    float b = __bfloat162float(ab[uint64_t(t) * 2 * vh + vh + j]);
    decay_beta[uint64_t(t) * 2 * vh + j] = expf(-expf(alog[j]) * softplus);
    decay_beta[uint64_t(t) * 2 * vh + vh + j] =
        __bfloat162float(__float2bfloat16_rn(1.f / (1.f + expf(-b))));
  }
}

// Extracted from qwen35_recurrent.cu recurrent<2,false>. The explicit RN ops
// below are the Native precise tree; 8/2 warps of 32 lanes = 128 threads and
// the host launches dim3(batch, value_heads, 16).
__device__ float reference_accumulate_false(float sum, float a, float b) {
  return __fadd_rn(sum, __fmul_rn(a, b));
}

__device__ float reference_sum_warp(float x) {
  for (int d = 16; d; d >>= 1)
    x = __fadd_rn(x, __shfl_down_sync(0xffffffff, x, d));
  return __shfl_sync(0xffffffff, x, 0);
}

extern "C" __global__ void infinity_qwen35_reference_gdn_recurrent(
    const __nv_bfloat16* values,
    const float* qk,
    const float* gates,
    const int32_t* cu,
    __nv_bfloat16* output,
    int kh,
    int vh) {
  constexpr int COLUMNS = 2, WARPS = 4;
  const int sequence = blockIdx.x, head = blockIdx.y, lane = threadIdx.x % 32,
            warp = threadIdx.x / 32;
  const int column = blockIdx.z * (COLUMNS * WARPS) + warp * COLUMNS;
  const int qhead = head / (vh / kh), channels = (2 * kh + vh) * 128;
  float state[COLUMNS][4] = {};
  for (int t = cu[sequence]; t < cu[sequence + 1]; ++t) {
    float decay = gates[int64_t(t) * 2 * vh + head];
    float beta = gates[int64_t(t) * 2 * vh + vh + head];
    float q[4], k[4], memory[COLUMNS] = {};
#pragma unroll
    for (int i = 0; i < 4; ++i) {
      q[i] = qk[(int64_t(t) * kh + qhead) * 256 + lane + i * 32];
      k[i] = qk[(int64_t(t) * kh + qhead) * 256 + 128 + lane + i * 32];
#pragma unroll
      for (int col = 0; col < COLUMNS; ++col) {
        state[col][i] = __fmul_rn(state[col][i], decay);
        memory[col] = reference_accumulate_false(memory[col], state[col][i], k[i]);
      }
    }
#pragma unroll
    for (int col = 0; col < COLUMNS; ++col)
      memory[col] = reference_sum_warp(memory[col]);
    float delta[COLUMNS], sum[COLUMNS] = {};
#pragma unroll
    for (int col = 0; col < COLUMNS; ++col) {
      float v = __bfloat162float(
          values[int64_t(t) * channels + 2 * kh * 128 + head * 128 + column + col]);
      delta[col] = __fmul_rn(__fsub_rn(v, memory[col]), beta);
    }
#pragma unroll
    for (int i = 0; i < 4; ++i) {
#pragma unroll
      for (int col = 0; col < COLUMNS; ++col) {
        state[col][i] = reference_accumulate_false(state[col][i], k[i], delta[col]);
        sum[col] = reference_accumulate_false(sum[col], state[col][i], q[i]);
      }
    }
#pragma unroll
    for (int col = 0; col < COLUMNS; ++col)
      sum[col] = reference_sum_warp(sum[col]);
    if (lane == 0) {
#pragma unroll
      for (int col = 0; col < COLUMNS; ++col)
        output[(int64_t(t) * vh + head) * 128 + column + col] =
            __float2bfloat16_rn(sum[col]);
    }
  }
}

// Original Candle qwen35_gdn_norm body.
extern "C" __global__ void infinity_qwen35_reference_gdn_norm(
    const __nv_bfloat16* x,
    const __nv_bfloat16* z,
    const __nv_bfloat16* weight,
    __nv_bfloat16* out,
    float eps) {
  const uint64_t row = blockIdx.x;
  const int j = threadIdx.x;
  float v = __bfloat162float(x[row * 128 + j]);
  float sum = reference_gdn_sum(v * v);
  __shared__ float sums[4];
  if (j % 32 == 0)
    sums[j / 32] = sum;
  __syncthreads();
  sum = (sums[0] + sums[1] + sums[2] + sums[3]) / 128.f;
  float normalized = __bfloat162float(__float2bfloat16_rn(v * rsqrtf(sum + eps)));
  normalized = __bfloat162float(__float2bfloat16_rn(normalized * __bfloat162float(weight[j])));
  float gate = __bfloat162float(z[row * 128 + j]);
  out[row * 128 + j] = __float2bfloat16_rn(normalized * (gate / (1.f + expf(-gate))));
}
