#!/usr/bin/env python3
"""Root one-batch driver: canonical38 append for SM90, SM100 and SM120.

Compiles exactly 14 new objects per architecture (42 total) and never rebuilds
the 70 old objects. The author runs this with --check-only only.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import subprocess
import sys

DEFAULT_SOURCE = pathlib.Path(
    "/tmp/oxide-docs-parity-20261102/fa4-all-model-v3/"
    "libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4")
DEFAULT_BASELINES = {
    "90": pathlib.Path("/tmp/oxide-fa4-canonical31-sm90-provider-v1"),
    "100": pathlib.Path("/tmp/oxide-fa4-canonical31-sm100-provider-v1"),
    "120": pathlib.Path("/tmp/oxide-fa4-canonical31-sm120-provider-v1"),
}
RUNTIME = pathlib.Path(
    "/tmp/oxide-fa4-build-env/lib/python3.12/site-packages/"
    "nvidia_cutlass_dsl/cu13/lib")
FFI = pathlib.Path(
    "/tmp/oxide-fa4-build-env/lib/python3.12/site-packages/tvm_ffi")
DEFAULT_SOURCE_FREEZE = pathlib.Path(
    "/tmp/oxide-docs-parity-20261102/fa4-all-model-v3/SOURCE-FREEZE.json")
DEFAULT_RECEIPT = pathlib.Path(
    "/tmp/oxide-docs-parity-20261102/FA431-OLD210-HANDOFF.json")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=pathlib.Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output-root", type=pathlib.Path, required=True)
    parser.add_argument("--runtime-dir", type=pathlib.Path, default=RUNTIME)
    parser.add_argument("--ffi-root", type=pathlib.Path, default=FFI)
    parser.add_argument("--python", type=pathlib.Path, default=pathlib.Path(sys.executable))
    parser.add_argument("--source-freeze", type=pathlib.Path, default=DEFAULT_SOURCE_FREEZE)
    parser.add_argument("--receipt", type=pathlib.Path, default=DEFAULT_RECEIPT)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    source = args.source.resolve()
    output_root = args.output_root.resolve()
    records = []
    for sm, baseline in DEFAULT_BASELINES.items():
        output = output_root / f"sm_{sm}"
        command = [
            str(args.python), str(pathlib.Path(__file__).with_name("append_canonical38.py")),
            "--source", str(source), "--baseline", str(baseline),
            "--output", str(output), "--runtime-dir", str(args.runtime_dir),
            "--ffi-root", str(args.ffi_root), "--python", str(args.python),
            "--source-freeze", str(args.source_freeze), "--receipt", str(args.receipt),
        ]
        if args.check_only:
            command.append("--check-only")
        completed = subprocess.run(command, text=True, capture_output=True)
        record = {
            "architecture": f"sm_{sm}a" if sm in ("90", "100") else f"sm_{sm}",
            "baseline": str(baseline),
            "output": str(output),
            "returncode": completed.returncode,
            "check_only": args.check_only,
            "command": command,
            "stdout_tail": completed.stdout[-4000:],
            "stderr_tail": completed.stderr[-4000:],
        }
        if completed.returncode:
            records.append(record)
            print(json.dumps(records, indent=2))
            raise SystemExit(completed.returncode)
        if args.check_only:
            record["report"] = json.loads(completed.stdout)
        records.append(record)
    summary = {
        "schema": "oxide-fa4-canonical38-batch/v1",
        "source": str(source),
        "architectures": len(records),
        "new_objects_per_architecture": 14,
        "new_objects_total": 14 * len(records),
        "old_objects_preserved_total": 70 * len(records),
        "check_only": args.check_only,
        "records": records,
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
