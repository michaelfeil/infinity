#!/usr/bin/env python3
"""CPU-only tests for the canonical38 Root append helper.

No GPU, NVCC, torch, cutlass or provider compile is imported or run.
"""
import json
import os
import pathlib
import tempfile
import unittest

import append_canonical38 as append

SOURCE = pathlib.Path(os.environ.get(
    "FA4_CANONICAL38_SOURCE",
    "/tmp/oxide-docs-parity-20261102/fa4-all-model-v3/"
    "libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4",
))


def contract():
    return append._contract(SOURCE)


def synthetic_baseline(root: pathlib.Path) -> pathlib.Path:
    c = contract()
    rows = c.canonical_rows_for(31)
    names = [row[0] for row in rows]
    kernels = []
    expected = c.expected_kernel_symbols(names)
    by_name = {}
    for mode, (name, heads, kv_heads, d, causal, local) in enumerate(rows):
        window = c.canonical_window(mode, name, causal, local)
        for dtype in c.DTYPES:
            by_name[f"fa4_{name}_{dtype}"] = c.profile_kernel(
                mode, name, heads, kv_heads, d, causal, window, dtype)
    for symbol in expected:
        kernels.append(dict(by_name.get(symbol) or c.HELPER_CONTRACTS[symbol]))
    link = [f"{symbol}.o" for symbol in c.expected_link_symbols(names)]
    root.mkdir(parents=True)
    objects = {}
    for name in link:
        (root / name).write_text(name + "\n")
        objects[name] = append.digest(root / name)
    manifest = {
        "abi_version": 7,
        "native_abi_version": 1,
        "architecture": "sm_90a",
        "target_sm_count": 132,
        "registry": dict(c.canonical_registry_for(31)),
        "kernels": kernels,
        "objects": objects,
        "link_object_order": link,
        "canonical31_inventory": {"exact_order": True, "symbols": expected},
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return root


def new_kernels_and_objects(output: pathlib.Path):
    c = contract()
    rows = c.canonical_rows_for(38)
    kernels = []
    output.mkdir(parents=True, exist_ok=True)
    for mode in range(31, 38):
        name, heads, kv_heads, d, causal, local = rows[mode]
        window = c.canonical_window(mode, name, causal, local)
        for dtype in c.DTYPES:
            symbol = f"fa4_{name}_{dtype}"
            (output / f"{symbol}.o").write_text(symbol + "\n")
            kernels.append(c.profile_kernel(
                mode, name, heads, kv_heads, d, causal, window, dtype))
    proof = {"compile_only_engine_control": {"calls": [
        {"engine_is_none": True, "real_IR_present": True} for _ in kernels
    ]}}
    return kernels, proof


class Canonical38Tests(unittest.TestCase):
    def test_source_is_exact_canonical38_and_old_prefix_is_frozen(self):
        report = append.validate_source(SOURCE)
        self.assertEqual(report["profiles"], 38)
        self.assertEqual(report["old_prefix_profiles"], 31)
        self.assertEqual(report["fingerprint"], append.EXPECTED_SOURCE_FINGERPRINT)
        self.assertEqual(report["old_fingerprint"], append.EXPECTED_OLD_FINGERPRINT)
        self.assertEqual(report["canonical38_registry"]["mode_mask"], "0x3fffffffff")
        self.assertEqual(report["expected_symbols"], 84)
        bridge = (SOURCE / "bridge.cpp").read_text()
        self.assertIn("infinity_fa4_modes_v1()", bridge)
        self.assertIn("uint64_t infinity_fa4_modes_v2()", bridge)
        self.assertIn("attention_modes >= 32 ? -1", bridge)

    def test_baseline_and_merged_manifest_are_canonical38(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            baseline = synthetic_baseline(root / "baseline")
            manifest = append.validate_baseline(baseline, SOURCE)
            self.assertEqual(manifest["registry"], append.EXPECTED_OLD_REGISTRY)
            output = root / "output"
            for name in manifest["objects"]:
                output.mkdir(parents=True, exist_ok=True)
                (output / name).write_text(name + "\n")
            kernels, proof = new_kernels_and_objects(output)
            merged = append.merge_manifest(SOURCE, baseline, output, kernels, proof)
            c = contract()
            rows = c.validate_profiles_inc(SOURCE / "profiles.inc")
            c.validate_manifest_inventory(merged, rows)
            self.assertEqual(merged["registry"], c.canonical_registry_for(38))
            self.assertEqual(len(merged["kernels"]), 84)
            self.assertEqual(len(merged["objects"]), 84)
            self.assertEqual(merged["metadata_derivation"]["base"], "canonical31")
            self.assertEqual(merged["canonical38_additive"]["new_object_count"], 14)
            self.assertEqual(len(merged["canonical38_additive"]["old_70_objects_preserved"]), 70)

    def test_rejects_wrong_dtype_window_source_abi_duplicate_and_missing(self):
        mutations = {
            "wrong_dtype": lambda m: m["kernels"].pop(1),
            "wrong_window": lambda m: m["kernels"][0].__setitem__("window", [1, 0]),
            "source_abi": lambda m: m.__setitem__("abi_version", 6),
            "duplicate_object": lambda m: m["link_object_order"].append(
                m["link_object_order"][0]),
            "missing_object": lambda m: m["objects"].pop(
                next(iter(m["objects"]))),
        }
        with tempfile.TemporaryDirectory() as temporary:
            for label, mutate in mutations.items():
                with self.subTest(label=label):
                    root = pathlib.Path(temporary) / label
                    baseline = synthetic_baseline(root / "baseline")
                    manifest = append.load(baseline / "manifest.json")
                    mutate(manifest)
                    (baseline / "manifest.json").write_text(json.dumps(manifest))
                    if label == "missing_object":
                        name = next(iter(append.load(
                            synthetic_baseline(root / "clean") / "manifest.json")["objects"]))
                        (baseline / name).unlink(missing_ok=True)
                    with self.assertRaises(SystemExit):
                        append.validate_baseline(baseline, SOURCE)

    def test_new_windows_and_compile_only_flags(self):
        c = contract()
        rows = c.canonical_rows_for(38)
        for mode in range(31, 38):
            name, _, _, _, causal, local = rows[mode]
            window = c.canonical_window(mode, name, causal, local)
            if mode in (35, 36, 37):
                self.assertEqual(window, (1023, 0))
            else:
                self.assertEqual(window, (None, None))
        command = append._link_command(
            SOURCE, pathlib.Path("/tmp/out"), {"architecture": "sm_90a"},
            pathlib.Path("/runtime"), pathlib.Path("/ffi"), pathlib.Path("/python"))
        for forbidden in ("--compile-only", "--export-only", "--only-symbol",
                          "--deberta", "--alibi", "--jinacode"):
            self.assertNotIn(forbidden, command)
        self.assertIn("--link-only", command)

    def test_atomic_manifest_publication(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / "manifest.json"
            path.write_text("old\n")
            append.atomic_write(path, "new\n")
            self.assertEqual(path.read_text(), "new\n")
            self.assertFalse(path.with_name("manifest.json.tmp").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
