# Canonical38 FA4 Root append packet

Read-only input: `/tmp/oxide-docs-parity-20261102/fa4-all-model-v3` (frozen
shared source). This packet does not duplicate or modify the source worker.

It appends canonical31 -> canonical38 per architecture:

- preserves the 70 old objects byte-for-byte (verified against
  `FA431-OLD210-HANDOFF.json`),
- compiles only 14 new dtype objects for modes 31..37 with fake tensors,
  compile-only AOT export, no JIT engine,
- merges the canonical38 registry/fingerprint and
  `infinity_fa4_modes_v2() -> u64`,
- relinks the bridge once with the existing runtime/FFI paths,
- publishes each manifest atomically and refuses nonempty outputs.

## CPU-only check

```sh
python3 test_contract.py
python3 append_all_canonical38.py --output-root /tmp/oxide-canonical38-check --check-only
```

Both are already recorded in `dry-run/`. No GPU/NVCC/provider/AOT compile ran.

## Root one batch (after authorization)

```sh
/tmp/oxide-fa4-build-env/bin/python append_all_canonical38.py \
  --source /tmp/oxide-docs-parity-20261102/fa4-all-model-v3/libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4 \
  --output-root OUTPUT_ROOT --runtime-dir /tmp/oxide-fa4-build-env/lib/python3.12/site-packages/nvidia_cutlass_dsl/cu13/lib \
  --ffi-root /tmp/oxide-fa4-build-env/lib/python3.12/site-packages/tvm_ffi \
  --source-freeze /tmp/oxide-docs-parity-20261102/fa4-all-model-v3/SOURCE-FREEZE.json \
  --receipt /tmp/oxide-docs-parity-20261102/FA431-OLD210-HANDOFF.json
```

This is 3 x 14 = 42 new objects, never a 212-object full rebuild. Do not add
compile/export flags to the link command; the helper emits only `--link-only`.
