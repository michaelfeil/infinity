# Gemma family composed v3 CPU evidence

Base: `09fbb71f27536f99713abc696b749e94e145b735`.
Worktree: `/tmp/oxide-docs-parity-20261102/gemma-family-composed-v3` (detached).
Inputs kept immutable: `gemma2-composed`, `gemma4-full-v2`, `fa4-all-model-v3`.

Environment: `CUDA_VISIBLE_DEVICES=` empty, Cargo offline, `taskset -c 136-143`,
`-j2`. No GPU, Torch, Docker, NVCC, cargo-oxide, device build, optimized build or
CUDA graph was executed.

## Gates

| gate | result |
|---|---|
| `cargo check -p infinity-backend-oxide --offline -j2` | pass |
| `cargo check -p infinity_v3-backend --no-default-features --features oxide` | pass |
| `cargo test -p infinity-backend-oxide --lib --no-run --offline -j2` | pass |
| `cargo clippy -p infinity-backend-oxide --lib --tests --offline -j2 -- -D warnings` | pass |
| `cargo fmt -p infinity-backend-oxide` | applied |
| Gemma2 focused suite | 53 passed, 2 ignored, 0 failed |
| Gemma4 focused suite | 65 passed, 11 ignored, 0 failed |
| Gemma2 media | 15 passed, 1 ignored, 0 failed |
| Gemma2 head512 | 2 passed, 0 failed |
| vendored head512 | 14 passed, 1 ignored; stub suite 6 ignored |
| backend-core media | 23 passed, 0 failed |
| FA4 canonical26/31/38 host tests | 36 passed, 9 ignored, 0 failed |

Logs are in `evidence/`. The Gemma2 source-inventory test was harmonized to keep
the old78/eight-export/media assertions while admitting the additive 20 Gemma4
exports, rather than overwriting the Gemma2 manifest.

## Composition checks

- `SELECTIVE.patch` is isolated against `09fbb71`.
- Clean-base patch apply + `cargo check` verified with a shared target directory.
- One vendored head512 crate (`backends/oxide/vendor/head512-aot`) is used by both
  families; no duplicate provider source.
- Device manifest contains 24 Gemma2 media exports and 20 Gemma4 exports, with no
  duplicate Gemma4 names or old-source overwrite.

## Remaining gaps

1. Noncausal E4B local Q8/KV2 d256 has no canonical38 profile; the explicit
   semantic device leaf remains a numeric gap for that geometry.
2. No GPU/runtime/numeric/sanitizer execution.
3. Official Rune 26B/E4B weight payloads are absent locally; full checkpoint
   forward and Native comparison remain Root inputs.
4. Public media admission, CUDA graphs, FP8 and performance remain out of scope.
