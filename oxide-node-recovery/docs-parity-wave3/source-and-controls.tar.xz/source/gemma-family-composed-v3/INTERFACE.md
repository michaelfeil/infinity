# Gemma family composed v3

Base: public `09fbb71f27536f99713abc696b749e94e145b735`.
Composition: exact `gemma2-composed/SELECTIVE.patch`, shared
`fa4-all-model-v3/SELECTIVE.patch` canonical38 producer, and the Gemma4
`gemma4-full-v2` source deltas. Gemma2-composed and Gemma4-full-v2 worktrees
remain immutable.

## One Engine, two concrete families

`ExecutableModel` has `Gemma2` and `Gemma4`; `Workspace` has the matching
`Gemma2Work` and `Gemma4Work`. Both use the normal factory/preflight/arena/
HostIoLease/completion-ticket/Deferred path. There is no placeholder family,
alias dispatch without forward, CUDA graph, Torch fallback or CPU forward.

- Gemma2: text PLE/shared KV/saved projection, 16-layer vision, 12-layer audio,
  packed media rows, request-owned media scratch/encodings, exact stream tickets,
  and the vendored fast d512 Native512 AOT provider.
- Gemma4: dense E2B/E4B text, Sparse-MoE Rune 26B router F32/fused experts,
  Rune BF16 option head, vision tower including d72/standardize, and owned
  vision Work retained through text completion.

Both families share one vendored `backends/oxide/vendor/head512-aot` source and
one `infinity-head512-aot` dependency. No `libs/head512_aot` duplicate is
present.

## Shared FA4 publisher

The `fa4-all-model-v3` canonical38 producer owns the registry. The composed tree
does not replace canonical31 or duplicate profile producers. Appended modes:

- 31 `qwen2_q14kv2_d64_causal`
- 32 `qwen2_q12kv2_d128_causal`
- 33 `llama_q32kv8_d64_noncausal`
- 34 `gemma3_global_d256_gqa2`
- 35 `gemma3_local1024_d256_gqa2` (also serves Rune 26B Q16/KV8 d256 local1024)
- 36 `gemma3_local1024_d128_gqa2`
- 37 `gemma4_e4b_local1024_d256_gqa4` (causal E4B Q8/KV2 d256 local)

The host loader preserves the old ABI7/i32 path for <=31 modes and uses the
new u64 mask/query only for canonical38. Old public H5120/A1/Qwen3.5-MoE
sources and profiles are preserved.

## Gemma4 additions from full-v2

- Generic dense geometry admission (E2B/E4B/Rune 26B config/plan).
- Optional PLE and PLE-less text; shared KV; per-layer local/global geometry;
  K=V full-attention copy; max positions 262144.
- Sparse MoE: BF16 router scale kernel, F32 router GEMM, request `MoeScratch`,
  fused expert upload, `MODEL_GEMMA4_E128_TOP8` dispatch with FP32 scales.
- Rune BF16 tied option head, retained host option-ID tail, deferred completion,
  result-memory charging.
- Vision d72/standardize and combined pool+standardize device kernel.
- New device exports included exactly once in the composed build manifest:
  `infinity_gemma4_router_scale_bf16_to_f32`,
  `infinity_gemma4_vision_pool_standardize_rows_bf16`, plus the existing 18
  Gemma4 text/Rune/vision exports.

## Remaining gaps

1. Noncausal E4B local Q8/KV2 d256 is not a canonical38 mode (mode37 is causal).
   The explicit `INFINITY_GEMMA4_SEMANTIC_LOCAL=1` device leaf is still required
   for that one geometry and is a numeric gap, not FA4 parity.
2. No GPU/device/NVCC/FA4/Head512 execution, sanitizer or Native comparison was
   run here.
3. Official 26B/E4B weight payloads are not present locally; geometry/plan and
   host executor tests are executed, full checkpoint forward remains Root input.
4. Public media admission, CUDA graphs, dynamic FP8 and performance claims remain
   out of scope.
