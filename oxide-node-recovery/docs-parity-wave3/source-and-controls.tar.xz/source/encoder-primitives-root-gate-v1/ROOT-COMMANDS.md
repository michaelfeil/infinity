# Frozen Root commands

All paths below are inside this packet unless `COMPOSED_ROOT` is set. Root owns
GPU0, the device compile, and the Torch SDK. The worker ran none of these.

## 0. CPU preflight (already run)

```sh
cd /tmp/oxide-docs-parity-20261102/encoder-primitives-root-gate-v1
CUDA_VISIBLE_DEVICES='' python3 root_control.py --check-only --allow-missing-gold
CUDA_VISIBLE_DEVICES='' python3 -m unittest discover -s cpu_tests -v
```

## 1. Compile the composed device bundle exactly once

```sh
cd /tmp/oxide-docs-parity-20261102/encoder-primitives-root-gate-v1
COMPOSED_ROOT=/path/to/composed/repo   # contains libs/infinity-v3 \
BUILD_DIR=/path/to/root/encoder-primitives-build \
CARGO_OXIDE=/path/to/cargo-oxide \
ARCH=sm_90 \
  scripts/compile-once.sh
```

`scripts/compile-once.sh` runs the composed
`libs/infinity-v3/backends/oxide/device/build.sh` once and then
`scripts/freeze_artifact.py` copies the single module to
`artifacts/encoder_primitives.<arch>.cubin` and writes
`artifacts/artifact-lock.json`. The lock is bound to `manifest.json` and both
frozen kernel-source hashes.

## 2. Produce actual Torch-CUDA gold

The script refuses to run outside the frozen SDK and without a real GPU.

```sh
cd /tmp/oxide-docs-parity-20261102/encoder-primitives-root-gate-v1
export CUDA_VISIBLE_DEVICES=0
export INFINITY_ENCODER_PRIMITIVES_GOLD=1
export INFINITY_NATIVE_SDK_SHA256=<b66-fingerprint>
/opt/torch-sdk/bin/python3.12 native/primitive_gold_producer.py --out gold
```

Outputs:

- `gold/primitive_gold.bin` (magic/header/payload, dtype/shape/hash/provenance)
- `gold/primitive_gold.manifest.json`
- `gold/primitive_gold.plan.json`

## 3. Run the unified ctypes control

```sh
cd /tmp/oxide-docs-parity-20261102/encoder-primitives-root-gate-v1
export CUDA_VISIBLE_DEVICES=0
export INFINITY_ENCODER_PRIMITIVES_ROOT=1
export COMPOSED_ROOT=/path/to/composed/repo   # contains libs/infinity-v3

# optional one-shot sequence; same artifact for init/mem/plain
ARTIFACT=$PWD/artifacts/encoder_primitives.sm_90.cubin \
ARCH=sm_90 REPEAT=3 scripts/run-root.sh
```

Or run each mode explicitly (same `--artifact` every time):

```sh
python3 root_control.py --mode init \
  --artifact artifacts/encoder_primitives.sm_90.cubin --repeat 3 \
  --composed-root "$COMPOSED_ROOT" --native-source-root "$COMPOSED_ROOT" \
  --report reports/init.json
python3 root_control.py --mode mem  --artifact ... --repeat 3 ...
python3 root_control.py --mode plain --artifact ... --repeat 3 ...
```

`init` validates the manifest, source pins, artifact lock and `cuFuncGetParamInfo`
ABI, then uploads/readbacks every guarded buffer without launching. `mem` launches
and checks canaries/immutability/ABI without comparing gold. `plain` adds the
gold comparison. All three modes must use the same artifact SHA-256;
`scripts/run-root.sh` enforces that.

The control rejects:

- a manifest/source pin/artifact-lock mismatch,
- `cuFuncGetParamInfo` parameter count or size drift,
- a missing/extra kernel parameter,
- canary or input-buffer corruption,
- non-BF16-widened B2 output words,
- a different artifact between modes,
- a synthetic structure fixture in a real mode.

## 4. Expected report shape

Each mode writes a JSON report with `artifact.sha256`, `gold.sha256`, per-case
status, ABI parameter info, repeat statuses, and either exact BF16 word counts
(A3/C3) or exact/tolerance counts (B2). A3/C3 require bit-exact BF16 words; B2
reports exact words plus the manifest's one-BF16-ulp relative tolerance.
