#!/usr/bin/env python3
"""CPU-only tests for packing, guards, manifest/ABI validation, controller logic.

No CUDA, Torch, NumPy, device compile, or optimized build is used. The synthetic
fixture is explicitly structural zeros, not numeric gold, and the controller
rejects it in every real mode.
"""
from __future__ import annotations

import ast
import os
import importlib.util
import json
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "native"))

import gold_pack  # noqa: E402
import root_control  # noqa: E402


def load_synthetic_module():
    spec = importlib.util.spec_from_file_location(
        "synthetic_gold_fixture", HERE / "synthetic_gold_fixture.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


SYNTHETIC = load_synthetic_module()


def temp_packet(with_gold: bool = False) -> Path:
    temp = Path(tempfile.mkdtemp(prefix="encoder-primitives-cpu-"))
    shutil.copy2(ROOT / "manifest.json", temp / "manifest.json")
    shutil.copytree(ROOT / "frozen", temp / "frozen")
    if with_gold:
        SYNTHETIC.make(temp)
    return temp


def cleanup(path: Path) -> None:
    shutil.rmtree(path, ignore_errors=True)


class PacketTests(unittest.TestCase):
    def test_manifest_contracts_and_source_pins(self):
        manifest, manifest_sha = root_control.load_manifest(ROOT)
        self.assertEqual(len(manifest["kernels"]), 3)
        by_symbol = {kernel["symbol"]: kernel for kernel in manifest["kernels"]}
        plain = by_symbol["infinity_plain_layer_norm_bf16_aten"]
        residual = by_symbol["infinity_deberta_plain_norm_bf16_aten"]
        colbert = by_symbol["infinity_colbert_l2_bf16_f32"]
        self.assertEqual(plain["arg_count"], 7)
        self.assertEqual(residual["arg_count"], 9)
        self.assertEqual(colbert["arg_count"], 5)
        self.assertEqual(plain["threads"], 128)
        self.assertEqual(residual["threads"], 128)
        self.assertEqual(colbert["threads"], 256)
        self.assertEqual(plain["widths"], [384, 768, 1024])
        self.assertEqual(residual["widths"], [384, 1024])
        self.assertEqual(colbert["widths"], [64, 96, 128])
        self.assertTrue(manifest["contracts"]["nine_arg_does_not_serve_768"])
        self.assertEqual(manifest["artifact"]["allowed_architectures"],
                         ["sm_90", "sm_100", "sm_120"])
        self.assertIn("projection", manifest["native_reference"]["b2_projection_boundary"].lower())
        self.assertEqual(len(manifest_sha), 64)
        for pin in manifest["source_pins"]:
            self.assertEqual(gold_pack.sha256_file(ROOT / pin["path"]), pin["sha256"])

    def test_case_plan_coverage(self):
        plan = gold_pack.build_case_plan()
        manifest, _ = root_control.load_manifest(ROOT)
        self.assertEqual(len(plan), 243)
        self.assertEqual(manifest["case_plan"]["count"], 243)
        self.assertEqual(gold_pack.case_plan_sha256(), manifest["case_plan"]["sha256"])
        self.assertEqual(gold_pack.validate_case_plan(plan, manifest), [])
        families = {}
        for case in plan:
            families.setdefault(case["family"], []).append(case)
        self.assertEqual(len(families["a3_plain_norm"]), 87)
        self.assertEqual(len(families["c3_deberta_residual_norm"]), 48)
        self.assertEqual(len(families["b2_colbert_l2"]), 108)
        norm_widths = {case["width"] for case in families["a3_plain_norm"]}
        self.assertEqual(norm_widths, {384, 768, 1024})
        norm_rows = {case["rows"] for case in families["a3_plain_norm"]}
        self.assertEqual(norm_rows, {1, 5, 33})
        colbert_widths = {case["width"] for case in families["b2_colbert_l2"]}
        self.assertEqual(colbert_widths, {64, 96, 128})
        colbert_patterns = {case["pattern"] for case in families["b2_colbert_l2"]}
        self.assertEqual(colbert_patterns, {"zero", "tiny", "mixed", "normal"})
        self.assertGreaterEqual(len({case["eps"] for case in plan}), 4)

    def test_container_roundtrip_and_corruption(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "c.bin"
            raw_a = b"abcdefgh"
            raw_b = struct.pack("<4H", 1, 2, 3, 4)
            blob_a = {"id": "a", "role": "input", "case": "c", "dtype": "bfloat16",
                      "shape": [4], "bytes": raw_a, "logical_offset": 0,
                      "logical_bytes": 8, "guard_prefix_words": 0,
                      "guard_suffix_words": 0, "nullable": False}
            blob_b = {"id": "b", "role": "gold", "case": "c", "dtype": "bfloat16",
                      "shape": [4], "bytes": raw_b, "logical_offset": 0,
                      "logical_bytes": 8, "guard_prefix_words": 0,
                      "guard_suffix_words": 0, "nullable": False}
            written = gold_pack.write_container(path, {"case_plan_sha256": "x"},
                                                [(blob_a, raw_a), (blob_b, raw_b)])
            header, payload = gold_pack.read_container(path)
            self.assertEqual(header["case_plan_sha256"], "x")
            self.assertEqual(payload, raw_a + raw_b)
            self.assertEqual(written["sha256"], gold_pack.sha256_file(path))
            data = path.read_bytes()
            path.write_bytes(data[:-1] + bytes([data[-1] ^ 0xFF]))
            with self.assertRaises(ValueError):
                gold_pack.read_container(path)

    def test_guards_detect_prefix_and_suffix_corruption(self):
        case = next(case for case in gold_pack.build_case_plan()
                    if case["id"].startswith("a3_plain_norm.w384.r1"))
        for blob in gold_pack.case_input_blobs(case):
            self.assertEqual(root_control.check_guards(blob["bytes"], blob), [])
            corrupted = bytearray(blob["bytes"])
            corrupted[0] ^= 0xFF
            self.assertTrue(root_control.check_guards(bytes(corrupted), blob))
            corrupted = bytearray(blob["bytes"])
            corrupted[-1] ^= 0xFF
            self.assertTrue(root_control.check_guards(bytes(corrupted), blob))
            logical = root_control.logical_slice(blob["bytes"], blob)
            self.assertEqual(len(logical), blob["logical_bytes"])

    def test_kernel_argument_packing(self):
        manifest, _ = root_control.load_manifest(ROOT)
        for kernel in manifest["kernels"]:
            values = {}
            for arg in kernel["args"]:
                name = arg["name"]
                if arg["c_type"] == "ptr":
                    values[name] = 0x1000 + len(values) * 0x100
                    if arg.get("nullable"):
                        pass
                elif arg["c_type"] == "u32":
                    values[name] = 7
                else:
                    values[name] = 1e-6
            array, objects, descriptors = root_control.build_kernel_args(kernel, values)
            self.assertEqual(len(objects), kernel["arg_count"])
            self.assertEqual(len(array), kernel["arg_count"])
            self.assertEqual([item["param_size"] for item in descriptors],
                             [arg["param_size"] for arg in kernel["args"]])
            self.assertTrue(all(isinstance(item, object) for item in objects))
        plain = root_control.kernel_by_symbol(manifest, "infinity_plain_layer_norm_bf16_aten")
        values = {"input": 0x1000, "gamma": 0x2000, "beta": None, "out": 0x3000,
                  "rows": 1, "width": 384, "eps": 1e-6}
        array, objects, descriptors = root_control.build_kernel_args(plain, values)
        self.assertEqual(len(array), 7)
        self.assertEqual([item["name"] for item in descriptors],
                         ["input", "gamma", "beta", "out", "rows", "width", "eps"])
        values["beta"] = 0x4000
        array, objects, _ = root_control.build_kernel_args(plain, values)
        self.assertEqual(len(objects), 7)
        bad = dict(values)
        bad["input"] = None
        with self.assertRaises(root_control.PacketError):
            root_control.build_kernel_args(plain, bad)

    def test_comparators(self):
        words = struct.pack("<4H", 0x3F80, 0x4000, 0x0000, 0x8000)
        result = root_control.compare_bf16_words(words, words)
        self.assertTrue(result["exact"])
        self.assertEqual(result["mismatches"], 0)
        changed = bytearray(words)
        changed[1] ^= 0x01
        result = root_control.compare_bf16_words(bytes(changed), words)
        self.assertFalse(result["exact"])
        self.assertEqual(result["mismatches"], 1)

        f32 = struct.pack("<4I", 0x3F800000, 0xBF800000, 0x00000000, 0x40000000)
        exact = root_control.compare_f32(f32, f32, 0.0078125, 0.0, True)
        self.assertEqual(exact["over_tolerance"], 0)
        self.assertEqual(exact["exact_fraction"], 1.0)
        nearly = struct.pack("<4I", 0x3F800001, 0xBF800000, 0x00000000, 0x40000000)
        within = struct.pack("<4I", 0x3F808000, 0xBF800000, 0x00000000, 0x40000000)
        result = root_control.compare_f32(within, f32, 0.0078125, 0.0, False)
        self.assertEqual(result["over_tolerance"], 0)
        self.assertLess(result["exact_fraction"], 1.0)
        beyond = struct.pack("<4I", 0x3F880000, 0xBF800000, 0x00000000, 0x40000000)
        result = root_control.compare_f32(beyond, f32, 0.0001, 0.0, False)
        self.assertGreater(result["over_tolerance"], 0)
        with self.assertRaises(root_control.PacketError):
            root_control.compare_f32(nearly, f32, 0.0078125, 0.0, True)

    def test_manifest_rejects_abi_and_thread_mismatch(self):
        for mutation in ("arg_count", "param_size", "threads", "source_pin"):
            temp = temp_packet()
            try:
                manifest = json.loads((temp / "manifest.json").read_text())
                if mutation == "arg_count":
                    manifest["kernels"][0]["arg_count"] = 8
                elif mutation == "param_size":
                    manifest["kernels"][0]["args"][0]["param_size"] = 4
                elif mutation == "threads":
                    manifest["kernels"][0]["threads"] = 64
                elif mutation == "source_pin":
                    manifest["source_pins"][0]["sha256"] = "0" * 64
                (temp / "manifest.json").write_text(json.dumps(manifest))
                with self.assertRaises(root_control.PacketError):
                    root_control.load_manifest(temp)
            finally:
                cleanup(temp)

    def test_artifact_lock_rejects_mismatch(self):
        temp = temp_packet()
        try:
            manifest, manifest_sha = root_control.load_manifest(temp)
            artifact = temp / "artifacts" / "encoder_primitives.cubin"
            artifact.parent.mkdir(parents=True)
            artifact.write_bytes(b"not-a-real-cubin")
            lock = {
                "schema": gold_pack.ARTIFACT_LOCK_SCHEMA,
                "arch": "sm_90",
                "sha256": gold_pack.sha256_file(artifact),
                "bytes": artifact.stat().st_size,
                "frozen_manifest_sha256": manifest_sha,
                "source_pins_sha256": gold_pack.sha256_bytes(
                    gold_pack.canonical_json_bytes(manifest["source_pins"])),
            }
            (temp / "artifacts" / "artifact-lock.json").write_text(json.dumps(lock))
            loaded = root_control.load_artifact_lock(temp, manifest, artifact)
            self.assertEqual(loaded["sha256"], lock["sha256"])
            lock["sha256"] = "f" * 64
            (temp / "artifacts" / "artifact-lock.json").write_text(json.dumps(lock))
            with self.assertRaises(root_control.PacketError):
                root_control.load_artifact_lock(temp, manifest, artifact)
        finally:
            cleanup(temp)

    def test_synthetic_fixture_is_check_only(self):
        temp = temp_packet(with_gold=True)
        try:
            result = subprocess.run(
                [sys.executable, str(ROOT / "root_control.py"), "--root", str(temp),
                 "--check-only", "--allow-synthetic-fixture"],
                capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            payload = json.loads(result.stdout)
            self.assertTrue(payload["gold_present"])
            self.assertTrue(payload["gold_synthetic"])
            manifest, _ = root_control.load_manifest(temp)
            gold = root_control.load_gold(temp, manifest, allow_synthetic=True)
            self.assertTrue(gold["synthetic"])
            with self.assertRaises(root_control.PacketError):
                root_control.load_gold(temp, manifest, allow_synthetic=False)
            result = subprocess.run(
                [sys.executable, str(ROOT / "root_control.py"), "--root", str(temp),
                 "--check-only"],
                capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
        finally:
            cleanup(temp)

    def test_no_cpu_reference_math_and_no_numpy(self):
        for path in (ROOT / "native" / "gold_pack.py", ROOT / "root_control.py",
                     ROOT / "native" / "primitive_gold_producer.py"):
            tree = ast.parse(path.read_text())
            imports = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imports.update(alias.name.split(".")[0] for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imports.add(node.module.split(".")[0])
            self.assertNotIn("numpy", imports, path.name)
        for path in (ROOT / "native" / "gold_pack.py", ROOT / "root_control.py"):
            source = path.read_text()
            tree = ast.parse(source)
            imported = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imported.update(alias.name.split(".")[0] for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imported.add(node.module.split(".")[0])
            self.assertNotIn("torch", imported, path.name)
        producer = (ROOT / "native" / "primitive_gold_producer.py").read_text()
        self.assertIn("native_layer_norm", producer)
        self.assertIn("linalg_vector_norm", producer)
        self.assertIn("clamp_min", producer)
        self.assertIn("cuda:0", producer)

    def test_frozen_source_function_signatures(self):
        plain = (ROOT / "frozen" / "plain_layer_norm_aten.rs").read_text()
        colbert = (ROOT / "frozen" / "colbert.rs").read_text()

        def arity(source: str, name: str) -> int:
            match = re.search(rf"pub unsafe fn {name}\((.*?)\)\s*\{{", source, re.S)
            self.assertIsNotNone(match, name)
            params = match.group(1).strip()
            return len([item for item in params.split(",") if item.strip()])

        self.assertEqual(arity(plain, "plain_layer_norm_bf16_aten"), 7)
        self.assertEqual(arity(plain, "deberta_plain_norm_bf16_aten"), 9)
        self.assertEqual(arity(colbert, "colbert_l2_bf16_f32"), 5)
        self.assertIn("const BLOCK_X: usize = 32;", plain)
        self.assertIn("const BLOCK_Y: usize = 4;", plain)
        self.assertIn("const NUM_THREADS: usize = BLOCK_X * BLOCK_Y;", plain)
        self.assertIn("block = 256", colbert)
        self.assertIn("round_bf16", colbert)
        self.assertIn("Grid = rows", colbert)
        self.assertIn("384 => unsafe", plain)
        self.assertIn("1024 => unsafe", plain)
        self.assertIn("_ => {}", plain)

    def test_native_l2_source_recipe(self):
        manifest, _ = root_control.load_manifest(ROOT)
        native = Path("/tmp/infinity-plain-cuda")
        if not (native / manifest["native_l2_source"]["path"]).is_file():
            self.skipTest("public Native source tree is unavailable")
        result = root_control.verify_native_l2_source(manifest, native)
        self.assertTrue(result["checked"])

    def test_controller_refuses_gpu_without_lock(self):
        manifest, manifest_sha = root_control.load_manifest(ROOT)
        old = dict(os.environ)
        try:
            os.environ.pop("CUDA_VISIBLE_DEVICES", None)
            os.environ.pop(root_control.GPU_LOCK_ENV, None)
            with self.assertRaises(root_control.PacketError) as raised:
                root_control.run_mode(
                    ROOT, manifest, manifest_sha,
                    {"path": "synthetic", "sha256": "0" * 64, "payload": b"", "blobs": {}},
                    ROOT / "missing.cubin",
                    {"sha256": "0" * 64}, "plain", 1, None, None)
            self.assertIn("CUDA_VISIBLE_DEVICES", str(raised.exception))
        finally:
            os.environ.clear()
            os.environ.update(old)


if __name__ == "__main__":
    unittest.main(verbosity=2)
