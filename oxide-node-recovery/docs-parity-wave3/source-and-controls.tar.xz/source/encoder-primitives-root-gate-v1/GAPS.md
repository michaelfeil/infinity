# Remaining gaps

1. **Root compile**: no device module was compiled here. Root must compile the
   composed tree once and write `artifacts/artifact-lock.json` with
   `scripts/freeze_artifact.py`.
2. **Root gold**: no gold container exists in this packet. Root must run
   `native/primitive_gold_producer.py` under
   `/opt/torch-sdk/bin/python3.12` with the frozen b66 SDK, then run the control.
3. **B2 reduction order**: the ColBERT kernel uses `block_sum` F32 accumulation.
   The Native `at::linalg_vector_norm` reduction order is not proven equal. The
   gate reports exact BF16-wide words and applies an explicit one-BF16-ulp
   relative tolerance; exactness is not assumed.
4. **9-arg width contract**: `infinity_deberta_plain_norm_bf16_aten` matches only
   H384/H1024. H768 is served by the 7-arg A3 entry, not the 9-arg entry.
5. **Artifact driver check**: `cuFuncGetParamInfo` is required. If the Root
   driver/library does not expose it, the control rejects the run instead of
   silently skipping the ABI check.
6. **No numeric claim yet**: there is no Native-vs-Oxide output record in this
   packet; the CPU tests are structural only. No trained-model or performance
   claim is made.
7. **Input generation**: BF16 fixture words are generated with a stdlib
   round-to-nearest-even encoder. They are inputs, not gold. Gold is always the
   actual Torch CUDA output.
8. **Canary pattern**: guards use fixed 0xA5A5 (BF16) / 0xDEADBEEF (F32) words.
   A kernel writing exactly those words at the guard boundary would be
   indistinguishable; the logical offsets keep guards outside the declared
   shape and the check is structural, not a security boundary.
