#!/usr/bin/env bash
# Frozen Root-run sequence for the encoder primitive packet.
# Root compiles exactly once (scripts/compile-once.sh), produces the actual
# Torch-CUDA gold once, then runs init/mem/plain against the same artifact.
set -euo pipefail

PACKET_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${COMPOSED_ROOT:?set COMPOSED_ROOT to the composed infinity-v3 tree}"
: "${CUDA_VISIBLE_DEVICES:?set CUDA_VISIBLE_DEVICES to the Root GPU}"
: "${INFINITY_ENCODER_PRIMITIVES_ROOT:?set INFINITY_ENCODER_PRIMITIVES_ROOT=1}"

PYTHON="${PYTHON:-/opt/torch-sdk/bin/python3.12}"
REPEAT="${REPEAT:-3}"
ARCH="${ARCH:-sm_90}"
if [[ -z "${ARTIFACT:-}" && -f "$PACKET_DIR/artifacts/ARTIFACT.path" ]]; then
  ARTIFACT="$PACKET_DIR/$(cat "$PACKET_DIR/artifacts/ARTIFACT.path")"
fi
ARTIFACT="${ARTIFACT:-$PACKET_DIR/artifacts/encoder_primitives.$ARCH.cubin}"
GOLD_DIR="$PACKET_DIR/gold"
REPORTS="$PACKET_DIR/reports"

mkdir -p "$REPORTS" "$GOLD_DIR"

if [[ ! -f "$PACKET_DIR/artifacts/artifact-lock.json" ]]; then
  echo "run-root: missing artifact lock; run scripts/compile-once.sh first" >&2
  exit 2
fi
if [[ ! -f "$ARTIFACT" ]]; then
  echo "run-root: missing artifact $ARTIFACT" >&2
  exit 2
fi

echo "run-root: structural check without gold"
python3 "$PACKET_DIR/root_control.py" --check-only --allow-missing-gold \
  --composed-root "$COMPOSED_ROOT" --native-source-root "$COMPOSED_ROOT"

if [[ ! -f "$GOLD_DIR/primitive_gold.bin" || "${REGENERATE_GOLD:-0}" == "1" ]]; then
  : "${INFINITY_NATIVE_SDK_SHA256:?set the frozen b66 SDK fingerprint}"
  : "${INFINITY_ENCODER_PRIMITIVES_GOLD:?set INFINITY_ENCODER_PRIMITIVES_GOLD=1}"
  echo "run-root: producing actual Torch-CUDA gold in $PYTHON"
  "$PYTHON" "$PACKET_DIR/native/primitive_gold_producer.py" --out "$GOLD_DIR"
fi

echo "run-root: full structural + gold provenance check"
python3 "$PACKET_DIR/root_control.py" --check-only \
  --composed-root "$COMPOSED_ROOT" --native-source-root "$COMPOSED_ROOT"

: > "$REPORTS/artifact-use.txt"
for mode in init mem plain; do
  echo "run-root: mode=$mode"
  python3 "$PACKET_DIR/root_control.py" \
    --mode "$mode" --artifact "$ARTIFACT" --repeat "$REPEAT" \
    --composed-root "$COMPOSED_ROOT" --native-source-root "$COMPOSED_ROOT" \
    --report "$REPORTS/$mode.json"
  python3 - "$REPORTS/$mode.json" "$mode" >> "$REPORTS/artifact-use.txt" <<'PY'
import json, sys
report = json.load(open(sys.argv[1]))
print(sys.argv[2], report["artifact"]["sha256"], sep="\t")
PY
done

python3 - "$REPORTS/artifact-use.txt" <<'PY'
import sys
rows = [line.split() for line in open(sys.argv[1]) if line.strip()]
if len(rows) != 3:
    raise SystemExit("run-root: expected init/mem/plain artifact records")
hashes = {row[1] for row in rows}
if len(hashes) != 1:
    raise SystemExit("run-root: modes used different artifacts")
print("run-root: same artifact used by init/mem/plain:", hashes.pop())
PY

echo "run-root: PASS (reports in $REPORTS)"
