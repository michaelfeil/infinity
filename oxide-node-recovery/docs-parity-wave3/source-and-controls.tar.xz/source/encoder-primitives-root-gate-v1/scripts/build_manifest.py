#!/usr/bin/env python3
"""Build the frozen packet manifest deterministically (CPU-only)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "native"))

import gold_pack  # noqa: E402

BASE_COMMIT = "252789b05ea2e09c14971c04dfcce458f863fead"

SOURCE_FREEZE = [
    {
        "path": "frozen/plain_layer_norm_aten.rs",
        "origin": "encoder-heads-corrected-v3/source (identical in deberta-widths-corrected-v3/source)",
        "origin_path": "libs/infinity-v3/backends/oxide/device/src/plain_layer_norm_aten.rs",
        "sha256": "4a51d695eb43033aab7b7f6124c308deac8cc71143c92602d42a155d50d7c6c6",
    },
    {
        "path": "frozen/colbert.rs",
        "origin": "sparse-colbert-corrected-v2/source",
        "origin_path": "libs/infinity-v3/backends/oxide/device/src/colbert.rs",
        "sha256": "649f91000a3e69202968635b46af461a0fd3bd6bf8fdfc60cd8801c39eba86cb",
    },
]

WRAPPER_SOURCE_PINS = [
    {
        "wave": "A3",
        "path": "encoder-heads-corrected-v3/source/libs/infinity-v3/backends/oxide/device/src/main.rs",
        "sha256": "b8ea2504c99fb93e59939c0074771667d727c42d618306b26c73e665deabb5ff",
        "wrapper": "infinity_plain_layer_norm_bf16_aten",
    },
    {
        "wave": "C3",
        "path": "deberta-widths-corrected-v3/source/libs/infinity-v3/backends/oxide/device/src/main.rs",
        "sha256": "f7b3927bb3f92e9cd6ab0307aba035ce84e940da35c968d1c1ab7f6d0cf94a44",
        "wrapper": "infinity_deberta_plain_norm_bf16_aten",
    },
    {
        "wave": "B2",
        "path": "sparse-colbert-corrected-v2/source/libs/infinity-v3/backends/oxide/device/src/main.rs",
        "sha256": "c4ee88744521b724b1d2925f439aaaf9531174664e1214c23fdc6251cd0d3a7a",
        "wrapper": "infinity_colbert_l2_bf16_f32",
    },
]


def ptr(name, dtype, shape, nullable=False, writable=False):
    return {
        "name": name,
        "c_type": "ptr",
        "param_size": 8,
        "pointee": "u16" if dtype == "bfloat16" else "f32",
        "dtype": dtype,
        "shape": shape,
        "nullable": nullable,
        "writable": writable,
        "device": True,
    }


def u32(name):
    return {"name": name, "c_type": "u32", "param_size": 4}


def f32(name):
    return {"name": name, "c_type": "f32", "param_size": 4}


KERNELS = [
    {
        "id": "A3.plain_layer_norm_bf16_aten",
        "wave": "A3",
        "family": "a3_plain_norm",
        "symbol": "infinity_plain_layer_norm_bf16_aten",
        "source": "frozen/plain_layer_norm_aten.rs",
        "source_function": "plain_layer_norm_bf16_aten",
        "args": [
            ptr("input", "bfloat16", "[rows,width]"),
            ptr("gamma", "bfloat16", "[width]"),
            ptr("beta", "bfloat16", "[width]", nullable=True),
            ptr("out", "bfloat16", "[rows,width]", writable=True),
            u32("rows"),
            u32("width"),
            f32("eps"),
        ],
        "arg_count": 7,
        "dtype": "bfloat16",
        "widths": [384, 768, 1024],
        "grid": "(rows,1,1)",
        "block": [32, 4, 1],
        "threads": 128,
        "dynamic_shared_bytes": 0,
        "static_shared_bytes": 24,
        "workspace_bytes": 0,
        "aliasing": "out may equal input; gamma/beta must not overlap input/out",
        "unsupported_width": "no-op (manifest admits only 384/768/1024)",
    },
    {
        "id": "C3.deberta_plain_norm_bf16_aten",
        "wave": "C3",
        "family": "c3_deberta_residual_norm",
        "symbol": "infinity_deberta_plain_norm_bf16_aten",
        "source": "frozen/plain_layer_norm_aten.rs",
        "source_function": "deberta_plain_norm_bf16_aten",
        "args": [
            ptr("input", "bfloat16", "[rows,width]"),
            ptr("residual", "bfloat16", "[rows,width]", nullable=True),
            ptr("bias", "bfloat16", "[width]", nullable=True),
            ptr("gamma", "bfloat16", "[width]"),
            ptr("beta", "bfloat16", "[width]", nullable=True),
            ptr("out", "bfloat16", "[rows,width]", writable=True),
            u32("rows"),
            u32("width"),
            f32("eps"),
        ],
        "arg_count": 9,
        "dtype": "bfloat16",
        "widths": [384, 1024],
        "grid": "(rows,1,1)",
        "block": [32, 4, 1],
        "threads": 128,
        "dynamic_shared_bytes": 0,
        "static_shared_bytes": 24,
        "workspace_bytes": 0,
        "residual_boundary": "value=input; if bias: value=bf16(value+bias); if residual: value=bf16(value+residual); then plain ATen LayerNorm",
        "unsupported_width": "no-op; width 768 is served by the A3 7-arg kernel, not this 9-arg entry",
    },
    {
        "id": "B2.colbert_l2_bf16_f32",
        "wave": "B2",
        "family": "b2_colbert_l2",
        "symbol": "infinity_colbert_l2_bf16_f32",
        "source": "frozen/colbert.rs",
        "source_function": "colbert_l2_bf16_f32",
        "args": [
            ptr("input", "bfloat16", "[rows,width]"),
            ptr("output", "float32", "[rows,width]", writable=True),
            u32("rows"),
            u32("width"),
            f32("eps"),
        ],
        "arg_count": 5,
        "dtype": "bfloat16->bfloat16-normalized->float32-widened",
        "widths": [64, 96, 128],
        "grid": "(rows,1,1)",
        "block": [256, 1, 1],
        "threads": 256,
        "dynamic_shared_bytes": 0,
        "static_shared_bytes": 32,
        "workspace_bytes": 0,
        "native_recipe": "norm=BF16 sqrt(F32 sum of squares); denom=BF16 clamp_min(norm, BF16(eps)); out=BF16(x/denom) widened to F32",
        "reduction_note": "The F32 block_sum order is not yet proven equal to ATen linalg_vector_norm; gold uses the actual Native expression and the gate reports exactness plus a one-BF16-ulp tolerance.",
    },
]


def main() -> int:
    plan = gold_pack.build_case_plan()
    manifest = {
        "schema": gold_pack.MANIFEST_SCHEMA,
        "packet": "encoder-primitives-root-gate-v1",
        "frozen": True,
        "base_commit": BASE_COMMIT,
        "native_reference": {
            "environment": "infinity-torch214-compare-sdk",
            "python": "/opt/torch-sdk/bin/python3.12",
            "torch_version": "2.14.1+cu130",
            "torch_version_prefix": "2.14.1",
            "cuda_version_prefix": "13.",
            "torch_git_version": "5c4886908584029761b579af026dcfb627c84070",
            "native_sdk_sha256_prefix": "b66",
            "gold_producer": "native/primitive_gold_producer.py",
            "gold_container": "gold/primitive_gold.bin",
            "gold_manifest": "gold/primitive_gold.manifest.json",
            "gold_is_actual_torch_cuda": True,
            "cpu_reference_forbidden": True,
            "b2_projection_boundary": "B2 input is the Native MultiVectorModel BF16 learned-projection output; this gate starts at L2 normalization and does not execute the projection.",
        },
        "source_pins": SOURCE_FREEZE,
        "wrapper_source_pins": WRAPPER_SOURCE_PINS,
        "artifact": {
            "required": True,
            "format": "cubin-or-ptx-driver-module",
            "allowed_architectures": ["sm_90", "sm_100", "sm_120"],
            "one_artifact_for_all_exports": True,
            "lock_schema": gold_pack.ARTIFACT_LOCK_SCHEMA,
            "artifact_lock": "artifacts/artifact-lock.json",
            "require_param_info": True,
        },
        "kernels": KERNELS,
        "contracts": {
            "plain_layer_norm_is_7_args": True,
            "deberta_residual_norm_is_9_args": True,
            "colbert_l2_is_5_args": True,
            "plain_norm_threads": 128,
            "plain_norm_block": [32, 4, 1],
            "deberta_residual_norm_threads": 128,
            "colbert_l2_threads": 256,
            "norm_widths": {"plain_7_arg": [384, 768, 1024], "deberta_9_arg": [384, 1024]},
            "colbert_widths": [64, 96, 128],
            "nine_arg_does_not_serve_768": True,
            "dynamic_shared_bytes": 0,
            "workspace_bytes": 0,
        },
        "case_plan": {
            "schema": gold_pack.PLAN_SCHEMA,
            "sha256": gold_pack.case_plan_sha256(),
            "count": len(plan),
            "families": {
                family: {
                    "widths": spec["widths"],
                    "rows": spec["rows"],
                    "eps": spec["eps"],
                    "patterns": spec["patterns"],
                    "extra_beta_absent": spec.get("extra_beta_absent", False),
                }
                for family, spec in gold_pack.FAMILIES.items()
            },
            "required_coverage": {
                "norm_widths": [384, 768, 1024],
                "norm_rows": [1, 5, 33],
                "colbert_widths": [64, 96, 128],
                "colbert_rows": [1, 5, 33],
                "canary_words_prefix": gold_pack.GUARD_PREFIX_WORDS,
                "canary_words_suffix": gold_pack.GUARD_SUFFIX_WORDS,
            },
        },
        "comparison": {
            "A3.plain_layer_norm_bf16_aten": {
                "kind": "bit_exact_bf16_words",
                "exact_required": True,
                "tolerance": None,
            },
            "C3.deberta_plain_norm_bf16_aten": {
                "kind": "bit_exact_bf16_words",
                "exact_required": True,
                "tolerance": None,
            },
            "B2.colbert_l2_bf16_f32": {
                "kind": "bf16_widened_f32",
                "exact_required": False,
                "report_exact": True,
                "require_bf16_representable": True,
                "rel_tol": 0.0078125,
                "abs_tol": 0.0,
            },
        },
        "modes": {
            "init": "validate manifest/source pins/artifact ABI, no launches",
            "mem": "launch and check guards/immutability/ABI, skip gold compare",
            "plain": "launch, check guards/immutability/ABI, compare every gold word",
            "same_artifact_required": ["init", "mem", "plain"],
        },
        "native_l2_source": {
            "path": "libs/infinity-v3/backends/libtorch/cpp/models/multivector_model.h",
            "sha256": "40814332637ea4a9f7c19e07d7f9a4f502ad3b52799e7c2401c1dfb916915da0",
            "line": 56,
            "expression": "return states / at::linalg_vector_norm(states, 2, {-1}, true).clamp_min(epsilon);",
        },
        "gaps": [
            "Root must compile one composed module containing all three exports and write artifacts/artifact-lock.json.",
            "Root must run the gold producer inside the exact SDK; no gold exists in this packet.",
            "The B2 F32 block_sum order is not proven equal to ATen linalg_vector_norm; exactness is reported and tolerance is explicit.",
            "The 9-arg DeBERTa entry intentionally serves only H384/H1024; H768 uses the 7-arg entry.",
            "No trained-model or end-to-end performance claim is made by this primitive gate.",
        ],
    }
    (ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "ok": True,
        "cases": len(plan),
        "plan_sha256": gold_pack.case_plan_sha256(),
        "manifest_sha256": gold_pack.sha256_file(ROOT / "manifest.json"),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
