#!/usr/bin/env bash
# Frozen Root compile-once command. The worker did NOT compile anything.
set -euo pipefail

PACKET_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${COMPOSED_ROOT:?set COMPOSED_ROOT to the composed infinity-v3 tree}"
: "${BUILD_DIR:?set BUILD_DIR to the one-shot bundle output}"
: "${CARGO_OXIDE:?set CARGO_OXIDE to the pinned cargo-oxide compiler}"
ARCH="${ARCH:-sm_90}"

cd "$COMPOSED_ROOT/libs/infinity-v3/backends/oxide/device"
CARGO_OXIDE="$CARGO_OXIDE" ./build.sh "$BUILD_DIR"
python3 "$PACKET_DIR/scripts/freeze_artifact.py" \
  --build-dir "$BUILD_DIR" --arch "$ARCH"
echo "compile-once: frozen artifact $ARCH at $PACKET_DIR/artifacts"
