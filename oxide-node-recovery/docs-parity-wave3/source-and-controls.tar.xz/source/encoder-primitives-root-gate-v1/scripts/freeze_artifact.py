#!/usr/bin/env python3
"""Freeze one Root-compiled module artifact into the packet lock (CPU-only).

The Root compiles the composed device bundle exactly once. This script does not
compile, load, or execute anything on the GPU. It copies the chosen cubin/PTX,
records its SHA-256/bytes/arch, and binds the lock to the frozen manifest and
the two frozen kernel source hashes.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "native"))

import gold_pack  # noqa: E402
import root_control  # noqa: E402


def find_artifact(build_dir: Path, arch: str) -> Path:
    candidates = sorted(path for path in build_dir.rglob("*.cubin"))
    if not candidates:
        candidates = sorted(path for path in build_dir.rglob("*.ptx"))
    if not candidates:
        raise SystemExit(f"freeze_artifact: no cubin/ptx under {build_dir}")
    preferred = [path for path in candidates if arch in str(path) or "kernels" in path.name]
    chosen = preferred or candidates
    if len(chosen) != 1:
        listing = "\n".join(str(path) for path in chosen[:16])
        raise SystemExit(f"freeze_artifact: ambiguous artifact; choose one explicitly:\n{listing}")
    return chosen[0]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--build-dir", default=None)
    parser.add_argument("--artifact", default=None)
    parser.add_argument("--arch", required=True, choices=["sm_90", "sm_100", "sm_120"])
    parser.add_argument("--artifact-out", default=None)
    parser.add_argument("--lock-out", default=None)
    args = parser.parse_args()

    root = Path(args.root).resolve()
    manifest, manifest_sha = root_control.load_manifest(root)
    if args.artifact:
        source = Path(args.artifact).resolve()
        if not source.is_file():
            raise SystemExit(f"freeze_artifact: missing artifact {source}")
    elif args.build_dir:
        source = find_artifact(Path(args.build_dir).resolve(), args.arch)
    else:
        raise SystemExit("freeze_artifact: pass --artifact or --build-dir")

    suffix = source.suffix if source.suffix.lower() in (".cubin", ".ptx") else ".cubin"
    artifact_out = Path(args.artifact_out or (root / "artifacts" /
                                             f"encoder_primitives.{args.arch}{suffix}"))
    artifact_out.parent.mkdir(parents=True, exist_ok=True)
    if source.resolve() != artifact_out.resolve():
        shutil.copy2(source, artifact_out)
    lock_path = Path(args.lock_out or (root / "artifacts" / "artifact-lock.json"))
    lock = {
        "schema": gold_pack.ARTIFACT_LOCK_SCHEMA,
        "artifact": str(artifact_out.relative_to(root)),
        "arch": args.arch,
        "sha256": gold_pack.sha256_file(artifact_out),
        "bytes": artifact_out.stat().st_size,
        "frozen_manifest_sha256": manifest_sha,
        "source_pins_sha256": gold_pack.sha256_bytes(
            gold_pack.canonical_json_bytes(manifest["source_pins"])),
        "source_pins": manifest["source_pins"],
        "created_by": "scripts/freeze_artifact.py",
        "device_compiled": False,
        "note": "Root compiled once after composition; this lock only records the artifact bytes.",
    }
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock_path.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n")
    (root / "artifacts" / "ARTIFACT.sha256").write_text(lock["sha256"] + "\n")
    (root / "artifacts" / "ARTIFACT.path").write_text(
        str(artifact_out.relative_to(root)) + "\n")
    print(json.dumps({"ok": True, "artifact": str(artifact_out), "lock": str(lock_path),
                      "sha256": lock["sha256"], "bytes": lock["bytes"],
                      "arch": lock["arch"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
