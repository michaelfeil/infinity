#!/usr/bin/env python3
"""Root-only Native gold producer for the encoder primitive packet.

Run inside the frozen comparison SDK:

    CUDA_VISIBLE_DEVICES=0 INFINITY_ENCODER_PRIMITIVES_GOLD=1 \
    INFINITY_NATIVE_SDK_SHA256=<b66...> \
    /opt/torch-sdk/bin/python3.12 native/primitive_gold_producer.py --out gold

Gold is produced by actual Torch CUDA operations, never by a CPU reference:

* A3 plain LayerNorm: ATen ``native_layer_norm`` on BF16 CUDA tensors.
* C3 DeBERTa residual LayerNorm: the source's BF16-rounded bias-then-residual
  boundary, followed by the same ATen ``native_layer_norm``.
* B2 ColBERT L2: the Native MultiVectorModel expression
  ``states / at::linalg_vector_norm(states, 2, {-1}, true).clamp_min(epsilon)``
  with model-dtype BF16 norm, clamp and quotient, then F32 widening.

The script is not run, imported, or simulated by the CPU worker. It refuses to
run without a real CUDA device, the frozen SDK interpreter, the exact Torch
version/CUDA build, and an explicit gold environment flag. No NumPy is used.
"""
from __future__ import annotations

import argparse
import json
import os
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import gold_pack  # noqa: E402  (stdlib-only sibling)

EXPECTED_TORCH = "2.14.1"
EXPECTED_CUDA_PREFIX = "13."
EXPECTED_TORCH_GIT = "5c4886908584029761b579af026dcfb627c84070"
EXPECTED_SDK_PYTHON = "/opt/torch-sdk/bin/python3.12"


def fail(message: str) -> "NoReturn":
    raise SystemExit(f"primitive_gold_producer: {message}")


def bf16_tensor(torch, words: list[int], shape: list[int], device):
    raw = struct.pack(f"<{len(words)}H", *words)
    tensor = torch.frombuffer(bytearray(raw), dtype=torch.bfloat16).reshape(shape).clone()
    return tensor.to(device=device)


def tensor_raw_bytes(torch, tensor) -> bytes:
    return bytes(tensor.detach().cpu().contiguous().view(torch.uint8).tolist())


def tensor_words_u16(torch, tensor) -> list[int]:
    raw = tensor.detach().cpu().contiguous().view(torch.uint8).tolist()
    if len(raw) % 2:
        fail("BF16 output byte length is odd")
    return [raw[i] | (raw[i + 1] << 8) for i in range(0, len(raw), 2)]


def tensor_words_f32(torch, tensor) -> list[int]:
    raw = tensor.detach().cpu().contiguous().view(torch.uint8).tolist()
    if len(raw) % 4:
        fail("F32 output byte length is not a multiple of four")
    return [int.from_bytes(bytes(raw[i:i + 4]), "little") for i in range(0, len(raw), 4)]


def native_layer_norm(torch, input_t, gamma, beta, eps: float, width: int):
    return torch.ops.aten.native_layer_norm(input_t, [width], gamma, beta, eps)[0]


def gold_plain(torch, case, blobs, device):
    input_t = bf16_tensor(torch, blobs["input"], [case["rows"], case["width"]], device)
    gamma = bf16_tensor(torch, blobs["gamma"], [case["width"]], device)
    beta = None if "beta" not in blobs else bf16_tensor(
        torch, blobs["beta"], [case["width"]], device)
    return native_layer_norm(torch, input_t, gamma, beta, case["eps"], case["width"])


def gold_residual(torch, case, blobs, device):
    width = case["width"]
    input_t = bf16_tensor(torch, blobs["input"], [case["rows"], width], device)
    gamma = bf16_tensor(torch, blobs["gamma"], [width], device)
    beta = None if "beta" not in blobs else bf16_tensor(
        torch, blobs["beta"], [width], device)
    pre = input_t
    if "bias" in blobs:
        bias = bf16_tensor(torch, blobs["bias"], [width], device)
        pre = (pre + bias).to(torch.bfloat16)
    if "residual" in blobs:
        residual = bf16_tensor(torch, blobs["residual"], [case["rows"], width], device)
        pre = (pre + residual).to(torch.bfloat16)
    return native_layer_norm(torch, pre, gamma, beta, case["eps"], width)


def gold_colbert(torch, case, blobs, device):
    width = case["width"]
    x = bf16_tensor(torch, blobs["input"], [case["rows"], width], device)
    # Actual Native expression: states / at::linalg_vector_norm(states, 2, {-1},
    # true).clamp_min(epsilon). The correction pins model-dtype BF16 norm,
    # clamp and quotient before F32 widening.
    norm = torch.linalg.vector_norm(x, 2, -1, keepdim=True).to(torch.bfloat16)
    divisor = norm.clamp_min(case["eps"]).to(torch.bfloat16)
    y = (x / divisor).to(torch.bfloat16)
    out = y.float()
    widened = out.to(torch.bfloat16).float()
    if not bool(torch.equal(out, widened)):
        fail(f"B2 gold output is not BF16-representable for {case['id']}")
    return out


def read_words(blob_bytes: bytes, dtype: str) -> list[int]:
    if dtype == "bfloat16":
        if len(blob_bytes) % 2:
            fail("BF16 input blob byte length is odd")
        return list(struct.unpack(f"<{len(blob_bytes)//2}H", blob_bytes))
    if len(blob_bytes) % 4:
        fail("F32 input blob byte length is not a multiple of four")
    return list(struct.unpack(f"<{len(blob_bytes)//4}I", blob_bytes))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(HERE.parent / "gold"))
    parser.add_argument("--cases", default=None, help="optional comma-separated case ids")
    parser.add_argument("--allow-other-python", action="store_true")
    parser.add_argument("--allow-torch-git-mismatch", action="store_true")
    args = parser.parse_args()

    if os.environ.get("INFINITY_ENCODER_PRIMITIVES_GOLD") != "1":
        fail("set INFINITY_ENCODER_PRIMITIVES_GOLD=1 for the Root-only gold producer")
    if not os.environ.get("CUDA_VISIBLE_DEVICES"):
        fail("CUDA_VISIBLE_DEVICES must select the Root GPU for real CUDA gold")
    sdk_sha = os.environ.get("INFINITY_NATIVE_SDK_SHA256", "")
    if not sdk_sha.startswith("b66"):
        fail("INFINITY_NATIVE_SDK_SHA256 must begin with the frozen b66 fingerprint")
    if not args.allow_other_python:
        executable = str(Path(sys.executable).resolve())
        expected = str(Path(EXPECTED_SDK_PYTHON).resolve())
        if executable != expected:
            fail(f"run under {expected}, not {executable}")

    import torch  # imported only after every guard above

    if not torch.__version__.startswith(EXPECTED_TORCH):
        fail(f"Torch {torch.__version__} is not the frozen {EXPECTED_TORCH} build")
    if not (torch.version.cuda or "").startswith(EXPECTED_CUDA_PREFIX):
        fail(f"Torch CUDA {(torch.version.cuda or 'absent')} is not the frozen CUDA build")
    git_version = getattr(torch.version, "git_version", "") or ""
    if (not args.allow_torch_git_mismatch and git_version
            and not git_version.startswith(EXPECTED_TORCH_GIT[:7])):
        fail(f"Torch git version {git_version} is not the frozen Native source")
    if not torch.cuda.is_available():
        fail("CUDA is unavailable; actual Torch CUDA gold is mandatory")
    device = torch.device("cuda:0")
    props = torch.cuda.get_device_properties(0)

    plan = gold_pack.build_case_plan()
    if args.cases:
        wanted = {item.strip() for item in args.cases.split(",") if item.strip()}
        unknown = wanted - {case["id"] for case in plan}
        if unknown:
            fail(f"unknown case ids: {sorted(unknown)[:4]}")
        plan = [case for case in plan if case["id"] in wanted]

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    container_blobs: list[tuple[dict, bytes]] = []
    plan_records = []
    with torch.no_grad():
        for case in plan:
            input_blobs = gold_pack.case_input_blobs(case)
            words = {}
            for blob in input_blobs:
                words[blob["role"]] = read_words(blob["bytes"], blob["dtype"])
                container_blobs.append((blob, blob["bytes"]))
            if case["kind"] == "plain_norm":
                gold = gold_plain(torch, case, words, device)
                gold_words = tensor_words_u16(torch, gold)
                gold_bytes = struct.pack(f"<{len(gold_words)}H", *gold_words)
                dtype = "bfloat16"
            elif case["kind"] == "residual_norm":
                gold = gold_residual(torch, case, words, device)
                gold_words = tensor_words_u16(torch, gold)
                gold_bytes = struct.pack(f"<{len(gold_words)}H", *gold_words)
                dtype = "bfloat16"
            elif case["kind"] == "colbert_l2":
                gold = gold_colbert(torch, case, words, device)
                gold_words = tensor_words_f32(torch, gold)
                gold_bytes = struct.pack(f"<{len(gold_words)}I", *gold_words)
                dtype = "float32"
            else:
                fail(f"unknown case kind {case['kind']!r}")

            if not torch.isfinite(gold).all():
                fail(f"gold output is not finite for {case['id']}")
            init_blob = gold_pack.output_blob_spec(case)
            gold_blob = {
                "id": f"{case['id']}/gold",
                "role": "gold",
                "case": case["id"],
                "dtype": dtype,
                "shape": [case["rows"], case["width"]],
                "bytes": None,
                "logical_offset": gold_pack.GUARD_PREFIX_WORDS * (2 if dtype == "bfloat16" else 4),
                "logical_bytes": len(gold_bytes),
                "guard_prefix_words": gold_pack.GUARD_PREFIX_WORDS,
                "guard_suffix_words": gold_pack.GUARD_SUFFIX_WORDS,
                "nullable": False,
                "present": True,
            }
            prefix = [gold_pack.BF16_GUARD_WORD if dtype == "bfloat16" else gold_pack.F32_GUARD_WORD]
            prefix = prefix * gold_pack.GUARD_PREFIX_WORDS
            suffix = prefix * gold_pack.GUARD_SUFFIX_WORDS
            if dtype == "bfloat16":
                full = prefix + gold_words + suffix
                gold_blob["bytes"] = struct.pack(f"<{len(full)}H", *full)
            else:
                full = prefix + gold_words + suffix
                gold_blob["bytes"] = struct.pack(f"<{len(full)}I", *full)
            container_blobs.append((gold_blob, gold_blob["bytes"]))
            container_blobs.append((init_blob, init_blob["bytes"]))
            plan_records.append({
                "id": case["id"],
                "family": case["family"],
                "kind": case["kind"],
                "width": case["width"],
                "rows": case["rows"],
                "eps": case["eps"],
                "pattern": case["pattern"],
                "gold_dtype": dtype,
                "gold_words": len(gold_words),
                "gold_sha256": gold_pack.sha256_bytes(gold_bytes),
            })

    provenance = {
        "producer": "native/primitive_gold_producer.py",
        "producer_sha256": gold_pack.sha256_file(Path(__file__)),
        "gold_pack_sha256": gold_pack.sha256_file(HERE / "gold_pack.py"),
        "torch_version": torch.__version__,
        "torch_cuda": torch.version.cuda,
        "torch_git_version": git_version,
        "cudnn_version": torch.backends.cudnn.version(),
        "native_sdk_sha256": sdk_sha,
        "device": {
            "name": props.name,
            "major": props.major,
            "minor": props.minor,
            "total_memory": props.total_memory,
            "multi_processor_count": props.multi_processor_count,
        },
        "gold_recipe": {
            "a3_plain_norm": "torch.ops.aten.native_layer_norm(input_bf16_cuda, [width], gamma_bf16_cuda, beta_bf16_cuda_or_None, eps)[0]",
            "c3_residual_norm": "pre=(input+[bias]).to(bfloat16); pre=(pre+[residual]).to(bfloat16); native_layer_norm(pre, [width], gamma, beta, eps)[0]",
            "b2_colbert_l2": "norm=linalg_vector_norm(x,2,-1,keepdim=True).to(bfloat16); divisor=norm.clamp_min(eps).to(bfloat16); out=(x/divisor).to(bfloat16).float()",
            "b2_projection_boundary": "input x is the BF16 output of the Native learned token projection; projection is outside this primitive gate",
        },
        "native_l2_source": {
            "path": "libs/infinity-v3/backends/libtorch/cpp/models/multivector_model.h",
            "line": 56,
            "expression": "return states / at::linalg_vector_norm(states, 2, {-1}, true).clamp_min(epsilon);",
        },
        "no_numpy": True,
    }
    header = {
        "schema": gold_pack.CONTAINER_SCHEMA,
        "case_plan_schema": gold_pack.PLAN_SCHEMA,
        "case_plan_sha256": gold_pack.case_plan_sha256(),
        "case_count": len(plan),
        "provenance": provenance,
        "cases": plan_records,
    }
    written = gold_pack.write_container(out_dir / "primitive_gold.bin", header, container_blobs)
    manifest = {
        "schema": "oxide-encoder-primitives-gold-manifest/v1",
        "container": {
            "path": written["path"],
            "bytes": written["bytes"],
            "sha256": written["sha256"],
        },
        "case_plan_sha256": gold_pack.case_plan_sha256(),
        "case_count": len(plan),
        "provenance": provenance,
        "cases": plan_records,
    }
    (out_dir / "primitive_gold.manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    (out_dir / "primitive_gold.plan.json").write_text(
        json.dumps({"schema": gold_pack.PLAN_SCHEMA, "cases": plan}, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "ok": True,
        "container": written["path"],
        "sha256": written["sha256"],
        "cases": len(plan),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
