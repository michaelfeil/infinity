# Encoder primitive Root gate v1

Frozen, CPU-tested packet for three additive device primitives:

| Wave | Export | Source contract | Threads |
| --- | --- | --- | --- |
| A3 | `infinity_plain_layer_norm_bf16_aten` | 7 args, plain ATen Welford BF16 LN | 128 (32x4) |
| C3 | `infinity_deberta_plain_norm_bf16_aten` | 9 args, BF16-rounded bias/residual then LN | 128 (32x4) |
| B2 | `infinity_colbert_l2_bf16_f32` | 5 args, BF16 norm/clamp/divide then F32 widen | 256 |

The 9-argument DeBERTa entry intentionally serves only H384/H1024. H768 uses
the 7-argument entry; this is explicit in `manifest.json`.

## Files

| Path | Purpose |
| --- | --- |
| `manifest.json` | Frozen kernel ABI/dtype/launch/workspace, source pins, case plan, tolerances |
| `frozen/plain_layer_norm_aten.rs` | Byte-identical A3/C3 kernel body |
| `frozen/colbert.rs` | Byte-identical B2 L2 body |
| `native/primitive_gold_producer.py` | Root-only actual Torch-CUDA gold producer |
| `native/gold_pack.py` | Pure-stdlib packing/case/container helpers (no Torch/NumPy) |
| `root_control.py` | Root-only ctypes CUDA-driver unified control |
| `scripts/compile-once.sh` | Frozen Root compile-once + artifact-lock command |
| `scripts/freeze_artifact.py` | Copies one compiled module and writes the artifact lock |
| `scripts/run-root.sh` | Frozen gold + init/mem/plain control sequence |
| `cpu_tests/synthetic_gold_fixture.py` | Structural zeros only; rejected by real modes |
| `cpu_tests/test_packet.py` | CPU tests for packing/guards/ABI/controller |

## Gold

Gold is produced only by actual Torch CUDA operations inside
`/opt/torch-sdk/bin/python3.12`:

- A3: `torch.ops.aten.native_layer_norm` on BF16 CUDA tensors.
- C3: BF16-rounded `input + bias`, then `+ residual`, then the same ATen LN.
- B2: the Native `MultiVectorModel` expression
  `states / at::linalg_vector_norm(states, 2, {-1}, true).clamp_min(epsilon)`
  with model-dtype BF16 norm/clamp/quotient, then F32 widening.

The worker did not import Torch, create a CUDA context, compile a device module,
or produce gold. No CPU reference is used as gold.

## Case coverage (243 cases)

- Norms: widths 384/768/1024, rows 1/5/33, varied eps, normal/offset/
  near-constant patterns, plus null-beta cases.
- DeBERTa residual: widths 384/1024, rows 1/5/33, both/residual-only/bias-only/
  near-constant, null bias/residual coverage.
- ColBERT: widths 64/96/128, rows 1/5/33, zero/tiny/mixed/normal vectors.

Every buffer has 8-word little-endian canaries on both sides; the control also
checks input immutability, output initialization overwrite, BF16 widening,
repeats, and source/artifact immutability.

## CPU gates (run by the worker)

```sh
CUDA_VISIBLE_DEVICES='' taskset -c 160-167 \
  python3 -m unittest discover -s cpu_tests -v
```

Result: 13 tests pass. These cover packing, container hashes, guards, argument
packing (7/9/5 args), ABI/thread/source-pin rejection, artifact-lock mismatch,
synthetic-fixture rejection, source signature contracts, and no-Torch/no-NumPy
controller hygiene. They do not execute a kernel and do not qualify numerics.

## Root gates (not run)

See `ROOT-COMMANDS.md` and `GAPS.md`. Root compiles once, produces actual gold,
then runs `init`/`mem`/`plain` against the same artifact and records exact and
tolerance results. No numeric or performance claim is made here.
