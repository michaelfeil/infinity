#!/usr/bin/env python3
"""Root-only ctypes CUDA-driver control for the frozen encoder primitives.

This is the consumer of the frozen manifest, the frozen kernel source pins, the
compiled module artifact lock, and the actual Torch-CUDA gold container. It
never imports Torch and never computes a LayerNorm/L2 reference. The only math
below is comparison/guard bookkeeping and ctypes argument packing.

Modes (all require the same artifact and artifact lock):
  init   validate manifest/source pins/artifact ABI; upload/readback canaries
  mem    launch, check canaries and input immutability; no gold compare
  plain  launch, check canaries/immutability/ABI, compare every gold word

Run ``--check-only`` on CPU to validate the packet/gold structure without
libcuda. Real modes refuse to start without the Root GPU lock environment.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import math
import os
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "native"))

import gold_pack  # noqa: E402

REPORT_SCHEMA = "oxide-encoder-primitives-report/v1"
GPU_LOCK_ENV = "INFINITY_ENCODER_PRIMITIVES_ROOT"
CUDA_DRIVER = "libcuda.so.1"


class PacketError(Exception):
    pass


def sha256_file(path: Path) -> str:
    return gold_pack.sha256_file(path)


def read_json(path: Path):
    if not path.is_file():
        raise PacketError(f"missing file: {path}")
    with path.open("rb") as handle:
        return json.loads(handle.read())


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def _require(condition, message: str) -> None:
    if not condition:
        raise PacketError(message)


def load_manifest(root: Path) -> tuple[dict, str]:
    path = root / "manifest.json"
    manifest = read_json(path)
    _require(manifest.get("schema") == gold_pack.MANIFEST_SCHEMA,
             f"bad manifest schema: {manifest.get('schema')!r}")
    _require(manifest.get("frozen") is True, "manifest is not frozen")
    manifest_sha = sha256_file(path)

    kernels = manifest.get("kernels")
    _require(isinstance(kernels, list) and kernels, "manifest has no kernels")
    symbols = set()
    for kernel in kernels:
        symbol = kernel.get("symbol")
        _require(symbol and symbol not in symbols, f"bad/duplicate symbol {symbol!r}")
        symbols.add(symbol)
        args = kernel.get("args")
        _require(isinstance(args, list) and args, f"{symbol}: no args")
        _require(kernel.get("arg_count") == len(args),
                 f"{symbol}: arg_count {kernel.get('arg_count')} != {len(args)}")
        for index, arg in enumerate(args):
            _require(arg.get("c_type") in ("ptr", "u32", "f32"),
                     f"{symbol}: arg {index} bad c_type {arg.get('c_type')!r}")
            expected = {"ptr": 8, "u32": 4, "f32": 4}[arg["c_type"]]
            _require(arg.get("param_size") == expected,
                     f"{symbol}: arg {index} param_size {arg.get('param_size')} != {expected}")
        block = kernel.get("block")
        _require(isinstance(block, list) and len(block) == 3, f"{symbol}: bad block")
        threads = block[0] * block[1] * block[2]
        _require(kernel.get("threads") == threads,
                 f"{symbol}: threads {kernel.get('threads')} != {threads}")
        _require(kernel.get("dynamic_shared_bytes") == 0,
                 f"{symbol}: dynamic shared bytes must be zero")
        _require(kernel.get("workspace_bytes") == 0,
                 f"{symbol}: workspace bytes must be zero")

    contracts = manifest.get("contracts", {})
    _require(contracts.get("plain_layer_norm_is_7_args") is True, "7-arg contract missing")
    _require(contracts.get("deberta_residual_norm_is_9_args") is True, "9-arg contract missing")
    _require(contracts.get("colbert_l2_is_5_args") is True, "5-arg contract missing")
    _require(contracts.get("plain_norm_threads") == 128, "plain norm must use 128 threads")
    _require(contracts.get("plain_norm_block") == [128, 1, 1],
             "plain norm must launch block (128,1,1), not the old 2-D (32,4,1)")
    _require(contracts.get("nine_arg_does_not_serve_768") is True,
             "9-arg/768 contract must be explicit")
    _require(contracts.get("norm_widths", {}).get("plain_7_arg") == [384, 768, 1024],
             "plain norm widths")
    _require(contracts.get("norm_widths", {}).get("deberta_9_arg") == [384, 1024],
             "deberta norm widths")
    _require(contracts.get("colbert_widths") == [64, 96, 128], "colbert widths")

    by_symbol = {kernel["symbol"]: kernel for kernel in kernels}
    _require(by_symbol["infinity_plain_layer_norm_bf16_aten"]["arg_count"] == 7, "A3 arg count")
    _require(by_symbol["infinity_deberta_plain_norm_bf16_aten"]["arg_count"] == 9, "C3 arg count")
    _require(by_symbol["infinity_colbert_l2_bf16_f32"]["arg_count"] == 5, "B2 arg count")
    _require(by_symbol["infinity_plain_layer_norm_bf16_aten"]["threads"] == 128, "A3 threads")
    _require(by_symbol["infinity_deberta_plain_norm_bf16_aten"]["threads"] == 128, "C3 threads")
    for symbol in ("infinity_plain_layer_norm_bf16_aten",
                   "infinity_deberta_plain_norm_bf16_aten"):
        _require(by_symbol[symbol]["block"] == [128, 1, 1],
                 f"{symbol}: block must be (128,1,1)")

    plan = gold_pack.build_case_plan()
    errors = gold_pack.validate_case_plan(plan, manifest)
    _require(not errors, "; ".join(errors))

    for pin in manifest.get("source_pins", []):
        path = root / pin["path"]
        _require(path.is_file(), f"missing frozen source {pin['path']}")
        _require(sha256_file(path) == pin["sha256"],
                 f"frozen source hash mismatch: {pin['path']}")
    _require(len(manifest.get("source_pins", [])) == 3,
             "expected main.rs plus the two frozen kernel sources")
    _require(len(manifest.get("wrapper_source_pins", [])) == 1,
             "expected one actual main.rs wrapper pin")
    return manifest, manifest_sha


def verify_composed_sources(root: Path, manifest: dict, composed_root: Path | None) -> dict:
    result = {"composed_root": str(composed_root) if composed_root else None, "checked": []}
    if composed_root is None:
        return result
    mapping = {
        "frozen/main.rs":
            "libs/infinity-v3/backends/oxide/device/src/main.rs",
        "frozen/plain_layer_norm_aten.rs":
            "libs/infinity-v3/backends/oxide/device/src/plain_layer_norm_aten.rs",
        "frozen/colbert.rs":
            "libs/infinity-v3/backends/oxide/device/src/colbert.rs",
    }
    pins = {pin["path"]: pin["sha256"] for pin in manifest["source_pins"]}
    for frozen, live in mapping.items():
        path = composed_root / live
        _require(path.is_file(), f"composed source missing: {path}")
        actual = sha256_file(path)
        _require(actual == pins[frozen],
                 f"composed source differs from frozen pin: {live} {actual}")
        result["checked"].append({"path": live, "sha256": actual})
    return result


def verify_native_l2_source(manifest: dict, native_root: Path | None) -> dict:
    if native_root is None:
        return {"checked": False}
    entry = manifest["native_l2_source"]
    path = native_root / entry["path"]
    _require(path.is_file(), f"native L2 source missing: {path}")
    actual = sha256_file(path)
    _require(actual == entry["sha256"], f"native L2 source hash mismatch: {actual}")
    text = path.read_text()
    _require(entry["expression"] in text, "Native L2 expression not found in source")
    return {"checked": True, "path": entry["path"], "sha256": actual}


def load_gold(root: Path, manifest: dict, allow_missing: bool = False,
              allow_synthetic: bool = False) -> dict:
    path = root / manifest["native_reference"]["gold_container"]
    if not path.is_file():
        if allow_missing:
            return {"present": False, "path": str(path)}
        raise PacketError(f"gold container missing: {path}")
    header, payload = gold_pack.read_container(path)
    _require(header.get("case_plan_sha256") == manifest["case_plan"]["sha256"],
             "gold case plan hash disagrees with manifest")
    _require(header.get("case_count") == manifest["case_plan"]["count"],
             "gold case count disagrees with manifest")
    provenance = header.get("provenance", {})
    expected = manifest["native_reference"]
    synthetic = provenance.get("synthetic_structure_only") is True
    if synthetic:
        if not allow_synthetic:
            raise PacketError("synthetic structure fixture cannot be used as numeric gold")
        _require(provenance.get("no_numpy") is True, "synthetic fixture must declare no NumPy")
    else:
        _require(str(provenance.get("torch_version", "")).startswith(expected["torch_version_prefix"]),
                 f"gold Torch version {provenance.get('torch_version')!r} is not frozen")
        _require(str(provenance.get("native_sdk_sha256", "")).startswith(
            expected["native_sdk_sha256_prefix"]), "gold Native SDK fingerprint is not b66")
        _require(provenance.get("no_numpy") is True, "gold producer must declare no NumPy")
        _require(provenance.get("gold_pack_sha256") ==
                 sha256_file(root / "native" / "gold_pack.py"),
                 "gold was produced by a different gold_pack.py")
        _require(provenance.get("producer_sha256") ==
                 sha256_file(root / "native" / "primitive_gold_producer.py"),
                 "gold was produced by a different primitive_gold_producer.py")
        recipe = provenance.get("gold_recipe", {})
        for key in ("a3_plain_norm", "c3_residual_norm", "b2_colbert_l2"):
            _require(key in recipe, f"gold provenance is missing {key} recipe")
        _require(provenance.get("native_l2_source", {}).get("expression") ==
                 manifest["native_l2_source"]["expression"],
                 "gold Native L2 expression disagrees with manifest")
    plan = gold_pack.build_case_plan()
    planned = {case["id"]: case for case in plan}
    cases = header.get("cases", [])
    _require(len(cases) == len(planned), "gold case count disagrees with the plan")
    blobs = {}
    for blob in header.get("blobs", []):
        key = (blob["case"], blob["role"])
        _require(key not in blobs, f"duplicate gold blob {key}")
        blobs[key] = blob
    for case_id, case in planned.items():
        needed = {"input", "gamma", "gold", "gold_init"}
        if not case["beta_absent"]:
            needed.add("beta")
        if case["kind"] == "residual_norm":
            if case["pattern"] in ("both", "residual_only", "near_constant_both"):
                needed.add("residual")
            if case["pattern"] in ("both", "bias_only", "near_constant_both"):
                needed.add("bias")
        for role in needed:
            _require((case_id, role) in blobs, f"gold missing {case_id}/{role}")
        gold = blobs[(case_id, "gold")]
        expected_dtype = "float32" if case["kind"] == "colbert_l2" else "bfloat16"
        _require(gold["dtype"] == expected_dtype, f"{case_id}: gold dtype")
    return {
        "present": True,
        "synthetic": synthetic,
        "path": str(path),
        "sha256": sha256_file(path),
        "bytes": path.stat().st_size,
        "header": header,
        "payload": payload,
        "blobs": blobs,
    }


def load_artifact_lock(root: Path, manifest: dict, artifact: Path) -> dict:
    lock_path = root / manifest["artifact"]["artifact_lock"]
    lock = read_json(lock_path)
    _require(lock.get("schema") == gold_pack.ARTIFACT_LOCK_SCHEMA, "bad artifact lock schema")
    _require(lock.get("frozen_manifest_sha256") == sha256_file(root / "manifest.json"),
             "artifact lock was not built from this frozen manifest")
    _require(lock.get("source_pins_sha256") == gold_pack.sha256_bytes(
        gold_pack.canonical_json_bytes(manifest["source_pins"])),
        "artifact lock source pins disagree with manifest")
    _require(artifact.is_file(), f"artifact missing: {artifact}")
    actual = sha256_file(artifact)
    _require(actual == lock.get("sha256"), f"artifact hash {actual} != lock {lock.get('sha256')}")
    _require(artifact.stat().st_size == lock.get("bytes"), "artifact size disagrees with lock")
    _require(lock.get("arch") in manifest["artifact"]["allowed_architectures"],
             f"artifact arch {lock.get('arch')!r} is not allowed")
    if lock.get("freeze_mode") == "copy-existing-compiled-bundle-no-build":
        _require(lock.get("bundle_manifest_sha256") ==
                 manifest["artifact"]["source_bundle_manifest_sha256"],
                 "artifact lock bundle manifest hash disagrees with manifest")
        _require(lock.get("symbols") == manifest["artifact"]["expected_symbols"],
                 "artifact lock symbols disagree with manifest")
        arch_entries = [item for item in lock.get("bundle_architectures", [])
                        if item.get("arch") == lock.get("arch")]
        _require(len(arch_entries) == 1, "artifact lock has no unique bundle arch")
        _require(arch_entries[0].get("cubin_sha256") == actual,
                 "artifact lock cubin hash disagrees with the actual artifact")
    return {
        "path": str(artifact),
        "sha256": actual,
        "bytes": artifact.stat().st_size,
        "arch": lock["arch"],
        "lock_sha256": sha256_file(lock_path),
    }


# ---------------------------------------------------------------------------
# ctypes argument packing and guard/comparison helpers (CPU-testable)


def kernel_by_symbol(manifest: dict, symbol: str) -> dict:
    for kernel in manifest["kernels"]:
        if kernel["symbol"] == symbol:
            return kernel
    raise PacketError(f"kernel not in manifest: {symbol}")


def build_kernel_args(kernel: dict, values: dict) -> tuple[object, list, list]:
    ctypes_module = ctypes
    objects = []
    descriptors = []
    for index, arg in enumerate(kernel["args"]):
        name = arg["name"]
        _require(name in values, f"{kernel['symbol']}: missing arg value {name}")
        value = values[name]
        if arg["c_type"] == "ptr":
            if value is None:
                _require(arg.get("nullable") is True,
                         f"{kernel['symbol']}: {name} is not nullable")
                value = 0
            _require(isinstance(value, int) and value >= 0,
                     f"{kernel['symbol']}: bad pointer for {name}")
            obj = ctypes_module.c_uint64(value)
        elif arg["c_type"] == "u32":
            _require(isinstance(value, int) and 0 <= value <= 0xFFFFFFFF,
                     f"{kernel['symbol']}: bad u32 for {name}")
            obj = ctypes_module.c_uint32(value)
        elif arg["c_type"] == "f32":
            _require(isinstance(value, (int, float)) and math.isfinite(float(value)),
                     f"{kernel['symbol']}: bad f32 for {name}")
            obj = ctypes_module.c_float(float(value))
        else:
            raise PacketError(f"{kernel['symbol']}: unsupported c_type {arg['c_type']!r}")
        objects.append(obj)
        descriptors.append({"index": index, "name": name, "param_size": arg["param_size"]})
    array = (ctypes_module.c_void_p * len(objects))(
        *[ctypes_module.cast(ctypes_module.byref(obj), ctypes_module.c_void_p) for obj in objects]
    )
    return array, objects, descriptors


def expected_guard_bytes(dtype: str, words: int) -> bytes:
    if dtype in ("bfloat16", "u16"):
        return struct.pack("<H", gold_pack.BF16_GUARD_WORD) * words
    if dtype in ("float32", "f32"):
        return struct.pack("<I", gold_pack.F32_GUARD_WORD) * words
    raise PacketError(f"unsupported guard dtype {dtype!r}")


def check_guards(raw: bytes, blob: dict) -> list[str]:
    dtype = blob["dtype"]
    elem = gold_pack.DTYPE_BYTES[dtype]
    prefix_words = blob["guard_prefix_words"]
    suffix_words = blob["guard_suffix_words"]
    prefix = expected_guard_bytes(dtype, prefix_words)
    suffix = expected_guard_bytes(dtype, suffix_words)
    errors = []
    if blob["logical_offset"] != len(prefix):
        errors.append(f"{blob['id']}: logical_offset {blob['logical_offset']} != {len(prefix)}")
    if len(raw) < len(prefix) + blob["logical_bytes"] + len(suffix):
        errors.append(f"{blob['id']}: buffer shorter than guards + logical region")
        return errors
    if raw[:len(prefix)] != prefix:
        errors.append(f"{blob['id']}: prefix canary changed")
    if raw[len(prefix) + blob["logical_bytes"]:len(prefix) + blob["logical_bytes"] + len(suffix)] != suffix:
        errors.append(f"{blob['id']}: suffix canary changed")
    return errors


def logical_slice(raw: bytes, blob: dict) -> bytes:
    start = blob["logical_offset"]
    return raw[start:start + blob["logical_bytes"]]


def compare_bf16_words(actual: bytes, expected: bytes) -> dict:
    _require(len(actual) == len(expected) and len(actual) % 2 == 0,
             "BF16 comparison length mismatch")
    actual_words = struct.unpack(f"<{len(actual)//2}H", actual)
    expected_words = struct.unpack(f"<{len(expected)//2}H", expected)
    mismatches = [
        {"index": index, "actual": actual_words[index], "gold": expected_words[index]}
        for index in range(len(actual_words)) if actual_words[index] != expected_words[index]
    ]
    return {
        "kind": "bit_exact_bf16_words",
        "words": len(actual_words),
        "mismatches": len(mismatches),
        "exact": not mismatches,
        "first_mismatches": mismatches[:8],
    }


def compare_f32(actual: bytes, expected: bytes, rel_tol: float, abs_tol: float,
                require_bf16_representable: bool) -> dict:
    _require(len(actual) == len(expected) and len(actual) % 4 == 0,
             "F32 comparison length mismatch")
    actual_words = struct.unpack(f"<{len(actual)//4}I", actual)
    expected_words = struct.unpack(f"<{len(expected)//4}I", expected)
    non_bf16 = [index for index, word in enumerate(actual_words) if word & 0xFFFF]
    if require_bf16_representable and non_bf16:
        raise PacketError(f"B2 output is not BF16-widened at {len(non_bf16)} words")
    exact = 0
    over = []
    max_abs = 0.0
    max_rel = 0.0
    for index, (a_bits, g_bits) in enumerate(zip(actual_words, expected_words)):
        a = struct.unpack("<f", struct.pack("<I", a_bits))[0]
        g = struct.unpack("<f", struct.pack("<I", g_bits))[0]
        if not (math.isfinite(a) and math.isfinite(g)):
            raise PacketError(f"non-finite L2 value at word {index}")
        if a_bits == g_bits:
            exact += 1
            continue
        delta = abs(a - g)
        scale = max(abs(a), abs(g))
        rel = delta / scale if scale else 0.0
        max_abs = max(max_abs, delta)
        max_rel = max(max_rel, rel)
        if delta > abs_tol + rel_tol * scale:
            over.append({"index": index, "actual": a, "gold": g, "abs": delta, "rel": rel})
    return {
        "kind": "bf16_widened_f32",
        "words": len(actual_words),
        "exact": exact,
        "mismatches": len(actual_words) - exact,
        "exact_fraction": exact / len(actual_words) if actual_words else 1.0,
        "over_tolerance": len(over),
        "max_abs": max_abs,
        "max_rel": max_rel,
        "rel_tol": rel_tol,
        "abs_tol": abs_tol,
        "first_over_tolerance": over[:8],
    }


def comparison_for(manifest: dict, kernel: dict) -> dict:
    return manifest["comparison"][kernel["id"]]


# ---------------------------------------------------------------------------
# CUDA driver


def cuda_error_name(result: int) -> str:
    return {
        0: "CUDA_SUCCESS",
        1: "CUDA_ERROR_INVALID_VALUE",
        2: "CUDA_ERROR_OUT_OF_MEMORY",
        3: "CUDA_ERROR_NOT_INITIALIZED",
        4: "CUDA_ERROR_DEINITIALIZED",
        100: "CUDA_ERROR_NO_DEVICE",
        101: "CUDA_ERROR_INVALID_DEVICE",
        209: "CUDA_ERROR_NO_BINARY_FOR_GPU",
        218: "CUDA_ERROR_INVALID_PTX",
        400: "CUDA_ERROR_INVALID_HANDLE",
        500: "CUDA_ERROR_NOT_FOUND",
        700: "CUDA_ERROR_ILLEGAL_ADDRESS",
        701: "CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES",
        719: "CUDA_ERROR_LAUNCH_FAILED",
    }.get(result, f"CUDA_ERROR_{result}")


class CudaDriver:
    def __init__(self):
        self.lib = ctypes.CDLL(CUDA_DRIVER)
        self._bind()

    def _bind(self):
        lib = self.lib
        lib.cuInit.argtypes = [ctypes.c_uint]
        lib.cuInit.restype = ctypes.c_int
        lib.cuDeviceGet.argtypes = [ctypes.POINTER(ctypes.c_int), ctypes.c_int]
        lib.cuDeviceGet.restype = ctypes.c_int
        lib.cuDevicePrimaryCtxRetain.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_int]
        lib.cuDevicePrimaryCtxRetain.restype = ctypes.c_int
        lib.cuDevicePrimaryCtxRelease.argtypes = [ctypes.c_int]
        lib.cuDevicePrimaryCtxRelease.restype = ctypes.c_int
        lib.cuCtxSetCurrent.argtypes = [ctypes.c_void_p]
        lib.cuCtxSetCurrent.restype = ctypes.c_int
        lib.cuModuleLoadData.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p]
        lib.cuModuleLoadData.restype = ctypes.c_int
        lib.cuModuleGetFunction.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p,
                                            ctypes.c_char_p]
        lib.cuModuleGetFunction.restype = ctypes.c_int
        lib.cuModuleUnload.argtypes = [ctypes.c_void_p]
        lib.cuModuleUnload.restype = ctypes.c_int
        self.param_info = getattr(lib, "cuFuncGetParamInfo", None)
        if self.param_info is not None:
            self.param_info.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
                                        ctypes.POINTER(ctypes.c_size_t),
                                        ctypes.POINTER(ctypes.c_size_t)]
            self.param_info.restype = ctypes.c_int
        lib.cuMemAlloc_v2.argtypes = [ctypes.POINTER(ctypes.c_uint64), ctypes.c_size_t]
        lib.cuMemAlloc_v2.restype = ctypes.c_int
        lib.cuMemFree_v2.argtypes = [ctypes.c_uint64]
        lib.cuMemFree_v2.restype = ctypes.c_int
        lib.cuMemcpyHtoD_v2.argtypes = [ctypes.c_uint64, ctypes.c_void_p, ctypes.c_size_t]
        lib.cuMemcpyHtoD_v2.restype = ctypes.c_int
        lib.cuMemcpyDtoH_v2.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_size_t]
        lib.cuMemcpyDtoH_v2.restype = ctypes.c_int
        lib.cuLaunchKernel.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint,
                                       ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
                                       ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p,
                                       ctypes.c_void_p, ctypes.c_void_p]
        lib.cuLaunchKernel.restype = ctypes.c_int
        lib.cuCtxSynchronize.argtypes = []
        lib.cuCtxSynchronize.restype = ctypes.c_int
        lib.cuGetErrorName.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_char_p)]
        lib.cuGetErrorName.restype = ctypes.c_int
        self.context = ctypes.c_void_p()
        self.device = ctypes.c_int()
        self.module = ctypes.c_void_p()

    def check(self, result: int, where: str) -> None:
        if result == 0:
            return
        name = cuda_error_name(result)
        error_name = ctypes.c_char_p()
        if self.lib.cuGetErrorName(result, ctypes.byref(error_name)) == 0 and error_name.value:
            name = error_name.value.decode()
        raise PacketError(f"{where}: {name} ({result})")

    def init(self) -> None:
        self.check(self.lib.cuInit(0), "cuInit")
        self.check(self.lib.cuDeviceGet(ctypes.byref(self.device), 0), "cuDeviceGet")
        self.check(self.lib.cuDevicePrimaryCtxRetain(ctypes.byref(self.context), self.device),
                   "cuDevicePrimaryCtxRetain")
        self.check(self.lib.cuCtxSetCurrent(self.context), "cuCtxSetCurrent")

    def load_module(self, artifact: Path) -> None:
        data = artifact.read_bytes()
        if artifact.suffix.lower() in (".ptx", ".ptx.txt"):
            data += b"\x00"
        image = ctypes.create_string_buffer(data, len(data))
        self.check(self.lib.cuModuleLoadData(ctypes.byref(self.module),
                                             ctypes.cast(image, ctypes.c_void_p)),
                   "cuModuleLoadData")

    def function(self, symbol: str):
        func = ctypes.c_void_p()
        self.check(self.lib.cuModuleGetFunction(ctypes.byref(func), self.module,
                                                symbol.encode()),
                   f"cuModuleGetFunction({symbol})")
        return func

    def verify_abi(self, kernel: dict, func) -> dict:
        if self.param_info is None:
            raise PacketError("cuFuncGetParamInfo unavailable; cannot reject ABI mismatch")
        checked = []
        for index, arg in enumerate(kernel["args"]):
            offset = ctypes.c_size_t()
            size = ctypes.c_size_t()
            result = self.param_info(func, index, ctypes.byref(offset), ctypes.byref(size))
            self.check(result, f"{kernel['symbol']} param {index} info")
            if size.value != arg["param_size"]:
                raise PacketError(
                    f"{kernel['symbol']} ABI mismatch at param {index} ({arg['name']}): "
                    f"artifact size {size.value} != manifest {arg['param_size']}")
            checked.append({"index": index, "name": arg["name"], "param_size": size.value,
                            "offset": offset.value})
        offset = ctypes.c_size_t()
        size = ctypes.c_size_t()
        extra = self.param_info(func, len(kernel["args"]), ctypes.byref(offset),
                                ctypes.byref(size))
        if extra == 0:
            raise PacketError(f"{kernel['symbol']}: artifact has extra kernel parameters")
        return {"symbol": kernel["symbol"], "args": checked, "param_info": True}

    def alloc(self, size: int) -> int:
        pointer = ctypes.c_uint64()
        self.check(self.lib.cuMemAlloc_v2(ctypes.byref(pointer), size), "cuMemAlloc_v2")
        return pointer.value

    def free(self, pointer: int) -> None:
        self.check(self.lib.cuMemFree_v2(ctypes.c_uint64(pointer)), "cuMemFree_v2")

    def hto_d(self, pointer: int, data: bytes) -> None:
        buffer = ctypes.create_string_buffer(data, len(data))
        self.check(self.lib.cuMemcpyHtoD_v2(ctypes.c_uint64(pointer),
                                            ctypes.cast(buffer, ctypes.c_void_p),
                                            len(data)), "cuMemcpyHtoD_v2")

    def dto_h(self, pointer: int, size: int) -> bytes:
        buffer = ctypes.create_string_buffer(size)
        self.check(self.lib.cuMemcpyDtoH_v2(ctypes.cast(buffer, ctypes.c_void_p),
                                            ctypes.c_uint64(pointer), size),
                   "cuMemcpyDtoH_v2")
        return bytes(buffer.raw)

    def launch(self, kernel: dict, func, values: dict) -> None:
        array, keepalive, _ = build_kernel_args(kernel, values)
        grid_x = int(values["rows"])
        block = kernel["block"]
        self.check(self.lib.cuLaunchKernel(
            func, grid_x, 1, 1, block[0], block[1], block[2],
            kernel["dynamic_shared_bytes"], None, ctypes.cast(array, ctypes.c_void_p), None),
            f"cuLaunchKernel({kernel['symbol']})")
        _ = keepalive  # keep ctypes argument storage alive through the launch
        self.check(self.lib.cuCtxSynchronize(), "cuCtxSynchronize")

    def close(self) -> None:
        if self.module:
            self.lib.cuModuleUnload(self.module)
            self.module = ctypes.c_void_p()
        if self.context:
            self.lib.cuDevicePrimaryCtxRelease(self.device.value)
            self.context = ctypes.c_void_p()


# ---------------------------------------------------------------------------
# Case execution


def role_pointer_map(device_pointers: dict) -> dict:
    values = {}
    for role, pointer in device_pointers.items():
        values[role] = pointer
    return values


def run_case(driver: CudaDriver, kernel: dict, func, case: dict, blobs: dict,
             gold: dict, mode: str, comparison: dict) -> dict:
    case_id = case["id"]
    case_blobs = {role: blobs[(case_id, role)] for role in
                  ("input", "gamma", "beta", "residual", "bias", "gold", "gold_init")
                  if (case_id, role) in blobs}
    payload = gold["payload"]
    raw_host = {}
    for role, blob in case_blobs.items():
        raw_host[role] = payload[blob["offset"]:blob["offset"] + blob["bytes"]]
    device = {}
    try:
        for role, raw in raw_host.items():
            if role == "gold":
                continue
            pointer = driver.alloc(len(raw))
            device[role] = pointer
            driver.hto_d(pointer, raw)
        if mode == "controller-init":
            for role in ("input", "gamma", "beta", "residual", "bias", "gold_init"):
                if role not in device:
                    continue
                raw = driver.dto_h(device[role], len(raw_host[role]))
                errors = check_guards(raw, case_blobs[role])
                if errors:
                    raise PacketError(f"{case_id}/{role}: " + "; ".join(errors))
                if raw != raw_host[role]:
                    raise PacketError(f"{case_id}/{role}: init upload/readback changed data")
            return {"id": case_id, "status": "ok", "mode": mode, "launched": False}

        values = role_pointer_map(device)
        values.update({"rows": case["rows"], "width": case["width"], "eps": case["eps"]})
        arg_names = {arg["name"] for arg in kernel["args"]}
        if "out" in arg_names:
            values["out"] = device["gold_init"]
        if "output" in arg_names:
            values["output"] = device["gold_init"]
        if "beta" not in device and "beta" in arg_names:
            values["beta"] = None
        if "residual" not in device:
            values["residual"] = None
        if "bias" not in device:
            values["bias"] = None
        driver.launch(kernel, func, values)

        errors = []
        readbacks = {}
        for role, raw in raw_host.items():
            if role == "gold":
                continue
            actual = driver.dto_h(device[role], len(raw))
            readbacks[role] = actual
            errors.extend(check_guards(actual, case_blobs[role]))
            if role != "gold_init" and actual != raw:
                errors.append(f"{case_id}/{role}: input buffer was mutated")
        if errors:
            raise PacketError("; ".join(errors))

        output = logical_slice(readbacks["gold_init"], case_blobs["gold_init"])
        result = {"id": case_id, "status": "ok", "mode": mode, "launched": True,
                  "output_sha256": sha256_bytes(output)}
        if mode == "plain":
            actual = output
            expected = logical_slice(raw_host["gold"], case_blobs["gold"])
            if case_blobs["gold"]["dtype"] == "bfloat16":
                cmp = compare_bf16_words(actual, expected)
                result["comparison"] = cmp
                if not cmp["exact"]:
                    result["status"] = "mismatch"
            else:
                cmp = compare_f32(actual, expected, comparison["rel_tol"],
                                  comparison["abs_tol"],
                                  comparison.get("require_bf16_representable", True))
                result["comparison"] = cmp
                if cmp["over_tolerance"]:
                    result["status"] = "mismatch"
        return result
    finally:
        for pointer in device.values():
            driver.free(pointer)


def run_mode(root: Path, manifest: dict, manifest_sha: str, gold: dict, artifact: Path,
             lock: dict, mode: str, repeat: int, composed_root: Path | None,
             native_root: Path | None) -> dict:
    if not os.environ.get("CUDA_VISIBLE_DEVICES"):
        raise PacketError("CUDA_VISIBLE_DEVICES must be set for every real GPU mode")
    if os.environ.get(GPU_LOCK_ENV) != "1":
        raise PacketError(f"set {GPU_LOCK_ENV}=1 to assert Root ownership of GPU0")
    source_before = {pin["path"]: sha256_file(root / pin["path"])
                     for pin in manifest["source_pins"]}
    artifact_sha_before = sha256_file(artifact)
    driver = CudaDriver()
    try:
        driver.init()
        driver.load_module(artifact)
        functions = {}
        abi = []
        for kernel in manifest["kernels"]:
            func = driver.function(kernel["symbol"])
            functions[kernel["symbol"]] = func
            abi.append(driver.verify_abi(kernel, func))
        plan = gold_pack.build_case_plan()
        reports = []
        if mode == "controller-init":
            # No launches; still exercise allocation/upload/readback for every case.
            for case in plan:
                kernel = kernel_by_symbol(manifest, case["symbol"])
                reports.append(run_case(driver, kernel, functions[kernel["symbol"]], case,
                                        gold["blobs"], gold, mode,
                                        comparison_for(manifest, kernel)))
        else:
            for case in plan:
                kernel = kernel_by_symbol(manifest, case["symbol"])
                case_reports = []
                for _ in range(repeat):
                    case_reports.append(run_case(driver, kernel, functions[kernel["symbol"]],
                                                 case, gold["blobs"], gold, mode,
                                                 comparison_for(manifest, kernel)))
                hashes = [item.get("output_sha256") for item in case_reports]
                deterministic = len(set(hashes)) == 1
                status = ("ok" if all(item["status"] == "ok" for item in case_reports)
                          and deterministic else "mismatch")
                reports.append({**case_reports[0], "status": status, "repeats": repeat,
                                "repeat_statuses": [item["status"] for item in case_reports],
                                "repeat_hashes": hashes,
                                "deterministic": deterministic})
        source_after = {pin["path"]: sha256_file(root / pin["path"])
                        for pin in manifest["source_pins"]}
        artifact_sha_after = sha256_file(artifact)
        if source_before != source_after:
            raise PacketError("frozen kernel source changed during the run")
        if artifact_sha_before != artifact_sha_after:
            raise PacketError("compiled artifact changed during the run")
        failures = [item for item in reports if item["status"] != "ok"]
        return {
            "schema": REPORT_SCHEMA,
            "mode": mode,
            "status": "pass" if not failures else "fail",
            "manifest_sha256": manifest_sha,
            "artifact": {**lock, "sha256": artifact_sha_before},
            "gold": {"path": gold["path"], "sha256": gold["sha256"]},
            "composed_sources": verify_composed_sources(root, manifest, composed_root),
            "native_l2_source": verify_native_l2_source(manifest, native_root),
            "abi": abi,
            "repeat": repeat,
            "cases": reports,
            "summary": {
                "cases": len(reports),
                "passed": len(reports) - len(failures),
                "failed": len(failures),
                "failed_ids": [item["id"] for item in failures[:16]],
            },
        }
    finally:
        driver.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(HERE))
    parser.add_argument("--gold", default=None)
    parser.add_argument("--artifact", default=None)
    parser.add_argument("--mode", choices=["controller-init", "controller-mem", "plain"],
                        default="plain")
    parser.add_argument("--repeat", type=int, default=3)
    parser.add_argument("--report", default=None)
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--allow-missing-gold", action="store_true")
    parser.add_argument("--allow-synthetic-fixture", action="store_true")
    parser.add_argument("--composed-root", default=None)
    parser.add_argument("--native-source-root", default=None)
    args = parser.parse_args()

    root = Path(args.root).resolve()
    try:
        manifest, manifest_sha = load_manifest(root)
        composed = verify_composed_sources(root, manifest,
                                           Path(args.composed_root) if args.composed_root else None)
        native = verify_native_l2_source(manifest, Path(args.native_source_root)
                                         if args.native_source_root else None)
        if args.allow_synthetic_fixture and not args.check_only:
            raise PacketError("--allow-synthetic-fixture is check-only")
        gold = load_gold(root, manifest, allow_missing=args.allow_missing_gold,
                         allow_synthetic=args.allow_synthetic_fixture)
        if args.check_only:
            print(json.dumps({
                "ok": True,
                "check_only": True,
                "manifest_sha256": manifest_sha,
                "cases": manifest["case_plan"]["count"],
                "gold_present": gold.get("present", False),
                "gold_synthetic": gold.get("synthetic", False),
                "gold_sha256": gold.get("sha256"),
                "composed_sources": composed,
                "native_l2_source": native,
            }, sort_keys=True))
            return 0
        if args.artifact is None:
            raise PacketError("--artifact is required for real modes")
        artifact = Path(args.artifact).resolve()
        lock = load_artifact_lock(root, manifest, artifact)
        if args.mode != "plain" and os.environ.get("INFINITY_ENCODER_PRIMITIVES_SANITIZER") == "1":
            raise PacketError("sanitizer wrappers must run --mode plain")
        if args.repeat < 1:
            raise PacketError("--repeat must be positive")
        report = run_mode(root, manifest, manifest_sha, gold, artifact, lock, args.mode,
                          args.repeat, Path(args.composed_root) if args.composed_root else None,
                          Path(args.native_source_root) if args.native_source_root else None)
        if args.report:
            write_json(Path(args.report), report)
        print(json.dumps({"ok": report["status"] == "pass", "mode": report["mode"],
                          "summary": report["summary"],
                          "artifact_sha256": report["artifact"]["sha256"]}, sort_keys=True))
        return 0 if report["status"] == "pass" else 1
    except PacketError as error:
        print(f"root_control: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
