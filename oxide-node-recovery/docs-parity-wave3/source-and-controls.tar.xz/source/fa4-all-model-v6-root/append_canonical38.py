#!/usr/bin/env python3
"""Root-only canonical31 -> canonical38 append for the shared FA4 provider.

Preserves all 70 canonical31 objects per architecture, compiles only the 14
new dtype objects for modes 31..37, merges the canonical38 manifest and relinks
the bridge with the extended u64 mode query. The author never runs device code.

The frozen source worker is read-only input via --source; this packet does not
copy or duplicate it.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

BASE_PROFILE_COUNT = 31
FIRST_NEW_MODE = 31
LAST_NEW_MODE = 37
OLD_COUNT = 70
NEW_COUNT = 14
TOTAL_COUNT = 84
EXPECTED_SOURCE_FINGERPRINT = (
    "5308427d3c2f149dba100ef7235843df3693b11dd125ccb78288616bd7dcd99d"
)
EXPECTED_OLD_FINGERPRINT = (
    "187defaacc9f9b9b326b392fbeda675545a73660f44f69e21743743f782a87f1"
)
EXPECTED_OLD_REGISTRY = {
    "namespace": "canonical31",
    "mode_count": 31,
    "mode_mask": "0x7fffffff",
    "profile_sequence_sha256": EXPECTED_OLD_FINGERPRINT,
}
TAIL = [
    ("qwen2_q14kv2_d64_causal", 14, 2, 64, True, False),
    ("qwen2_q12kv2_d128_causal", 12, 2, 128, True, False),
    ("llama_q32kv8_d64_noncausal", 32, 8, 64, False, False),
    ("gemma3_global_d256_gqa2", 16, 8, 256, True, False),
    ("gemma3_local1024_d256_gqa2", 16, 8, 256, True, True),
    ("gemma3_local1024_d128_gqa2", 32, 16, 128, True, True),
    ("gemma4_e4b_local1024_d256_gqa4", 8, 2, 256, True, True),
]


def digest(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path: Path) -> dict:
    return json.loads(Path(path).read_text())


def die(message: str) -> None:
    print(f"append-canonical38: {message}", file=sys.stderr)
    raise SystemExit(2)


def atomic_write(path: Path, payload: str) -> None:
    """Publish one manifest atomically on the output filesystem."""
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def _contract(source: Path):
    sys.path.insert(0, str(source))
    import build_contract  # noqa: PLC0415

    return build_contract


def expected_symbols(source: Path, count: int) -> list[str]:
    contract = _contract(source)
    rows = contract.canonical_rows_for(count)
    names = [row[0] for row in rows]
    return contract.expected_kernel_symbols(names)


def validate_source(source: Path) -> dict:
    source = source.resolve()
    contract = _contract(source)
    rows = contract.validate_profiles_inc(source / "profiles.inc")
    if len(rows) != 38:
        die(f"source profiles.inc must declare 38 rows, got {len(rows)}")
    if rows[:BASE_PROFILE_COUNT] != list(contract.CANONICAL31_PROFILES):
        die("source modes 0..30 differ from the frozen canonical31 prefix")
    if rows[BASE_PROFILE_COUNT:] != TAIL:
        die(f"source canonical38 tail differs: {rows[BASE_PROFILE_COUNT:]!r}")
    if contract.PROFILE_SEQUENCE_SHA256 != EXPECTED_SOURCE_FINGERPRINT:
        die("source canonical38 fingerprint differs")
    if contract.canonical_registry_for(31) != EXPECTED_OLD_REGISTRY:
        die("source canonical31 registry identity differs")
    bridge = (source / "bridge.cpp").read_text()
    if "infinity_fa4_modes_v1()" not in bridge:
        die("source bridge lacks legacy signed mode query")
    if "uint64_t infinity_fa4_modes_v2()" not in bridge:
        die("source bridge lacks extended u64 mode query")
    build = (source / "build.py").read_text()
    for token in ('38: "canonical38"', "canonical31_inventory",
                  '"abi_version": 7', '"native_abi_version": 1'):
        if token not in build:
            die(f"source build.py lacks {token}")
    return {
        "profiles": len(rows),
        "old_prefix_profiles": BASE_PROFILE_COUNT,
        "fingerprint": contract.PROFILE_SEQUENCE_SHA256,
        "old_fingerprint": EXPECTED_OLD_FINGERPRINT,
        "tail": [list(row) for row in rows[BASE_PROFILE_COUNT:]],
        "canonical38_registry": contract.canonical_registry_for(38),
        "expected_symbols": len(expected_symbols(source, 38)),
    }


def validate_source_freeze(source: Path, freeze_path: Path) -> dict:
    freeze = load(freeze_path)
    changed = freeze.get("changed_files")
    if not isinstance(changed, dict):
        die("source freeze lacks changed_files")
    prefix = "libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4/"
    checked = 0
    for name, expected in changed.items():
        if not name.startswith(prefix):
            continue
        relative = name[len(prefix):]
        path = source / relative
        if not path.is_file():
            die(f"source freeze file is missing: {relative}")
        if digest(path) != expected:
            die(f"source freeze hash differs: {relative}")
        checked += 1
    if checked == 0:
        die("source freeze contains no FA4 vendor files")
    return {"files": checked, "freeze_sha256": digest(freeze_path)}


def validate_receipt(baseline: Path, receipt_path: Path) -> dict:
    receipt = load(receipt_path)
    records = receipt.get("records")
    if not isinstance(records, list):
        die("baseline receipt lacks records")
    target = baseline.resolve()
    for record in records:
        if Path(record.get("root", "")).resolve() != target:
            continue
        manifest = baseline / "manifest.json"
        library = baseline / "libinfinityfa4.so"
        if record.get("manifest_sha256") != digest(manifest):
            die("baseline manifest hash differs from the verified receipt")
        if record.get("library_sha256") != digest(library):
            die("baseline library hash differs from the verified receipt")
        if record.get("objects") != OLD_COUNT:
            die("baseline receipt does not record 70 old objects")
        return {
            "architecture": record.get("architecture"),
            "manifest_sha256": record.get("manifest_sha256"),
            "library_sha256": record.get("library_sha256"),
            "objects": record.get("objects"),
            "receipt_sha256": digest(receipt_path),
        }
    die("baseline is not present in the verified receipt")


def validate_baseline(baseline: Path, source: Path) -> dict:
    manifest_path = baseline / "manifest.json"
    if not manifest_path.is_file():
        die(f"baseline manifest is missing: {manifest_path}")
    manifest = load(manifest_path)
    if manifest.get("abi_version") != 7 or manifest.get("native_abi_version") not in (None, 1):
        die("baseline is not export ABI7/native ABI1")
    if manifest.get("registry") != EXPECTED_OLD_REGISTRY:
        die(f"baseline registry is not canonical31: {manifest.get('registry')}")
    kernels = manifest.get("kernels")
    objects = manifest.get("objects")
    if not isinstance(kernels, list) or len(kernels) != OLD_COUNT:
        die(f"baseline must have {OLD_COUNT} kernels")
    if not isinstance(objects, dict) or len(objects) != OLD_COUNT:
        die(f"baseline must have {OLD_COUNT} objects")
    contract = _contract(source)
    names = [row[0] for row in contract.canonical_rows_for(BASE_PROFILE_COUNT)]
    expected = contract.expected_kernel_symbols(names)
    if [kernel.get("symbol") for kernel in kernels] != expected:
        die("baseline kernel order/dtype coverage differs from canonical31")
    expected_link = [f"{symbol}.o" for symbol in contract.expected_link_symbols(names)]
    if expected_link != manifest.get("link_object_order"):
        die("baseline link object order differs from canonical31")
    if any(
        kernel.get("symbol", "").replace("fa4_", "").rsplit("_", 1)[0]
        in {row[0] for row in TAIL}
        for kernel in kernels
    ):
        die("baseline already contains a canonical38 tail symbol")
    for name, expected_hash in objects.items():
        path = baseline / name
        if not path.is_file():
            die(f"baseline object is missing: {name}")
        if digest(path) != expected_hash:
            die(f"baseline object hash differs: {name}")
    for name in manifest.get("link_object_order", []):
        if name not in objects:
            die(f"baseline link object is missing from objects: {name}")
    if len(set(manifest.get("link_object_order", []))) != OLD_COUNT:
        die("baseline link object order contains duplicates")
    try:
        contract.validate_manifest_inventory(
            manifest, contract.canonical_rows_for(BASE_PROFILE_COUNT))
    except RuntimeError as error:
        die(f"baseline kernel/registry contract differs: {error}")
    return manifest


def stage_patch_and_verify(
    source: Path,
    capability: int,
    manifest: dict,
    contract,
):
    """Stage FA4, apply the SM100 local patch, then verify source identity.

    The order is compile-critical: build_contract.verify_source_identity for
    capability 100 expects the *after-patch* hashes. This helper performs the
    patch and check before Torch/flash_attn import and is injectable for the
    CPU ordering test.
    """
    from fa4_source import stage_fa4_sources  # noqa: PLC0415

    staged, softmax = stage_fa4_sources()
    if softmax != manifest["softmax_backport"]:
        die("staged FA4 softmax policy differs from baseline")
    patch = None
    if capability == 100:
        from gemma_sm100_local import patch_interface  # noqa: PLC0415

        patch = patch_interface(Path(staged.name) / "flash_attn/cute/interface.py")
        if patch != manifest["gemma_sm100_local_source_patch"]:
            die("SM100 local source patch differs from the qualified baseline")
    lock = contract.load_source_lock(source / "fa4_source_lock.json")
    before = contract.verify_source_identity(
        Path(staged.name) / "flash_attn/cute", capability, lock
    )
    return staged, patch, before


def compile_new_objects(
    source: Path,
    baseline: Path,
    output: Path,
    python: Path,
    runtime_dir: Path,
    ffi_root: Path,
) -> tuple[list[dict], dict]:
    """Compile the 14 appended objects only. Root-only; never called by tests."""
    manifest = load(baseline / "manifest.json")
    arch = manifest["architecture"]
    capability = int(arch.removeprefix("sm_").removesuffix("a"))
    contract = _contract(source)
    contract.validate_compile_env(os.environ, True)
    os.environ.update(
        FLASH_ATTENTION_ARCH=arch,
        CUTE_DSL_ARCH=arch,
        FLASH_ATTENTION_NUM_SMS=str(manifest["target_sm_count"]),
    )
    staged, patch, before = stage_patch_and_verify(
        source, capability, manifest, contract)
    import torch  # noqa: PLC0415

    if torch.cuda.is_initialized():
        die("CUDA context initialized after torch import")
    import flash_attn.cute.interface as interface  # noqa: PLC0415
    if torch.cuda.is_initialized():
        die("CUDA context initialized after flash_attn import")
    lock = contract.load_source_lock(source / "fa4_source_lock.json")
    after = contract.verify_source_identity(
        Path(interface.__file__).parent, capability, lock
    )
    if importlib.metadata.version("nvidia-cutlass-dsl") != manifest["cutlass_dsl"]:
        die("cutlass-dsl version differs from baseline")
    from compile_only import install_export_only_compile  # noqa: PLC0415
    from portable_host import export_portable  # noqa: PLC0415

    state = install_export_only_compile(interface.cute)
    from torch._subclasses.fake_tensor import FakeTensorMode  # noqa: PLC0415

    rows = contract.validate_profiles_inc(source / "profiles.inc")
    new_kernels = []
    with FakeTensorMode():
        offsets = torch.tensor([0, 127, 256], device="cuda", dtype=torch.int32)
        for mode in range(FIRST_NEW_MODE, LAST_NEW_MODE + 1):
            name, heads, kv_heads, head_dim, causal, local = rows[mode]
            window = contract.canonical_window(mode, name, causal, local)
            for dtype_name, dtype in (("fp16", torch.float16), ("bf16", torch.bfloat16)):
                q = torch.zeros((256, heads, head_dim), device="cuda", dtype=dtype)
                k = torch.zeros((256, kv_heads, head_dim), device="cuda", dtype=dtype)
                cache = interface._flash_attn_fwd.compile_cache.cache
                cache.clear()
                if cache:
                    die("FA4 compile cache did not clear")
                if head_dim == 256 and window[0] is not None and capability == 100:
                    interface._flash_attn_fwd(
                        q, k, k, cu_seqlens_q=offsets, cu_seqlens_k=offsets,
                        max_seqlen_q=129, max_seqlen_k=129, tile_mn=(128, 64),
                        num_splits=1, pack_gqa=False, causal=causal,
                        window_size_left=window[0], window_size_right=window[1],
                        disable_scheduler_metadata=True,
                    )
                elif head_dim == 256 and capability in (80, 86, 89, 120):
                    interface._flash_attn_fwd(
                        q, k, k, cu_seqlens_q=offsets, cu_seqlens_k=offsets,
                        max_seqlen_q=129, max_seqlen_k=129, tile_mn=(64, 64),
                        num_splits=1, pack_gqa=False, causal=causal,
                        window_size_left=window[0], window_size_right=window[1],
                        disable_scheduler_metadata=True,
                    )
                else:
                    interface.flash_attn_varlen_func(
                        q, k, k, cu_seqlens_q=offsets, cu_seqlens_k=offsets,
                        max_seqlen_q=129, max_seqlen_k=129, causal=causal,
                        window_size=window, disable_scheduler_metadata=True,
                    )
                if len(cache) != 1:
                    die(f"{name}/{dtype_name}: expected exactly one compiled new kernel")
                compiled = next(iter(cache.values()))
                symbol = f"fa4_{name}_{dtype_name}"
                export_portable(compiled, output / f"{symbol}.o", symbol)
                if torch.cuda.is_initialized():
                    die("CUDA context initialized during fake-tensor export")
                cache.clear()
                new_kernels.append(
                    contract.profile_kernel(
                        mode, name, heads, kv_heads, head_dim, causal, window, dtype_name
                    )
                )
    if len(state["calls"]) != len(new_kernels) or not all(
        call["engine_is_none"] and call["real_IR_present"] for call in state["calls"]
    ):
        die("AOT-only real IR / absent runtime JIT engine proof missing")
    proof = {
        "source_identity_before": before,
        "source_identity_after": after,
        "gemma_sm100_local_source_patch": patch,
        "fake_tensor_inputs": True,
        "cuda_initialized": torch.cuda.is_initialized(),
        "compile_only_engine_control": state,
        "new_objects": {kernel["symbol"]: digest(output / f"{kernel['symbol']}.o")
                        for kernel in new_kernels},
    }
    return new_kernels, proof


def merge_manifest(
    source: Path,
    baseline: Path,
    output: Path,
    new_kernels: list[dict],
    proof: dict,
    provenance: dict | None = None,
) -> dict:
    contract = _contract(source)
    original = load(baseline / "manifest.json")
    rows = contract.validate_profiles_inc(source / "profiles.inc")
    names = [row[0] for row in rows]
    manifest = copy.deepcopy(original)
    manifest["registry"] = dict(contract.canonical_registry_for(38))
    manifest["kernels"] = original["kernels"] + list(new_kernels)
    expected = contract.expected_kernel_symbols(names)
    if [kernel["symbol"] for kernel in manifest["kernels"]] != expected:
        manifest["kernels"] = contract.canonical_metadata_order(
            original["kernels"] + list(new_kernels), names)
        if [kernel["symbol"] for kernel in manifest["kernels"]] != expected:
            die("merged kernel order is not canonical38")
    manifest["objects"] = {
        f"{kernel['symbol']}.o": digest(output / f"{kernel['symbol']}.o")
        for kernel in manifest["kernels"]
    }
    manifest.pop("canonical26_inventory", None)
    manifest.pop("canonical31_inventory", None)
    manifest["canonical38_inventory"] = {"exact_order": True, "symbols": expected}
    # Keep the shared build_contract key available for legacy consumers.
    manifest["canonical31_inventory"] = {"exact_order": True, "symbols": expected}
    manifest["link_object_order"] = [
        f"{symbol}.o" for symbol in contract.expected_link_symbols(names)
    ]
    control = proof.get("compile_only_engine_control", {"calls": []})
    manifest["compile_only_engine_control"] = control
    manifest["compile_cache_isolation"] = {
        "policy": "clear-cache-before-and-after-every-export",
        "exports": len(new_kernels),
        "compile_callbacks": len(control.get("calls", [])),
        "cache_entries_after_each_compile": 1,
    }
    manifest["canonical38_additive"] = {
        "baseline_manifest": str(baseline / "manifest.json"),
        "baseline_manifest_sha256": digest(baseline / "manifest.json"),
        "old_objects_exact": True,
        "old_object_count": OLD_COUNT,
        "new_object_count": len(new_kernels),
        "new_modes": [
            {
                "mode": mode, "profile": name, "heads": heads,
                "kv_heads": kv_heads, "d": head_dim, "causal": causal,
                "window": list(contract.canonical_window(mode, name, causal, local)),
            }
            for mode, (name, heads, kv_heads, head_dim, causal, local) in enumerate(rows)
            if mode >= BASE_PROFILE_COUNT
        ],
        "source_contract": "canonical38",
        "source_fingerprint": contract.PROFILE_SEQUENCE_SHA256,
        "source_profiles_sha256": digest(source / "profiles.inc"),
        "source_manifest_provenance": provenance or {},
        "source_proof": proof,
        "old_70_objects_preserved": {
            name: digest(output / name) for name in original["objects"]
        },
    }
    manifest["metadata_derivation"] = {
        "schema": "infinity-fa4-canonical38-append/v1",
        "base": "canonical31",
        "first_mode": FIRST_NEW_MODE,
        "last_mode": LAST_NEW_MODE,
        "append_only": True,
    }
    atomic_write(output / "manifest.json", json.dumps(manifest, indent=2) + "\n")
    return manifest


def _link_command(source: Path, output: Path, manifest: dict, runtime_dir: Path,
                  ffi_root: Path, python: Path) -> list[str]:
    return [
        str(python), str(source / "build.py"), str(output),
        "--link-only", "--arch", manifest["architecture"],
        "--runtime-dir", str(runtime_dir), "--ffi-root", str(ffi_root),
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True,
                        help="canonical38 FA4 vendor source directory")
    parser.add_argument("--baseline", type=Path, required=True,
                        help="one canonical31 architecture provider directory")
    parser.add_argument("--output", type=Path, required=True,
                        help="fresh canonical38 output directory")
    parser.add_argument("--runtime-dir", type=Path, required=True)
    parser.add_argument("--ffi-root", type=Path, required=True)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument("--source-freeze", type=Path)
    parser.add_argument("--receipt", type=Path)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    source = args.source.resolve()
    baseline = args.baseline.resolve()
    output = args.output.resolve()
    freeze_report = (validate_source_freeze(source, args.source_freeze)
                     if args.source_freeze else None)
    contract_report = validate_source(source)
    baseline_manifest = validate_baseline(baseline, source)
    receipt_report = (validate_receipt(baseline, args.receipt)
                      if args.receipt else None)
    report = {
        "schema": "oxide-fa4-canonical38-append-root/v1",
        "author_compiled_device": False,
        "root_only": True,
        "source": str(source),
        "baseline": str(baseline),
        "output": str(output),
        "architecture": baseline_manifest["architecture"],
        "old_count": OLD_COUNT,
        "new_count": NEW_COUNT,
        "total_count": TOTAL_COUNT,
        "new_modes": list(range(FIRST_NEW_MODE, LAST_NEW_MODE + 1)),
        "contract": contract_report,
        "source_freeze": freeze_report,
        "receipt": receipt_report,
        "check_only": args.check_only,
    }
    if args.check_only:
        print(json.dumps(report, indent=2))
        return
    if output.exists() and any(output.iterdir()):
        die("refusing to overwrite a nonempty append output")
    output.mkdir(parents=True, exist_ok=True)
    for name, expected in baseline_manifest["objects"].items():
        shutil.copy2(baseline / name, output / name)
        if digest(output / name) != expected:
            die(f"copied old object changed: {name}")
    new_kernels, proof = compile_new_objects(
        source, baseline, output, args.python, args.runtime_dir, args.ffi_root)
    provenance = {
        "source_freeze_sha256": (freeze_report or {}).get("freeze_sha256"),
        "baseline_receipt_sha256": (receipt_report or {}).get("receipt_sha256"),
        "baseline_manifest_sha256": baseline_manifest.get("manifest_sha256")
        or digest(baseline / "manifest.json"),
    }
    merged = merge_manifest(source, baseline, output, new_kernels, proof, provenance)
    contract = _contract(source)
    rows = contract.validate_profiles_inc(source / "profiles.inc")
    contract.validate_manifest_inventory(merged, rows)
    link = _link_command(source, output, baseline_manifest, args.runtime_dir,
                         args.ffi_root, args.python)
    completed = subprocess.run(link)
    if completed.returncode:
        die(f"link failed with {completed.returncode}")
    final = load(output / "manifest.json")
    if final["registry"] != contract.canonical_registry_for(38):
        die("linked manifest registry is not canonical38")
    if len(final["kernels"]) != TOTAL_COUNT:
        die(f"linked manifest does not contain {TOTAL_COUNT} kernels")
    for name, expected in baseline_manifest["objects"].items():
        if digest(output / name) != expected:
            die(f"old object changed after link: {name}")
    # Re-publish the final manifest atomically after the linker's in-place write.
    atomic_write(output / "manifest.json", json.dumps(final, indent=2) + "\n")
    report.update(
        status="passed",
        manifest_sha256=digest(output / "manifest.json"),
        library_sha256=digest(output / "libinfinityfa4.so"),
        old_objects_preserved=OLD_COUNT,
        new_objects=[kernel["symbol"] for kernel in new_kernels],
        link=link,
    )
    atomic_write(output / "APPEND-REPORT.json", json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
