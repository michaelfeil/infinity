#!/usr/bin/env python3
"""Node-recovery wave3 checkpoint: source/controls + runtime/evidence archives.

CPU/IO only. Writes only under docs-parity-wave3 and this script's path.
"""
from __future__ import annotations
import argparse, datetime, gzip, hashlib, io, json, os, pathlib, subprocess, sys, tarfile

SRC = pathlib.Path('/tmp/oxide-docs-parity-20261102')
DEST = pathlib.Path('/tmp/oxide-node-recovery/oxide-node-recovery/docs-parity-wave3')
PUBLIC = pathlib.Path('/tmp/infinity-remove-vertex')
BASE_COMMIT = 'c57c661'
WAVE2_DIR = pathlib.Path('/tmp/oxide-node-recovery/oxide-node-recovery/docs-parity-wave2')
WAVE2_MANIFEST = WAVE2_DIR / 'MANIFEST.json'
WAVE2_ARCHIVE = WAVE2_DIR / 'source-and-controls.tar.xz'
WAVE2_PUSH = 'f0acb42'

SOURCE_ALLOWED = {
    '.rs','.toml','.lock','.py','.sh','.bash','.zsh','.cpp','.cc','.cxx','.c','.cu','.cuh',
    '.h','.hpp','.hh','.inc','.json','.jsonl','.md','.txt','.patch','.diff','.yml','.yaml',
    '.cmake','.log','.stdout','.stderr','.csv','.tsv','.xml','.html','.jinja','.j2','.cfg',
    '.ini','.sql','.proto'
}
NAMED_ALLOWED = {'Makefile','CMakeLists.txt','Dockerfile','LICENSE','NOTICE','COPYING','AUTHORS',
                 'THIRD_PARTY_NOTICES.md','README','README.md','VERSION'}
BINARY_EXT = {'.so','.dylib','.dll','.o','.a','.rlib','.rmeta','.cubin','.fatbin','.ptx',
              '.bin','.safetensors','.pt','.pth','.ckpt','.onnx','.gguf','.npz','.npy','.pyc',
              '.pyd','.gz','.xz','.zst','.zip','.tar','.whl','.deb','.rpm','.img','.iso'}
PRUNE_DIRS = {'.git','target','dev-target','.work','__pycache__','.ruff_cache','.mypy_cache',
              '.pytest_cache','node_modules','.venv','venv','.cache','.cargo','models','weights',
              'kernels.work','tmp'}
SECRET_NAMES = {'opencode.json','auth.json','credentials.json','token.json','secrets.json',
                'id_rsa','id_ed25519'}
MAX_NORMAL = 16 * 1024 * 1024
MAX_PATCH = 32 * 1024 * 1024

def sha256_bytes(data): return hashlib.sha256(data).hexdigest()
def sha1_blob(data):
    h = hashlib.sha1(); h.update(f'blob {len(data)}\0'.encode()); h.update(data); return h.hexdigest()
def sha256_file(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def human(n):
    for unit in ('B','KiB','MiB','GiB'):
        if n < 1024: return f'{n:.1f}{unit}'
        n /= 1024
    return f'{n:.1f}TiB'

def load_public_tree():
    out = subprocess.check_output(['git','-C',str(PUBLIC),'ls-tree','-r','--full-tree',BASE_COMMIT], text=True)
    mapping = {}
    for line in out.splitlines():
        meta, path = line.split('\t',1)
        mode, typ, blob = meta.split()
        if typ == 'blob': mapping[path] = blob
    return mapping

def candidate_public_keys(path, repo_root):
    keys = []
    if repo_root is not None:
        keys.append(str(path.relative_to(repo_root)))
    rel = str(path.relative_to(SRC))
    keys.append(rel)
    for marker in ('libs/infinity-v3/','docs/','backends/','config/','core/','router/','libs/'):
        idx = rel.find(marker)
        if idx >= 0:
            keys.append(rel[idx:])
    return keys

def is_build_dir(name):
    low = name.lower()
    return (low in PRUNE_DIRS or low.startswith(('target-', 'target_', 'dev-target', 'dev-target-'))
            or low.endswith(('-target', '_target', '.target', '.work')))

def walk_source():
    for current, dirs, names in os.walk(SRC, followlinks=False):
        current = pathlib.Path(current)
        dirs[:] = sorted(d for d in dirs if not is_build_dir(d))
        yield current, names

def source_candidates():
    repo_roots = {}
    for current, names in walk_source():
        has_git = (current / '.git').exists()
        repo_roots[current] = current if has_git else repo_roots.get(current.parent)
        for name in sorted(names):
            if name == '.git' or name in SECRET_NAMES or name.startswith('.env'):
                continue
            path = current / name
            if path.is_symlink() or not path.is_file():
                continue
            ext = path.suffix.lower()
            low = name.lower()
            if ext in {'.yaml','.yml','.json','.toml','.ini','.cfg'} and any(
                    token in low for token in ('secret','credential','token')):
                continue
            if ext in BINARY_EXT:
                continue
            if ext not in SOURCE_ALLOWED and name not in NAMED_ALLOWED and not name.startswith(('LICENSE','NOTICE','COPYING','THIRD_PARTY')):
                continue
            yield path, repo_roots.get(current)

def scan_source(public_tree, wave2):
    stats = {'candidates':0,'candidate_bytes':0,'selected':0,'selected_bytes':0,
             'omit_public':0,'omit_wave2':0,'excluded_size':0,'excluded_binary':0}
    omit_public=[]; omit_wave2=[]; excluded=[]
    selected=[]
    for path, repo_root in source_candidates():
        size = path.stat().st_size
        stats['candidates'] += 1; stats['candidate_bytes'] += size
        ext = path.suffix.lower()
        if ext in ('.patch','.diff'):
            limit = MAX_PATCH
        else:
            limit = MAX_NORMAL
        if size > limit:
            excluded.append({'path':str(path.relative_to(SRC)),'bytes':size,'reason':'size'})
            stats['excluded_size'] += 1
            continue
        data = path.read_bytes()
        sha = sha256_bytes(data)
        rel = str(path.relative_to(SRC))
        blob = sha1_blob(data)
        public_key = None
        for key in candidate_public_keys(path, repo_root):
            if public_tree.get(key) == blob:
                public_key = key; break
        if public_key is not None:
            omit_public.append({'path':rel,'public_path':public_key,'blob_sha1':blob,'bytes':len(data)})
            stats['omit_public'] += 1
            continue
        w2 = wave2.get(rel)
        if w2 and w2.get('sha256') == sha and w2.get('bytes') == len(data):
            omit_wave2.append({'path':rel,'sha256':sha,'bytes':len(data)})
            stats['omit_wave2'] += 1
            continue
        selected.append({'path':path,'rel':rel,'data':data,'bytes':len(data),'sha256':sha})
        stats['selected'] += 1; stats['selected_bytes'] += len(data)
    return stats, selected, omit_public, omit_wave2, excluded

def runtime_files():
    roots = {
      'fa4-canonical38-all3-v2': pathlib.Path('/tmp/oxide-fa4-canonical38-all3-v2'),
      'dense-wave3-device-all3-v1': SRC/'dense-wave3-device-all3-v1',
      'gemma3-wave4-device-all3-v1': SRC/'gemma3-wave4-device-all3-v1',
      'q35moe-reference': pathlib.Path('/tmp/infinity-oxide-parity-20261101/q35moe-normal-factory-v3/reference'),
      'encoder-primitives-root-gate-v4-root': SRC/'encoder-primitives-root-gate-v4-root',
    }
    files=[]
    for prefix, root in roots.items():
        if not root.exists(): raise SystemExit(f'missing runtime root {root}')
        for current, dirs, names in os.walk(root, followlinks=False):
            current = pathlib.Path(current)
            dirs[:] = sorted(d for d in dirs if d not in {'__pycache__','.ruff_cache','.git','target','dev-target','.cache'})
            for name in sorted(names):
                if name in SECRET_NAMES or name.startswith('.env'): continue
                path = current/name
                if path.is_symlink() or not path.is_file(): continue
                rel = path.relative_to(root)
                files.append({'root':prefix,'path':path,'arcname':f'runtime/{prefix}/{rel}'})
    consumers = {
      'q35moe-unified-runtime-v3': pathlib.Path('/tmp/oxide-q35moe-unified-runtime-v3/consumer-target/debug/q35moe-unified-runtime'),
      'mistral3-host-consumer-v9': SRC/'mistral3-mean/postbuild-unified-consumer-v9-successor3/artifacts/mistral3-host-consumer',
      'qwen3-vl-host-consumer-v5': pathlib.Path('/tmp/opencode/qv3-tensor-view-v5-target/debug/examples/qwen3_vl_host_consumer-e7dbcd8f3362daa0'),
    }
    for name, path in consumers.items():
        if not path.is_file(): raise SystemExit(f'missing consumer {path}')
        files.append({'root':'consumers','path':path,'arcname':f'runtime/consumers/{name}'})
    return files

def add_file(tar, arcname, data, mode=0o644):
    info = tarfile.TarInfo(arcname); info.size=len(data); info.mode=mode; info.mtime=0
    tar.addfile(info, io.BytesIO(data))

def write_source_archive(dest, selected, extra_entries):
    archive = dest/'source-and-controls.tar.xz'
    files_manifest={}
    with tarfile.open(archive,'w:xz',preset=6) as tar:
        for entry in selected:
            arcname='source/'+entry['rel']
            add_file(tar, arcname, entry['data'], 0o755 if os.access(entry['path'], os.X_OK) else 0o644)
            files_manifest[arcname]={'bytes':entry['bytes'],'sha256':entry['sha256']}
        for arcname,data in extra_entries.items():
            add_file(tar, arcname, data)
            files_manifest[arcname]={'bytes':len(data),'sha256':sha256_bytes(data)}
    return archive, files_manifest

def write_runtime_archive(dest, files):
    archive=dest/'runtime-and-evidence.tar.xz'
    manifest={}
    consumer_info={}
    with tarfile.open(archive,'w:xz',preset=6) as tar:
        for entry in files:
            data=entry['path'].read_bytes()
            arc=entry['arcname']
            add_file(tar, arc, data, 0o755 if os.access(entry['path'], os.X_OK) else 0o644)
            manifest[arc]={'bytes':len(data),'sha256':sha256_bytes(data)}
            if entry['root']=='consumers':
                gz=gzip.compress(data, compresslevel=1, mtime=0)
                if len(gz) >= 90*1024*1024:
                    raise SystemExit(f'individual compressed consumer exceeds 90MB: {arc}')
                consumer_info[arc]={'raw_bytes':len(data),'raw_sha256':sha256_bytes(data),
                                    'gzip_bytes':len(gz),'gzip_sha256':sha256_bytes(gz)}
    return archive, manifest, consumer_info

def verify_archive(archive, manifest, prefixes):
    prefixes=(prefixes,) if isinstance(prefixes,str) else tuple(prefixes)
    seen={}
    with tarfile.open(archive,'r:xz') as tar:
        for member in tar:
            name=member.name
            if not any(name.startswith(p) for p in prefixes) or name.startswith('/') or '..' in pathlib.PurePosixPath(name).parts or not member.isfile():
                raise SystemExit(f'invalid archive member {name}')
            f=tar.extractfile(member)
            h=hashlib.sha256(); size=0
            while True:
                chunk=f.read(1024*1024)
                if not chunk: break
                size+=len(chunk); h.update(chunk)
            if size != member.size: raise SystemExit(f'size mismatch {name}')
            seen[name]={'bytes':size,'sha256':h.hexdigest()}
    if seen != manifest:
        missing=sorted(set(manifest)-set(seen)); extra=sorted(set(seen)-set(manifest))
        raise SystemExit(f'manifest/archive mismatch missing={missing[:5]} extra={extra[:5]}')
    return len(seen)

def compile_snapshot(files):
    rows=[]
    for entry in files:
        if entry['root'] in ('consumers',) or entry['path'].suffix.lower() in {'.o','.so','.cubin','.ptx','.bin','.a','.rlib'} or entry['path'].name in {'kernels.cubin','kernels.ptx'}:
            rows.append((entry['arcname'], sha256_file(entry['path'])))
    return rows

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--scan',action='store_true')
    args=parser.parse_args()
    public_tree=load_public_tree()
    wave2_manifest=json.loads(WAVE2_MANIFEST.read_text())
    wave2_files=wave2_manifest.get('files',{})
    stats, selected, omit_public, omit_wave2, excluded = scan_source(public_tree, wave2_files)
    runtime=runtime_files()
    runtime_bytes=sum(e['path'].stat().st_size for e in runtime)
    print(json.dumps({'source_stats':stats,'selected_files':len(selected),
                      'runtime_files':len(runtime),'runtime_bytes':runtime_bytes,
                      'runtime_human':human(runtime_bytes)},indent=2))
    if args.scan:
        return
    DEST.mkdir(parents=False, exist_ok=False)
    # Public-base repository licenses, stored both beside archives and inside source archive.
    license_entries={}
    for name in ('LICENSE','NOTICE','THIRD_PARTY_NOTICES.md'):
        data=subprocess.check_output(['git','-C',str(PUBLIC),'show',f'{BASE_COMMIT}:libs/infinity-v3/{name}'])
        (DEST/name).write_bytes(data)
        license_entries[f'licenses/{name}']=data
    qual_status={
      'schema':'oxide-docs-parity-wave3-qualification-status/v1',
      'do_not_claim_qualified':True,
      'new_models_not_numerically_qualified':['Gemma family','UltraV3','Nomic','Gemmathree G3','typed heads','Q35','GTE'],
      'known_numeric_failures':{
        'Mistral V9 partial11 independent':{'source':str(SRC/'mistral-v9-partial11-independent-v3.json'),'pass':False,'note':'pairs reported pass=false with large max_abs/cosine divergence'},
        'QV3 V5 empty-images':{'source':str(SRC/'qv3-tensor-view-v5/LOCALIZATION.json'),'pass':False,'note':'root quality-life returncode 1, DriverError invalid argument; later life-contract verification does not establish numeric parity'},
        'Q35/Qwen3.5 numeric':{'source':str(SRC/'qv35-numeric/STATUS.json'),'pass':None,'note':'CPU pins finalized; runtime/GPU numeric gate pending; no numeric qualification claimed'}
      },
      'frozen_manifests_take_precedence':True,
      'active_private_edits':'unfinished live snapshot'
    }
    qual_bytes=(json.dumps(qual_status,indent=2)+'\n').encode()
    (DEST/'QUALIFICATION-STATUS.json').write_bytes(qual_bytes)
    readme=('Docs parity wave3 live snapshot. Active private edits are unfinished; frozen component manifests take precedence. '
            'Source archive omits files byte-identical to public base c57c661 and to wave2 by exact SHA, with explicit omission lists. '
            'Runtime archive contains FA4 canonical38, device bundles, explicit case gold/evidence and consumer binaries; no model weights, Torch or cuBLAS SDK libraries. '
            'No model is claimed numerically qualified.\n').encode()
    (DEST/'README.md').write_bytes(readme)
    extra_entries={**license_entries,
                   'source/QUALIFICATION-STATUS.json':qual_bytes,
                   'source/README.md':readme}
    snap_before=compile_snapshot(runtime)
    source_archive, source_files = write_source_archive(DEST, selected, extra_entries)
    runtime_archive, runtime_manifest, consumer_info = write_runtime_archive(DEST, runtime)
    snap_after=compile_snapshot(runtime)
    if snap_before != snap_after:
        raise SystemExit('compile artifacts changed during archive creation')
    source_count=verify_archive(source_archive, source_files, ('source/','licenses/'))
    runtime_count=verify_archive(runtime_archive, runtime_manifest, 'runtime/')
    manifest={
      'schema':'oxide-docs-parity-wave3-checkpoint/v1',
      'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'status':'live unfinished source snapshot; frozen component manifests take precedence',
      'base_public_commit':BASE_COMMIT,
      'parent_wave2':{'push':WAVE2_PUSH,'directory':str(WAVE2_DIR),
                      'manifest_sha256':sha256_file(WAVE2_MANIFEST),
                      'archive':WAVE2_ARCHIVE.name,'archive_sha256':sha256_file(WAVE2_ARCHIVE),
                      'archive_bytes':WAVE2_ARCHIVE.stat().st_size,
                      'native_sdk':wave2_manifest.get('native_sdk'),
                      'omission_policy':'omit only when current sha256/bytes equal the wave2 manifest entry; exact list below'},
      'source':{'archive':source_archive.name,'bytes':source_archive.stat().st_size,
                'sha256':sha256_file(source_archive),'entry_count':source_count,
                'files':source_files,
                'omitted_identical_to_public_base':{'count':len(omit_public),'files':omit_public},
                'omitted_identical_to_wave2':{'count':len(omit_wave2),'files':omit_wave2},
                'excluded':excluded,
                'selected_count':len(selected),'selected_bytes':stats['selected_bytes']},
      'runtime':{'archive':runtime_archive.name,'bytes':runtime_archive.stat().st_size,
                 'sha256':sha256_file(runtime_archive),'entry_count':runtime_count,
                 'files':runtime_manifest,'consumers':consumer_info,
                 'roots':['fa4-canonical38-all3-v2','dense-wave3-device-all3-v1',
                          'gemma3-wave4-device-all3-v1','q35moe-reference',
                          'encoder-primitives-root-gate-v4-root','consumers'],
                 'compile_artifacts_fixed_before_after':True,
                 'compile_artifact_rows':len(snap_before),
                 'compile_artifact_snapshot_sha256':sha256_bytes('\n'.join(f'{p} {s}' for p,s in snap_before).encode())},
      'qualification_status':'QUALIFICATION-STATUS.json',
      'exclusions':['build caches/targets','.git','models/weights/safetensors','Torch/cuBLAS SDK libraries','environment/credential/secret configs','symlinks','compiled artifact extensions in source archive'],
      'native_sdk_reference':'parent wave2 native-sdk-b66.so.gz; not duplicated',
      'counts':{'source_entries':source_count,'runtime_entries':runtime_count,
                'source_archive_bytes':source_archive.stat().st_size,
                'runtime_archive_bytes':runtime_archive.stat().st_size}
    }
    (DEST/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (DEST/'MANIFEST-SHA256.txt').write_text(sha256_file(DEST/'MANIFEST.json')+'  MANIFEST.json\n')
    print(json.dumps({'source_archive':{'bytes':manifest['source']['bytes'],'sha256':manifest['source']['sha256'],'entries':source_count},
                      'runtime_archive':{'bytes':manifest['runtime']['bytes'],'sha256':manifest['runtime']['sha256'],'entries':runtime_count},
                      'omitted_public':len(omit_public),'omitted_wave2':len(omit_wave2),
                      'selected_source':len(selected),'runtime_roots':len(manifest['runtime']['roots'])},indent=2))

if __name__ == '__main__':
    main()
