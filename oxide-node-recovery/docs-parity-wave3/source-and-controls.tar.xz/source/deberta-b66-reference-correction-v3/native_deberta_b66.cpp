// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
// Test-only declaration/source-exact adapter for the DeBERTa b66 control
// packet.  The private Native Deberta::forward() is not exported by
// libtei_torch.so, so this file never claims a Native model export.  Every
// reference below is an actual b66 Torch ATen composition matching the public
// Native source order, explicitly labelled as SOURCE-EXACT ATen.
#include <ATen/ATen.h>
#include <ATen/core/Tensor.h>
#include <c10/util/ArrayRef.h>
#include <torch/library.h>
#include <cstdint>
#include <cstdlib>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

// Declared against the actual exported b66 C++ symbol; no Native norm is
// recompiled here. Conv/activation remain source-exact ATen compositions.
namespace infinity {
at::Tensor encoder_layer_norm_only(const at::Tensor&,const at::Tensor&,double,const at::Tensor&,const at::Tensor&,bool);
}
namespace {

constexpr const char* kSdk =
    "/tmp/native214-fa4-mode20/install/lib/libtei_torch.so";

std::string json_string(const char* text) {
  std::string out = "\"";
  for (const unsigned char c : std::string(text ? text : "")) {
    if (c == '\\' || c == '"')
      out += '\\';
    if (c < 32)
      throw std::runtime_error("invalid metadata string");
    out += static_cast<char>(c);
  }
  return out + '"';
}

const char* env_or_empty(const char* name) {
  const char* value = std::getenv(name);
  return value ? value : "";
}

std::string binding() {
  std::ostringstream out;
  out << "{\"method\":\"source-exact-ATen-on-actual-b66-Torch/"
         "private-Deberta-forward-not-exported\",\"sdk\":"
      << json_string(kSdk)
      << ",\"native_deberta_export\":false"
      << ",\"reference_tag\":\"source_exact_aten_actual_b66_torch\"}";
  return out.str();
}

std::string observed_flags() {
  auto& context = at::globalContext();
  std::ostringstream out;
  out << "{\"allow_tf32_cudnn\":" << (context.allowTF32CuDNN() ? "true" : "false")
      << ",\"allow_tf32_cublas\":" << (context.allowTF32CuBLAS() ? "true" : "false")
      << ",\"allow_fp16_accumulation_cublas\":"
      << (context.allowFP16AccumulationCuBLAS() ? "true" : "false")
      << ",\"allow_fp16_reduction_cublas\":"
      << static_cast<int>(context.allowFP16ReductionCuBLAS())
      << ",\"allow_bf16_reduction_cublas\":"
      << static_cast<int>(context.allowBF16ReductionCuBLAS())
      << ",\"deterministic_algorithms\":"
      << (context.deterministicAlgorithms() ? "true" : "false")
      << ",\"deterministic_fill_uninitialized_memory\":"
      << (context.deterministicFillUninitializedMemory() ? "true" : "false")
      << ",\"env\":{"
      << "\"CUDNN_BENCHMARK\":" << json_string(env_or_empty("CUDNN_BENCHMARK"))
      << ",\"CUDNN_DETERMINISTIC\":" << json_string(env_or_empty("CUDNN_DETERMINISTIC"))
      << ",\"CUDNN_LOGLEVEL_DBG\":" << json_string(env_or_empty("CUDNN_LOGLEVEL_DBG"))
      << ",\"CUDNN_LOGDEST_DBG\":" << json_string(env_or_empty("CUDNN_LOGDEST_DBG"))
      << ",\"CUBLAS_WORKSPACE_CONFIG\":"
      << json_string(env_or_empty("CUBLAS_WORKSPACE_CONFIG"))
      << ",\"NVIDIA_TF32_OVERRIDE\":"
      << json_string(env_or_empty("NVIDIA_TF32_OVERRIDE"))
      << ",\"TORCH_ALLOW_TF32_CUBLAS_OVERRIDE\":"
      << json_string(env_or_empty("TORCH_ALLOW_TF32_CUBLAS_OVERRIDE"))
      << ",\"TORCH_ALLOW_TF32_CUDNN_OVERRIDE\":"
      << json_string(env_or_empty("TORCH_ALLOW_TF32_CUDNN_OVERRIDE"))
      << "}}";
  return out.str();
}

void require_cuda_bf16(const at::Tensor& tensor, const char* what) {
  TORCH_CHECK(tensor.is_cuda(), what, " must be a CUDA tensor");
  TORCH_CHECK(tensor.scalar_type() == at::kBFloat16, what, " must be BF16");
}

void require_cuda_long(const at::Tensor& tensor, const char* what) {
  TORCH_CHECK(tensor.is_cuda(), what, " must be a CUDA tensor");
  TORCH_CHECK(tensor.scalar_type() == at::kLong, what, " must be int64");
}

void require_cuda_int32(const at::Tensor& tensor, const char* what) {
  TORCH_CHECK(tensor.is_cuda(), what, " must be a CUDA tensor");
  TORCH_CHECK(tensor.scalar_type() == at::kInt, what, " must be int32");
}

at::Tensor activate(const at::Tensor& x, int64_t code) {
  switch (code) {
    case 0:
      return at::gelu(x, "none");
    case 1:
      return at::tanh(x);
    case 2:
      return at::relu(x);
    case 3:
      return at::silu(x);
    case 4:
      return at::gelu(x, "tanh");
    default:
      TORCH_CHECK(false, "unsupported activation code: ", code);
  }
}

at::Tensor compose(at::TensorList inputs, c10::IntArrayRef ints) {
  TORCH_CHECK(inputs.size() == 6, "compose expects ids,positions,types,word,position,token_type");
  TORCH_CHECK(ints.size() == 4, "compose expects tokens,width,position_biased,token_types");
  const auto& ids = inputs[0];
  const auto& positions = inputs[1];
  const auto& types = inputs[2];
  const auto& word = inputs[3];
  const auto& position = inputs[4];
  const auto& token_type = inputs[5];
  require_cuda_long(ids, "compose ids");
  require_cuda_long(positions, "compose positions");
  require_cuda_long(types, "compose types");
  require_cuda_bf16(word, "compose word");
  TORCH_CHECK(ids.dim() == 1 && ids.numel() == ints[0], "compose ids length differs");
  TORCH_CHECK(positions.dim() == 1 && positions.numel() == ints[0],
              "compose positions length differs");
  TORCH_CHECK(types.dim() == 1 && types.numel() == ints[0],
              "compose types length differs");
  TORCH_CHECK(word.dim() == 2 && word.size(1) == ints[1] && word.is_contiguous(),
              "compose word must be contiguous [vocab,width]");
  auto h = at::embedding(word, ids);
  if (ints[2] != 0) {
    require_cuda_bf16(position, "compose position");
    TORCH_CHECK(position.dim() == 2 && position.size(1) == ints[1] &&
                    position.is_contiguous(),
                "compose position must be contiguous [positions,width]");
    h = h + at::embedding(position, positions);
  }
  if (ints[3] != 0) {
    require_cuda_bf16(token_type, "compose token_type");
    TORCH_CHECK(token_type.dim() == 2 && token_type.size(1) == ints[1] &&
                    token_type.is_contiguous(),
                "compose token_type must be contiguous [types,width]");
    h = h + at::embedding(token_type, types);
  }
  return h.contiguous();
}

std::vector<int64_t> spans(const at::Tensor& offsets, int64_t tokens) {
  require_cuda_int32(offsets, "conv offsets");
  TORCH_CHECK(offsets.dim() == 1 && offsets.is_contiguous() && offsets.numel() >= 2,
              "conv offsets must be contiguous 1D with at least two entries");
  auto host = offsets.to(at::kCPU);
  auto access = host.accessor<int32_t, 1>();
  std::vector<int64_t> result;
  result.reserve(static_cast<size_t>(offsets.numel()));
  for (int64_t index = 0; index < offsets.numel(); ++index)
    result.push_back(static_cast<int64_t>(access[index]));
  TORCH_CHECK(result.front() == 0 && result.back() == tokens,
              "conv offsets must start at zero and end at tokens");
  for (size_t index = 1; index < result.size(); ++index)
    TORCH_CHECK(result[index] > result[index - 1], "conv offsets must be increasing");
  return result;
}

at::Tensor conv_activated(at::TensorList inputs, c10::IntArrayRef ints) {
  TORCH_CHECK(inputs.size() == 4, "conv expects input,offsets,weight,bias");
  TORCH_CHECK(ints.size() == 4, "conv expects kernel,groups,padding,activation");
  const auto& input = inputs[0];
  const auto& offsets = inputs[1];
  const auto& weight = inputs[2];
  const auto& bias = inputs[3];
  require_cuda_bf16(input, "conv input");
  require_cuda_bf16(weight, "conv weight");
  require_cuda_bf16(bias, "conv bias");
  TORCH_CHECK(input.dim() == 2 && input.size(1) == 768 && input.is_contiguous(),
              "conv input must be contiguous [tokens,768]");
  const int64_t tokens = input.size(0);
  const int64_t kernel = ints[0];
  const int64_t groups = ints[1];
  const int64_t padding = ints[2];
  const int64_t activation = ints[3];
  TORCH_CHECK(kernel > 0 && kernel % 2 == 1 && kernel <= 15,
              "conv kernel must be odd and at most 15");
  TORCH_CHECK(groups > 0 && 768 % groups == 0, "conv groups must divide 768");
  TORCH_CHECK(padding == (kernel - 1) / 2, "conv padding must be (kernel-1)/2");
  TORCH_CHECK(weight.dim() == 3 && weight.size(0) == 768 &&
                  weight.size(1) == 768 / groups && weight.size(2) == kernel &&
                  weight.is_contiguous() && weight.device() == input.device(),
              "conv weight must be contiguous [768,768/groups,kernel]");
  TORCH_CHECK(bias.dim() == 1 && bias.numel() == 768 && bias.is_contiguous() &&
                  bias.device() == input.device(),
              "conv bias must be contiguous [768]");
  auto bounds = spans(offsets, tokens);
  std::vector<at::Tensor> pieces;
  pieces.reserve(bounds.size() - 1);
  for (size_t row = 0; row + 1 < bounds.size(); ++row) {
    const int64_t start = bounds[row];
    const int64_t length = bounds[row + 1] - start;
    auto x = input.narrow(0, start, length).transpose(0, 1).unsqueeze(0);
    auto convolved = at::conv1d(x, weight, bias, {1}, {padding}, {1}, groups);
    pieces.push_back(activate(convolved, activation).squeeze(0).transpose(0, 1));
  }
  return at::cat(pieces, 0).contiguous();
}

at::Tensor conv_residual_norm(at::TensorList inputs, c10::IntArrayRef ints,
                              c10::ArrayRef<double> floats) {
  TORCH_CHECK(inputs.size() == 7,
              "conv_residual_norm expects input,offsets,weight,bias,h,gamma,beta");
  TORCH_CHECK(floats.size() == 1, "conv_residual_norm expects epsilon");
  auto activated = conv_activated(
      at::TensorList(inputs.data(), 4), ints);
  const auto& h = inputs[4];
  const auto& gamma = inputs[5];
  const auto& beta = inputs[6];
  require_cuda_bf16(h, "conv_residual_norm h");
  require_cuda_bf16(gamma, "conv_residual_norm gamma");
  require_cuda_bf16(beta, "conv_residual_norm beta");
  TORCH_CHECK(h.sizes() == activated.sizes() && h.is_contiguous() &&
                  h.device() == activated.device(),
              "conv_residual_norm h must match activated [tokens,768]");
  TORCH_CHECK(gamma.dim() == 1 && gamma.numel() == 768 && gamma.is_contiguous() &&
                  gamma.device() == h.device(),
              "conv_residual_norm gamma must be contiguous [768]");
  TORCH_CHECK(beta.dim() == 1 && beta.numel() == 768 && beta.is_contiguous() &&
                  beta.device() == h.device(),
              "conv_residual_norm beta must be contiguous [768]");
  auto summed = h + activated;
  return infinity::encoder_layer_norm_only(summed,gamma,floats[0],at::Tensor(),beta,true);
}

std::vector<at::Tensor> run(const std::string& op, at::TensorList inputs,
                            c10::IntArrayRef ints,
                            c10::ArrayRef<double> floats) {
  if (op == "compose")
    return {compose(inputs, ints)};
  if (op == "conv_activated")
    return {conv_activated(inputs, ints)};
  if (op == "conv_residual_norm")
    return {conv_residual_norm(inputs, ints, floats)};
  TORCH_CHECK(false, "unknown DeBERTa b66 control operation: ", op);
  return {};
}

}  // namespace

TORCH_LIBRARY(oxide_native_deberta_b66, m) {
  m.def("binding() -> str", TORCH_FN(binding));
  m.def("observed_flags() -> str", TORCH_FN(observed_flags));
  m.def("run(str op, Tensor[] inputs, int[] ints, float[] floats) -> Tensor[]",
        TORCH_FN(run));
}
