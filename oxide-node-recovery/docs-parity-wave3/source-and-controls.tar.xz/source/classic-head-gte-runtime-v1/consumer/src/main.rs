// Copyright Infinity Core Contributors. Licensed under the repository LICENSE.
//! Root-only consumer of actual cached checkpoints through the public Backend API.
use infinity_backend_oxide::OxideBackend;
use infinity_raw_probe::{build_batch, validate_batch, BatchFile, OutputEntry};
use infinity_v3_backend_core::{Backend, Embedding, Inference, ModelType, Pool};
use serde::Deserialize;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, io::Read, path::Path, process::ExitCode};

#[derive(Deserialize)]
struct Packet { schema: String, models: Vec<Model> }
#[derive(Deserialize)]
struct Model {
    key: String, path: String, pool: String, width: usize,
    ignore_types: bool, config_sha256: String, checkpoint_sha256: String,
    checkpoint_file: String, cases: Vec<Case>,
}
#[derive(Deserialize)]
struct Case {
    name: String, operation: String, batch: BatchFile, submitted_batch: BatchFile,
    expected_native: Vec<OutputEntry>, expected_qualified: Option<Vec<OutputEntry>>,
    require_native_bits: bool,
}
fn hash(path: &Path) -> Result<String, String> {
    let mut f = fs::File::open(path).map_err(|e| e.to_string())?;
    let mut b = vec![0u8; 4 * 1024 * 1024];
    let mut digest = Sha256::new();
    loop { let n = f.read(&mut b).map_err(|e| e.to_string())?; if n == 0 { break; } digest.update(&b[..n]); }
    Ok(format!("{:x}", digest.finalize()))
}
fn checked(model: &Model) -> Result<ModelType, String> {
    let path = Path::new(&model.path);
    if model.width == 0 || hash(&path.join("config.json"))? != model.config_sha256
        || hash(&path.join(&model.checkpoint_file))? != model.checkpoint_sha256 {
        return Err("Actual checkpoint/configuration identity changed".into());
    }
    let config: Value = serde_json::from_slice(&fs::read(path.join("config.json")).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    for case in &model.cases {
        let batch = validate_batch(case.batch.clone()).map_err(|e| e.to_string())?;
        validate_batch(case.submitted_batch.clone()).map_err(|e| e.to_string())?;
        for (field, values, ignored) in [
            ("vocab_size", &batch.file.input_ids, false),
            ("max_position_embeddings", &batch.file.position_ids, false),
            ("type_vocab_size", &batch.file.token_type_ids, model.ignore_types),
        ] {
            if !ignored {
                let limit = config[field].as_u64().ok_or_else(|| format!("Missing {field}"))?;
                if values.iter().any(|&v| u64::from(v) >= limit) { return Err(format!("Input exceeds {field}")); }
            }
        }
        compare(&case.expected_native, &case.expected_native, true)?;
        if let Some(old) = &case.expected_qualified { compare(old, &case.expected_native, false)?; }
    }
    Ok(match model.pool.as_str() {
        "classifier" => ModelType::Classifier,
        "cls" => ModelType::Embedding(Pool::Cls),
        "mean" => ModelType::Embedding(Pool::Mean),
        "last-token" => ModelType::Embedding(Pool::LastToken),
        _ => return Err("Unsupported runtime pool".into()),
    })
}
fn submit(backend: &OxideBackend, case: &Case, width: usize) -> Result<Inference<Vec<OutputEntry>>, String> {
    let batch = validate_batch(case.submitted_batch.clone()).map_err(|e| e.to_string())?;
    let input = build_batch(&batch);
    match case.operation.as_str() {
        "sequence" => backend.submit_predict(input).map(|x| x.map(move |r| {
            let mut out = r.iter().map(|(&index, values)| OutputEntry { index, kind: "pooled".into(), shape: vec![width], values: values.clone() }).collect::<Vec<_>>();
            out.sort_by_key(|x| x.index); out
        })),
        "tokens" => backend.submit_predict_tokens(input).map(|x| x.map(move |r| {
            let mut out = r.iter().map(|(&index, rows)| OutputEntry { index, kind: "raw".into(), shape: vec![rows.len(), width], values: rows.iter().flatten().copied().collect() }).collect::<Vec<_>>();
            out.sort_by_key(|x| x.index); out
        })),
        "embedding" => backend.submit_embed(input).map(|x| x.map(move |r| {
            let mut out = r.iter().map(|(&index, e)| match e {
                Embedding::Pooled(values) => OutputEntry { index, kind: "pooled".into(), shape: vec![values.len()], values: values.clone() },
                Embedding::All(rows) => OutputEntry { index, kind: "raw".into(), shape: vec![rows.len(), rows.first().map_or(0, Vec::len)], values: rows.iter().flatten().copied().collect() },
            }).collect::<Vec<_>>(); out.sort_by_key(|x| x.index); out
        })),
        _ => return Err("Unsupported runtime operation".into()),
    }.map_err(|e| e.to_string())
}
fn compare(actual: &[OutputEntry], expected: &[OutputEntry], exact: bool) -> Result<Value, String> {
    if actual.len() != expected.len() { return Err("Result-map selection count changed".into()); }
    let mut words = 0; let mut equal = 0;
    let mut worst_abs = 0f64; let mut worst_l2 = 0f64; let mut min_cos = 1f64;
    for (a, e) in actual.iter().zip(expected) {
        if (a.index, &a.kind, &a.shape) != (e.index, &e.kind, &e.shape)
            || a.values.len() != e.values.len() || a.shape.iter().product::<usize>() != a.values.len() {
            return Err("Output index/kind/shape changed".into());
        }
        let width = a.shape.last().copied().filter(|&w| w > 0).ok_or("Empty output width")?;
        for (ar, er) in a.values.chunks_exact(width).zip(e.values.chunks_exact(width)) {
            let mut delta = 0.; let mut aa = 0.; let mut ee = 0.; let mut dot = 0.;
            for (&av, &ev) in ar.iter().zip(er) {
                if !av.is_finite() || !ev.is_finite() { return Err("Nonfinite result".into()); }
                words += 1; equal += usize::from(av.to_bits() == ev.to_bits());
                let (av, ev) = (f64::from(av), f64::from(ev));
                worst_abs = worst_abs.max((av-ev).abs()); delta += (av-ev)*(av-ev); aa += av*av; ee += ev*ev; dot += av*ev;
            }
            let rel = if ee == 0. { if delta == 0. { 0. } else { f64::INFINITY } } else { (delta/ee).sqrt() };
            let cosine = if aa == 0. || ee == 0. { if delta == 0. { 1. } else { 0. } } else { dot/(aa*ee).sqrt() };
            worst_l2 = worst_l2.max(rel); min_cos = min_cos.min(cosine);
        }
    }
    if worst_abs > 0.25 || worst_l2 > 0.02 || min_cos < 0.999 || exact && equal != words {
        return Err(format!("Numerical guard failed: exact={equal}/{words}, maxabs={worst_abs}, relativeL2={worst_l2}, cosine={min_cos}"));
    }
    Ok(json!({"words":words,"bit_exact_words":equal,"max_abs":worst_abs,"max_relative_l2":worst_l2,"min_cosine":min_cos}))
}
fn check_case(actual: &[OutputEntry], case: &Case) -> Result<Value, String> {
    let native = compare(actual, &case.expected_native, case.require_native_bits)?;
    if let Some(old) = &case.expected_qualified { compare(actual, old, true)?; }
    Ok(native)
}
fn run() -> Result<(), String> {
    let mut args = std::env::args().skip(1); let mut manifest = None; let mut key = None; let mut output = None; let mut check_only = false;
    while let Some(flag) = args.next() {
        if flag == "--check-only" { check_only = true; continue; }
        let value = args.next().ok_or("Missing argument value")?;
        let slot = match flag.as_str() { "--manifest" => &mut manifest, "--model" => &mut key, "--output" => &mut output, _ => return Err("Unknown argument".into()) };
        if slot.replace(value).is_some() { return Err("Duplicate argument".into()); }
    }
    let manifest = manifest.ok_or("Missing --manifest")?; let key = key.ok_or("Missing --model")?; let output = output.ok_or("Missing --output")?;
    if Path::new(&output).exists() { return Err("Output file must be fresh".into()); }
    let packet: Packet = serde_json::from_slice(&fs::read(&manifest).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    if packet.schema != "classic-head-gte-runtime/v1" { return Err("Unsupported manifest schema".into()); }
    let model = packet.models.iter().find(|m| m.key == key).ok_or("Actual model key absent")?;
    let model_type = checked(model)?;
    let report = if check_only { json!({"status":"cpu-validated","model":key,"cases":model.cases.len(),"engine_created":false}) } else {
        let backend = OxideBackend::new(Path::new(&model.path), "bfloat16", model_type, 0).map_err(|e| e.to_string())?;
        let mut cases = Vec::new();
        for case in &model.cases {
            let mut last = None;
            for _ in 0..3 {
                let pending = submit(&backend, case, model.width)?;
                if !case.expected_native.is_empty() && !matches!(&pending, Inference::Deferred(_)) { return Err("Nonempty result skipped deferred public path".into()); }
                let values = pending.complete().map_err(|e| e.to_string())?;
                let metrics = check_case(&values, case)?;
                if let Some(previous) = &last { compare(&values, previous, true)?; }
                last = Some(values); cases.push(json!({"case":case.name,"metrics":metrics}));
            }
        }
        // Exactly two outstanding core leases; never invoke a third submit while both live.
        let mut selected = model.cases.iter().filter(|c| !c.expected_native.is_empty());
        let a = selected.next().ok_or("Missing nonempty lease control A")?; let b = selected.next().ok_or("Missing nonempty lease control B")?;
        let held_a = submit(&backend, a, model.width)?; let held_b = submit(&backend, b, model.width)?;
        check_case(&held_b.complete().map_err(|e| e.to_string())?, b)?;
        check_case(&held_a.complete().map_err(|e| e.to_string())?, a)?;
        drop(submit(&backend, a, model.width)?);
        check_case(&submit(&backend, b, model.width)?.complete().map_err(|e| e.to_string())?, b)?;
        backend.health().map_err(|e| e.to_string())?;
        json!({"status":"passed","model":key,"cases":cases,"held_two_out_of_order":true,"cancel_recovery":true,"third_submit_tested":false,"performance_claim":false})
    };
    let mut f = fs::OpenOptions::new().write(true).create_new(true).open(&output).map_err(|e| e.to_string())?;
    std::io::Write::write_all(&mut f, &serde_json::to_vec_pretty(&report).map_err(|e| e.to_string())?).map_err(|e| e.to_string())
}
fn main() -> ExitCode { match run() { Ok(()) => ExitCode::SUCCESS, Err(e) => { eprintln!("classic-head-gte-runtime: {e}"); ExitCode::FAILURE } } }
