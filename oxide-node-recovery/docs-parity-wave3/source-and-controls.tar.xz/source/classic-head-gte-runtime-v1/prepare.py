#!/usr/bin/env python3
"""Normalize already-qualified b66 references without Torch, CUDA, or model writes."""
import argparse
import hashlib
import json
import math
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path('/tmp/infinity-oxide-parity-20261101')
SDK = 'b66d70b61b39e1bf0d565aca33bac7c5e21849677396ce5216f5baf73027d37e'
MODELS = Path('/tmp/infinity-oxide-bench/models')
GTE = Path('/workspace/model-performance/michaelfeil/torch215-comparison-20261029/models/Alibaba-NLP--gte-base-en-v1.5')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while b := f.read(4 * 1024 * 1024):
            h.update(b)
    return h.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def bits(values):
    if any(not math.isfinite(v) for v in values):
        raise ValueError('Nonfinite reference')
    return struct.pack('<%df' % len(values), *values)


def entries(outputs, batch):
    """Preserve duplicate evidence, then apply the public raw-overrides map contract."""
    rows = {}
    for e in outputs:
        key = (e['index'], e['kind'])
        if math.prod(e['shape']) != len(e['values']):
            raise ValueError('Output shape/payload mismatch')
        if key in rows and bits(rows[key]['values']) != bits(e['values']):
            raise ValueError('Duplicate physical outputs differ')
        rows[key] = e
    result = []
    for index in sorted(set(batch['pooled_indices']) | set(batch['raw_indices'])):
        kind = 'raw' if index in batch['raw_indices'] else 'pooled'
        result.append(rows[(index, kind)])
    return result


def classic(reference):
    data = load(reference)
    if data['status'] != 'ok' or data['failures'] or data['sdk']['native_sdk_sha256'] != SDK:
        raise ValueError('Native classifier reference failed')
    if not data['relocation']['all_blas_relocations_host_vendor']:
        raise ValueError('Native classifier GOT proof absent')
    for m in data['models']:
        path = MODELS / m['directory']
        cfg = path / 'config.json'
        if sha(cfg) != m['config_sha256']:
            raise ValueError('Original classifier configuration changed: ' + str(cfg))
        checkpoint = next((path / n for n in ['model.safetensors', 'pytorch_model.bin'] if (path / n).is_file()))
        checkpoint_sha = sha(checkpoint)
        conversion_proof = None
        if checkpoint_sha != m['checkpoint_sha256']:
            conversion_path = OLD / 'classifier-widths-native-views/views' / m['directory'] / 'conversion-report.json'
            conversion_proof = load(conversion_path)
            if (sha(conversion_path) != m['pin'].get('conversion_report_sha256')
                or conversion_proof['status'] != 'passed'
                or conversion_proof['original_sha256'] != checkpoint_sha
                or conversion_proof['converted_sha256'] != m['checkpoint_sha256']
                or conversion_proof['versions']['torch_git'] != '5c4886908584029761b579af026dcfb627c84070'):
                raise ValueError('Original BIN versus Native explicit F32 view proof differs')
        cases = []
        for c in m['cases']:
            if c['status'] == 'N/A':
                if c['name'] != 'empty' or c['outputs'] is not None:
                    raise ValueError('Unexpected classifier numerical waiver')
                continue
            if c['status'] != 'ok' or not c['graph']['delta']['ok_replay']:
                raise ValueError('Saved classifier case was not qualified')
            batch = c['effective_batch']
            op = 'sequence' if c['operation'] == 1 else 'tokens'
            bounds = c['original_batch']['cumulative_seq_lengths']
            count = len(bounds) - 1
            expected_batch = dict(c['original_batch'])
            expected_batch['pooled_indices'] = list(range(count)) if op == 'sequence' else []
            expected_batch['raw_indices'] = [] if op == 'sequence' else list(range(count))
            if expected_batch != batch:
                raise ValueError('Classifier canonicalization changed physical inputs')
            expected = []
            for e in c['canonical']['entries']:
                start = e['offset_floats']
                length = math.prod(e['shape'])
                expected.append(dict(index=e['index'], kind=e['kind'], shape=e['shape'], values=c['canonical']['floats'][start:start + length]))
            cases.append(dict(name=c['name'] + '-' + op, operation=op, batch=batch, submitted_batch=c['original_batch'], expected_native=expected, expected_qualified=None, require_native_bits=True))
        if len(cases) != 14:
            raise ValueError('Classifier reference count changed')
        yield dict(key=m['directory'], path=str(path), pool='classifier', width=m['classification_width'], hidden=m['native_config']['hidden'], ignore_types=False, config_sha256=sha(cfg), checkpoint_sha256=checkpoint_sha, native_checkpoint_sha256=m['checkpoint_sha256'], native_conversion_proof=conversion_proof, checkpoint_file=checkpoint.name, reference=str(reference), reference_sha256=sha(reference), historical_capture_budget=data['capture_budget'], cases=cases)


def gte(pool):
    source = OLD / 'gte-down-recovery-matched75/root-replay75'
    guard = load(source / 'guard-summary.json')
    if guard['status'] != 'passed' or guard['numeric_failed'] or guard['graph_failed']:
        raise ValueError('Historical GTE qualification failed')
    cases = []
    refs = {}
    cfg = GTE / 'config.json'
    for path in sorted((source / 'native' / pool).glob('*.json')):
        if path.name.startswith('_'):
            continue
        d = load(path)
        if d['pins']['library']['sha256'] != SDK or d['pins']['config_sha256'] != sha(cfg):
            raise ValueError('GTE SDK/configuration differs')
        if not d['pins']['vendor_binding_proof']['all_blas_relocations_host_vendor']:
            raise ValueError('GTE GOT proof absent')
        if not d['graph_guard']['ok'] or d['status'] != 'ok':
            raise ValueError('Historical GTE case failed')
        qualified_path = source / 'rust' / pool / path.name
        q = load(qualified_path)
        if d['physical_batch'] != q['physical_batch']:
            raise ValueError('Historical native/Rust physical batches differ')
        refs[str(path)] = sha(path)
        refs[str(qualified_path)] = sha(qualified_path)
        cases.append(dict(name=path.stem, operation='embedding', batch=d['physical_batch'], submitted_batch=d['physical_batch'], expected_native=entries(d['outputs'], d['physical_batch']), expected_qualified=entries(q['outputs'], q['physical_batch']), require_native_bits=False))
    if len(cases) != 25:
        raise ValueError('GTE reference case count changed')
    cp = GTE / 'model.safetensors'
    return dict(key='gte-base-' + pool, path=str(GTE), pool=pool, width=768, hidden=768, ignore_types=True, config_sha256=sha(cfg), checkpoint_sha256=sha(cp), checkpoint_file=cp.name, references=refs, historical_capture_budget=32, cases=cases)


def prepare():
    models = []
    for relative in ['classifier-native-task-control/root-native32/native.json', 'classifier-widths-native-control/root-native32/native.json']:
        models.extend(classic(OLD / relative))
    models.extend(gte(pool) for pool in ['cls', 'mean', 'last-token'])
    return dict(schema='classic-head-gte-runtime/v1', models=models, scope='Four actual cached BERT classifier checkpoints plus cached GTE-base; no trained RoBERTa/XLM-R/CamemBERT/GTE-multilingual/GTE-large qualification', native_reference_policy='Reuse exact saved b66 outputs and original checkpoint hashes. Historical references used explicit capture budget32; this is not fresh default-policy or performance evidence.', no_native_gpu_regeneration=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.output.write_text(json.dumps(prepare(), separators=(',', ':')) + '\n')
    print(a.output)
