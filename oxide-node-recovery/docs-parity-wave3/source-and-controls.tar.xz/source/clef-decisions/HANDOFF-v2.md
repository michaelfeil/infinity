# Cloudflare Clef / Clef-flash typed decision head - successor v2

Base source: public commit `252789b05ea2e09c14971c04dfcce458f863fead`
(`libs/infinity-v3`). Output tree:
`/tmp/oxide-docs-parity-20261102/clef-decisions/repo`.

## Scope delivered

New Clef-only leaves plus the minimal root declarations:

- `clef_decision.rs` - config/dtype/request/output contract.
- `clef_decision_weights.rs` - exact Native joint-head tensor schema/casting.
- `clef_decision_plan.rs` - packed request plan and single u32 metadata tail.
- `clef_decision_prepared.rs` - deferred owner retaining that host tail.
- `clef_decision_head.rs` - immutable cold weights, FA4 provider, head owner.
- `clef_decision_kernels.rs` - shared/source-only kernel entry loading.
- `clef_decision_workspace.rs` - capacity-backed device scratch, no request alloc.
- `clef_decision_exec*.rs` - actual prepared dataflow split by phase.
- `clef_decision_attention.rs` - Native separate-Q/K/V projection composition.
- `clef_decision_ops*.rs` - existing cuBLAS/FA4/oxide launch helpers.
- `clef_decision_finish.rs` - result split and Native action probability `1.0`.
- `device/src/clef_decision.rs`,
  `device/src/clef_decision_features.rs` - source-only small device primitives.
- `device/clef_decision_exports.txt` - required export names.

No Qwen3.5/Modern executor, `qwen35_*`, `decision_head*`, router, or other
worker file was edited. The only shared-file edit is the module declaration
block in `backends/oxide/src/lib.rs`.

## Native source of truth

Read completely before implementation:

- `backends/libtorch/cpp/models/decision_models.cpp` `Linear`, `Norm`,
  `Attention`, `Routing`, `FieldDecoder`, `ClefHead`.
- `decision_models.h` request/result contracts.
- `bridge.cpp::weight_dtype` - no Clef F32 override; head follows model dtype.
- Native tests `decision_models_test.cpp` and `tests/decision_parity.rs`.

Root fetched the actual public sidecars. Verbatim CPU fixtures are now in
`backends/oxide/tests/fixtures/clef/Cloudflare--clef[-flash]/`:
`config.json`, `joint_head_config.json`, original `METADATA-PROVENANCE.json`,
and a local hash manifest. Both are dense Qwen3.5, `dtype: bfloat16`, hidden
5120 / 4096; both joint heads are `width=1024`, `heads=16`,
`feedforward=4096`, `layers=4`, `routing_layers=2`. No weight payload was
downloaded or synthesized. CPU tests now load these actual sizes and validate
the 122-tensor Native schema, not only toy dimensions.

## Exact weight contract

`joint_head.safetensors` must contain, for `H=hidden_size`, `W=width`,
`F=feedforward`, `R=routing_layers`, `L=layers`:

- `hidden_norm.{weight,bias}` `[H]`
- `option_summary_norm/field_norm/option_norm.{weight,bias}` `[W]`
- six biasless projections `[W,H]`: memory, question, option_question,
  global, option_context, option_lexical
- `type_embedding.weight` `[3,W]`
- `residual_scorer.0.{weight,bias}` `[W,4W]`/`[W]`;
  `residual_scorer.3.{weight,bias}` `[1,W]`/`[1]`
- `prior_logit_scale`, `joint_logit_scale`, `residual_gate` rank-0 scalars
- per routing layer: three `[W]` affine norms, biased attention
  `[3W,W]`/`[3W]` + `[W,W]`/`[W]`, FFN `[F,W]`/`[F]` + `[W,F]`/`[W]`
- per decoder layer: three norms, self attention, cross attention, two FFN
  linears with the same shapes.

F32/F16/BF16 tensor payloads are cast once to BF16 at cold load, matching
Native `to(model.dtype)`. `float16` serving is rejected explicitly: the public
Clef route implements only BF16 prepared storage, uploads and FA4. This is a
reported pending dtype capability, not a silent F16->BF16 fake.

### DenseMlp bias/activation stages

`helpers/dense_mlp.cpp` was read for the exact Decision-head recipe.
`make_mlp` constructs `DenseMlp(..., MlpActivationRecipe{activation})`; the
default recipe has `epilogue=None`. Because `DenseMlp::forward` only selects a
fused epilogue when `activation_.epilogue` is non-None, Native Decision heads
execute:

1. `at::linear(x, weight, bias)` for each biased projection (fused/addmm bias,
   FP32 accumulation, one BF16 cast);
2. `at::gelu(x, "none")` for `MlpActivation::Gelu` - exact erf GELU, not tanh;
3. `at::linear` for the output projection.

The Clef leaf now uses `linear_biased`: BF16 bias seed + cuBLAS beta=1 FP32
accumulation + one BF16 cast, followed by the existing exact
`infinity_gelu_exact`. It no longer inserts a separate BF16 post-GEMM bias add.
Attention/FFN/QKV/out projection/residual scorer all use this fused-bias path;
biasless projections keep beta=0.

### Cold scalar boundary fix (v2)

The previous parser read raw F32 scalar values and applied CPU `exp`/`sigmoid`.
That bypassed `bridge.cpp::weight_dtype`, which casts every Clef head tensor to
the model BF16 dtype before `ClefHead` evaluates `clamp_max(log(100)).exp()` and
`sigmoid()`. v2 fixes this cold-only path:

1. `scalar_bf16` checks the rank-0 payload byte extent exactly (no unchecked
   indexing/panic), then casts original F32/F16/BF16 to BF16.
2. The three BF16 scalars are uploaded once at cold head load.
3. `infinity_clef_scalar_prep_bf16` (new source-only cold primitive) rounds the
   `log(100)` clamp bound to BF16, clamps, computes exp/sigmoid, rounds each
   result to BF16, then widens exactly to F32.
4. One cold launch/fence/D2H stores the three F32 host values. Request enqueue
   performs no scalar readback/query.

The new primitive is source-pending Root ATen-equivalence gating. No claim is
made that a guessed CPU exp is equivalent. Runtime dtype remains BF16 only.

## Actual dataflow

`Qwen35Work`-style cached capacity -> single H2D u32 metadata tail -> Native
order:

1. affine LayerNorm hidden; memory projection; last-row gather.
2. question/option span means (FP32 mean, one BF16 cast); lexical embedding
   gather and lexical span means.
3. six projections and `question_query + context + lexical` composition.
4. routing layers: query/memory norm, separate Q/K/V, noncausal global FA4,
   out projection+bias+query residual, feed norm, exact-GELU FFN, residual.
5. per-field route scores, softmax-weighted option summary, summary norm,
   global projection, type embedding, field composition.
6. decoder layers: self attention (field rows), cross attention (field queries
   to token memory), exact-GELU FFN, each with Native residual/bias order.
7. final field norm; `normalize(question+global)` anchor; lexical prior;
   option norm; normalized cosine plus `[f, option, f*option, |f-option|]`;
   residual scorer MLP; `prior + (cosine*joint_scale+residual)*gate`.
8. one async F32 logits D2H; `finish_outputs` splits field/option order and
   writes action probability `1.0` for every request.

Warmup is a real synthetic field `{kind:0, question:(0,1), options:[(0,1)]}`,
including one lexical token from the sequence; it is not an option head.

## Ownership / failure contract

- Cold `ClefHead::load` uploads immutable joint weights once.
- `ClefWorkspace::new` is the only device allocation point and is capacity
  based. Prepare/enqueue allocate no GPU memory and never synchronize.
- `ClefPrepared` owns the host metadata tail until the outer completion fence;
  on failed/uncertain drain it retains the plan.
- `ClefWorkspace` Drop drains only when safe; otherwise it forgets every device
  owner.
- Partial enqueue failures leave the prepared/workspace owners retained for
  quarantine, never freed under a possibly-reading stream.
- The outer Engine/Work remains the sole completion/fence authority.

## Verification performed

CPU only, `CUDA_VISIBLE_DEVICES` empty, offline, `-j2`, CPU affinity `16-23`:

```bash
CARGO_TARGET_DIR=/tmp/oxide-docs-parity-20261102/clef-decisions/target-clef \
  cargo check -p infinity-backend-oxide --offline --jobs 2
CARGO_TARGET_DIR=/tmp/oxide-docs-parity-20261102/clef-decisions/target-clef \
  cargo test -p infinity-backend-oxide --lib clef_decision --offline --jobs 2
```

Result: `cargo check` clean; `8 passed; 0 failed`.

Covered: actual Clef/Clef-flash sidecar sizes and 122-tensor schema,
config/dtype validation, exact tensor names/shapes/dtypes, span/field/option
order, invalid spans/kinds/counts, Warmup synthetic field, output/action budget,
action probability `1.0`, field-order split, actual-sidecar schema, and checked
scalar parsing/BF16 first-cast boundaries. No Tensor payload, optimized
build, GPU, FA4/AOT/device compile, query, Torch, Docker, or network was used.

## Root pending integration

1. Add `mod clef_decision;` and `mod clef_decision_features;` to
   `device/src/main.rs`, wrap the 11 functions listed in
   `device/clef_decision_exports.txt` as `#[kernel] infinity_clef_*`
   exports, and add them to the canonical export registry.
2. Route `joint_head_config.json` to `ClefHead` instead of the current explicit
   unsupported error in the Qwen3.5 factory.
3. Add `ClefCapacity`/`ClefWorkspace` to the cached Work owner, and store
   `ClefPrepared` with the request until the existing HostIo/completion fence.
4. Wire the actual normalized BF16 activation and the backbone lexical
   `lm_head.weight`/tied embedding owner into `enqueue_bound`, appending
   `ClefPrepared::metadata()` to the single Work input tail. Use the request's
   existing `HostIoLease` output slice and call `ClefPrepared::finish(...)`
   after completion. The leaf interface is documented in `INTERFACE.md`.
5. The small `clef_*` device primitives (including the cold scalar primitive)
   are **Root-native-primitive pending** until the shared artifact is composed.
   No numeric/math qualification or latency claim is made here.
6. Serial span-mean, generic LayerNorm/FA4/FFN and the remaining kernel math are
   still pending actual Native primitives; only established shared entries are
   reused.

This successor is delivered as `SELECTIVE-v2.patch`; the earlier
`SELECTIVE.patch`/`HANDOFF.md` snapshot remains in place. The original public
provenance fixtures were copied verbatim and are not overwritten.
