# Canonical38 FA4 Root append packet v5

Frozen input: `/tmp/oxide-docs-parity-20261102/fa4-all-model-v3` (source) and
`/tmp/oxide-docs-parity-20261102/fa4-all-model-v4-buildpacket` (preserved).
This packet does not duplicate or modify the source worker.

## Fix over v4

`compile_new_objects` previously called
`verify_source_identity(staged, 100, lock)` before applying
`gemma_sm100_local.patch_interface`. For capability 100 the verifier expects the
post-patch hashes, so a fresh SM100 stage failed. v5 extracts
`stage_patch_and_verify()` and applies the SM100 patch **before** the identity
check, then imports Torch. Non-SM100 behavior is unchanged.

`test_contract.py` now has a mock ordering test proving `patch -> verify` on
SM100, no patch on non-100, and that the helper contains no Torch import.

## CPU-only evidence

`dry-run/logs/summary.json` records 3/3 architectures, jobs=3, 42 new / 210 old,
`inputs_unchanged=true`, zero failures. Per-arch stdout/stderr/report files are
under `dry-run/logs/`. No provider compile, GPU, NVCC or AOT build ran.

## Root one batch (after authorization)

```sh
/tmp/oxide-fa4-build-env/bin/python append_all_canonical38.py \
  --source /tmp/oxide-docs-parity-20261102/fa4-all-model-v3/libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4 \
  --output-root OUTPUT_ROOT --jobs 3 --log-dir OUTPUT_ROOT/logs \
  --runtime-dir /tmp/oxide-fa4-build-env/lib/python3.12/site-packages/nvidia_cutlass_dsl/cu13/lib \
  --ffi-root /tmp/oxide-fa4-build-env/lib/python3.12/site-packages/tvm_ffi \
  --source-freeze /tmp/oxide-docs-parity-20261102/fa4-all-model-v3/SOURCE-FREEZE.json \
  --receipt /tmp/oxide-docs-parity-20261102/FA431-OLD210-HANDOFF.json
```

Exactly 42 new objects, 210 old objects preserved. Full child output goes to
per-arch log files; the console only receives PASS/FAIL and a summary line.
