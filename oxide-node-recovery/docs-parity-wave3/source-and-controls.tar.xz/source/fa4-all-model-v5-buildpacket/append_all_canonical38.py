#!/usr/bin/env python3
"""Root one-batch driver: canonical38 append for SM90, SM100 and SM120.

Runs up to three independent fresh-output jobs in parallel (default and maximum
3), writes per-architecture logs/reports, and proves the frozen source and
baseline inputs are byte-identical before and after. Full child stdout/stderr
goes to files, never to the console.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import pathlib
import subprocess
import sys

DEFAULT_SOURCE = pathlib.Path(
    "/tmp/oxide-docs-parity-20261102/fa4-all-model-v3/"
    "libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4")
DEFAULT_BASELINES = {
    "90": pathlib.Path("/tmp/oxide-fa4-canonical31-sm90-provider-v1"),
    "100": pathlib.Path("/tmp/oxide-fa4-canonical31-sm100-provider-v1"),
    "120": pathlib.Path("/tmp/oxide-fa4-canonical31-sm120-provider-v1"),
}
RUNTIME = pathlib.Path(
    "/tmp/oxide-fa4-build-env/lib/python3.12/site-packages/"
    "nvidia_cutlass_dsl/cu13/lib")
FFI = pathlib.Path(
    "/tmp/oxide-fa4-build-env/lib/python3.12/site-packages/tvm_ffi")
DEFAULT_SOURCE_FREEZE = pathlib.Path(
    "/tmp/oxide-docs-parity-20261102/fa4-all-model-v3/SOURCE-FREEZE.json")
DEFAULT_RECEIPT = pathlib.Path(
    "/tmp/oxide-docs-parity-20261102/FA431-OLD210-HANDOFF.json")


def digest(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bounded_jobs(value: int) -> int:
    return max(1, min(3, value))


def input_hashes(source: pathlib.Path, baselines: dict[str, pathlib.Path]) -> dict:
    source_files = {}
    for path in sorted(source.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            source_files[str(path.relative_to(source))] = digest(path)
    baselines_out = {}
    for sm, root in baselines.items():
        entries = {
            "manifest.json": digest(root / "manifest.json"),
            "libinfinityfa4.so": digest(root / "libinfinityfa4.so"),
        }
        for path in sorted(root.glob("*.o")):
            entries[path.name] = digest(path)
        baselines_out[sm] = entries
    return {"source": source_files, "baselines": baselines_out}


def atomic_write(path: pathlib.Path, payload: str) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(payload)
    import os
    os.replace(temporary, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=pathlib.Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output-root", type=pathlib.Path, required=True)
    parser.add_argument("--runtime-dir", type=pathlib.Path, default=RUNTIME)
    parser.add_argument("--ffi-root", type=pathlib.Path, default=FFI)
    parser.add_argument("--python", type=pathlib.Path, default=pathlib.Path(sys.executable))
    parser.add_argument("--source-freeze", type=pathlib.Path, default=DEFAULT_SOURCE_FREEZE)
    parser.add_argument("--receipt", type=pathlib.Path, default=DEFAULT_RECEIPT)
    parser.add_argument("--jobs", type=int, default=3)
    parser.add_argument("--log-dir", type=pathlib.Path)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    jobs = bounded_jobs(args.jobs)
    source = args.source.resolve()
    output_root = args.output_root.resolve()
    log_dir = (args.log_dir or (output_root / "logs")).resolve()
    log_dir.mkdir(parents=True, exist_ok=True)
    before = input_hashes(source, DEFAULT_BASELINES)

    def run_one(sm: str):
        baseline = DEFAULT_BASELINES[sm]
        output = output_root / f"sm_{sm}"
        command = [
            str(args.python), str(pathlib.Path(__file__).with_name("append_canonical38.py")),
            "--source", str(source), "--baseline", str(baseline),
            "--output", str(output), "--runtime-dir", str(args.runtime_dir),
            "--ffi-root", str(args.ffi_root), "--python", str(args.python),
            "--source-freeze", str(args.source_freeze), "--receipt", str(args.receipt),
        ]
        if args.check_only:
            command.append("--check-only")
        completed = subprocess.run(command, text=True, capture_output=True)
        stem = f"sm_{sm}"
        (log_dir / f"{stem}.stdout.log").write_text(completed.stdout)
        (log_dir / f"{stem}.stderr.log").write_text(completed.stderr)
        record = {
            "architecture": f"sm_{sm}a" if sm in ("90", "100") else f"sm_{sm}",
            "baseline": str(baseline),
            "output": str(output),
            "returncode": completed.returncode,
            "check_only": args.check_only,
            "command": command,
            "stdout_log": str(log_dir / f"{stem}.stdout.log"),
            "stderr_log": str(log_dir / f"{stem}.stderr.log"),
        }
        if completed.returncode == 0:
            try:
                report = json.loads(completed.stdout)
            except json.JSONDecodeError:
                report = None
            record["report"] = report
            if report is not None:
                atomic_write(log_dir / f"{stem}.report.json",
                             json.dumps(report, indent=2) + "\n")
        return record

    records = [None] * 3
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as pool:
        futures = {pool.submit(run_one, sm): index
                   for index, sm in enumerate(DEFAULT_BASELINES)}
        for future in concurrent.futures.as_completed(futures):
            index = futures[future]
            records[index] = future.result()
            record = records[index]
            status = "PASS" if record["returncode"] == 0 else "FAIL"
            print(f"{record['architecture']}: {status} "
                  f"logs={record['stdout_log']}", flush=True)
    after = input_hashes(source, DEFAULT_BASELINES)
    inputs_unchanged = before == after
    failures = [record for record in records if record["returncode"] != 0]
    summary = {
        "schema": "oxide-fa4-canonical38-batch/v1",
        "source": str(source),
        "architectures": len(records),
        "jobs": jobs,
        "new_objects_per_architecture": 14,
        "new_objects_total": 14 * len(records),
        "old_objects_preserved_total": 70 * len(records),
        "check_only": args.check_only,
        "inputs_unchanged": inputs_unchanged,
        "input_hashes_before": before,
        "input_hashes_after": after,
        "failures": len(failures),
        "records": records,
    }
    atomic_write(log_dir / "summary.json", json.dumps(summary, indent=2) + "\n")
    print(f"summary: {log_dir / 'summary.json'} "
          f"({len(records) - len(failures)}/{len(records)} ok, "
          f"{14 * len(records)} new, {70 * len(records)} old, "
          f"inputs_unchanged={inputs_unchanged})", flush=True)
    if failures or not inputs_unchanged:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
