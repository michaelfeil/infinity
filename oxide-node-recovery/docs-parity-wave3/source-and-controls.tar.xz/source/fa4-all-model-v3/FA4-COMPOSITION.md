# Shared FA4 producer composition (canonical38)

Base `09fbb71f27536f99713abc696b749e94e145b735`. Source-only; no GPU, NVCC,
provider link or AOT build was run.

## Prefix

- `profiles.inc`: **38** ordered rows. Modes 0..30 are byte-for-byte the public
  canonical31 rows (published20 / registry24 / canonical26 / canonical31 intact).
- Appended modes 31..37:
  - 31 `qwen2_q14kv2_d64_causal` (jina-code 0.5B)
  - 32 `qwen2_q12kv2_d128_causal` (jina-code 1.5B)
  - 33 `llama_q32kv8_d64_noncausal` (Nemotron rerank 1B v2)
  - 34 `gemma3_global_d256_gqa2`
  - 35 `gemma3_local1024_d256_gqa2`
  - 36 `gemma3_local1024_d128_gqa2`
  - 37 `gemma4_e4b_local1024_d256_gqa4`
- Registry: `canonical38`, `mode_count=38`, `mode_mask=0x3fffffffff`,
  fingerprint `5308427d3c2f149dba100ef7235843df3693b11dd125ccb78288616bd7dcd99d`.
- 76 ordinary FP16/BF16 objects + 8 helper objects = 84 total at full export.

## Deduplication proof

`fa4-uniqueness.py` matches by reduced ratio + exact head_dim + causal + exact
window over 134 saved official configs (`../model-metadata`). Result in
`FA4-UNIQUENESS.json`: 7 unique new modes, 1 deduplicated request, no duplicate
profile keys.

- Rune 26B Q16/KV8 d256 local1024 shares mode 35 with KaLM Gemma3 12B.
- Qwen3 16 Q/8 KV d128 noncausal already shares published `voyage` (mode 3).
- Gemma4 E4B Q8/KV2 d256 local1024 is source-declared by
  `gemma4-full-v2/INTERFACE.md` / E4B admission tests; its official config is
  not present in the local metadata set.
- Gemma3 global d256 is needed by the full-attention layers of the saved
  12B/27B configs; those configs alternate global and local layers.

## Capability contract

- ABI1 / export ABI7 unchanged.
- `infinity_fa4_modes_v1() -> i32` remains, and returns -1 above 31 modes.
- New `infinity_fa4_modes_v2() -> u64` is loaded only when a manifest declares
  more than 31 exports; old manifests keep the old query and load path.
- Host `validate_registry_metadata` accepts the 38-bit mask for canonical38 and
  preserves all old prefix identities.
- Producer `build_contract.py` validates complete legacy19/published20/private23/
  registry24/canonical26/27/28/29/30/31 and canonical38 manifests; partial
extended prefixes are not published.

## Root one-batch compile

```sh
CUDA_VISIBLE_DEVICES= python build_all.py /path/to/infinityfa4 \
  --architectures '90;100;120'
```

This must compile both dtypes for SM90/SM100/SM120, then link with
`-DFA4_REGISTRY_MODE_COUNT=38 -DFA4_REGISTRY_NAMESPACE="canonical38"` as
`build.py` already derives from the manifest registry. The new d256 local
profiles use the generic one-CTA local path; no provider source lock changed.
