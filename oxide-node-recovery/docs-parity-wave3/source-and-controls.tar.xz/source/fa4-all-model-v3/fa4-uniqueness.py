#!/usr/bin/env python3
"""Prove canonical38 FA4 profile uniqueness against saved official configs.

Matching mirrors the host/provider: reduced Q/KV ratio, exact head_dim, exact
causal bit, and exact global/local window. Absolute head counts are ignored.
"""
import json, math, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent
VENDOR = ROOT / "libs/infinity-v3/backends/libtorch/cpp/vendor/infinity_fa4"
META = ROOT.parent / "model-metadata"
sys.path.insert(0, str(VENDOR))
import build_contract  # noqa: E402

def ratio(h, k):
    g = math.gcd(h, k)
    return (h // g, k // g)

def parse_profiles():
    rows = build_contract.parse_profile_rows(VENDOR / "profiles.inc")
    out = []
    for mode, (name, h, k, d, causal, local) in enumerate(rows):
        window = build_contract.canonical_window(mode, name, causal, local)
        out.append({"mode": mode, "name": name, "heads": h, "kv_heads": k,
                    "head_dim": d, "causal": causal, "window": list(window),
                    "ratio": list(ratio(h, k))})
    return out

def matches(p, sig):
    return (list(ratio(p["heads"], p["kv_heads"])) == sig["ratio"]
            and p["head_dim"] == sig["head_dim"]
            and p["causal"] == sig["causal"]
            and p["window"] == sig["window"])

def signature(h, k, d, causal, window):
    return {"heads": h, "kv_heads": k, "head_dim": d, "causal": causal,
            "window": list(window), "ratio": list(ratio(h, k))}

def config_signature(cfg):
    if isinstance(cfg.get("text_config"), dict):
        cfg = cfg["text_config"]
    mt = cfg.get("model_type")
    heads = cfg.get("num_attention_heads")
    kv = cfg.get("num_key_value_heads", heads)
    if not heads or not kv:
        return None
    d = cfg.get("head_dim") or (cfg.get("hidden_size", 0) // heads)
    if not d:
        return None
    causal = cfg.get("is_causal")
    if causal is None:
        if mt in ("llama_bidirec", "bidirectional_pplx_qwen3"):
            causal = False
        elif isinstance(mt, str) and mt.startswith("gemma"):
            # Gemma text is causal; the saved "vision" marker applies to the
            # separate image tower, not the text layer mask.
            causal = cfg.get("use_bidirectional_attention") is not True
        else:
            causal = not cfg.get("use_bidirectional_attention", False)
    window = [None, None]
    sliding = cfg.get("sliding_window")
    maximum = cfg.get("max_position_embeddings")
    if isinstance(sliding, int) and sliding > 0 and (maximum is None or sliding < maximum):
        window = [sliding - 1, 0]
    return {"family": mt, "heads": heads, "kv_heads": kv, "head_dim": d,
            "causal": bool(causal), "window": window, "ratio": list(ratio(heads, kv))}

def main():
    profiles = parse_profiles()
    old31 = profiles[:31]
    official = []
    for path in sorted(META.glob("*/config.json")):
        try:
            cfg = json.loads(path.read_text())
        except Exception:
            continue
        sig = config_signature(cfg)
        if sig is None:
            continue
        sig["model"] = path.parent.name.replace("--", "/")
        official.append(sig)

    requests = [
        ("Qwen2 14/2 d64 causal (jina-code 0.5B)", signature(14, 2, 64, True, [None, None])),
        ("Qwen2 12/2 d128 causal (jina-code 1.5B)", signature(12, 2, 128, True, [None, None])),
        ("Llama 32/8 d64 noncausal (Nemotron rerank 1B v2)", signature(32, 8, 64, False, [None, None])),
        ("Gemma3 16/8 d256 causal global (KaLM 12B/27B full layers)", signature(16, 8, 256, True, [None, None])),
        ("Gemma3 16/8 d256 causal local1024 (KaLM 12B)", signature(16, 8, 256, True, [1023, 0])),
        ("Gemma3 32/16 d128 causal local1024 (harrier 27B)", signature(32, 16, 128, True, [1023, 0])),
        ("Gemma4 E4B 8/2 d256 causal local1024 (source-declared)", signature(8, 2, 256, True, [1023, 0])),
        ("Gemma4 Rune 26B 16/8 d256 causal local1024", signature(16, 8, 256, True, [1023, 0])),
    ]
    results = []
    for label, sig in requests:
        old_hits = [p["mode"] for p in old31 if matches(p, sig)]
        new_hits = [p["mode"] for p in profiles[31:] if matches(p, sig)]
        catalog = [o["model"] for o in official if matches_dict(sig, o)]
        results.append({"label": label, "signature": sig,
                        "old31_matching_modes": old_hits,
                        "new_matching_modes": new_hits,
                        "already_covered_by_old31": bool(old_hits),
                        "official_configs_with_same_signature": catalog})

    def key(p):
        return (tuple(p["ratio"]), p["head_dim"], p["causal"],
                tuple(p["window"]))
    keys = [key(p) for p in profiles]
    duplicates = sorted({k for k in keys if keys.count(k) > 1}, key=str)
    claimed = {}
    unique_modes = set()
    dedup = 0
    for request in results:
        hits = tuple(request["new_matching_modes"]) or tuple(request["old31_matching_modes"])
        if hits and hits in claimed:
            dedup += 1
        if request["new_matching_modes"]:
            unique_modes.update(request["new_matching_modes"])
        claimed.setdefault(hits, request["label"])
    out = {
        "schema": "oxide-fa4-uniqueness/v3",
        "base_commit": "09fbb71f27536f99713abc696b749e94e145b735",
        "profiles_total": len(profiles),
        "old_prefix": 31,
        "new_modes": [p["mode"] for p in profiles[31:]],
        "extended_mask": f"{(1 << len(profiles)) - 1:#x}",
        "official_configs_scanned": len(official),
        "requests": results,
        "unique_new_modes": len(unique_modes),
        "deduplicated_requests": dedup,
        "duplicate_profile_keys": duplicates,
    }
    (ROOT / "FA4-UNIQUENESS.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))
    return 0 if not duplicates else 1

def matches_dict(sig, o):
    return (o["ratio"] == sig["ratio"] and o["head_dim"] == sig["head_dim"]
            and o["causal"] == sig["causal"] and o["window"] == sig["window"])

if __name__ == "__main__":
    sys.exit(main())
