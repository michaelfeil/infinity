# EmbeddingGemma2 full pipeline interface (composed text + media)

Status: source-complete, CPU-gated; Root device build/numeric gates pending.

## One serving path

`OxideBackend` factory detects `model_type = embedding_gemma2`, loads
`Gemma2Text` (text weights, PLE, shared KV, saved 768 projection) and, when the
official config declares 16 vision / 12 audio layers, loads
`MediaHost` + `MediaRuntime` (all tower weights and 24 media kernels). There is
no constructor that recognizes towers and rejects all media.

Per request the single Engine path is:

1. `ExecutableModel::preflight` -> `Gemma2Executor::preflight_media` calls
   `MediaRequest::plan` on the host. This validates `Batch.multimodal` vs
   boundaries, placeholder token ids, absolute spans, grid/mask geometry,
   duplicate rows and total rows before any context bind, arena reservation,
   lease begin or H2D upload.
2. Engine reserves the one `Gemma2Work` text arena and host lease, uploads packed
   input, marks the completion ticket.
3. `Gemma2Executor::enqueue_multimodal` runs `MediaRuntime::prepare` for the
   actual image/audio towers on the same stream/context/cuBLAS handle.
4. Text gathers `embed_tokens * bf16(sqrt(512))`, then
   `MediaRuntime::scatter` writes the projected BF16 rows into the gathered
   `[tokens,512]` state.
5. PLE, 24 text layers (local d256 FA4 + fast d512 Native512 provider), saved
   `embedding_projection` to 768, mean/CLS/last pooling and raw rows complete on
   the same stream.
6. `PreparedMedia` (projected rows, indices, vision/audio scratch and retained
   processor encodings) is moved into `Gemma2Work` with the request's
   `CompletionTicket`. It is dropped only after the exact text-stream completion
   or a proven drain; failed drains retain/quarantine it. Its device bytes are
   charged to `LIVE_ARENA_BYTES`.

## Required Roots/environment

- `INFINITY_OXIDE_KERNEL_MODULE`: one bundle containing the existing exports +
  8 `infinity_gemma2_*` text primitives + 24 `infinity_gemma2_media_*` exports.
- `INFINITY_FA4_ROOT`: FA4 bundle with registry24
  `embedding_gemma2_local256` (H4/KV2/d256 noncausal local 512/512, scale 1.0).
- `INFINITY_HEAD512_ROOT`: cold head512 AOT artifact root (`sm_90`, `sm_100`,
  `sm_120`) built from the vendored
  `backends/oxide/vendor/head512-aot` source. The provider is API2/ABI2,
  BF16 noncausal global H4/KV1/d512, scale 1.0.

No SIMT d512 export and no extra FA4 profile were added.

## Media fixture / metadata

The oxide test fixture `tests/fixtures/embedding_gemma2/config.json` is
byte-identical to the saved official config
(`sha256 b8f1e993...1b5bb3`). `Gemma2TextConfig` admission accepts
`embedding_gemma2` / `embedding_gemma2_text` / `EmbeddingGemma2Model`.

The core processor still reads the official `processor_config.json` (image and
video processor sections plus the audio feature extractor) at the model root;
the saved metadata directory only contains `preprocessor_config.json`, so Root
must use the full official model directory for image/audio serving.
