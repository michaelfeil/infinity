# EmbeddingGemma2 full text+image+audio composition

Status: **SOURCE_ONLY_CPU_GATES_PASS_ROOT_GPU_PENDING**. No GPU, CUDA context,
device/AOT compilation, Torch, Docker or network was used.

- Base: `09fbb71f27536f99713abc696b749e94e145b735`
- Worktree: `work/` (detached)
- Patch: `SELECTIVE.patch` (applies cleanly to the base)
- Evidence: `EVIDENCE.json`
- Frozen inputs: `freeze/text-v1/`, `freeze/media-v1/`
- Final interface: `INTERFACE.md`

## Implemented

One normal factory/Engine/Workspace/request-lease path now owns:

- text: `Gemma2Text` config/weights, PLE, shared KV, saved `embedding_projection`,
  mean/CLS/last pooling and raw 768 rows;
- media: actual Gemma4 16-layer vision and 12-layer conformer audio towers,
  projectors, span planning and packed-row scatter;
- attention: existing FA4 local d256 profile plus the vendored fast
  FlashAttention-2.8.3-derived Native512 AOT provider for d512;
- ownership: media rows/indices/scratch/processor encodings retained on
  `Gemma2Work` until the exact text completion ticket, with live-byte accounting;
- validation: media spans/placeholders/grids run in preflight before context,
  arena, lease or upload work.

## CPU gates

- oxide focused Gemma2: 53 passed, 0 failed, 2 ignored
- backend-core media: 23 passed
- core EmbeddingGemma2 processor: 5 passed
- vendored head512 host library: 14 passed, 1 ignored
- clippy `--lib --tests -D warnings`: pass
- fmt `--all --check`: pass
- `cargo check -p infinity_v3-backend --no-default-features --features oxide`: pass
- patch `git apply --check` against `09fbb71`: pass

## Remaining Root gates

Build the unified SM90/SM100/SM120 kernel bundle and the head512 AOT artifacts,
set the three roots above, load official weights + full processor sidecars, and
compare actual text/image/audio/mixed outputs with Native. Regenerate the audio
fixture with the production decoder. No numeric/performance claim is made.
