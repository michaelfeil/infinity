//! Public Mistral3/Pixtral image preparation, matching Transformers 5.12.1.
//! Adapted from Transformers' Apache-2.0 Pixtral processor; see retained notices.
use super::{
    image::{resize_rgb, QwenImageProcessor},
    media::{MediaBudget, MediaResolver, ResolvedImage},
    MultimodalConfig, PreparedMultimodal,
};
use crate::{
    chat::ChatProcessor,
    input::{ContentPart, ImageDetail, Message, MessageContent, MessageRole},
    tokenization::EncodingInput,
    TextEmbeddingsError,
};
use image::ImageDecoder;
use infinity_v3_backend::{ImagePatches, MultimodalEncoding};
use std::{collections::HashMap, path::Path, sync::Arc};
use tokenizers::{Tokenizer, TruncationDirection};
use tokio::sync::Semaphore;

type Result<T> = std::result::Result<T, TextEmbeddingsError>;
fn invalid(s: impl Into<String>) -> TextEmbeddingsError {
    TextEmbeddingsError::Validation(s.into())
}

#[derive(Clone)]
pub struct Mistral3Processor {
    state: Arc<State>,
    resolver: MediaResolver,
    workers: Arc<Semaphore>,
}
impl std::fmt::Debug for Mistral3Processor {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Mistral3Processor").finish_non_exhaustive()
    }
}
struct State {
    chat: ChatProcessor,
    tokenizer: Tokenizer,
    config: MultimodalConfig,
    budget: MediaBudget,
    max_tokens: usize,
    patch: usize,
    merge: usize,
    edge: u32,
    mean: [f32; 3],
    std: [f32; 3],
    scale: f32,
    ids: [u32; 3],
    prompts: Option<HashMap<String, String>>,
    default_prompt: Option<String>,
}
impl Mistral3Processor {
    pub fn load(
        root: &Path,
        mut tokenizer: Tokenizer,
        max_tokens: usize,
        config: MultimodalConfig,
        prompts: Option<HashMap<String, String>>,
        default_prompt: Option<String>,
    ) -> Result<Self> {
        let read = |name: &str| -> Result<serde_json::Value> {
            serde_json::from_slice(
                &std::fs::read(root.join(name)).map_err(|e| invalid(e.to_string()))?,
            )
            .map_err(|e| invalid(e.to_string()))
        };
        let model = read("config.json")?;
        // Retrieval checkpoints render prefixes as a system message, without
        // instruction-model BOS/EOS wrappers. Keep instruction models unchanged.
        let retrieval = model["is_causal"] == false && model["pooling"] == "avg";
        if !retrieval && default_prompt.is_some() {
            return Err(invalid(
                "Mistral3 instruction models do not support default prompt overrides",
            ));
        }
        let processor = read("processor_config.json")?;
        let image = &processor["image_processor"];
        let patch = model["vision_config"]["patch_size"].as_u64().unwrap_or(0) as usize;
        let merge = model["spatial_merge_size"].as_u64().unwrap_or(2) as usize;
        let edge = image["size"]["longest_edge"]
            .as_u64()
            .and_then(|n| u32::try_from(n).ok())
            .unwrap_or(0);
        if model["model_type"] != "mistral3"
            || patch == 0
            || patch > 64
            || merge == 0
            || merge > 8
            || edge == 0
            || edge > 4096
            || max_tokens == 0
            || max_tokens > u32::MAX as usize
            || config.workers == 0
            || config.workers > 32
            || config.max_images == 0
            || config.max_images > 32
            || config.max_decoded_pixels == 0
            || config.max_decoded_pixels > 16_777_216
            || processor["patch_size"] != patch
            || processor["spatial_merge_size"] != merge
            || image["resample"] != 3
            || image["do_resize"] != true
            || image["do_rescale"] != true
            || image["do_normalize"] != true
            || image["do_convert_rgb"] != true
            || image["do_center_crop"] == true
            || image["do_pad"] == true
        {
            return Err(invalid(
                "Unsupported Mistral3/Pixtral processor configuration",
            ));
        }
        let mut mean = [0.; 3];
        let mut std = [0.; 3];
        for c in 0..3 {
            mean[c] = image["image_mean"][c]
                .as_f64()
                .ok_or_else(|| invalid("Missing Pixtral image mean"))? as f32;
            std[c] = image["image_std"][c]
                .as_f64()
                .ok_or_else(|| invalid("Missing Pixtral image standard deviation"))?
                as f32;
        }
        let scale = image["rescale_factor"]
            .as_f64()
            .ok_or_else(|| invalid("Missing image rescale factor"))? as f32;
        if !scale.is_finite()
            || scale <= 0.
            || mean.iter().any(|x| !x.is_finite())
            || std.iter().any(|x| !x.is_finite() || *x <= 0.)
        {
            return Err(invalid("Invalid Pixtral normalization"));
        }
        if (0..3).any(|c| {
            !((-mean[c]) / std[c]).is_finite() || !((255.0 * scale - mean[c]) / std[c]).is_finite()
        }) {
            return Err(invalid("Pixtral normalization overflows"));
        }
        let mut ids = [0; 3];
        for (i, key) in ["image_token", "image_break_token", "image_end_token"]
            .iter()
            .enumerate()
        {
            let name = processor[key]
                .as_str()
                .ok_or_else(|| invalid("Missing image token"))?;
            ids[i] = tokenizer
                .token_to_id(name)
                .ok_or_else(|| invalid("Missing tokenizer image token"))?;
        }
        if model["image_token_index"].as_u64() != Some(u64::from(ids[0])) {
            return Err(invalid("Image token IDs differ from model config"));
        }
        tokenizer.with_padding(None);
        tokenizer
            .with_truncation(None)
            .map_err(|e| invalid(e.to_string()))?;
        let chat = ChatProcessor::load(root)
            .map_err(invalid)?
            .ok_or_else(|| invalid("Mistral3 requires its native chat template"))?;
        let budget = MediaBudget::new(config.memory_budget_bytes)?;
        let resolver = MediaResolver::new(
            config.allowed_image_hosts.clone(),
            budget.clone(),
            config.max_image_bytes,
            config.download_concurrency,
            config.timeout,
        )?;
        let workers = Arc::new(Semaphore::new(config.workers));
        Ok(Self {
            state: Arc::new(State {
                chat,
                tokenizer,
                config,
                budget,
                max_tokens,
                patch,
                merge,
                edge,
                mean,
                std,
                scale,
                ids,
                prompts: retrieval.then(|| prompts.unwrap_or_default()),
                default_prompt,
            }),
            resolver,
            workers,
        })
    }
    pub async fn prepare(
        &self,
        input: EncodingInput,
        truncate: bool,
        direction: TruncationDirection,
        prompt_name: Option<String>,
    ) -> Result<PreparedMultimodal> {
        let prefix = match prompt_name {
            Some(name) => Some(
                self.state
                    .prompts
                    .as_ref()
                    .ok_or_else(|| {
                        invalid("Mistral3 instruction models do not support prompt_name")
                    })?
                    .get(&name)
                    .cloned()
                    .ok_or_else(|| invalid(format!("Unknown prompt_name: {name}")))?,
            ),
            None => self.state.default_prompt.clone(),
        };
        tokio::time::timeout(
            self.state.config.timeout,
            self.prepare_inner(input, truncate, direction, prefix),
        )
        .await
        .map_err(|_| invalid("Mistral3 preprocessing timed out"))?
    }
    async fn prepare_inner(
        &self,
        input: EncodingInput,
        truncate: bool,
        direction: TruncationDirection,
        prefix: Option<String>,
    ) -> Result<PreparedMultimodal> {
        if input.count_chars() > self.state.max_tokens.saturating_mul(250) {
            return Err(invalid("Conversation exceeds the character limit"));
        }
        let mut messages = match input {
            EncodingInput::Single(text) => vec![Message {
                role: MessageRole::User,
                content: MessageContent::Text(text),
            }],
            EncodingInput::Dual(query, document) => vec![
                Message {
                    role: MessageRole::Query,
                    content: MessageContent::Text(query),
                },
                Message {
                    role: MessageRole::Document,
                    content: MessageContent::Text(document),
                },
            ],
            EncodingInput::Messages(m) => m,
            _ => return Err(invalid("Mistral3 accepts text or native messages")),
        };
        if let Some(prefix) = prefix {
            prepend_retrieval_prefix(&mut messages, prefix)?;
        }
        validate(&messages, self.state.config.max_images)?;
        let mut resolved = Vec::new();
        for message in &mut messages {
            if let MessageContent::Parts(parts) = &mut message.content {
                for part in parts {
                    if let ContentPart::ImageUrl { image_url } = part {
                        resolved.push(
                            self.resolver
                                .resolve(std::mem::take(&mut image_url.url))
                                .await?,
                        );
                    }
                }
            }
        }
        let worker = self
            .workers
            .clone()
            .acquire_owned()
            .await
            .map_err(|_| invalid("Image workers closed"))?;
        let state = self.state.clone();
        let (tx, rx) = tokio::sync::oneshot::channel();
        tokio::task::spawn_blocking(move || {
            let _worker = worker;
            let result =
                state.prepare_cpu(messages, resolved, truncate, direction, || tx.is_closed());
            let _ = tx.send(result);
        });
        rx.await.map_err(|_| invalid("Image worker failed"))?
    }
}

/// Normalize one patch row into the checkpoint's patch-major pixel layout.
///
/// Writes go through iterator chunks so a decoder that disagrees with the planned grid can
/// only skip work, never abort the request.
#[allow(clippy::too_many_arguments)]
fn fill_patch_row(
    row: &mut [f32],
    rgb: &[u8],
    y: usize,
    gw: usize,
    patch: usize,
    stride: usize,
    scale: f32,
    mean: &[f32; 3],
    std: &[f32; 3],
) {
    for (x, block) in row.chunks_exact_mut(3 * patch * patch).enumerate().take(gw) {
        for (channel, plane) in block.chunks_exact_mut(patch * patch).take(3).enumerate() {
            for (py, target) in plane.chunks_exact_mut(patch).enumerate() {
                let offset = (y * patch + py) * stride + x * patch * 3;
                let Some(source) = rgb.get(offset..offset.saturating_add(patch * 3)) else {
                    continue;
                };
                for (slot, value) in target.iter_mut().zip(source.chunks_exact(3)) {
                    let Some(sample) = value.get(channel) else {
                        continue;
                    };
                    *slot = (f32::from(*sample) * scale - mean[channel]) / std[channel];
                }
            }
        }
    }
}

/// Fill `pixels` with `gh` patch rows, using at most `threads` workers.
#[allow(clippy::too_many_arguments)]
fn fill_patches(
    pixels: &mut [f32],
    rgb: &[u8],
    gh: usize,
    gw: usize,
    patch: usize,
    stride: usize,
    scale: f32,
    mean: &[f32; 3],
    std: &[f32; 3],
    threads: usize,
) {
    let row_len = gw * 3 * patch * patch;
    let mut threaded = false;
    if threads > 1 {
        let failed = std::sync::atomic::AtomicBool::new(false);
        let rows_per_thread = gh.div_ceil(threads);
        std::thread::scope(|scope| {
            for (index, chunk) in pixels.chunks_mut(rows_per_thread * row_len).enumerate() {
                let first = index * rows_per_thread;
                let task = move || {
                    for (offset, row) in chunk.chunks_exact_mut(row_len).enumerate() {
                        fill_patch_row(
                            row,
                            rgb,
                            first + offset,
                            gw,
                            patch,
                            stride,
                            scale,
                            mean,
                            std,
                        );
                    }
                };
                // Thread creation can fail under load; retry serially instead of aborting.
                if std::thread::Builder::new()
                    .spawn_scoped(scope, task)
                    .is_err()
                {
                    failed.store(true, std::sync::atomic::Ordering::Relaxed);
                    break;
                }
            }
        });
        threaded = !failed.load(std::sync::atomic::Ordering::Relaxed);
    }
    if !threaded {
        for (y, row) in pixels.chunks_exact_mut(row_len).enumerate().take(gh) {
            fill_patch_row(row, rgb, y, gw, patch, stride, scale, mean, std);
        }
    }
}

fn prepend_retrieval_prefix(messages: &mut Vec<Message>, prefix: String) -> Result<()> {
    if messages.len() != 1 || !matches!(messages[0].role, MessageRole::User) {
        return Err(invalid("Retrieval prompt_name/default prompt requires one user message; use an explicit system message for a custom prefix"));
    }
    messages.insert(
        0,
        Message {
            role: MessageRole::System,
            content: MessageContent::Text(prefix),
        },
    );
    Ok(())
}
fn validate(messages: &[Message], max_images: usize) -> Result<()> {
    if messages.is_empty() {
        return Err(invalid("Conversation must not be empty"));
    }
    let text = |s: &str| {
        if ["[IMG]", "[IMG_BREAK]", "[IMG_END]"]
            .iter()
            .any(|m| s.contains(m))
        {
            Err(invalid("Text must not contain reserved image markers"))
        } else {
            Ok(())
        }
    };
    let mut count = 0;
    for m in messages {
        match &m.content {
            MessageContent::Text(s) => text(s)?,
            MessageContent::Parts(parts) => {
                for p in parts {
                    match p {
                        ContentPart::Text { text: s } => text(s)?,
                        ContentPart::ImageUrl { image_url }
                            if matches!(m.role, MessageRole::User | MessageRole::Document) =>
                        {
                            if !matches!(image_url.detail, None | Some(ImageDetail::Auto)) {
                                return Err(invalid("Image detail must be auto or omitted"));
                            }
                            count += 1;
                            if count > max_images {
                                return Err(invalid("Too many images"));
                            }
                        }
                        _ => return Err(invalid("Mistral3 supports text and user images only")),
                    }
                }
            }
        }
    }
    Ok(())
}
fn dimensions(width: u32, height: u32, edge: u32, factor: usize) -> Result<(u32, u32)> {
    if width == 0 || height == 0 || factor == 0 {
        return Err(invalid("Invalid image dimensions"));
    }
    let ratio = f64::from(width.max(height)) / f64::from(edge);
    let (w, h) = if ratio > 1. {
        (
            (f64::from(width) / ratio).floor() as usize,
            (f64::from(height) / ratio).floor() as usize,
        )
    } else {
        (width as usize, height as usize)
    };
    if w == 0 || h == 0 {
        return Err(invalid("Image aspect ratio produces an empty Pixtral grid"));
    }
    Ok((
        (w.div_ceil(factor) * factor) as u32,
        (h.div_ceil(factor) * factor) as u32,
    ))
}
impl State {
    fn prepare_cpu(
        &self,
        messages: Vec<Message>,
        resolved: Vec<ResolvedImage>,
        truncate: bool,
        direction: TruncationDirection,
        canceled: impl Fn() -> bool,
    ) -> Result<PreparedMultimodal> {
        let mut sizes = Vec::new();
        let mut bytes = 0usize;
        for image in &resolved {
            if canceled() {
                return Err(invalid("Image preprocessing canceled"));
            }
            let mut decoder =
                QwenImageProcessor::decoder(&image.bytes, self.config.max_decoded_pixels)
                    .map_err(invalid)?;
            let (mut w, mut h) = decoder.dimensions();
            let orientation = decoder
                .orientation()
                .map_err(|_| invalid("Invalid image orientation"))?;
            if matches!(
                orientation,
                image::metadata::Orientation::Rotate90
                    | image::metadata::Orientation::Rotate270
                    | image::metadata::Orientation::Rotate90FlipH
                    | image::metadata::Orientation::Rotate270FlipH
            ) {
                std::mem::swap(&mut w, &mut h);
            }
            let (rw, rh) = dimensions(w, h, self.edge, self.patch * self.merge)?;
            // Includes decoded/conversion buffers, resize intermediates, F32 patches and upload copies.
            bytes = bytes
                .checked_add(
                    (w as usize * h as usize) * 12
                        + (rw as usize * rh as usize) * 40
                        + (rw as usize * h as usize) * 4,
                )
                .ok_or_else(|| invalid("Image allocation overflow"))?;
            sizes.push((rw, rh));
        }
        let memory = self.budget.reserve(bytes)?;
        let prompt = self.chat.render_native(&messages, false).map_err(invalid)?;
        if prompt.chars().count() > self.max_tokens.saturating_mul(250) {
            return Err(invalid("Rendered conversation exceeds the character limit"));
        }
        // The template already contains BOS and turn markers.
        let encoding = self
            .tokenizer
            .encode(prompt, false)
            .map_err(|_| invalid("Conversation tokenization failed"))?;
        let mut ids = Vec::new();
        let mut spans = Vec::new();
        let mut image_index = 0;
        for id in encoding.get_ids() {
            if *id != self.ids[0] {
                ids.push(*id);
                continue;
            }
            let (w, h) = *sizes
                .get(image_index)
                .ok_or_else(|| invalid("Image placeholder mismatch"))?;
            let nh = h as usize / (self.patch * self.merge);
            let nw = w as usize / (self.patch * self.merge);
            let total = nh * (nw + 1);
            if ids.len().saturating_add(total) > self.max_tokens {
                return Err(invalid(
                    "Image tokens exceed the input limit; multimodal inputs cannot be truncated",
                ));
            }
            if canceled() {
                return Err(invalid("Image preprocessing canceled"));
            }
            let rgb = resize_rgb(
                &resolved[image_index].bytes,
                w,
                h,
                self.config.max_decoded_pixels,
            )
            .map_err(invalid)?;
            let gh = h as usize / self.patch;
            let gw = w as usize / self.patch;
            let patch = self.patch;
            let stride = w as usize * 3;
            let expected = (w as usize)
                .checked_mul(h as usize)
                .and_then(|pixels| pixels.checked_mul(3))
                .ok_or_else(|| invalid("Resized image dimensions overflow"))?;
            if rgb.len() != expected {
                return Err(invalid(
                    "Resized image length does not match its dimensions",
                ));
            }
            let mean = self.mean;
            let std = self.std;
            let row_len = gw * 3 * patch * patch;
            let mut pixels = vec![0f32; gh * row_len];
            let threads = if gh * row_len >= 1 << 18 {
                std::thread::available_parallelism()
                    .map(|count| count.get())
                    .unwrap_or(1)
                    .clamp(1, 4)
                    .min(gh)
            } else {
                1
            };
            fill_patches(
                &mut pixels,
                rgb.as_slice(),
                gh,
                gw,
                patch,
                stride,
                self.scale,
                &mean,
                &std,
                threads,
            );
            spans.push((
                ids.len(),
                Arc::new(ImagePatches {
                    pixels,
                    grid_thw: [1, gh, gw],
                    patch_dim: 3 * self.patch * self.patch,
                    merge_size: self.merge,
                }),
            ));
            for row in 0..nh {
                ids.resize(ids.len() + nw, self.ids[0]);
                ids.push(if row + 1 == nh {
                    self.ids[2]
                } else {
                    self.ids[1]
                });
            }
            image_index += 1;
        }
        if image_index != resolved.len() {
            return Err(invalid("Image count differs from template placeholders"));
        }
        if ids.len() > self.max_tokens {
            if !spans.is_empty() || !truncate {
                return Err(invalid("Input exceeds the configured token limit"));
            }
            match direction {
                TruncationDirection::Left => {
                    ids.drain(..ids.len() - self.max_tokens);
                }
                TruncationDirection::Right => ids.truncate(self.max_tokens),
            }
        }
        if ids.is_empty() {
            return Err(invalid("Empty model input"));
        }
        let positions = (0..ids.len() as u32).collect::<Vec<_>>();
        Ok(PreparedMultimodal {
            input_ids: ids,
            media: Arc::new(MultimodalEncoding {
                images: spans,
                audios: vec![],
                position_ids: std::array::from_fn(|_| positions.clone()),
                memory: Some(Arc::new(memory)),
            }),
        })
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    #[ignore = "Generate scripts/nemotron-embed-parity.py fixtures and set NEMOTRON_REFERENCE and NEMOTRON_MODEL"]
    async fn nemotron_preparation_matches_transformers() {
        let root = std::path::PathBuf::from(std::env::var("NEMOTRON_REFERENCE").unwrap());
        let model = std::path::PathBuf::from(std::env::var("NEMOTRON_MODEL").unwrap());
        let prompts: serde_json::Value = serde_json::from_slice(
            &std::fs::read(model.join("config_sentence_transformers.json")).unwrap(),
        )
        .unwrap();
        let load = |default| {
            Mistral3Processor::load(
                &model,
                Tokenizer::from_file(model.join("tokenizer.json")).unwrap(),
                2048,
                MultimodalConfig::default(),
                Some(serde_json::from_value(prompts["prompts"].clone()).unwrap()),
                default,
            )
            .unwrap()
        };
        let processor = load(None);
        let cases: Vec<serde_json::Value> =
            serde_json::from_slice(&std::fs::read(root.join("reference.json")).unwrap()).unwrap();
        for case in &cases {
            let input = if let Some(text) = case["input"].as_str() {
                EncodingInput::Single(text.into())
            } else {
                EncodingInput::Messages(serde_json::from_value(case["input"].clone()).unwrap())
            };
            let prepared = processor
                .prepare(
                    input,
                    false,
                    TruncationDirection::Right,
                    case["prompt_name"].as_str().map(str::to_owned),
                )
                .await
                .unwrap();
            let ids: Vec<u32> = serde_json::from_value(case["input_ids"].clone()).unwrap();
            assert_eq!(prepared.input_ids, ids, "{} tokens", case["name"]);
            assert_eq!(
                prepared.media.images.len(),
                case["pixels"].as_array().unwrap().len()
            );
            for ((_, image), pixels) in prepared
                .media
                .images
                .iter()
                .zip(case["pixels"].as_array().unwrap())
            {
                let expected: Vec<f32> = serde_json::from_value(pixels.clone()).unwrap();
                assert_eq!(image.pixels.len(), expected.len());
                let error = image
                    .pixels
                    .iter()
                    .zip(expected)
                    .map(|(a, b)| (a - b).abs())
                    .fold(0f32, f32::max);
                assert!(error < 1e-5, "{} pixels: {error}", case["name"]);
            }
        }
        // A configured default prefix must produce the same tokens as an
        // explicit per-request name; explicit system prefixes stay unambiguous.
        let query = cases.iter().find(|case| case["name"] == "query").unwrap();
        let default = load(Some("query: ".into()));
        let prepared = default
            .prepare(
                EncodingInput::Single(query["input"].as_str().unwrap().into()),
                false,
                TruncationDirection::Right,
                None,
            )
            .await
            .unwrap();
        assert_eq!(
            serde_json::to_value(prepared.input_ids).unwrap(),
            query["input_ids"]
        );
        assert!(processor
            .prepare(
                EncodingInput::Single("hello".into()),
                false,
                TruncationDirection::Right,
                Some("missing".into())
            )
            .await
            .is_err());
    }
    #[test]
    fn patch_rows_match_serial_layout() {
        let patch = 2usize;
        let gw = 3usize;
        let gh = 5usize;
        let w = gw * patch;
        let h = gh * patch;
        let rgb: Vec<u8> = (0..w * h * 3).map(|i| (i * 37 % 251) as u8).collect();
        let scale = 0.00392156862745098f32;
        let mean = [0.5f32, 0.5, 0.5];
        let std = [0.5f32, 0.5, 0.5];
        let row_len = gw * 3 * patch * patch;
        let mut expected = vec![0f32; gh * row_len];
        for y in 0..gh {
            for x in 0..gw {
                for c in 0..3 {
                    for py in 0..patch {
                        for px in 0..patch {
                            let index = ((y * patch + py) * w + x * patch + px) * 3 + c;
                            expected[y * row_len + (x * 3 + c) * patch * patch + py * patch + px] =
                                (rgb[index] as f32 * scale - mean[c]) / std[c];
                        }
                    }
                }
            }
        }
        for threads in 1..=4 {
            let mut pixels = vec![0f32; gh * row_len];
            fill_patches(
                &mut pixels,
                &rgb,
                gh,
                gw,
                patch,
                w * 3,
                scale,
                &mean,
                &std,
                threads,
            );
            assert_eq!(pixels, expected, "threads={threads}");
        }
    }

    #[test]
    fn retrieval_prefix_preserves_content_and_rejects_ambiguous_roles() {
        let content = serde_json::json!([
            {"type":"text","text":"a document"},
            {"type":"image_url","image_url":{"url":"data:image/png;base64,..."}}
        ]);
        let mut messages: Vec<Message> = serde_json::from_value(serde_json::json!([
            {"role":"user","content":content}
        ]))
        .unwrap();
        prepend_retrieval_prefix(&mut messages, "passage: ".into()).unwrap();
        assert!(matches!(messages[0].role, MessageRole::System));
        assert_eq!(
            serde_json::to_value(&messages[1]).unwrap()["content"],
            content
        );
        // A prefix must not replace an explicit system prefix or turn a
        // reranking pair into an embedding conversation.
        for json in [
            serde_json::json!([]),
            serde_json::json!([{"role":"system","content":"custom"},{"role":"user","content":"a"}]),
            serde_json::json!([{"role":"query","content":"a"},{"role":"document","content":"b"}]),
        ] {
            let mut messages: Vec<Message> = serde_json::from_value(json).unwrap();
            assert!(prepend_retrieval_prefix(&mut messages, "query: ".into()).is_err());
        }
    }
    #[test]
    fn pixtral_resize_ceil_and_budget_validation() {
        assert_eq!(dimensions(37, 65, 1540, 28).unwrap(), (56, 84));
        assert_eq!(dimensions(2000, 1000, 1540, 28).unwrap(), (1540, 784));
        assert!(dimensions(0, 10, 1540, 28).is_err());
        assert!(dimensions(16_000_000, 1, 1540, 28).is_err());
    }
    #[test]
    fn rejects_reserved_markers_and_unsupported_parts() {
        for json in [
            serde_json::json!([{"role":"user","content":"[IMG]"}]),
            serde_json::json!([{"role":"assistant","content":[{"type":"image_url","image_url":{"url":"data:image/png;base64,"}}]}]),
            serde_json::json!([{"role":"user","content":[{"type":"video_url","video_url":{"url":"https://example.com/v"}}]}]),
        ] {
            let m: Vec<Message> = serde_json::from_value(json).unwrap();
            assert!(validate(&m, 4).is_err());
        }
    }
}
