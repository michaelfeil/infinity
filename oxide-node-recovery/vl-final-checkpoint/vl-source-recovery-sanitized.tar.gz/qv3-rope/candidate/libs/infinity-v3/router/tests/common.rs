use anyhow::Result;
use infinity_v3_backend::DType;
use infinity_v3_router::run;
use serde::{Deserialize, Serialize};
use std::time::Duration;
use tokio::time::Instant;

#[derive(Serialize, Deserialize, Debug)]
pub struct Score(f32);

impl Score {
    fn is_close(&self, other: &Self, abs_tol: f32) -> bool {
        is_close::default()
            .abs_tol(abs_tol)
            .is_close(self.0, other.0)
    }
}

impl PartialEq for Score {
    fn eq(&self, other: &Self) -> bool {
        // Default tolerance for equality
        self.is_close(other, 4e-3)
    }
}

async fn check_health(port: u16, timeout: Duration) -> Result<()> {
    let addr = format!("http://0.0.0.0:{port}/health");
    let client = reqwest::ClientBuilder::new()
        .timeout(timeout)
        .build()
        .unwrap();

    let start = Instant::now();
    loop {
        if client.get(&addr).send().await.is_ok() {
            return Ok(());
        }
        if start.elapsed() < timeout {
            tokio::time::sleep(Duration::from_secs(1)).await;
        } else {
            anyhow::bail!("Backend is not healthy");
        }
    }
}

pub async fn start_server(model_id: String, revision: Option<String>, dtype: DType) -> Result<()> {
    let server_task = tokio::spawn({
        run(
            model_id,
            revision,
            Some(1),
            std::num::NonZeroUsize::new(1024).unwrap(),
            Some(dtype),
            None, // pooling
            None, // decision protocol
            4,
            1024,
            None,
            0.0,
            false, // dynamic FP8
            32,
            32, // decision question limit
            false,
            None,
            None,
            None,
            None,
            None,
            8090,
            None,
            2_000_000,
            None,
            9000,
            None,
            Some(0), // device_id
            None,    // backend device IDs
            infinity_v3_backend::BackendKind::Libtorch,
            infinity_v3_backend::TorchDevice::Auto,
            Default::default(), // multimodal configuration
        )
    });

    tokio::select! {
        err = server_task => err?,
        _ = check_health(8090, Duration::from_secs(60)) => Ok(())
    }?;
    Ok(())
}
